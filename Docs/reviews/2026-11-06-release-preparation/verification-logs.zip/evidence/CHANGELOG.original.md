# Changelog

项目变更记录。未发布内容集中在 `[Unreleased]`，提交前应同步更新用户可见行为和验证入口。

## [Unreleased]

### 改动

- **修复 MoviePilot 换服漏加载与音频中断后的误恢复播放**（2026-11-06）。订阅加载按会话修订和请求代次隔离，切服后立即启动新请求，旧请求不能覆盖列表、错误或加载状态；正常取消不再显示为失败。系统明确暂停时先清除中断恢复意图，已暂停的播放保持暂停，打开中的播放也会记住暂停要求。新增 11 个回归场景，双端 App 全量通过，验证入口见 `Docs/reviews/2026-11-06-release-followup-fixes/FIX_REPORT.md`。

- **修复跨服务器图片缓存串读，准备 0.2.3**（2026-11-06）。图片缓存身份纳入服务器类型、稳定服务器 ID 与账号；同服换地址和 token 轮换继续复用，缺少服务器 ID 时按档案与入口保守隔离。URLCache、内存、字节缓存与图片任务使用同一上下文；登录页只恢复本档案的 v2 身份，无法确认归属的旧缓存重新下载。回归覆盖相同 UserId/图片路径跨服、同源不同服、重启、头像、登录海报墙与迁移边界，验证入口见 `Docs/reviews/2026-11-06-image-isolation/FIX_REPORT.md`。

- **修复 MoviePilot 会话改绑、迟到登录与多源字幕/精确续播**（2026-11-06）。旧请求固定服务器与会话，换服后停止重试；登录验证后原子提交，失败保留原会话，迟到响应与通知不能覆盖新登录。外挂字幕严格使用当前媒体源并隔离服务器/源/轨道缓存；旧批次不能干扰新批次。明确续播位置支持 1–29 秒，非法数值不进入内核。详情已看回写与取消建库等待遵守会话边界，保留 #96 的独立进度记录与冲突保护。

- **固定排队末次进度的操作时间**（2026-11-06）。等待建库或前一写回期间完成的新已看/未看操作，不会再被旧播放快照撤销；仓储保留较新磁盘记录的确认边界，后续服务端更新正常接管。增加排队、跨会话和内存/磁盘回归。MetadataKit 全量 299 项通过；macOS 899 项通过、19 项条件跳过，iOS 920 项通过、3 项条件跳过，新增 App 排队回归两端均正常完成。

- **升级 liberika 内核到 v0.3.4**（2026-11-06）。同步官方 C 头、Swift 版本和资产 SHA-256，适配打开选项的起播位置字段；包含密集 CJK 字幕 glyph atlas 超过 Metal 纹理上限的上游修复。渲染回归等待异步上采样构建完成并验证实际输出，验收记录见 `Docs/reviews/2026-11-06-kernel-upgrade/UPGRADE_REPORT.md`。

- **修复淘汰后的末次写回和分集失败回退的状态反转**（2026-11-06）。元数据或纯内存条目淘汰后，退出播放仍采用独立进度中最新的已看/未看状态，再合并末次位置；保留完整会话元数据及最新进度字段。分集刷新失败时，条目内存与详情采用同一份最终合并结果。新增两方向、LRU、跨租户、清缓存和失败/成功对照回归；验证统一使用 App 的依赖锁；该轮 MetadataKit 全量 294 项通过，两端 App 全量测试及实际 Release 打包通过。

- **补齐进度保护在显式标记与自动淘汰时的边界**（2026-11-06）。已看/未看成功后仍拦截先发旧回包，后发读取正常接管；较旧的排队末次写入不能撤销新操作。SQLite v4 增量迁移保留进度记录并解除元数据淘汰的级联删除，离线首页和分页可恢复独立进度；确认后的记录释放大段元数据，用户主动清缓存则同时清除磁盘和内存保护。新增迁移、并发、淘汰与 App 接线回归，设计与冲突规则见 `Docs/MEDIA-DATA-PLANE.md`。

- **修复 Stopped 上报超时后首页和磁盘进度被旧响应覆盖**（2026-11-06）。末次位置在 SQLite v3 增量表中保存本地保护记录；首页、详情、分集和分页的网络写入在同一事务内合并并返回一致的进度。读到后发请求确认的位置后恢复服务端更新，确认前已发出的迟到请求仍受保护；主动倒退位置、跨租户同 ID、播完后服务端已看/清零和显式已看/未看均有回归覆盖。空继续观看列表可保留尚未确认的本地条目，已有缓存迁移保留原内容。App 的生产默认 5 秒超时路径与正常上报对照已加入 `StoppedProgressRegressionTests`。

- **修复媒体仓储与播放进度的一致性**（2026-11-05）。冷启动并发读取复用同一仓储，等待建库期间切服或登出不会复活旧会话；退出播放的末次进度固定写回原租户，收尾任务等待本地进度和远端上报，重复收尾不重复记录。首页与分页从磁盘恢复时批量合并条目表的最新进度，保留列表顺序与其他元数据。新增会话时序和持久化回归测试，设计说明见 `Docs/MEDIA-DATA-PLANE.md`。

- **修复详情页返回后标签栏晚一步闪现**（2026-11-05）。iPhone 详情页不再通过局部 `toolbarVisibility` 等待返回后恢复标签栏，而是在实际导航页的出现/离开时，将系统标签栏动画登记到导航转场协调器；取消交互式返回时恢复来源页的隐藏状态。五个 Tab 根页显式恢复可见状态，支持详情栈保留期间切换分区；iPad 详情继续显示标签栏。新增导航页标记、普通返回、缩放返回和取消交互返回 4 项用例，并扩展生产 AppShell 集成用例覆盖详情进出与跨 Tab 切换。缩放返回探针中，标签栏约 77 ms 开始恢复，导航约 878 ms 完成。相关 iPhone 测试 14 项通过，iPad 导航与生产外壳集成测试 5 项通过。

- **恢复独立搜索按钮，并修复首页头像偶尔未去色**（2026-11-05）。iOS 27 的搜索 Tab 显式使用 `TabRole.prominent`，iOS 26 保留 `.search`，搜索页继续使用原有常驻输入框；新角色与 `UITab.selectedImage` 同时加编译器版本判断，兼容 CI 的 Xcode 26 SDK（旧 SDK 通过 `UITabBarItem` 维护选中图片）。头像桥接同时维护 `UITab` 图片源与 `UITabBarItem`，通过图片、栏项重建和选中变化的通知合并回写，替代启动后几次固定延迟补写；两态图片的颜色由实际选中的分区决定，避免搜索展开时系统复用上一页的 `selectedImage` 仍显示彩色头像。增加 5 条桥接回归用例与生产 `AppShellView` 的搜索/头像集成用例。使用 Xcode 27.1 SDK 编译，iPhone 17 Pro 与 iPad Pro 11-inch (M5) 的 iOS 26.3 模拟器各 21 项相关测试通过，macOS Debug 编译通过；iOS 27 的 `.prominent` 分支已编译验证，随后安装到 iOS 27.2 的 iPhone 17 并通过启动检查。

- **CI 测试门禁拆成三个并行 job：墙钟 35 分 09 秒 → **9 分 02 秒 ~ 12 分 17 秒**（`BLD-09`）**
  - **现场（实测 #86 `41676015501`，14:46:48 → 15:21:15）**：一个 job 里三步**串行** —— macOS AppTests **357 s**、iOS 模拟器 **805 s**、SwiftPM 包 **706 s**，加准备（Erika 16 s + SwiftPM 缓存 64 s + iOS 缓存 27 s + Seed/Cache release 98 s）与收尾约 70 s ⇒ **34 分 27 秒**。三条缓存**全部命中**，所以慢的不是拉依赖。
  - **iOS 那 805 s 的构成（按日志时间戳）**：`simctl bootstatus` 预热 **101 s** → `xcodebuild test` 的编译段（16:46:44 → 16:53:46）**422 s** → 用例 ~112 s → 收尾 ~30 s。**命中缓存仍要编译 422 s**（PR 改了源码，增量重编 App target + 测试 target 是固有成本），因此这一刀不是「再修缓存」，而是**让三步同时跑**：三步产物互不重叠（macOS 用 `.local-build/ci-test`、iOS 用 `.local-build/ci-test-ios`、包测试用 `Packages/*/.build`），串行只是沿用了「一个 job」的历史形状。
  - **拆法**：`macos` → `macos-apptests` / `ios-apptests` / `spm-packages`。三个 job 各自 checkout + `Resolve Erika version` + `setup-erika` + 自己的缓存，**不再有跨步依赖**；`Seed/Cache release SPM checkouts (main only)` 只留在 `macos-apptests`（跑三份会互相顶掉 `spm-pkg-v1` 同一个 key）。
  - **缓存 key 必须分开（这条是正确性，不是优化）**：`mac-dd-v1`（path 仅 `.local-build/ci-test`，新增）、`spm-test-v2`（path 收窄为 `Packages/*/.build`；旧 `spm-test-v1` 是 `.local-build/ci-test` + `Packages/*/.build` 两条路径合在一条，实测 2665 MiB）、`ios-dd-v1` 不变。同一个 key 配不同 path 时 `actions/cache` 的「精确命中就不重写」语义会让**后写的内容被永久丢弃**（日志只有一句 warning）。
  - **实测四轮（拆的是同一个 PR #88）**：

    | | 墙钟（三 job 并发跨度） | macOS | iOS | SwiftPM | 关键路径 |
    |---|---|---|---|---|---|
    | 拆分前（`41676015501`） | **35m09s** | 357 s | 805 s | 706 s | 三步**串行** |
    | 拆分后第 1 轮（缓存全冷） | **17m00s** | 8m14s | 14m24s | 16m59s | SwiftPM |
    | 拆分后第 2 轮（缓存全命中） | **11m34s** | 4m01s | 11m34s | 4m21s | iOS |
    | 第 3 轮（`hashFiles` 改完，`41773180683`） | **9m02s** | 3m33s | 9m02s | 4m10s | iOS |
    | 最终树 `6f730ff`（`41774360339`） | **12m17s** | 3m57s | 12m17s | 4m29s | iOS |

    **相对拆分前的 35m09s，暖态收益是 -65%~-74%**（`9m02s` → -74%、`12m17s` → -65%；单次运行的实际值就落在 9m02s ~ 12m17s 这个区间里，波动来自 iOS 模拟器预热与 runner 冷热，两轮之间差的 5m26s 则是首次造缓存的一次性成本）。第 2 轮三条缓存都是 `Cache hit occurred on the primary key …, not saving cache`（说明命中后不再重复写），无一条 `Unable to reserve cache` 告警。后续同类运行实测在 **9m02s ~ 12m17s** 之间波动，**关键路径始终是 iOS 步**（`41773180683` = 9m02s / iOS 9m02s；`41774360339` = 12m17s / iOS 12m17s；两轮 macOS 与 spm 都只要 3m33s~4m29s，三条缓存均精确命中）——差异来自 iOS 模拟器预热与 runner 冷热，不是流程问题。
  - **「用旧 key 兜底一轮」这个想法是错的，已撤回（实测 + 源码核实）**：原计划让 `spm-test-v2` 的 `restore-keys` 带 `spm-test-v1-`，从旧条目里拿暖的 `Packages/*/.build`。**实测命中不了**——首轮日志打印 `Cache not found for input keys: …spm-test-v1-macOS-`，而同期 path 没变的 `ios-dd-v1` 能正常按前缀命中 main 上的旧条目，证明不是「PR 读不到 main」的问题。**根因是缓存条目的身份是 `(key, version)` 二元组，而 `version = sha256(paths|compression|salt)`**（actions/toolkit `getCacheVersion`，源码核实）：旧条目 path 是 `.local-build/ci-test` + `Packages/*/.build` 两条，新条目只剩一条 ⇒ **version 不同 ⇒ 旧条目根本不可见**，key 前缀能对上也没用。⇒ 两条新缓存的 `spm-test-v1-` fallback 已删除，注释里写明不要再加；冷启动就是拆分的必然成本，不能靠 fallback 绕过。
  - **顺带扒出一个既有隐患并顺手治好**：同一个 `hashFiles('**/Package.resolved')` 表达式，在旧 workflow（单 job 串行）里**一次运行会算出三个不同的值**——`Cache SwiftPM builds` 求值 `9dfe529d`、`Cache iOS DerivedData` 求值 `19b319d7`、`Cache release SPM checkouts` 求值 `fae8c559`。因为 `hashFiles` 的匹配范围包含 `.local-build/` 里被上一步 restore 出来的 `SourcePackages/checkouts/*/Package.resolved`，**缓存 key 因此依赖「前面几步在磁盘上留下了什么」**，而不是只依赖锁文件。拆成三个 job 后三条 key 都只在 checkout 之后、任何 restore 之前求值，实测三条**全部是 `9dfe529d`**。⇒ 这个隐患不再存在。
  - **额度**：拆分后条目 = `erika` 838 + `release` 741 + `ios-dd` 724 + `spm-test-v2` 1945 + `mac-dd-v1` 745 MiB ≈ **4.9 GiB / 10 GiB**（拆分是**分区**不是复制，总量与拆分前相当）。旧 `spm-test-v1`（2665 MiB）已无用途，可直接删。
  - **`hashFiles` 改成显式路径（7 处：`test.yml` ×4、`release.yml` ×3），根治「key 依赖磁盘上留了什么」**：原写法 `hashFiles('**/Package.resolved')` 会**遍历进点开头目录**——`@actions/glob` 的 minimatch 选项是 `dot: true`（源码核实），所以 `**` 能走 `.local-build/` 与 `.build/`。改成两条显式路径后，匹配范围只可能是那 4 个被 git 跟踪的锁文件，与 restore / resolve 无关。
    - **机制从【复核】升级为【实测】**：`_hashFiles` 只把各文件内容的 sha256 **按 glob 枚举顺序串接**再哈希一次，**不含路径**（源码核实）。本地用那 4 个文件的 sha256 串接，**逐位复现出新鲜的 `9dfe529d`**（顺序：`OcPlayer.xcodeproj/…` → `BangumiKit` → `JellyfinKit` → `MetadataKit`）；而 24 种排列**都无法**复现 `19b319d7` / `fae8c559` ⇒ 后两个必然包含了额外文件，只能来自 restore / resolve 落盘的东西。（此前用 Python `glob` 复现失败，是因为 Python 默认跳过点开头目录——与 `@actions/glob` 语义不同，所以那次「验不出」并不构成反证。）
    - **这不是未来风险，是已经发生的错配**：release 工作流自己算的是新鲜值 `9dfe529d`，而 `test.yml` 的播种步骤在 `-resolvePackageDependencies` **之后**求值、算成 `fae8c559` ⇒ 实测 `40065759850` 里 release 的 `spm-pkg-v1` **从来没有精确命中过**，一直靠 `restore-keys` 前缀兜底（`Cache hit for restore-key: spm-pkg-v1-macOS-fae8c559…`）。换成显式路径后两边都只依赖那 4 个文件，**播种与读取终于算同一个 key**。
    - **预测已在 CI 上验证（run `41773180683`）**：三条「checkout 后立刻求值」的 key 改完后**仍是 `9dfe529d`**，且全部 `Cache hit occurred on the primary key …, not saving cache`——即**这次改动没有让任何缓存失效**（`mac-dd-v1` / `ios-dd-v1` / `spm-test-v2` 全部精确命中，墙钟 9m02s）。`spm-pkg-v1` 只在 main 上跑（`Seed/Cache release` 有 `if: github.ref == 'refs/heads/main'`），**本次 PR 无从验证**；按预测它会从 `fae8c559` 变成 `9dfe529d`，旧条目（741 MiB）作废一次，**这正是要修的错配本身**——合并后第一次 main 运行才能看到该验证，届时以日志里的实际 key 为准。

  - **顺带补了一个既有缺口**：旧的 `Upload test logs on failure` 只传 `.local-build/ci-test/Logs`（macOS 那个目录），**iOS 步失败时没有任何 artifact**（它的 xcresult 在 `ci-test-ios`）。现在按 job 分开传：`test-logs-macos` / `test-logs-ios`。
  - **覆盖没有缩水（逐条核过，不是只看数）**：第 2 轮 macOS `862 条用例 / 843 passed / 0 failed / 19 skipped`，iOS `Executed 854 tests, with 3 tests skipped and 0 failures`——与拆分前 `41676015501` 的 iOS 数字**逐字相同**；macOS 我用用例名做集合 diff，两棵树相同（初次比对疑多一条 `PlayerVideoColorLabelTests.testTransferLabels`，复核是基线日志行被截断造成的假阳性）。三条测试命令（`xcodebuild`×2、`swift test`×11 含 ErikaKit 的 7 条 `--skip`）与拆分前**逐字一致**。
  - **未做**：把 `spm-packages` 再按包拆细——暖态关键路径始终是 iOS（9m02s ~ 12m17s 全是它在决定墙钟），再拆包测试不减少墙钟，只增加缓存条目与 setup 开销。真正能再压的是 iOS 那 388 s 编译与 132 s 预热（`BLD-08` 的观测点继续保留）。

- **修「打开详情页会闪一下另一张背景图，像是出来后马上被 tmdb 替代了」——不是数据层给了两份数据，是渲染顺序把「TMDB 优先」这一条规则的两个阶段都画了出来**
  （用户口径：「他现在打开还是会有一瞬间闪另外一张背景图，也是赛博朋克的，感觉是出来后马上被tmdb的替代了一样，像是之前重构媒体数据之前的逻辑」）
  - **实测现场**（Debug 深链 `OCPLAYER_START_ROUTE=detail.series` + 视图探针，`赛博朋克：边缘行者`）：一次进场出现**三张**背景图，URL 依次为 ① 氛围池兜底图（`Items/8fe73569…`）→ ② 本条目服务端 backdrop（`Items/082528dc…`）→ ③ `image.tmdb.org/t/p/original/3UbHGmu9…`；②→③ 间隔 **293 ms**，与数据层独立复现三次的 293/475/445 ms 一致。关键排除项：**三张都命中本地 blob 缓存、三个会话 TMDB 网络请求 = 0** ⇒ 不是图加载慢、不是缓存失效，是 `tmdbOverlay` 读回那一瞬 URL 被**二次决议**。
  - **根因（两层）**：① TMDB 图片策略默认「优先顶替服务端已有的图」（`TMDbPreferences.replaceExistingImages` 默认 true，产品口径是「填了 key 就是想完整补全」），而 `overlay(for:)` 是 async（虽只查库不发网络），旧代码把它排在 `load()` 末尾 ⇒ 详情内容先按服务端图上屏、随后被 TMDB 图顶掉；② `DetailView.task` 是 `attach(app)`（同步）→ `await load()`，而解析在 `load()` 第一句 ⇒ 「app 已挂上、overlay 未读回」之间还有一帧会把②画出去，**只做「解析后锁定」堵不住这一帧**。
  - **修法**：新增纯值状态机 `BackdropSourceLatch`——**解析完成前一律不给本条目的图**（视图回落氛围池兜底图，即既有的「背景延续」设计：同 URL、内存缓存命中、观感连续），**解析后按宽度档锁定第一张非空图**、本页不再因迟到数据改口；`load()` 第一句改为先 `await resolveBackdropSource()` 再预热。迟到的 TMDB 数据照常落库，**下次进页**第一帧就是 TMDB 那张。锁定/解析绝不能写在 body 求值路径上（`backdropTarget` 必须是纯函数），否则 `@Observable` 状态写入会与「视图读取 → 重新求值」形成自激环 —— 本仓实测过一次详情页死循环、CPU 100%、窗口出不来，成因与修法都记在 `DetailViewModel.backdropTarget(width:)` 的注释里。
  - **修后判据（与直觉不同，写清楚免得下次误判）**：正确端点是**去重 2 张（①池兜底 → ③最终图）、②一帧都不出现**，不是 1 张。页面在详情落地前本来就该显示池子那张（背景延续），把它算成「闪」会得出错误结论；真正要消灭的是「**同一条目的两张不同图**先后上屏」。
  - **反向验证**：`BackdropSourceLatch` 6 条用例全绿；审查用变异实验逐条打穿（拆掉「解析前返回空」→ `testReturnsEmptyBeforeResolved` 红；取消锁定 / nil 也入锁 / 忽略宽度档 / 凭证锁成 nil → 对应 4 条红），6 条**无一摆设**。`CollectionDetailTests` 补接线回归：解析前必须扣住背景图、解析完成后立刻给出最终图、迟到详情落地能补锁且**之后不再改口**、**取详情那一刻**（`StubMediaServer.onItemCall` 观测点）解析已完成且 `backdropTarget` 已是最终那张（把 `resolveBackdropSource()` 挪到取数之后即红）。原有 4 条背景来源用例（服务端优先 / 成员兜底 / 无图 / 非合集不借用）改为先解析再断言，保持原意，并在文件里写明「为什么解析这一步属于被测行为」。
  - **没动的**：TMDB 图片策略默认值（产品口径，另开关可关）、`ImagePipeline` / `RemoteImage` / `ImageArrivalScheduler`（三者行为正确，不背这个锅）、PlaybackKit 与 MetadataKit。
  - **已知代价**：`resolveBackdropSource()` 解析后若本机既无服务端 backdrop tag 也无 TMDB 缓存，本页会一直停在氛围池兜底图（正确行为），需要下一次进页、或详情/overlay **迟到落地时补锁**才出本条目图 —— 补锁挂在那两个既有状态变更点（`detail.didSet` / `tmdbOverlay.didSet`），不在 body 路径上。

- **重构媒体数据面：把「SQLite 写穿 + App 内存详情快照 + 视图分页表 + 各处直连服务器」收敛成一个 `MediaRepository`，图片层补上「槽位 + 双键代次 + 帧到达调度」**
  （用户口径：「对 OcPlayer 进行大改，把媒体数据管理混乱的情况修好」）
  - **问题事实**：同一详情有三份真相（`MetadataKit` 条目、`AppModel.detailSnapshots`、`DetailViewModel` 状态），TTL 与写回口径各不相同；`page` 表只有测试读写，库分页冷启动必整套重拉；首页 / 详情 / 预取 / 库搜索各自发请求，取消与错误折叠逐处手写；播放结束只刷内存、不写 SQLite，首页与详情可能显示不同进度。
  - **数据层**：`MetadataKit` 新增 `MediaRepository`（actor）——内存 LRU → `MetadataStore` → `MediaServer` 唯一读路径，`cached*` 给旧内容、`refresh*` 做同键单飞；库页 / 搜索页按「库 + 类型 + 排序 + 观看状态 + 搜索词 + 分页窗口」真实落盘并跨实例恢复；首页四条数据并行刷新、失败分区保留上一份；已看标记与播放退出进度走同一写入口，同步更新内存全部投影与 SQLite。建库失败退化为内存模式，不再保留第二套直连实现。
  - **App 层**：`MetadataCoordinator` 变成数据面宿主（`app.server` 赋值即切换仓储会话）；删除 `AppModel.detailSnapshots` / `detailPrefetchTasks` / `detailSnapshotTTL`；预取与进页共用同一单飞任务；`DetailViewModel`、`LibraryView`、首页搜索、合集 / 库封面解析全部改走仓储；`CachedMediaServer` 与 `MetadataHydrator` 两个旧层删除（含其 500+ 行测试，行为由仓储用例接管）。
  - **图片层**：`RemoteImage` 换 URL 不再先清空旧帧，成功必须「键 + 代次」双匹配才上屏；成功到达经 `ImageArrivalScheduler` 每帧批量放行；`ImagePipeline` 在「磁盘之后、网络之前」按 host 熔断，取消探针不钉死宿主。
  - **测试**：`MetadataKit` 216 XCTest + 34 swift-testing；`AppDesignKit` 187；macOS scheme **789 通过 / 0 失败 / 19 跳过（808 总数）**。新增 `MediaRepositoryTests`（10 条：磁盘恢复 / 部分失败 / 单飞 / 分页合并 / 搜索分键 / 进度写回 / 无库降级）与图片层 39 条。
  - **日志噪声**：共享 `HTTPClient` 把 URLSession 取消（`-999`）记成 `error`，Bangumi 搜索防抖每次取消都刷一条红；改为 `请求取消` 的 debug 级，真实传输失败仍是 error。
  - **文档**：`Docs/MEDIA-DATA-PLANE.md`（问题清单与目标边界）。

- **修「首页 / Bangumi（在看+搜索）顶栏纯白、丢失透明」——`.home` scrim 从窗口顶就压 0.55 白雾 + 系统窗口工具栏材质提亮去饱和，把顶栏玻璃底下的氛围图洗成了白条；详情页 / MoviePilot 资源搜索页因为「自带浓色主体图 + 自己摘了材质」才没这事**
  （用户口径：「bangumi的搜索结果页面顶栏为什么是纯白，丢失了透明的效果」→ 复查补充：「moviepilot的搜索都没这种情况，首页的和bangumi的就出这个问题了」）
  - **像素取证（用户实拍截图 + `Scripts/ambience-probe.swift` 分条带，CGImage.cropping 直读避开 y 轴翻转坑）**：工具栏条带（top 区域）色度中位 **5（阈值 6，判 `flat`＝纯色）**，同一窗口内容顶左缘色度 **35**——条带与内容之间一条断崖。跨换图两帧顶栏色相跟随氛围图（绿图 11 / 暖图 28）证明「玻璃采样整窗氛围层」的机制没坏，白是叠出来的。
  - **三层来源与对应修法**：① `.home` scrim 顶部第一档 0.55 白（浅色）正压在顶栏条带上 → 重塑为「顶栏条带以下才起满雾」：顶档 0.25（夜间 0.10）、0.12 处爬到满档 0.66/0.48——内容顶（继续观看标题 / chips 行，≈0.10-0.13 窗高）雾度与改前几乎一致，可读性不变；② 其余页面都吃系统默认工具栏材质的洗白（详情页一直自己 `.toolbarBackground(.hidden)` 所以没事）→ 在 `appShellChrome()`（分区根页）与 `RegularBackChrome`（全部 push/呈现页，所有路由页与下载管理都经它）两处收口补同一句，Mac 限定；review 补漏：**管理服务器 / 开源许可证**两个呈现式叶子页不经 `appShellBackChrome`（保留系统返回键），各自单独补同款摘材质——至此全部有顶栏的页面无遗漏（sheet 类是独立窗口、无窗口工具栏，不适用）；③ 轮播层 `AmbientBackdropCarousel()` 在调用点补 `.ignoresSafeArea()`，与声明层同一待遇——堵住「页面 ignoresSafeArea 用法改变继承安全区 → 图被裁到工具栏以下」这个记载过的塌陷家族的暴露面。
  - **改后实测（同探针同区域）**：Bangumi 进度页 top **`flat`→`image`、5→11**，跨换图第二帧 **28**；首页 **14**；详情页 **36**（观感不变）。目视核对：粉/绿两帧顶栏均与内容连续、无白带；资源搜索页经 `RegularBackChrome` 同步摘材质，观感方向与详情页一致（更透）。
  - **iOS 一并生效**：`.home` 档双端共用，iOS 顶部雾同步变薄（与 Liquid Glass 导航栏的透是同一方向），刻意不做平台分叉；`.detail` 档（详情页白字头部压底）不动。
  - **未改**：氛围池查询与轮播节奏、`.detail` scrim、任何测试（`RouteAmbienceCoverageTests` 只钉 scrim 档位语义、不钉数值）。
  - **验证**：macOS Debug 构建 + `OCPLAYER_START_SECTION=bangumi|home` / `OCPLAYER_START_ROUTE=detail` 逐页 `screencapture -l` + `ambience-probe --regions top,left --json`（数值见上）；全量 `xcodebuild test`（macOS scheme）**793 通过 / 0 失败 / 19 跳过（812 总数）**。深色模式用 `-AppleInterfaceStyle Dark` 进程级覆盖实拍：top 色度 **63**（深夜蓝图透进条带、玻璃件与文字可读），stops 0.10/0.48 直接可用。

- **修「MoviePilot 资源搜索结果还是没懒加载：一次性铺一堆液态玻璃、滚动卡顿」——卡片流被 `VStack` 包住，`LazyVStack` 眼里只有一个子视图；60 条窗口首帧就整块建完、当帧被 footer 顶到 120，且触底续载从未生效**
  （用户口径：「moviepilot 的搜索结果显示还是没有进行懒加载，一次性展示太多了，一堆液态玻璃在那会出现卡顿的状况，你调研一下列表懒加载那些实现方案」）
  - **现场（代码事实）**：`MoviePilotResourceView` 的 `ScrollView` 里是 `LazyVStack(spacing: 18)`（`:60`），但里面**只放了 `torrentsSection(displayed:)` 一个子视图**（`:92`）；而 `torrentsSection` 返回的是 `VStack(spacing: 12)`（`:244`），把「资源」标题、状态卡、`ForEach(displayed.prefix(displayLimit))` 与 footer 全包在里面。上一批（`d0b9c55`）加的 60 条窗口因此**从未生效**。
  - **根因（SwiftUI 的懒不是「按行」是「按直接子视图」）**：`LazyVStack` 只按**直子视图**决定物化哪些，铺满可视区就停；一个视图的 body 顶层若是一个**布局容器**，那个容器会被当成**一个**子视图整体求值，里面所有行一次性建出来。WWDC26「Dive into lazy stacks and scrolling with SwiftUI」明确讲了这条（并给了「body 顶层平铺多个视图时仍分别懒加载」的对照）。
  - **本机探针实测（`Reports/moviepilot-list-lazy-loading-20261101/probe/`，只依赖 SwiftUI/AppKit，可直接 `swiftc` 跑）**：400×800 窗口、60pt 行、60 条窗口——
    | 结构 | 首帧物化行数 | footer 触发 | 窗口 |
    | --- | --- | --- | --- |
    | `VStack` 包住 ForEach（改造前） | **60 行一次建完** | 1 次（首帧） | 60 → **120** |
    | body 顶层平铺（现在） | **7 行** | 0 次 | 60 |
    | 滚到底之后（改造前） | 仍是 60 | **永远停在 1 次** | 120，再也不动 |
    | 滚到底之后（现在） | 每滚一次多一屏 | 每触底一次 | 60 → 120 → 180 |
    另一个探针确认「抽成独立 `View` 是安全的」，**前提是 body 顶层平铺**：一旦包一层 `VStack`，立刻退回 120 行。
  - **修法**：①卡片流抽成 `MoviePilotTorrentList`，它的 **body 顶层平铺**（`ForEach` + `if` 两个子视图，不包任何布局容器）；②`MoviePilotResourceView` 的 `LazyVStack` 改放**直子视图**——页头（hero + 搜索 + 筛选 + 提示，收在一个 `VStack(spacing: 18)` 里，全在首屏、惰性无意义）/「资源」标题 / 状态卡 / 卡片流；③窗口语义收进 `TorrentRevealWindow`（纯值类型）：`shownCount` / `hasMore` / `reveal`（每次 +60、夹到 total）/ `clamp`（结果变少后收敛、不落到一页以下——窗口是「用户滚到多深」的记忆，放开筛选不该把人弹回顶部）/ `reset`。
  - **间距逐项对账（没有一处靠「看起来差不多」）**：页头内部三块之间 18 → 18（`pageHeader` 内部 spacing）；页头末块 →「资源」18 + 4 → 12 + 10；「资源」→ 状态卡/首卡 12 → 12；卡与卡之间 12 → 12；末卡 → footer 12 → 12。
  - **footer 的 `.id(window.limit)` 与实测口径**：**反向验证时把它去掉，测试仍然全绿** —— 说明「改造后续载只触发一次」的真因**不是**身份，而是 `VStack` 包住的整块是 eager 的、footer 从头到尾都在树上。`.id` 保留（把续载时机钉在「露了多少条」上，不依赖系统「滚出屏的 subview 保留几个更新周期」这条内部策略），但注释按实测结论重写，不写没验证过的因果。
  - **测试**：新增 `TorrentRevealWindowTests`（**14 条**：首窗、不足一窗、触底 +60、夹到 total、全露完后幂等、clamp 缩到 5 条仍保底一页、clamp 在窗口中间收敛、空数据、reset、hasMore 边界、`pageSize <= 0` 兜底、负 total）与 `MoviePilotTorrentListLazinessTests`（**3 条**，**真实宿主窗口** + 500 条夹具，用行自身 `onAppear` 计数当「物化了多少行」的判据：首帧 ≤12 行、连续触底的窗口序列必须是 `[60, 120, 180]`、结果不足一窗时 footer 不出现）。**反向验证**：把 `MoviePilotTorrentList.body` 包回 `VStack(spacing: 12)`，首帧物化立刻变 **500 行**（窗口首帧被推到 total），3 条里 2 条变红（`XCTAssertLessThanOrEqual failed: ("500") is greater than ("12")`）。macOS scheme **812 通过 / 0 失败 / 19 跳过**（新增 17 条）。
  - **一个测量坑记在用例里**：「滚到底」不能用一次 `scroll(to: maxY)` 复刻——`LazyVStack` 的文档高度是**估算值**，新行落位会把它抬高，「底」一直在移动；一次跳底只会命中当时的估算底，之后内容长出来就停在那儿（实测：真实宿主窗口里第二页永远触发不到）。用例改成**一帧 400pt 地连续推**，与真实滚动同构。
  - **调试入口**：`#if OCPLAYER_SELFTEST` 新增 `OCPLAYER_MOVIEPILOT_TORRENTS=<n>`，灌 n 条字段形态复刻真实 SSE 元素的合成结果（`torrent_info` + `meta_info`），不接服务器就能把「一千条 + 液态玻璃」这一屏摆出来看；与既有 `OCPLAYER_MOVIEPILOT_CARDS` 同一套 `SIMCTL_CHILD_` 用法。
  - **未改**：媒体搜索结果页（`MoviePilotHomeView.searchResultsView`）与下载管理页的 `ForEach` **本来就是 `LazyVStack` 的直接子视图**（探针同构结构只物化 7 行），不动；液态玻璃观感、数据模型、`MoviePilotKit` 包 API 一律不动——这次卡顿的量级来自**物化数量**，不是玻璃本身。
  - **调研结论（为什么不是别的方案）**：`List` 会挡死整窗氛围（本仓库 `MoviePilotDownloadsView` 已有判例）；`PagedListLoader` 那套 offset 分页不适用——`/api/v1/search/title/stream` 是 SSE 全量流，没有 offset 可分；`onScrollTargetVisibilityChange` 留作兜底（先把官方推荐的 footer `onAppear` 哨兵跑通，实测触发时机已稳定）；`drawingGroup()` 明确不能用（会截断 `ignoresSafeArea` 且玻璃无法采样被栅格化的背景）。
  - **验证**：`Scripts/clean.sh` → macOS Debug 构建通过（Build 629）；全量 `xcodebuild test` 812/0/19；首屏人工核对（`Reports/moviepilot-list-lazy-loading-20261101/first-screen-after.png`：402×874 下只铺 4 张卡，不是全部）。

- **修「明明是最新版 liberika，播到片尾还是弹播放出错、也不连播」：一次 seek 打断的读把 EIO 永久锁进 FFmpeg 的 `AVIOContext.error`，读到 EOF 时先拿到它——App 侧按自然收尾做窄口径折叠**
  （用户口径：「去查手机上的 OcPlayer，为什么明明是最新版修改过的 liberika 还是播完会有报错」+ 手机截图：S3E53 · 24:02，`playback error: demux worker error: … av_read_frame … Input/output error (-5); custom AVIO read at offset 6296469 failed earlier: source read canceled`）
  - **现场**（iPhone 17 / iOS 26.6.2 / OcPlayer 0.2.2 (621) / liberika v0.3.0；日志用 `xcrun devicectl device copy from --device … --domain-type appDataContainer --domain-identifier dev.jumusu.OcPlayer --source Library/Logs/OcPlayer` 直接拉回，不用碰设备）：`药屋少女的呢喃 S3E53`（片长 1442.176 s）**09:05:23.424** `open()` → **09:05:24.533** 续播 `seek 0 → 933.474 s`，**13 ms 后**内核 stderr 落 `[matroska,webm @ 0x11bb99b80] Read error`（在途读被 interrupt 打断，用户看不见）→ 正常播 7 分钟 → **09:12:18.977** 自动跳过 credits 到 1441.676 s（被 0.5 s 尾部防线钳在 1442.176−0.5）→ **09:12:19.165** `playback_fatal: demux worker error: source error: ffmpeg error in av_read_frame: Input/output error (-5); custom AVIO read at offset 6296469 failed earlier: source read cancelled`，位置 1441.690 s → `.error`、无连播，7 秒后用户手动关。对照：同一份日志 11:53 的会话也有两次 seek（含片尾跳过），`error_count=0`、`.stopped` 干净收尾——那两次 worker 没在途读，interrupt 没打到东西。
  - **根因在内核，不在尾读**：`AsyncDemuxer::seek` 先 `SourceCancellation::interrupt()` 打断在途 HTTP 读（`crates/erika/src/playback.rs`），被打断的读在 `CustomAvio::read_packet` 里对**所有** source 错误一律翻成 EIO；FFmpeg 把任何负返回值**永久**锁进 `AVIOContext.error`（`libavformat/aviobuf.c` 的 `fill_buffer` / `avio_read`：`s->error = len`，而 `avio_seek` **只清 `eof_reached`、从不清 `error`**）。此后**第一次读到 0 字节**（自然播完或跳到片尾）`avio_read` 先返回这条陈旧 EIO 而不是 EOF → `av_read_frame` = -5 → demux worker 判 fatal。报错里 `offset 6296469`（6.29 MB）与那句 `failed earlier` 是**旧伤**，与 22 分钟处的本次读无关——文案会把人往「尾读又坏了」上带。内核 v0.3.0 / 上游 #169 修的是「HTTP 尾部 range 投递失败归一成 EOF」，与本条差一层：这次 source 老实返回空、`last_error` 已清，失败发生在它上面。
  - **App 侧兜底**：`PlayerState` 新增 `nonisolated static isStaleIOErrorInTail(message:position:duration:)`，**两条判据同时成立**才折叠——①片长已知且位置在「片长 − 2 s」以内；②文案是 `av_read_frame` 的 EIO（认错误码 `(-5)` 而不是认英文 `Input/output error`：`av_strerror` 随 locale 变，认文本会在非英文环境里变成死代码）。命中即落 `.stopped`：不置 `lastError`、不计 `errorCount`、不写结构化 `error` 事件，只留一条 warning。上报层只认 `.stopped` 的 `isNaturalEnd` 于是自然成立 → 本集正常收尾、连播继续、`session.end` 的 `error_count=0`。内核同一件事会连推 `.failed` 与 `.stateChanged(.error)` 两条，后者由 `foldedStaleTailIOFailure` 挡住，不许把状态翻回错误态。
  - **会话已经真失败时不折叠**：先到的那条真错误（EOF stall 风暴、HTTP 4xx）才是这一集的死因，随后的陈旧读错误是收尾阶段的回声——翻回 `.stopped` 会让上报层当成自然播完、在一集明明失败的情况下连播下一集；盖掉 `lastError` 又会把徽章换成带 `failed earlier` 的误导文案。所以 `state == .error` 时直接丢掉这条事件：状态、`lastError`、`errorCount` 一律不动。
  - **两处过期说法同步**：`PlaybackReportingCoordinator.naturalEndPositionSlackSeconds` 的注释（原写「片尾真错误现在就该露徽章」）补上这条例外并与 `Docs/DEVELOPMENT.md` 的内核章节对齐——那次拆除的理由只覆盖「HTTP 尾部 range 投递失败」，不覆盖 AVIO 的 error latch。
  - **为什么仍是窄口径**：上一批「拆除片尾 EOF 兜底」的判据是「内核 v0.3.0 之后片尾不该再报错」——对**尾读**成立，对 **AVIO 的 error latch** 不成立。折回「片尾任何 `.error` 都算播完」会把 EOF stall 风暴、HTTP 401 这些真错误一起吞掉（PR #68 的教训），所以只认这一个签名；别的错误即便落在片尾也照旧露徽章、计错误数。
  - **已接受的代价**：片尾最后 2 s 内真的发生 I/O 故障（如断网）也会落进这个签名、被当成自然收尾。那一集剩下的内容本就不足 2 s，误判代价小于「每集播完都因内核缺陷报错」；内核修好后本兜底整体撤掉，这条代价随之消失。
  - **测试**：`PlaybackKit` 全量 **69** 条绿（+7：现场原文折叠成 `.stopped` 且 `errorCount=0`、判据纯函数（含 `isInTailWindow` 三种输入）、窗口外同文案照旧报错、片尾其它错误照旧报错、折叠后孪生 `.stateChanged(.error)` 不翻盘、重复投递只折叠一次、**已经真失败的会话不被翻回 `.stopped`**（`lastError` 与 `errorCount` 都不动）；原 `testEndOfStreamErrorIsNoLongerFolded` 更名为 `testTailStaleIOErrorFoldsToNaturalStop` 并反转断言，`testIdenticalErrorStormCountsOnce` / `testMidStreamErrorStillFails` / `testUnknownDurationStillFails` 原样保留）。**反向验证**：①把判据改成恒 `false`，只有 4 条正向用例变红（10 个断言失败），两条边界用例（窗口外 / 片尾别的错误）保持绿；②去掉 `state != .error` 那道 guard，`testStaleTailIOErrorDoesNotResurrectFailedSession` 立刻变红（`("stopped") is not equal to ("error")`），其余全绿。
  - **回退**：把 `isStaleIOErrorInTail` 的 `return true` 改回 `false`，即回到「片尾错误照实露徽章」的旧行为。内核侧根治（seek 后清 AVIO latch，或 interrupt 不翻 EIO 而改为等 resume 后重发）已提单到 [1824239290/Erika#4](https://github.com/1824239290/Erika/issues/4)（我们自己的 liberika 副本）。

- **详情页「在 MoviePilot 找资源」不再自己搜：改为跳到 MoviePilot 分区的搜索结果页，由用户挑条目后再「查资源」**
  （用户口径三条：「详情页里的那个使用 moviepilot 找片点击后是直接搜索，其他地方的逻辑都是先调用 moviepilot 的搜索媒体，然后我手动选择 themoviedb 的或者 douban 的再开始搜索。详情页那种情况的话下载会导致 moviepilot 自动刮削缺 tmdbid 等等问题。所以你需要修改一下这个地方。」→「但我之前的风格不是这样的啊？」→「不应该出弹窗，而是直接去到 moviepilot 的搜索番剧的结果页面」）
  - **根因**：资源搜索页下载时把 `MPMediaInfo.raw` **原样**回传成 `/download/` 的 `media_in`，MoviePilot 服务端靠里面的 `media_source` / `media_id` / `tmdb_id` 去刮削、改名、入库。详情页此前有两条近道：①条目带 `tmdbID` 时**本地拼**一个 `MPMediaInfo`（只有 `media_source` / `media_id` / `tmdb_id` / `title` / `type` / `year`，`poster_path`、`overview`、评分全缺，回来的媒体对象只有「我们自己以为的形状」）；②没有 `tmdbID` 时按标题搜一次后 `first { 年份吻合 } ?? first` **自动挑第一个**——而 `/media/search` 是多源聚合，第一条由服务端 `SEARCH_SOURCE` 决定，挑到 Douban 条目时对象里根本没有 `tmdb_id`。两条都会让下载后的自动刮削缺编号甚至认错条目。
  - **最终改法（第三轮定稿）：详情页不产出任何媒体对象**。入口卡只做两件事——把片名写进 `AppModel.pendingMoviePilotQuery`、`switchSection(.moviepilot)`；MoviePilot 首页原有的消费点（`MoviePilotHomeView` 的 `.task(id: boundServerID)`）取走关键词、调 `/media/search`、渲染多源候选列表。用户在那页自己挑 TMDB / Douban 条目、点该条的「查资源」进站点资源搜索。**这条链与 Bangumi 详情页那颗「MoviePilot下载」完全同源**（同一个通道、同一个消费点），也是 MoviePilot 分区本来就有的原生动线。`MoviePilotResourceSection` 因此从「有状态的两级流程」退回到无状态：没有 `picked` / `isPicking` / sheet / `navigationDestination`，`DetailView` 的 `isResourcePresented` 与 `.coveredByPresented` 一并删除。
  - **为什么不做弹窗选源**（第二轮方案，已被否）：用户口径明确「不应该出弹窗，而是直接去到 moviepilot 的搜索番剧的结果页面」。弹窗是同一个 `/media/search` 的二次包装，却新造了一套列表 UI（海报行、推荐标记、编号摘要），既与 MoviePilot 分区那页重复，又多一层「点了关掉才落地」的时序（`onDismiss` 里 `pushPresented`）。跳页方案让详情页只依赖既有组件。
  - **版面沿用原样式**（第二轮口径「但我之前的风格不是这样的啊？」）：入口卡仍是那张液态玻璃卡（`.padding(12)` / `spacing: 3` / `.liquidGlassCard()` / `chevron.forward` 用 `.tertiary`），与改造前带 tmdbID 条目看到的那张卡逐项一致，也与详情页整页内容件（Bangumi 章节区、媒体信息）同源。第一版曾把它换成 `neutralProminentButton()` 实心黑胶囊——而改造前只有**缺 tmdbID 的罕见条目**才走那颗按钮，等于把多数条目的观感换掉了。`neutralProminentButton()` 在详情页这一处不再使用；其余 6 处（MoviePilot 首页门控 2 + 空态 1、Bangumi 首页 2、Bangumi 登录 1）都是门控 / 空态页上真正的实底主行动，原样保留。
  - **顺带的搜索页改造**：①`MoviePilotHomeView` 消费 `pendingMoviePilotQuery` 时**同时写 `keyword`**（此前只写 `submittedKeyword`，会出现「有结果但搜索框空着」的错位；从详情页跳进来尤其显眼）；②搜索结果按 `MoviePilotMediaRanking.candidates(...)` 重排成 **TMDB 源优先**——`/media/search` 的顺序由服务端 `SEARCH_SOURCE` 配置决定，Douban 条目可能排第一，而 MoviePilot 的刮削链路以 `tmdb_id` 为锚点。这里**只调整展示顺序、不替用户选择**，每张卡仍是服务端返回的完整对象。
  - **排序口径收进包里**（`MoviePilotKit/MoviePilotMediaRanking.swift`，纯函数可测）：`sortedForDisplay(_:)` 把 TMDB 源（+100）与带 `tmdb_id` 的条目（+10）排到前面，**同分按服务端原序**（显式带下标比较——`sorted` 不保证稳定）。只调整顺序，不增删条目、不改内容。
  - **review 时砍掉的投机设计**：第一版按「选源面板」的需求写了一整套打分（年份 +30、类型 +5、与条目 TMDB 编号精确匹配 +1000）、`recommended(...)` 推荐接口、`Candidate.isRecommended` / `isMissingTMDBID` / `sourceSummary`。面板取消后**生产调用只剩一处且不传任何上下文**（`MoviePilotHomeView.search()` 手里只有关键词，拿不到年份或条目编号），于是那 3 个权重、推荐接口与三个派生属性全部无从调用——119 行的模块里大半是死代码，注释还在讲已删除的「面板」。现已收成 47 行的 `sortedForDisplay` + 两个真正生效的权重，测试同步重写（6 条，全部对着现存行为）。
  - **review 补的兜底（孤儿关键词）**：`AppModel` 新增 `openMoviePilotSearch(_:)`，把「切分区 + 排关键词」收成一个入口，**先确认切换被接受、再放词**——`beginRouteExit` 在两段式转场途中会丢弃调用（`guard !routeExiting`），早先 Bangumi 与 Jellyfin 两处都是「先写 `pendingMoviePilotQuery` 再 `switchSection`」，那次被丢弃的点击会留下一个没人消费的关键词，用户下次自己进 MoviePilot 时会莫名发起一次他并没有要求的搜索。为此 `switchSection` / `beginRouteExit` 改为 `@discardableResult -> Bool` 回报是否被接受，两个写入方（Bangumi 条目详情、Jellyfin 详情页）都改走同一入口。`MoviePilotHomeView` 另补 `.onChange(of: app.pendingMoviePilotQuery)` 消费点：原先只有 `.task(id: boundServerID)` 一处，本页已在树上时（iOS Tab 保活）写入不会触发它。两处共用 `consumePendingQuery(_:)`，靠「取走即清」防重复。
  - **`sourceSummary` 转为真正使用**：资源搜索页那条「没有 TMDB 编号」的橙色提示现在会把**实际带的编号**一起写出来（「来源 DOUBAN · 豆瓣编号 35593344。换一条 TMDB 来源的条目可以避免。」）——只说「没有 TMDB 编号」时用户无从判断该不该换。
  - **测试**：`MoviePilotKit` 全量 **76** 条绿（`MoviePilotMediaRankingTests` 6 条：服务端把 Douban 排前面时 TMDB 源仍排第一、已排好时幂等、非 TMDB 源里带编号的在前、同分保持服务端原序、空输入、排序不改动条目对象）；`AppDesignKit` **148** 条绿；macOS scheme **776 通过 / 0 失败 / 19 跳过**（含新增 `AppModelLifecycleTests` 3 条：切换被转场丢弃时不留孤儿关键词、已在 MoviePilot 分区时仍能排队且关键词 trim、空关键词不排队）。
  - **反向验证**：把 `openMoviePilotSearch` 改回「先写词再切分区」，孤儿关键词那条用例立刻变红（`TEST FAILED`），其余 `AppModelLifecycleTests` 全绿——证明它抓的是这个缺陷本身，不是碰巧通过。
  - **文案收口（第四、五轮）**：先按用户口径「按钮下的那些描述可以去掉」删掉了我新加的两行解释（「跳到 MoviePilot 搜「片名」…」「选中的条目会随下载一起回传…」）；随后用户指出「好像少了什么」——删多了，把**改造前那句原有说明**也一并带走了。现在卡片回到「标题 + 一行说明」的原始形状：标题 `搜索站点资源并下载`、说明 `按标题搜、可选站点；下载完成后 MoviePilot 自动整理入库，稍后出现在媒体库`，两者都**逐字沿用改造前**。我那两句流程解释不再回来——这一步只需要说明「点下去会发生什么、结果落在哪」，不必复述跳页路线。编号回传仍有兜底：资源搜索页对缺 TMDB 编号的条目会当场给橙色提示。
  - **未含**：不给资源搜索页加「换源」按钮（回 MoviePilot 页换即可）。

- **修「详情页 MoviePilot 主行动按钮在浅色模式下是黑底黑字、整颗看不见」（同日另一起，与上条同源）**
  （用户口径：「按钮怎么变这样了？？」+ 截图 `807×108`）。
  - **现场**：截图里 `在 MoviePilot 找资源` 那颗胶囊底色 `rgb(8,8,8)`、文字 `rgb(0,0,0)`——对比度 1.0:1，等于没有文字。用户是**浅色外观**，深色外观下同一颗按钮正常（浅底黑字），所以这个 bug 只在浅色下显形。
  - **根因**：`AppAccent.neutralProminentButton()` 写的是 `buttonStyle(.borderedProminent)` + `.foregroundStyle(AppAccent.onSolid)`。`.foregroundStyle` 挂在 `buttonStyle` **之后**时，`borderedProminent` **不会**把它传给标签（`ImageRenderer` 逐档实测：A 写法浅色渲染出 `(8,8,8)` 底 + `(0,0,0)` 字；把同一个 `.foregroundStyle` 挪进 label 内部则正常）。而根节点的 `.tint(.primary)` 让系统也**算不出**对比度（`Color.primary` 是内容色，不是「标签色」语义），于是系统既不反色、我们补的反色又被丢掉。深色下碰巧成立：`.primary` 是白，系统按「亮底配默认黑字」渲染，正好可读——这正是它长期没被发现的原因。
  - **修法**：新增 `AppAccent.solidTint`（`UIColor.label` / `NSColor.labelColor`，与 `.primary` **同值**但语义是标签色），`neutralProminentButton()` 改为 `.buttonStyle(.borderedProminent).tint(AppAccent.solidTint)`——**让系统自己算反色**。实测深 / 浅 × 常态 / 禁用四组合全部可读（浅色黑底白字、深色白底黑字），按压态 / 禁用态 / 圆角 / 内边距仍沿用系统实现。6 个调用点（MoviePilot 首页 3 处、Bangumi 首页 2 处、Bangumi 登录 1 处）一并修好。
  - **测试为什么漏了它**：`AppAccentTests` 原有 3 条只渲染**自绘复刻品**（`solid` 底 + `onSolid` 字），守的是「这套配方本身对比度够」——量不到扩展方法里两句修饰符的**组合顺序**。新增 3 条直接渲染**真实 `neutralProminentButton()`**（浅色可读 / 深色可读 / 两外观反色），并按 `RootView` 钉 `.tint(.primary)` 复刻触发环境。**反向验证**：把实现改回旧写法，只有「浅色可读」一条变红，其余全绿——与现场（只有浅色坏）逐条吻合。
  - **一个测量陷阱记在用例里**：`borderedProminent` 实底自带约 5% 透明度，填充像素 alpha 实测 **242**；统计时若按 alpha ≥ 250 过滤「透明背景」，会把按钮本身也丢掉，只剩白字参与统计，量出「底=字=`rgb(255,255,255)`、1:1」的假红。阈值取 **128**。
  - **验证**：`AppDesignKit` 全量 **148** 条绿（+3）；macOS / iOS 重建并覆盖安装。

- **新增自填镜像源：Bangumi 与 TMDB 的命中地址可改走镜像，国内网络不必再挂全局代理**
  （用户口径：「我们使用到了 bangumi 和 tmdb，但中国大陆的网络在没有代理的情况下会无法连接，你去设置里添加一个使用镜像源的选项吧，然后再完成项目对自定义镜像源的支持」；
  位置口径：「设置里的位置放到他们自己的栏位里面，比如 bangumi 的镜像源设置放到 bangumi 栏位里，tmdb 的同理」）。
  - **为什么需要**：`api.bgm.tv` / `lain.bgm.tv` / `api.themoviedb.org` / `image.tmdb.org` 在国内直连不通，表现为 Bangumi 分区空白、封面全裂、TMDB 补全静默失败。此前唯一的出口是给整机挂代理——对只看番的用户门槛太高。
  - **位置**：镜像**不是独立子页**，而是跟着它服务的那一家走——「设置 → Bangumi」页内一段「镜像源」（Bangumi 开关 + 根域输入框 + `bangumi.lat` 示例 + 当前 API/图床两行 + 恢复官方直连），「设置 → TMDB 元数据补全」页内一段「镜像源」（TMDB 开关 + API/图片两个输入框 + `api.tmdb.org/3` 示例 + 当前 API/图片两行 + 恢复官方直连）。找 Bangumi 的连接设置只去 Bangumi 页，TMDB 同理；两页各有一句「不影响另一家的线路」把边界说清。TMDB 那段刻意放在 `isConfigured` 闸门**之外**——镜像正是「连不上才需要改」的东西，只在配好 Key 之后才出现等于让用户先撞一次墙。
  - **两个开关，不是总开关**：`bangumi.mirrorEnabled` / `tmdb.mirrorEnabled` 是**两个键**。镜像按线路配，两家镜像常是不同的提供方，共用一个开关只是巧合；合并键的症状会是「只想关 TMDB 的镜像，Bangumi 也跟着断」。两个「恢复官方直连」也各清自家那几个键，互不越界。
  - **hub 值预览**：Bangumi 行在「已登录 / 昵称」后挂「（镜像）」，TMDB 行在「已启用」后挂「（镜像）」——镜像配错的第一症状是「首页空白但设置说已登录」，把线路状态摆到一级页能省掉一轮「是不是代理没开」的试错。标记的判据是**真正生效**（开关开 **且** 地址能解析），不是裸开关：地址留空 / 填错时域包已退回官方，此时还挂「（镜像）」就是在撒谎——而这个标记存在的全部理由恰恰是别让用户以为线路改了。
  - **交互**：没有保存按钮——`@AppStorage` 写的就是域包读的那几个键，**下一个请求即生效**。地址可留空（= 该项走官方），非法值不拦保存、按官方处理并在框下给橙色提示（拦住输入会让用户卡在一个填错的框里出不去，静默退回官方才是可用的降级）。
  - **Bangumi 侧**（`Packages/BangumiKit`）：`BangumiURL` 新增 `mirrorEnabledKey` / `mirrorRootDomainKey` / `activeMirrorRootDomain` 与纯解析 `resolvedMirrorRootDomain(enabled:rawValue:)`；根域按既有约定派生 `api.` / `lain.` / `next.` / 主站四个域名（可带端口，自建反代可用）。读路径仍每次现采样（不记忆化），`ImageURLStringCache` 以镜像值当代次标签，改完地址旧条目整表作废。**顺带修掉一条登录死路**：`buildOAuthURL()` 返回的授权页改走镜像主站（`BangumiURL.mainSiteURL`，路径与 `client_id` / `redirect_uri` / `state` 原样保留）——API 镜像好了而 `bgm.tv` 打不开时用户仍然登不进去。
  - **TMDB 侧**（`Packages/MetadataKit`）：新增 `TMDbEndpoints`（API 根 + 图片根的值类型）与 `TMDbEndpointSettings`（读键 + 纯解析）。`TMDbClient` 的 API 根改为构造时注入的 `endpointProvider()`（**每次请求现取**，已装好的客户端不用重启就跟着改）；`TMDbImageSize.url` 默认读设置、另给显式 `endpoints:` 重载；图片根只填域名时补 `/t/p`，用户直接粘一张带档位的图会自动把档位段吃掉，否则会拼出 `…/w500/w342/xx.jpg`。**安全相关**：`DisplayMetadata.isTMDbImage` 的 host 判据跟着图片根走——原先写死 `image.tmdb.org`，镜像模式下每张海报都会被判成「服务端图」，把 Jellyfin 的 `Authorization` 发给镜像 CDN。
  - **第三方入口同源**：「在浏览器中打开」的三处（Bangumi 条目详情工具栏、每日放送工具栏、详情页外链图标）改走 `BangumiURL.main`——指向打不开的域名等于一个必然失败的按钮。
  - **图片防盗链**（`Packages/AppDesignKit`）：`ImagePipeline.makeRequest` 的 Bangumi 图床判据从 `host.contains("bgm.tv")` 换成 `bangumiReferer(forHost:)`：官方 `lain.bgm.tv` 仍发 `Referer: https://bgm.tv/`；镜像 `lain.<根域>` 推 `https://<根域>/`（含端口），否则镜像若沿用官方防盗链策略会整面 403；顺带堵掉 `bgm.tv.evil.example` 这类伪装域被当成官方图床的漏洞。
  - **配置备份**：新增 `mirror` 模块（后加模块，老文件解码为 nil、导入时不动目标设备），五个键一起搬（两个开关 + 三个地址）；导入是**整段覆盖**（含清空），避免留下「开关开着、地址是上一台设备的」这种自相矛盾状态；维护页的导入确认弹窗同步列出「镜像源（Bangumi / TMDB 各自的线路）」。该段的解码**刻意容错**：`Codable` 合成解码器缺一个键就抛，代价是整份配置导不进来（连 TMDB Key、播放偏好一起丢），所以两个开关按「缺 = 关」处理，并认第一版单开关形态的 `enabled`。
  - **测试**：`BangumiMirrorSettingsTests`（11 条，swift-testing：键字面量、开关/空值/非法值三种退化、根域派生四域名与端口、授权页改写与官方逐字返回）、`TMDbEndpointSettingsTests`（16 条：键字面量、两个根的规范化与非法值、逐项独立退化、客户端真的打到镜像 host、图片 host 判据随端点翻转）、`BangumiImageRefererTests`（7 条：官方 / 镜像 / 端口 / 伪装域）、`MirrorKeyContractTests` + `MirrorSettingsTests`（App 层：跨包键名逐个比对、**两个开关必须是两个键**、五行值预览互不串台、输入校验、两处复位各清自家键且不越界、镜像不再是子页且 `settings.mirror` 解析为 nil）、`ConfigBackupTests` 新增三条（五个键的镜像往返 + 老备份不动镜像 + 缺键/legacy 单开关形态容错）。同时把三处**依赖开发机偏好**的断言改成按生效端点拼期望值（`CollectionDetailTests` / `MetadataCacheIntegrationTests` / `DetailExternalLinksTests`）、包内 TMDB 用例统一显式传 `endpoints: .official`——否则本机一开镜像，这些用例会在正确的实现上变红。
  - **验证**：`Scripts/clean.sh` → `SKIP_ERIKA_FETCH=1 Scripts/build-macos.sh debug` 通过（Build 618）；`xcodebuild test`（macOS）目标用例全绿；包测试 MetadataKit 63 条、BangumiKit 89 条、AppDesignKit 145 条全绿。
  - **未含**：不做镜像探测与自动切换（可用性随网络与时间变化，内置任何一份清单都会在失效后变成误导）；不改 `next.bgm.tv` 的网关路径（弹弹play 网关是另一条链路，不受镜像影响）。
- **内核弹幕渲染路线恢复：默认改回内核内置渲染器（liberika DFM+），设置 → 弹幕 页可切回 App 层渲染**
  （2026-08-25 因「在屏弹幕跳轨」被整体禁用，根因已定位并修复）。
  - **根因**：转换器当年给每条弹幕合成 `id`，内核拿它当 shell `stable_tracks` 的 key，viewport 重排时个别弹幕的轨道偏好互相顶掉 → 单独几条突然换位置。**修复 = 转换器不再输出 `id`**（匿名条目内核不保留逐条轨道记忆，重排时整体重排；考证见 `DanmakuJSONConverter.erikaJSON` 的注释）。随 liberika v0.3.0 换装恢复本判定。
  - **路线判定**：`resolveOverlayDanmakuRoute()` 回到真判定——所选内核不支持内置弹幕渲染器时强制 overlay（否则弹幕会静默消失），否则听偏好 **`danmakuUseOverlayRenderer`（默认 false = 内核渲染）**；路线与内核一起在 `prepareEngine()` 锁定，改动下一次播放生效。另补一处易漏时序：`prepareForPresentation()` 会先刷新一次路线快照——弹幕编排器在引擎就绪**之前**就按 `danmakuPayloadFormat` 产载荷，只靠 `prepareEngine()` 刷新会让冷启动首播/翻转开关后的首播按旧路线产载荷（内核路线缺 JSON → 本集弹幕静默缺失）。
  - **用户可见**：①默认弹幕由内核渲染，与视频同一渲染管线（画面截图两条路线都不含弹幕——内核截图契约排除在屏评论）；②HUD「过滤与显示规则 → 合并重复」入口恢复（仅内核渲染路线出现，overlay 渲染器不实现 merge）；③HUD 字号调节对内核路线生效（此前只喂 overlay，恢复后内核路线成默认会让它变成死操作）——应用层 pt 按比例映射到内核字号（100% = 内核自己的 30 逻辑 px，视觉零变化）；④设置 → 弹幕 页的「弹幕渲染」卡承载路线开关（位置调整见下一条）。
  - **风险与回退**：内核渲染的 DFM+ 轨道模型与 overlay 不同（可能观感差异）；若真机复现跳轨，把 `PlaybackPreferences.danmakuUseOverlayRenderer` 默认值翻回 true 即可（一行），或让用户在该开关里切回 App 层渲染。
  - **测试**：`testDanmakuRouteFollowsPreference`（偏好 true/false 两向）、「内核不支持弹幕时强制 overlay」保留、新增 `testDanmakuRouteRefreshesAtPresentation`（换片后快照跟设置刷新）、`DanmakuKernelFontSizeTests`（比例映射 + ≥1 夹紧）；装载侧缺 JSON 载荷由静默跳过改为 warning 留痕。
  - **随本批次一起合入**：另含「用内核渲染弹幕」开关从设置 → 播放 挪到设置 → 弹幕（独立提交）。

- **「用内核渲染弹幕」开关从「设置 → 播放」的「播放内核」卡挪到「设置 → 弹幕」页**
  （用户口径：「把设置-播放的那个内核弹幕设置项，放到 弹幕 那一栏上」）。
  - 渲染路线本来就是弹幕偏好，和内核选择不是一回事，放在弹幕页才找得到；播放页只留内核 / 画质增强。
  - 判定与行为不变：仅当前所选内核 `supportsKernelDanmaku` 时出现，写同一个 `PlaybackPreferences.danmakuUseOverlayRenderer` key，改动从下一次播放开始生效；`Docs/DEVELOPMENT.md` 的渲染路线一节同步改了入口位置。
- **片尾自然播完不再被误判成「播放出错」：内核 v0.3.0 修好尾读语义后，App 侧三层 EOF 兜底整体拆除**
  （根因来自内核：Erika v0.2.1 在请求边界跨过文件末尾时会把「读到文件尾」间歇报成 fatal `av_read_frame: Input/output error (-5)`，自然播完反而进 `.error`；上游 liberika v0.3.0 把最后 4 MiB 内未送达的 HTTP 尾部 range 按 EOF 处理，我们报的 #163 已随上游 #169 修复）。
  - **拆掉的三层兜底**：①`PlayerState` 的片尾折叠（PR #68 引入）：片尾窗口内的 `.failed` / `.stateChanged(.error)` 不再折叠成 `.stopped`——片尾真错误恢复置 `lastError`、计 `errorCount`、露出错误徽章；②上报层的 `isEndOfStream` 删除：心跳与 `stop()` 统一走只认 `.stopped` 的 `isNaturalEnd`（「位置 ≥ 片长 − 2 s」的干净收尾容差保留，它先于 EOF 兜底存在），片尾的 `.error` 不再触发连播；③尾部安全边际 3 s → **0.5 s**（`tailGuardSeconds`）：只保留「防 seek 越过/贴住 EOF 触发内核 `audio output stalled at EOF` 错误风暴（逐帧重发 `.failed`，实测一次刷 6302 条）」这一条理由，「尾读 fatal」的理由已随内核修复消失。
  - **用户可见变化**：①片尾若真出内核错误，现在会如实弹错误徽章、不连播（这正是修复后的语义，内核不该再在片尾报错）；②「跳过片尾 / 不保留」的落点从片长 − 3 s 变为片长 − 0.5 s——不保留与 0–2 s 短保留档的落点比原先晚 2.5 s（片尾多播约 2.5 秒后自然收口），设置页文案同步改成「停在片尾前 0.5 秒」；③进度条拖到最右端（`seek(toFraction: 1)`）也补上同一道防线，此前只有跳过/章节/续播路径钳落点。
  - **测试**：`PlayerStateFoldingTests` 删掉 8 条折叠用例，新增「片尾错误不再折叠」「同一错误风暴只计一次（去重与折叠无关，必须存活）」；`PlaybackReportingCoordinatorTests` 片尾错误用例断言翻转（`reachedEnd` true → false），防止有人把 `.error` 重新接进终态判定；`SkipPreferenceTests` 5 条断言 3 s → 0.5 s 并更名 `tailGuard`，新增 2 条 scrub 落点用例。
  - **回退**：若真机再次出现片尾误报 EOF，把内核钉点退回 v0.2.1 并恢复 PR #68 的折叠逻辑即可（`Config/Erika.version` + 该 PR revert）。

- **播放内核换装 liberika v0.3.0（原 Erika）：片尾尾读不再报假 EOF，字幕/弹幕字形改为 2× 超采样，软件解码默认多线程**
  （上游 0.3.0 起仓库更名 [AimesSoft/liberika](https://github.com/AimesSoft/liberika)，C ABI 仍为 `erika_*`）。
  - **钉点**：`Config/Erika.version` v0.2.1 → **v0.3.0**，`Scripts/erika-v0.3.0.sha256` 存官方两包哈希（macos-arm64 + ios，下载时逐包校验）；`erika.h` 与 `ErikaVersion.swift` 随 tag 重写入库（头文件纯新增：帧导出 / 诊断 JSON / chapters / hwaccel 回退事件，既有签名与结构体布局未动）。
  - **fetch-erika.sh 两处基建**：①v0.3.0 的官方 macOS `.a` 里有 285 个 compiler-rt 对象同时带 macOS 与 MACCATALYST 两条 `LC_BUILD_VERSION`，`xcodebuild -create-xcframework` 会把整个归档判成「多平台」拒收——新增 `strip_catalyst_build_version` 把 Catalyst 声明原地改写成等长的 `LC_UUID`（结构合法、对象与符号全保留；改 `LC_SOURCE_VERSION` 会被 ranlib 丢成员，注释里写明勿用），老 tag 检出 0 处自动跳过；②改写后 macOS 切片改名 `liberika_capi.macos-only.a`，「已就绪」快路径跟着认新名字——否则每次构建都会重解包 ~320 MB、重建 ~780 MB xcframework，并刷新 `erika.h` 触发 ErikaKit 全量重编。失败语义也收紧：改写脚本除 0/2 之外的退出码一律中止 fetch（不再把错误吞进 `if` 条件、拿未改写的归档去合成）。
  - **用户可见影响**：①**字幕与弹幕字形按 2× 栅格化**（上游默认开启、C ABI 无关闭开关）——同屏 ≤2 条 CJK 字幕时进程 CPU 约 +22%（真实片源）～+70%（合成最坏场景）、内存 +11～19 MB，字形更锐利；已知风险：高密度 CJK 字幕（同屏数百字形）会把超采样 glyph atlas 顶过 Metal 16384 纹理上限、直接 MTL 断言 abort，待报上游；②**软件视频解码默认多线程**（硬解不受影响；软解片源 open/seek 后首帧可能略延后，可用 `ERIKA_VIDEO_DECODE_THREADS=1` 回单线程）；③片尾尾读语义修复带来的行为变化见「拆除片尾 EOF 兜底」一条。
  - **性能探针**：新增 `ErikaPerfProbeTests`（env 门控 `ERIKA_PERF_PROBE=1`，CI 与普通测试零开销直通），同一把尺子量不同 tag 的进程 CPU / 内存 / 每 tick 内核渲染耗时；本地合成场景与远程真片源（`ERIKA_PERF_URL` / `ERIKA_PERF_AUTH`）两种模式，实测数据见 `Docs/DEVELOPMENT.md` 内核章节。
  - **验证**：CI `macOS + iOS tests` 绿（含 v0.3.0 内核下载、哈希校验、Catalyst 改写与 xcframework 合成）；本机 `SKIP_ERIKA_FETCH=1 Scripts/build-macos.sh debug` 通过；ErikaKit 全量 65 用例绿。

- **iOS MoviePilot 搜索结果卡整体错乱：标签被压成逐字竖排、两个胶囊只剩 `+` / 🔍、标题截成「药屋少女的…」——动作区移出信息行、独占卡片底部整宽**
  （用户口径：「moviepilot 搜索番剧得到的结果在手机上会这样，完全混乱，你看看修改一下 UI 排布」；方案 A 经效果演示确认后实施）。
  - **根因**：卡内宽 330pt（402 − 页面留白 22×2 − 卡内边距 14×2），而 `HStack` 里同时放入了刚性海报（`MediaArtwork(width: 76)`）、可压缩文字列、`Spacer(minLength: 8)` 与两个自带 14pt 水平内边距的胶囊——账面 `76 + 16 + 124 + 8 + 49 + 8 + 49 = 330` **刚好塞满**，所以不溢出、不报错，SwiftUI 只是按负空间分配**把 `Text` 静默压掉**：4 枚 `PillChip` 被压到 16 / 51 / 16 / 16pt（中文无空格可断 → 逐字竖排，真机上是三根 156pt 高的「纺锤形竖条」），胶囊文案压成 0 宽（只剩图标），标题 `.lineLimit(1)` 截断。原文全文无 `fixedSize` / `layoutPriority`。
  - **改法（方案 A · 两段式）**：紧凑档（`horizontalSizeClass == .compact`）把动作区**移出那一行**，独占卡片底部整宽 330pt；文字列因此拿到 238pt。标签行由裸 `HStack` 改 `FlowLayout(spacing: 6)`（`AppDesignKit` 既有原语）并逐枚 `.fixedSize()`；标题紧凑档 2 行；胶囊文案 `.lineLimit(1) + .fixedSize(horizontal: true, vertical: false)`（与 `BangumiSubjectDetailView.actionCapsule` 同款）；动作条用 `ViewThatFits` 三档兜大字号（并排 → 堆叠 → 堆叠且放行压缩），且**刻意放在 `GlassEffectContainer` 外层**——容器内的提案行为不稳（`PlayerHUDActions` 有记录）。常规档（iPad 834 / macOS 最小窗 960）版式不变，只补不压缩兜底。卡高 ≈262 → ≈186pt。整卡从 `MoviePilotHomeView.swift`（1297 行）抽到独立文件 `MoviePilotMediaGlassCard.swift`。
  - **顺带的无障碍修补**：海报 `.accessibilityHidden(true)`（装饰图，片名在信息列）、信息列 `.combine`、两枚胶囊各自补 `accessibilityLabel` / `Hint`、卡片 `.accessibilityElement(children: .contain)`；此前 `MediaArtwork` / `RemoteImage` 全仓无 a11y 标注，读屏会把图片、四个 chip、两个按钮拆成七段朗读。
  - **验证**：iOS / macOS 两个 scheme 均 BUILD SUCCEEDED；**iOS 全量 863 条、macOS 746 条测试全绿（0 失败）**。新增 `MoviePilotMediaCardLayoutTests` 6 条几何钉子（`ImageRenderer` 量卡高：紧凑档 ≤200（推导值 186 + 14）/ 常规档收紧到 ≤155（142 + 13）/ 窄宽两档各带绝对上界 / **`sparse == full` 等式钉子**（极简内容与完整内容必须等高，因为海报 114pt 恒定主导信息段）/ 已订阅态不改几何 / AX 档只增不缩 + 动作条高度近 2×——最后两条 `#if os(iOS)` 门控，因 macOS 的 Dynamic Type 不驱动 AppKit 字体缩放，实测两侧恒等 182pt，跑在 mac 上只会假红）；`MoviePilotMediaCardSnapshotTests` 明确定位为**导出工具而非回归测试**（仅渲染写盘、无基线比对，唯一断言是「高度 > 40」；未设 `OCPLAYER_SNAPSHOT_DIR` 时整类 `XCTSkip`，避免被当成视觉防护计入绿灯）。
  - **测试有效性做过注入式反向验证（不是推测）**：把紧凑档动作区塞回信息行（只回退结构、保留 `fixedSize` + `FlowLayout`——未来最可能的重构形态），只跑该类 → `testCompactCardShapeMatchesSparseContent` 与 `testCompactCardHeightIndependentOfActionRowWidth` **均变红**；而单靠 `height ≤ 200` 会漏判（≈202 刚好越过边界），这也正是必须加等式钉子的原因。结论已写进测试类注释。
  - **新增 Debug-only 验收台** `MoviePilotCardPreviewStage`（`SIMCTL_CHILD_OCPLAYER_MOVIEPILOT_CARDS=1`，绕过登录门控，因搜索结果本就要连真服务器），在 iPhone 17 Pro 模拟器实机截图核对：紧凑档文字列拿满、标签平铺、两胶囊文案完整；AX3 以上动作条自动降级为各占一行、无一字被吞。AX 字号下标题再放一档到 3 行（此前 2 行仍会截成「药屋少女的…」）。
  - **未含**：`MoviePilotResourceView` 种子卡（`:426-506`，6 枚 chip + 下载按钮同行，同构高风险）与 `BangumiHomeView.SearchResultRow`（`:798-879`，中风险）用同一套「左图 + 中文字 + 右按钮」结构，窄屏 + 大字号下同样可能被压；`PillChip` 原语本身（26 处调用点）缺防压缩，建议之后同批收口。

- **iOS Bangumi 详情页头部「收藏状态 / 我的评分」两个胶囊只显示图标、文案被压成 0（截图里只剩「👁」「☆」和一个压扁的箭头）；紧凑宽度动作区改为整卡宽度，胶囊文案不再被压成 0**
  （用户口径：「iOS 的 bangumi 的详情页里面再看的选项框、评分选项框这两个显示有问题。iOS 端的布局可能需要你重新设计一下」）。
  - **根因**：两个胶囊原先放在信息列里，iPhone 17 Pro 上信息列只剩 ≈206pt（卡片内宽 326 − 封面 100 − 间距 20），同一行还要挤带 `.frame(maxWidth: .infinity)` 的「已看 x/y 话」。HStack 宽度不够时按默认压缩顺序先截 `Text`（字号不变、宽度归零），于是两个胶囊的文案各被压成 0、箭头被压成一条竖线——宽度越窄越明显，Dynamic Type 一放大必现。
  - **改法**：① 动作区搬出信息列，紧凑宽度下铺满卡片、放在封面/标题下方（可用宽度 ≈206pt → ≈326pt）；② 两个胶囊收进同一个 `actionCapsule(tint:isActive:compressible:)`，默认 `.fixedSize` 不允许压缩文案、`.contentShape(Capsule())` 让点击区覆盖整胶囊——两枚胶囊就此统一为同一配方（评分胶囊内边距 10/7→12/8、激活态底 0.12→0.18、描边 0.35→0.4）；③ 外层用 `ViewThatFits` 兜底：紧凑宽度三档（一行 → 进度换行 → 各占一行）、常规宽度动作行两档（一行 → 进度换行），大字号/窄窗下自动降级而不是静默吞字；最终档放行省略号截断——fixedSize 的失败模式是画出玻璃卡边界，比截字更糟；④ 顺手修掉「已看 1/0 话」：`eps == 0`（连载中总数未知）时只报「已看 1 话」；⑤ iOS 箭头改单 `chevron.down`（macOS 保留双箭头）并对 VoiceOver 隐藏，收藏态胶囊改用域色（想看紫 / 在看蓝 / 看过绿…，与日历页同一套 `BangumiStatusColor.collection`），当前状态一眼可辨。
  - **评审跟进（PR #76 静态评审 Approve 后补）**：极窄容器 + 超大字号的最终兜底档由「fixedSize 出界」改为「compressible 截字」；常规宽度 `wideActionRow` 补 ViewThatFits 兜底；已知行为入注释——紧凑三档是不同视图分支，选中档变化会重建 `Menu` 实例，弹层开着时会被连带关掉（业务状态在父视图，不受影响）；**保存转圈不再让胶囊塌缩**：收藏/评分是真实网络往返（几百 ms ~ 2s），旧写法把整条 label 换成转圈会让胶囊从 ~94–126pt 塌成 ~52pt、旁边的胶囊与进度文案跟着平移，现在转圈叠在图标位上（`.opacity` + `.overlay` 不参与布局），宽度恒定。
  - **验证**：`xcodebuild -scheme OcPlayer-iOS` 与 `OcPlayer-macOS` 均 BUILD SUCCEEDED；iPhone 17 Pro 模拟器实机渲染对照——旧版 206pt 复现截图症状，新版 326pt 两个胶囊文案完整，240pt 进度自动换行，AX3 超大字号降级后仍不吞字，另有整块头部卡片新旧版式对照；开发签名 Release 装真机（iPhone 17）验收通过。

- **App 启动动画「一笔橘猫」：冷启动第一秒用品牌标志盖住 bootstrap——一笔描出猫头轮廓、播放三角弹入、胡须依次补笔，等首页背景穿好衣服再交棒给内容；iOS 系统启动屏同步配底色，消除首帧白闪**
  - **分镜（与方案预览逐帧同源）**：0ms 底色就位 → 80–700ms 猫头轮廓一笔描出 → 470–740ms 播放三角 spring 弹入 + 中心光晕 → 610–850ms 四根胡须依次补笔 → 900ms 落定；bootstrap 未就绪就**呼吸等待**（幅度 1.2%、2.6s 一轮，不是转圈），数据就绪后**交棒**：标志淡出 150ms 并轻微放大，启动层整体 260ms 淡出。动画与 bootstrap 并行、不设时间上限——快机器上垫满 900ms 下限时，首页磁盘预热与图片装载恰好被盖住，交棒时首页已满血（实测本机 bootstrap 仅 ~60ms，垫时长换来的是从「闪一帧空壳再弹图」变成「完整品牌帧后直接是成品页」）。
  - **氛围图 hold（真机验收发现的问题，不是动画 bug）**：冷启动时间线实测——动画 11.71s 起、bootstrap 19ms、**13.14s 动画退场、13.99s 氛围池才装载**（池子要发一次 `randomBackdropItems` 网络查询 + 预热首图，两次网络往返 ≈2.3s），中间 ~840ms 首页裸奔着见人，用户看到「背景先空白再淡入」。修法顺着「动画盖住真实加载」的原则：**有会话时交棒前等氛围池就绪**（池子非空 = 首图已预热），等就绪立刻交棒（+120ms 缓冲）；迟迟不就绪按上限封顶（下限 +1600ms，离线/无 backdrop 图库的用户不陪着吊），等待期标志照常呼吸。迟到不回卷——若交棒已开始则忽略迟到信号，避免透明度回卷闪变；早到不丢——池子比内容就绪先就绪时信号先存后补（见「结构」⑤）。onboarding / 本地播放（无会话）不等。
  - **首页骨架 hold（用户实测「logo 退场时首页还没加载好，揭过去是一页空白」）**：氛围 hold 只等背景图，首页内容本身（磁盘缓存预热 / 三条 rail 网络）没有门控——缓存冷或 NAS 慢时，交棒揭开的还是骨架屏。修法同构：`AppModel.homeContentLoaded`（`hasAnyHomeContent` || `homeInitialLoadDone`，后者在 `loadHome` 收官时置位、`resetBrowseState` 复位——「有内容可看」或「首次加载已收官（空库空态/错误态）」都算就绪，boot 期两者皆无不算）作为第二个门控信号，与氛围池**共享同一个 1.6s 上限**（`exitStart` 多门控取 max、缺谁就抬到上限，不叠加）；`homeBecameReady()` 与氛围同套「迟到不回卷、早到先存后补」。诊断「启动动画结束」新增 `homeMs` 字段。
  - **标志是 1:1 描摹，不是手绘**：从 `AppIcon-Light-1024.png` 机器描摹（掩码 → 轮廓追踪 → 高斯平滑 → 密折线），渲染对原图逐像素 IoU 0.990、原图全部橙色像素落在 3px 邻域内；描边层画完**就地交叉淡入填充形**（Web 预览发现 `<mask>` 内 `stroke-dash` 在 WebKit 是坏的，App 侧用「可见描边 + 填充交叉」同构绕开），终帧恒为描摹本体。深浅色分别取自两块 AppIcon 的实测垂直渐变（Light #FE9108→#FE6705 / Dark #FC8F05→#FD6002），底色三处同源（系统启动屏 colorset / `.boot` 占位 / 动画层都取登录墙 backdrop）。
  - **结构**：AppDesignKit 新增 `OcMark`（描摹几何 + 预构建 Path）与 `LaunchStyle`（色板）；App 侧新增 `LaunchTimeline`（纯编排数学，每帧一个纯函数）、`LaunchPresenter`（门控/时钟/撤除）、`LaunchExperienceView`（逐帧求值渲染，Path 全静态预构建、每帧只改 trim/opacity/scale）；`RootView` 的 `.boot` 占位（cat.fill + 转圈）退役。**macOS 启动层挂独立覆盖窗口（`LaunchOverlayWindow`），主窗口系统 chrome 全程一次不碰**：一扇无边框透明子窗口（`addChildWindow`，自动随主窗口移动；尺寸/进出全屏由 `didResize`/全屏通知同步 frame 与圆角——AppKit 子窗口不自动跟随 resize，而覆盖层 `ignoresMouseEvents` 允许用户在动画期拖主窗口边缘/点绿灯）盖住整窗含标题栏，交棒时整窗淡出、主窗口（顶栏 + 首页成品）作为一张图被揭开，没有任何 chrome 跳变；主窗口 willClose 即拆链撤窗（hosting controller 强持 presenter，不摘会滞留到进程退出）。这么绕是有原因的——让**活的**窗口 chrome 来回变两条路都试过且都被实机否掉：SwiftUI `.toolbar(.hidden→.visible)` 销毁重建 NSToolbar，顶栏比首页晚 ~1s（「顶栏迟到」）；AppKit `NSToolbar.isVisible` 直控则三处时序堵不住（开局闪一下才收起、动画中途被壳层重建弹回、结尾恢复落空，用户实机三连报）。落地的五个坑：①承载用 `NSHostingController`——裸 `NSHostingView` 塞独立窗口内容树根本不建（sublayers 恒 nil，整窗只剩底色）；②`TimelineView(.animation)` 在这种非 key 子窗口**只渲染首帧、不推进**（实测整段停在 t=0、收尾时主窗口直接闪出），macOS 改 RunLoop 定时器 60Hz 自驱同一份 `evaluate`，iOS 仍用 `TimelineView`；③contentView 按 macOS 26 窗口圆角（实测 `_cornerRadius`=26）裁切并铺同款底色兜底首帧——不裁的话舞台四角是直角，和下面圆角主窗口对不上；④**淡出交给渲染服务器**：交棒时刻一排定（`onExitScheduled`）就在 contentView 根层**预提交**一个 `beginTime` 指向未来的 CA opacity 动画——commit 当场落进渲染服务器，之后主线程哪怕被首页装配堵死几秒，淡出也准点执行（实测主线程拥堵曾把交棒顺延 ~2.4s：排定 2.46s、实际 4.9s，用户看到 logo 多挂两秒多；日志「预提交淡出 delayMs」与「启动动画结束」时刻对照可复诊）；`onExitStart` 只作兜底（presentation opacity 已 <0.01 就跳过）。退场收尾任务睡的是 `exitStart − 排定时钟` 的**差值**——时间轴绝对时刻直接睡会把信号到达时刻叠进去，撤除 overlay/覆盖窗口与「启动动画结束」诊断整体迟到 readyAt 那么多（慢 bootstrap 时数秒，且 `durationMs` 已改为记实测墙钟时长）。macOS 的 SwiftUI 层因此不再自己做 `overlayOpacity` 淡出，整层（含底色兜底）作为一张图准时淡出、揭开主窗口；⑤氛围 hold 的**早到竞态**：池子比内容就绪先就绪（缓存命中）时 `onChange` 信号只来一次，先存后补（否则 hold 白等到上限，交棒后首页才补背景）。
  - **门控（本功能最大回归风险是验收台截图拍到标志）**：进程内只播一次（macOS 关窗重开不重播）；测试宿主静默跳过；自检通道（`OCPLAYER_START_SECTION` / `OCPLAYER_START_ROUTE` / `OCPLAYER_SELFTEST_FILE`、显式 `OCPLAYER_LAUNCH_ANIMATION=0`）一律跳过；新增 `OCPLAYER_LAUNCH_FREEZE_MS`（时间轴冻结逐帧截图）与 `OCPLAYER_LAUNCH_READY_MS`（钉住数据就绪时刻，配合能拍到慢启动呼吸态）；减弱动态播静态标志（淡入淡出、600ms 下限、无描边/呼吸/脉冲）。诊断记「开始/跳过(原因)/结束(时长)」，3.5s 未就绪记 warning。
  - **iOS 系统启动屏**：新增 `LaunchBackground` colorset（双外观）+ `UILaunchScreen.UIColorName`，关掉空白生成屏（`INFOPLIST_KEY_UILaunchScreen_Generation=NO`）——系统启动屏消失前的最后一块颜色 = 首帧颜色，无白闪。
  - **验证**：`LaunchTimelineTests` 逐帧钉子（描边/交叉/退场 + 氛围 hold 与首页骨架 hold 的就绪/上限/双门控共享上限）+ `OcMarkTests` 6 条几何钉子（包内）+ `LaunchPresenterTests` 状态机钉子（早到先存后补 / 迟到不回卷 / 重排只提前 / 退场按时间轴钟触发的实时回归）全绿；macOS scheme 全量测试绿；真机流程验证——冻结帧核对（描边中段/完整标志/呼吸态）+ 屏录像逐帧核对开窗无 chrome、交棒交叉淡化（中段帧能同时看到舞台与首页成品）；iPhone / iPad 真机安装由用户实测 iOS 端通过；iOS 模拟器构建后 `plutil` 校验产物 `UILaunchScreen`。

### 已知问题

- **高密度 CJK 字幕崩溃尚未修复，等待上游**（2026-11-06）。官方 Erika v0.3.0 在密集 ASS 素材上会因 18768 > 16384 的 Metal 纹理宽度断言退出，已用同源码对照确认属于内核问题。按本轮决定保留官方内核，不继续本地补丁构建或更改发版内核。应用层进度修复不改变这一已知问题。

- **`DanmakuKit` 内置的 `defaultAPIKey` 是「设计上公开」的，不要当泄漏去改**
  - 位置：`Packages/DanmakuKit/Sources/DanmakuKit/DandanplaySettingsStore.swift:23`。
  - 它随 App 分发、属公共额度，注释写在原地（「内置公共 API Key……开箱即用……属公共额度」）。**删掉或换成占位符会让所有用户的弹幕开箱失效**，而安全性没有变化——这是「看起来像漏洞、实际不能碰」的典型，写在这里免得下一轮又被当成新发现去修。

## [0.2.2] · 2026-10-24 · 全站 Liquid Glass 统一与设置页卡片流、选集选季分区、播放 HUD 让位灵动岛、片尾自然结束修复、批量性能优化

### 改动

- **iOS 播放 HUD 让位灵动岛/屏幕圆角：横屏侧边与竖屏窗口期顶部的控件不再画进系统禁区**
  （用户口径：「现在播放界面的 HUD 会有内容被灵动岛遮挡的情况，你看看怎么做适配」）。
  - **根因**：播放覆盖层整体无参 `.ignoresSafeArea()`（RootView）后子树内安全区归零，HUD 各锚点全是固定常量（顶距 14/22、水平 16/28、信息面板 70/82）——灵动岛机型横屏侧边禁区 62pt、竖屏（进播放锁横屏生效前的窗口期）顶部药丸带 62pt，顶栏两端 / 音量胶囊 / 底部进度条 / 右下动作簇 / 跳过按钮 / 信息面板都画进禁区；macOS 分支同位置有系统 chrome 让位（56/58），iOS 分支没有对应处理。
  - **方案**：结构不动（视频/黑底/弹幕照常全屏 bleed）。`RootView` 在 ignoresSafeArea 之外用 `onGeometryChange` 读 `safeAreaInsets`（转屏自动更新；macOS 不接值、结构性保持恒零），经 `\.playerChromeInsets` 环境值注入 PlayerScreen 子树；`PlayerChromeMetrics` 纯函数公式——顶部锚点 = `insets.top + 原呼吸值`，水平锚点 = `max(insets.leading, insets.trailing, 原值)`，**insets 全零时精确退化到原常量**（无刘海机型 / macOS 零回归）。垂直底距不动：home indicator 已被 `persistentSystemOverlays(.hidden)` 藏掉、无实体遮挡（单测钉死 bottom 不进公式，防将来双重让位）。
  - **验证**：`PlayerChromeMetricsTests` 5 条（零值回归把 8 个旧常量全部钉死 / 竖屏顶部平移 / 横屏侧让位 / 不对称取宽侧 / bottom 不进公式）；iOS + macOS scheme 全量测试绿；模拟器实测（iPhone 17 Pro，Debug 自检通道启动即播）横屏 insets = `top 0 / bottom 20 / leading = trailing 62`（`statusBarHidden` 下侧边禁区不归零）、竖屏 `top 62 / bottom 34`；像素级前后对比（GLM-5.3-Flash 审图，@3x）：四个侧边元素从 84px（28pt）全部让位至 186px（=62pt）±1px、左右对称、顶部元素不动；真机（iPhone 17）手测通过。
  - **未含**：弹幕层水平避让（横屏弹幕从侧边滑入会穿过灵动岛区域）与 HUD 是两套布局，另行处理。

- **片尾自然播完不再报 EOF：内核在片尾把「跨 EOF 的读」报成致命错误时，播放状态层直接按自然结束收口（临时兜底，根因在内核侧尚未修）**
  （用户口径：「现在片尾自然结束的时候会报 EOF，你看看有没有办法暂时处理一下」）。
  - **根因**：Erika v0.2.1 在请求边界跨过文件末尾时会间歇把「读到文件尾」报成致命错误（2026-10-09 iPad / 2026-10-12 桌面实测 `av_read_frame: Input/output error (-5)`，也见过 `audio output stalled at EOF`）——内核落 `playback_fatal`，事件流给到 `.failed` 或 `.stateChanged(.error)`。于是**自然播完**反而进 `.error`：UI 弹「播放出错」徽章、诊断记一条 error、`session.end` 的 `error_count` 被污染。上一轮修复（`13b5431`）只在**上报层**把片尾 `.error` 认成「播完」，保证连播/退出能发生；错误徽章与错误计数仍会短暂/持续出现，用户看到的「报 EOF」正是这一层。
  - **临时兜底（本次）**：`PlaybackKit.PlayerState` 新增 `endOfStreamToleranceSeconds = 2.0`，`apply(.failed)` 与 `apply(.stateChanged(.error))` 两条路都过同一道折叠——**片长已知且位置已进末尾 2 s 窗口**时，内核错误按自然结束收口成 `.stopped`：不置 `lastError`、不计 `errorCount`、不弹错误徽章；诊断每会话最多两条（两个标记分开记：`.stateChanged(.error)` 先到时先留一条不带 `code`/`message` 的，随后 `.failed` 带内核原文到达时再补一条细节行，避免把归因凭据抑制掉），字段 `code` / `message` / `position_ms` / `duration_ms` / `tolerance_s`，连续重发的错误风暴仍按 `lastFailedEventKey` 去重。判据**只看位置、不看错误文案**（文案跨内核版本会变，位置稳定：三次实机现场全部落在片尾前 0.4–0.5 s）；片长未知（0 = 直播 / duration 还没到）或位置还在 0（短片开头就出错）时不折叠，照旧报错——否则 `duration ≤ 2 s` 的片子会在 `position=0` 时满足 `0 + tolerance >= duration`，把**开头**的真故障也折叠成「播完了」。
  - **一处口径，不许分叉**：`PlaybackReportingCoordinator.isReachedEnd` 里写死的 `- 2` 改成引用 `PlayerState.endOfStreamToleranceSeconds`。折叠出的 `.stopped` 必须被上报层认成「播完」，否则会变成「没有错误徽章、也不连播/退出」的静默卡死。
  - **删除条件**：根因在内核侧（跨 EOF 的读应返回干净 EOF / 短读，而不是 EIO），等上游 Erika 修掉、升 `Config/Erika.version` 后，连同 `isAtEndOfStream` 与两处调用点一起删（常量注释里已写明）。
  - **验证**：`PlayerStateFoldingTests` 新增 10 条——片尾 `.failed` 折叠成 `.stopped` 且 `lastError=nil` / `errorCount=0`、片中 `.failed` 仍 `.error`、片长未知仍 `.error`、片尾 `.stateChanged(.error)` 同样折叠、状态迁移先到而 `.failed` 后到时保持 `.stopped`（内核原文不被抑制、状态不翻回）、容差边界（位置 = 片长 − 2 s，`>=` 命中）、窗口外 1 ms 仍报错、短片在 `position=0` 时不折叠、50 条错误风暴不改状态不计数、`reset()` 清折叠标记；`Scripts/clean.sh` → `swift test --package-path Packages/PlaybackKit` 全量 67 条 XCTest + 2 条 swift-testing 全绿，跑完再 `Scripts/clean.sh`（独立核验员复跑同一冻结树，并用「`>=` 改 `>`」反向验证确认恰有一条边界用例变红）。
  - **实机复核（2026-10-23，本机 Build 608 + 两台真机开发签名 Release，两条路都跑到了）**：①**macOS** 把进度条快速拖到片尾，内核确实又报 fatal（`code=3`、`playback error: demux worker error: ffmpeg error in av_read_frame: Input/output error (-5)`，位置 1424.715 s / 片长 1425.024 s）——兜底当场命中（两条 warning：一条带内核原文、一条来自先到的 `.stateChanged(.error)`），随后 `PlayerState -> stopped`、UI 全程无错误徽章、`session.end` 的 `error_count=0`，直接连播下一集并标记 Bangumi 已看；②同一操作在 **iPad mini 5** 上这次是干净收尾（内核 `decoder_eof_drain stage=complete` → `.stopped` → 连播），根本没有进折叠分支。结论：fatal 与干净 EOF 两条路都能正常连播，折叠只在需要时生效。

- **详情页选集区：「剧集」标题位改成选季控件；选集轨道按每 30 集切一个分区，长番不用再横着翻几百张卡**
  （用户口径：截图红框「剧集」→「红框选集改成右侧那个季的选框」；「做一个每三十集一个小分区一样，方便多集的番剧不用翻的很麻烦」）。
  - **标题位 = 选季**：`DetailView.seasonBar` 左侧的 `Text("剧集")` 删除，换成新的 `seasonSelector`——多季时就是原先右侧那个季菜单胶囊（当前季名 + `chevron.up.chevron.down`）搬到标题位，单季退回季名纯文本（不给只有一项的死下拉），季数据未到时用「选集」兜底；右侧原季菜单随之删除，同一件事不留两个入口，正序/倒序仍在右侧。
  - **每 30 集一个分区**：新增纯策略 `MetadataKit.EpisodeChunker` / `EpisodeChunk`（`Packages/MetadataKit/Sources/MetadataKit/Episodes/EpisodeChunks.swift`）——顺序切分、保序不丢格（`chunk(slots).flatMap(\.slots)` 与输入逐位相等）；分区标签取段内**实际存在的**首尾集号（`1-30`、`1001-1030`，只剩一集的尾段写 `61`），整段都是无 `IndexNumber` 的本地条目时才退回轨道位置号。`DetailViewModel.rebuildEpisodeSlots()` 改成单一出口：`episodeSlots` 与 `episodeChunks` 一起赋值（含「关掉占位」的早退分支），两者不可能漂开。
  - **单条轨道只渲染当前 ≤30 格**：新增 `EpisodeChunkBar`（`DetailComponents.swift`，胶囊复用 `AppDesignKit.OptionChip`），一季超过 30 集时出现在轨道上方；点分区只换轨道内容，**不改选中集**（顶部播放钮播的仍是选中集），分区胶囊只负责浏览。倒序时分区顺序与段内顺序一起反，等价于改动前的「整条轨道反转」。
  - **浏览状态是纯值类型**：`EpisodeChunkNavigation`（展示哪些分区 / 当前哪一段 / 渲染哪些格 / 手点越界忽略 / 倒序反序）收在 `MetadataKit` 与 `EpisodeChunker` 同文件，视图只剩 `@State` 一个字段与接线——这段是本次风险最高的逻辑，放在包里才能脱离 SwiftUI 单测（6 条用例）。
  - **落点与滚动**：默认停在选中集（VM 的 `preferredEpisodeID`，通常是第一个未看完的）所在分区，分区条会自动把当前段滚进视野（千集长番 ≈37 段时必须在屏内）；手点分区后只浏览，选中集一变（换季 / 点卡 / 播放回填）就回到「跟随选中集」。轨道身份 = 季 + 当前分区，变化时重建 `HoverArrowHScroll`，横向偏移归零——否则会停在上一分区的偏移上（点 31-60 却先看到 60）。
  - **验证**：`swift test --package-path Packages/MetadataKit --filter EpisodeChunkTests`（16 条纯策略用例：切点边界 0/30/31/61、保序、占位集号进标签、乱序 min/max 兜底、无编号兜底、非正 size、分区浏览状态的跟随/手点越界/倒序反序/越界渲染）+ `xcodebuild -project OcPlayer.xcodeproj -scheme OcPlayer-macOS -configuration Debug -destination 'platform=macOS' -derivedDataPath .local-build/current/DerivedData test -skip-testing:OcPlayerTests/DanmakuOverlaySpawnCostTests`（App 全量 705 条全绿、0 失败、19 skip；计时敏感的 `DanmakuOverlaySpawnCostTests` 在并行满载时会因机器争用超时，空载单跑 3 条全过）+ 新增 `OcPlayerTests/DetailEpisodeChunkTests`（3 条接线用例：35 集切两段且与轨道逐位一致、关占位早退分支照样切、≤30 集只有一段）。

- **全站内容卡统一为原生 Liquid Glass（基准是 MoviePilot 下载队列那套 `liquidGlassCard`；用户点名的搜索结果页卡片原先用的是 `.ultraThinMaterial` / 纯色底，观感相近但原语不同，本次一并收编）；设置页为此整体脱离 `Form`，改成 `ScrollView` + 玻璃卡片流（A 方案先试后被否，B 方案落地）**
  （用户口径：「moviepilot 的搜索结果、下载队列里面的这个是玻璃的效果，你再看看我们的设置、bangumi 等等都不是玻璃的效果，
  我想让他们都跟下载列表的一样，使用玻璃效果的」；看到 A 方案实机效果后追加：「现在效果太差了，你上方案 B 吧」）。
  - **实现（先把散落的卡片收编到同一原语，再换设置页承载）**：
    - **内容卡统一**：Bangumi 四页（`BangumiHomeView` / `BangumiCalendarView` / `BangumiSubjectDetailView` /
      `BangumiChapterSection`）与详情页 `DetailMediaInfoSection` 的内容卡，从 `.ultraThinMaterial` / `.fill.quaternary`
      换成 `liquidGlassCard`；MoviePilot 资源页原先**三处各说各话**——
      `MoviePilotResourceView` 媒体卡是 `.ultraThinMaterial` + 0.12 手绘描边、同文件种子卡是 `primary .04`
      纯色 + 0.08 描边、`MoviePilotResourceSection` 入口卡是 `.fill.quaternary`——三处收编到同一原语。
      `HoverFeedback.swift` 的 `hoverRowHighlight` 底也从 `.ultraThinMaterial` 换成玻璃，**悬停信号因此改道**：
      玻璃会把叠上去的填充当背景吃掉（实测 `primary .08` 在玻璃上不可见），所以提亮改成 overlay 里的内容层
      6% `primary` 填充 + accent 0.35 描边，交互态由 `liquidGlassCard(isInteractive:)` 自己给。
    - **圆角统一（2026-10-22 追加口径「圆角统一一下」）**：`liquidGlassCard` 的圆角默认值改成新 token
      `Metrics.glassCardRadius = 16`，全站**顶层内容卡**一律用它、调用点不再各写一个数——原先散落着
      10（`Metrics.cardRadius`）/ 12 / 14 / 16 / 18 / 24 六档，同一张卡在不同页里轮廓会跳。
      另立**「小格档」**`Metrics.glassNestedRadius = 8`：给**尺寸明显更小、密集排布**的次级格子用
      （Bangumi 条目详情的「作品信息」格与「全站收藏概况」统计格 —— 都是 `EqualRowHeightGrid` /
      `LazyVGrid` 里的 40–60pt 高小格，用 16 会圆得过头）；`Metrics.episodeCardRadius` 也锁到同值 8
      （选集格与上述小格在页面上是同一档密度，并排时圆角不能打架）。
      **注意这 8 不是一个「同心圆角」公式算出来的**（16 + 内边距 8 → 8）：那些小格并不嵌在玻璃卡内部，
      而是直接排在页面级的 VStack 里；资源页的种子卡与资源入口卡用的都是默认 16（它们是列表里的顶层卡）。
      所以两个 token 的判据是**元素尺寸**（顶层卡 16 / 密集小格 8），不是嵌套层级。
      无圆角字面量残留：`grep "liquidGlassCard(cornerRadius: [0-9]"` 为空。
    - **B 方案（设置页）**：新增 `Packages/AppDesignKit/Sources/AppDesignKit/Controls/SettingsGlassCard.swift`——
      `SettingsGlassPage`（`ScrollView` + 卡片流 + `contentLeading` 留白 + `pageMaxContentWidth` 居中）、
      `SettingsGlassSection`（段标题 + 一整块玻璃卡 + 段脚）、`SettingsGlassCard`（`liquidGlassCard` + 0.5pt 描边，
      **行高由承载层统一施加**，调用点不用逐行补）。`SettingsCardRowLayout` 把卡内子视图分三档行角色：
      `row`（操作行抬到最小行高：iOS 44 → 行距 58；macOS 30 → 行距 42）、`note`（附注只留 4pt）、`inline`（分隔线零间隙）。
      行件重写 `Form` 专有的「标题 + 行尾控件」形态：`SettingsRow` / `SettingsPickerRow` / `SettingsTextRow` /
      `SettingsFieldRow`（带 `textContentType` / 禁自动更正等链式修饰的输入行：行形态交给原语、控件原样传入）/
      `SettingsActionRow`。`settingsToggleStyle()` 补一个坑：macOS 的 `Toggle` 脱离 `Form` 后会退化成
      **复选框**，这里做成行尾开关（iOS no-op）。`SettingsGlassDivider` 自绘 1 物理像素线、leading inset 对齐文字左缘
      （`Divider()` 的取向由父栈决定，在自定义 `Layout` 里会失效，故自绘）。
    - **迁完的范围**：设置 hub、10 个子页、管理服务器、开源许可证详情全部换成 `SettingsGlassPage` / `SettingsGlassSection`；
      `OpenSourceLicensesView` 的**条目列表仍是系统 `List`**（没换成玻璃卡片流，只摘掉旧的 `settingsCard()` 行底），
      真正换承载的是它的详情页。`settingsCard()` /
      `settingsSectionSpacing()` / 旧卡底原语 `SettingsCardFill` 及其令牌 `cardFillDarkOpacity` / `cardFillLightOpacity`
      与三条钉它们的不透明度用例**一并退役删除**（`Packages/AppDesignKit/Controls/SettingsCard.swift` 已删）；
      `SettingsMetrics` 新增卡相关令牌：`cardContentInset` 16 / `cardContentVerticalInset` 6 / `cardCornerRadius` 16 /
      `cardRowMinHeight` / `sectionHeaderSpacing` / `sectionHeaderInset` / `pageTopInset` / `pageBottomInset` /
      `pageMaxContentWidth` / `cardTrailingFieldMaxWidth`；macOS 的 `rowVerticalInset` 由 0 改 6，与 `cardRowMinHeight` 30
      合成 42pt 行距；`SettingsNavRow` 走的 `settingsRow()` 内容最小高也同步换成 `cardRowMinHeight`（它仍负责 Button 热区），
      与承载层叠加后行距不变。**同一张卡只有一层玻璃**：卡内小件（图标、按钮、色板）保持纯色 tint，不再叠玻璃——玻璃不能取样玻璃。
  - **A→B 的判例（先试 A，实机后被否，不是「A 再修修」）**：A 方案是保留 `Form`、把每个 `Section` 的内容包成
    `SettingsGlassCard`（一段 = 一个 List 行 = 一整块玻璃）。工装 `/tmp/glass-spike`（macOS 26.6 (25G72) + Xcode 27.1；
    iOS 26.3 模拟器、iPhone 17 Pro 运行时）逐页截图 + 像素判据给出三条硬结论：① **macOS 的 grouped `Form` 根本不执行
    `.listRowBackground`**——诊断页连不透明品红都不画，A 组与纯 `Form` 对照组**全帧 98.6% 的像素完全一致**；这也正是仓库里
    `settingsCard()` 当年只能写 `#if os(iOS)` 的真正原因。② **iOS 能画，但逐行各画一块**——行界出 **3px 暗线**
    （luma **233.5 → 216.6**）、圆角缝里透出原始氛围底、系统分隔线压在玻璃顶上，相邻两行的独立玻璃拼不回「一张卡」
    （玻璃不能取样玻璃）。③ **macOS 上 `Form` 自己给 section 加 13–14pt 侧缩进**，卡比目标窄 **26pt**；负 padding 会裁字
    （「媒体服务器」缺首字）、负 `listRowInsets` 被接受但不生效。两边都做不到「一整段一张玻璃」→ 设置页整体换承载。
  - **代价（认下来的）**：丢掉 `Form` 的键盘焦点漫游、List 的行分组无障碍语义、`DisclosureGroup` 的原生行样式
    （控件仍可用，只是不再是 Form 行那套观感）、`Picker` / `TextField` 的系统行尾布局（改由行件显式给出，
    也就多了一层「漏一个样式就长歪」的风险）。
  - **已知取舍（浅色下比旧卡更实）**：玻璃在浅色下等效不透明度 **0.60–0.65**、透出度 **0.35–0.44**，而原先
    「白 0.30」的透出度是 **0.70**——即浅色下这次比旧纯色卡更不透明。深色下 `.regular` 会把卡往下压 **−48.8**、
    `.clear` 更透（**+23.4**）；最终仍取 `.regular` 与下载页保持一致，浅色偏实这点作为**已知取舍**记录，本轮不再调档。
  - **真机实测补丁（装机后立刻暴露、离屏测试与模拟器都测不出）**：装机到 iPhone 17 Pro（真机）后，设置页有**两处
    可读性问题**，都是「玻璃不是实心底」带来的、改造前在 `Form` 的实色行底上不存在：
    ① **段标题**（`.secondary` + `.footnote`）压在**氛围照片**上——实测「网络缓冲」那一行字与底只差
    **~2 luma**，等于消失；改成 `.primary`（与首页/MoviePilot 压在氛围图上的栏标题同一口径）后恢复。
    ② **卡内说明小字**（`SettingsNote` / 段脚）原来是 `.tertiary`——压在玻璃上直接糊成一片，提到
    `.secondary` 仍偏淡（玻璃自己会把底提亮，前景与底的绝对差被压缩），最终用**显式 `primary` +
    0.82 不透明度**（不用语义层级：`.secondary` 是「前景 60%」且会被玻璃二次稀释）。
    两处都写进 `SettingsNote` / `SettingsGlassSection` 的注释，标明「判据是看不看得清，不是语义层级听起来对不对」。
    这条同时说明**离屏 UI 测试的方法论上限**：`glassEffect` 不进离屏渲染，合成后的对比度只能在真机上量
    （见 `AppTests/SettingsLayoutTests` 类注释）。
  - **被推翻的旧判例**：① 2026-10-13「设置界面『向 Rex 靠』」里的「**为什么不用 material / glassEffect**」一节
    （本次插入前 `CHANGELOG.md:2058-2061`）——那条的论据是「亮色透出度 0.37 < 白 0.30 的 0.70」，比较对象是 material、
    且默认接受了「白 0.30 纯色卡」这个前提；本次用户明确要求换玻璃，A 方案又实测证明「卡」在 `Form` 里做不出来，故改判。
    ② 同条末尾「**未做**：Liquid Glass 卡片（本仓规格要求『用户明确要求才上』）」（本次插入前 `CHANGELOG.md:2072`）——
    **本次即该明确要求**，前提已满足。行号按插入前文件计（本条目插在 `[Unreleased]` 顶部，之后行号整体下移）。
  - **验证**（可复现的判据与入口）：① 工装逐页像素：A vs 纯 `Form` 全帧 **98.6%** 像素相同、iOS 行界 **3px** 暗线
    （luma **233.5 → 216.6**）、macOS 卡窄 **26pt**（`Form` 段侧缩进 **13–14pt**）；② **孪生对照**——工装页 J＝`Form` 承载 /
    K＝`ScrollView` 承载、同一段内容：iOS 上卡 bbox 完全一致、卡内 RGB 差 **< 1/255**、卡外与纯氛围底
    **mean|diff| = 0.00**（记在 `SettingsGlassCard.swift` 文件头）；③ 观感数据见上（0.60–0.65 / 0.35–0.44 / 0.70 / −48.8 / +23.4）；
    ④ **氛围回归闸门不变**：承载换了、氛围挂载点没换，`Scripts/verify-ambience.sh --pages ios.settings` 的判据与期望值不变
    （见 `Docs/AMBIENCE.md` §二/§四，本次只补注、判据未改）；⑤ 本轮是纯视图层重排，未新增业务逻辑与新用例；
    旧 `AppTests/SettingsLayoutTests` 对 `Form` 的前提已不成立，适配与两端构建/全量跑分随本批另记（本条不写未经实跑的数字）。

- **导航栏图标统一成「选中 = 品牌原色 / 未选中 = 灰」（Bangumi、MoviePilot、首页头像三格，iOS + macOS）**
  （用户口径：两个 logo 现在只有「选中白一点 / 未选中灰一点」，要改成和首页一样 —— 选中是 SVG 原本的
  logo 色、未选中是灰；随后追加「这个也要改哦，macOS 端的」；问清范围后确认「三格统一」）。
  - **macOS（顶栏药丸，纯 SwiftUI）**：`AppShellSectionGroup.Segment.Icon.brand` 从 `(String, side)`
    扩成 `(name:colorName:side:)`，新增 `SectionBrandIcon` 按状态切
    `.renderingMode(isSelected ? .original : .template)`。Bangumi 的彩色是另一份渐变资产
    （`bangumi-logo-color`，同一 viewBox 的同一 glyph），MoviePilot 的彩色本来就在同一个 SVG 里
    （`colorName == name`，只换渲染模式）。**资产层一个字没动** —— 两个 imageset 的
    `template-rendering-intent` 仍留给设置页行图标与详情页外链用。未选中态与改动前**逐像素同款**
    （模板 + `.secondary`），只有选中那一格从单色变成品牌色。
  - **iOS（底部标签栏）**：SwiftUI 的 `Tab` 只吃一张图，**没有任何 SwiftUI 侧的表达方式**（三条实测
    否证见下），只能下到 `UITabBarItem`。新增 `App/Shared/TabBarBrandIconBridge.swift`：一个挂在
    `TabView.background` 上的 `UIViewControllerRepresentable`，找到宿主 `UITabBarController`，按**标题**
    把三个槽位的 `image`（模板，吃系统未选中色）/ `selectedImage`（品牌原色，`alwaysOriginal`）换掉。
    标签栏本身仍是系统那一个 —— 几何、玻璃底、搜索栏展开、iPad 尺寸类适配、无障碍全不动，没有自绘标签栏。
  - **首页头像也一起纳入**：iOS 原先头像两态都是彩色（选中反馈只靠系统玻璃胶囊），现在未选中用
    `AppModel.grayscaleTabIcon(from:)` 烤一张去饱和的位图（Core Image `CIColorControls(saturation:0)`，
    **只抽饱和度不动亮度**，与 macOS 药丸 `.grayscale(1)` 同口径）。头像没设的账号不接管，仍走系统
    `house.fill`（它本来就靠前景色亮暗区分两态）。
  - **三条被实测否证的 SwiftUI 路子（写进注释与 Reports，别再试）**：① label 里套
    `.grayscale` / `.saturation` / `.opacity` / `if isSelected` —— 标签栏只取底层位图，绘制修饰符在交给
    标签栏前就被丢掉（探针实测加与不加逐像素相同；条件视图还会画出黑圆角块，这是既有实拍约束）；
    ② label 里套 `.renderingMode(.original)` 能保色但**两态都彩色**（标签栏不对 `alwaysOriginal` 灰化）；
    ③ `Tab(..., image:)` 传彩色资产同理两态都彩色。
  - **踩到的三个坑（每个都实拍复现过）**：① **注入的图会被 SwiftUI 重置** —— 头像到达会换掉
    `compactTabs` 的「有无头像」两条分支，标签栏项被重建 / 被重置回 label 那张彩色图，而
    `updateUIViewController` 是在**之前**调的。→ `viewDidAppear` 与 `updateUIViewController` 里各排一串
    **有界**补拍（0.1 / 0.3 / 0.8 / 1.6 / 3.0 s），全部结束即停，不是常驻轮询。
    ② **不能拿「实例是否同一个」判断要不要写**：`UITabBarItem` 的 setter 会**拷贝**图片，写进去的对象
    与读出来永远不是同一实例 → 每次调用都判成「没生效」（日志里 `applied=0`，图其实换好了）。
    ③ **也不能拿关联对象当「已接管」记号**：SwiftUI 会**复用同一个** `UITabBarItem`、只把 `image` 重置回
    彩色，对象没变、记号还在 → 判成「已接管」，首页那格又变回彩色（浅色外观实拍抓到）。最终是
    **无条件重设**，代价可忽略（只在标签栏相关的更新时调用，不是每帧）。
  - **验证**：新增 `SectionBrandIconTests`（8 条，`ImageRenderer` 真渲染 App 真实资产量像素：选中态通道
    极差 0.63 / 0.61、未选中在**纯绿探针前景色**下必须变成探针色（证明模板语义，而不只是「是单色」）、
    生产上下文的单色、两态外接框同尺寸、`makeSegments` 的资产接线、三个资产可解析）、
    `AppModelAvatarTests` 新增 1 条（灰化头像去饱和但亮度不变 + 仍裁圆 + 仍 `alwaysOriginal`）、
    `TabBarBrandSlotTests`（3 条，钉住「哪些标题被接管」）。
    **用例本身做了反向变异复验**（故意改坏看红不红），据此补掉三个漏抓面：① 未选中判据原先是「平均
    通道极差≈0」，Bangumi 的 SVG 自带 `#e6e6e6` 浅灰，误用 `.original` 时**照样绿** —— 改用纯绿探针
    前景色后同一条变异 3 条红（详见 commit `ee3a1a6` / 本节下方）；② 所有渲染用例都直接构造
    `SectionBrandIcon`，把 `makeSegments` 里 Bangumi 的 `colorName` 改回单色资产时 6 条**全绿**
    （渲染对、配置错）—— 补接线用例；③ `Image` 不可失败，资产名写错只渲染成空 —— 补资产可解析用例。
    **端到端链路验收**：给模拟器喂一个本机假 Jellyfin（`/Users/Me` 带头像 tag + `/UserImage` 吐测试头像），
    用 Debug-only 的 `OCPLAYER_START_SECTION` 深链直落四个分区逐张实拍 —— iPhone 17 Pro / 深色：首页选中
    头像彩色、Bangumi 选中洋红 `(254,91,161)`、MoviePilot 选中紫色渐变、设置选中时首页头像灰化（通道极差
    254 → 0）；浅色外观四个状态同样逐格取样、iPad Pro 13″（标签栏在底部）各拍一张。macOS 侧还做了
    **装机验收**：`SKIP_ERIKA_FETCH=1 Scripts/build-macos.sh debug`（v0.2.1 Build 598）用 `ditto` 覆盖到
    `/Applications/OcPlayer.app`，再直落四个分区实拍药丸。截图与做法见 `Reports/tab-icon-color-20261022/`
    （本地 gitignore 目录）。跑分：macOS `OcPlayerTests` **701 通过 / 0 失败 / 18 跳过**（唯一用例 719）、
    `OcPlayerTests-iOS` **724 通过 / 0 失败**。

### 修复

- **「后退 10 秒 / 前进 10 秒」每次都把进度条甩到片尾**（用户 2026-10-17 报的现场：播放中按后退 10 秒，进度条直接跳到结尾）。`PlaybackController.skip(by:)` 的落点单位混了：`state.position` 是 µs，`target = position.microseconds + seconds * 1_000_000` 也是 µs，但片尾安全边际那次改动把它**当成秒**去跟（秒口径的）`duration` 取 min —— `clampedBeforeEnd(540_749_000, duration: 1426.45)` = `min(5.4e8, 1423.45)` = **1423.45**，于是**任何一次** ±10 秒都落到「片长 − 3s」。实机日志逐字对上（`~/Library/Logs/OcPlayer/diagnostics-20261017-143331-a8b3cdfa.jsonl`，FX战士久留美 S01E03 / duration 1426s）：`kind=skip from_ms=540749 to_ms=1423450`，紧跟着 `PlayerState -> stopped`；同一会话里 4 次 skip 的 `to_ms` 全是 `1423450`，而同一时段的 `scrub`（走 `seek(toFraction:)`，µs 口径自洽）落点一切正常。引入点是 `b40608c`（2026-10-13，把四散口径收成 `clampedBeforeEnd` 的那次），**未进任何 tag**（`v0.2.1` 之后才有），此前 v0.2.1 及更早的 `min(target, duration − 500_000)` 两侧都是 µs、其实是对的。**修法**：先把位置换算成秒，钳完再一次性 `seek(to: .seconds(landing))`，全链路只留一个口径。**验证**：`SkipPreferenceTests` 新增 4 条（后退/前进各 10s 的精确落点、片头不落负值、越过片尾仍钳到片长 − 3s），其中后退那条直接用实机数值 `duration=1426.450s / position=540.749s → 530.749s` 钉死；macOS 全量用例全绿。

- **测试不再读写开发者本机的真实数据与偏好**（处理上一轮 iPad 验收时发现的隔离缺口）。
  - **现象**：`AppTests` 跑在 **App 宿主进程**里（`TEST_HOST = OcPlayer.app`），宿主照常装配真实存储与真实偏好 —— 跑完一次 macOS 全量用例，`~/Library/Application Support/OcPlayer/` 下 `credentials.json`、`Media.sqlite-wal`、`Bangumi.sqlite-wal` 与真实偏好 plist 的 mtime 全落在测试窗口内。逐键比对确认凭据**内容没坏**（只是 JSON 键序被重排），但一个会写开发机凭据文件的测试套件迟早会把它写坏。
  - **开关**：环境变量 `OCPLAYER_ISOLATED_STORAGE=1`，收在 `OcPlayerStorage.isIsolated`。打开后存储根 → `临时目录/OcPlayerAutomation`（凭据 / 各 sqlite / 图片缓存 / 弹幕 / 字幕），App 偏好默认域 → 隔离根下的独立 plist（`UserDefaults(suiteName:)` 认「像路径的名字」，于是也不在 `~/Library/Preferences` 留垃圾）。生产不设它 → 默认域仍是 `.standard`，行为零变化。
  - **接线**：新增 `OcPlayerStorage.defaultPreferences` 作为 App 偏好默认域的单一入口 —— `ServerStore(defaults:)`（App 侧默认参数）、`AppModel(preferences:)`、`BangumiStore.shared`、`MoviePilotStore.shared`、`DandanplaySettingsStore`、`AppUpdateChecker.shared`、`HomeRailPresence`、`DiagnosticsSettings` 全走它；两个 scheme 的 TestAction 设上变量。包内 `init(defaults:)` 的公开默认值**没动**（只改包内单例的构造点），对外 API 不变。
  - **踩到的坑（已写进 scheme 注释）**：TestAction 的 `shouldUseLaunchSchemeArgsEnv` 原本是 `YES`，含义是「测试沿用 **Run 动作**的参数与环境变量」—— 于是加在 TestAction 里的隔离变量被**静默忽略**，第一次复跑真实文件照写。两个 scheme 的 Run 动作本来就没有参数/环境变量，改成 `NO` 不丢东西。**以后往 TestAction 加变量，先确认这一位。**
  - **边界（写在 `defaultPreferences` 的类型注释里）**：视图层 50 处 `@AppStorage` 仍读 `.standard`（那些键只在用户真去点开关时才写，测试不点）→ 隔离运行下真实偏好 plist 的 **mtime 仍会被刷一次，但内容逐值一致**（`defaults export` hash 不变）。日志目录此前已由 `RuntimeEnvironment.isRunningTests` 隔离（写临时目录），不在本次范围。
  - **验证**：跑前跑后对真实数据目录（mtime + 凭据逐键 hash）与真实偏好域（导出 hash）做快照 —— macOS 全量用例期间**数据目录 diff 为空**，测试产物全部落在 `临时目录/OcPlayerAutomation`（`Danmaku/`、`ImageCache/`、`Subtitles/`、`preferences.plist`）。跑分：iOS 596 条 0 失败、macOS 578 通过 / 0 失败 / 18 跳过；被改动的三个包（DiagnosticsKit / BangumiKit / MoviePilotKit）包测试各自通过。

- **`AppModelAvatarTests` 只能在 @3x 机型上过的既有缺陷**（上一轮 iPad 实拍时暴露）：用例把烤出来的标签栏头像断言成 `userAvatarPixelSize`（＝按 @3x 估的 84px），而 `tabIcon(from:)` 按**屏幕 scale** 栅格化 —— iPad 是 @2x、实测 56px，于是把 destination 换成 iPad 模拟器当场红（CI 一直跑 iPhone，所以一直没暴露）。位图的**自然尺寸**两档都对（都是 28pt），功能无碍。改成「像素数 = 点尺寸 × 屏幕 scale」＋「烤图密度与 `UIGraphicsImageRendererFormat.default().scale` 一致」；顺带把 `userAvatarPixelSize` 与 `tabIcon` 里两处「正好 28pt @3x = 84px」的表述改成两档都写明 —— 那个常量是**取图下采样预算**，不是烤图尺寸。

- **iPad 只让标签栏走 iPhone 形态，内容全部回 iPad 版式**（用户口径：「**tabview 保留 iPhone 样式的，但其他所有都保持 iPad 的**，这是 iPad 端的目标」）。上一条「iPad 整个走 iPhone 版式」做过头了：外壳为了让标签栏落到底部，把 `TabView` 整棵子树的 `horizontalSizeClass` 钉成了紧凑档，而**环境是向下继承的** —— 页面读到的也成了紧凑档，于是 iPad 上首页 rail、媒体库（13″ 横屏 **12 列**）、详情页（290pt 通栏横幅 + 通栏播放钮 + 20pt 留白，即「iPad 端怎么详情页也变成了 iPhone 的样式了」）、设置卡片全被降级成放大版 iPhone。
  - **口径按「层」切开**：同一个纯函数 `ShellSizeClass.resolved(idiom:actual:layer:)` 有两个 `Layer` —— `TabView` **自己那一层**（`.tabBar`）iPad 恒紧凑（标签栏因此落到底部，这是钉尺寸类的唯一目的），**内容那一层**（`.pageContent`）原样返回设备真实宽度。
  - **实现**：`TabView` 那层保留 `.environment(\.horizontalSizeClass, shellSizeClass)`；每个 Tab 的内容挂 `.pageContentSizeClass(contentSizeClass)` 换回真实值（Tab 根页与 `appRoutes()` 推出来的页都在这棵子树里，新增页面不用各自补）。横向留白 `contentLeading` 同步改回跟**内容**层走（iPad 52pt / iPhone 22pt）—— 内容不降级，留白也不该降级，否则会出现「iPad 版式 + iPhone 留白」的错位。
  - **验证**：`ShellSizeClassTests` 改写为 4 条 —— 标签栏层 iPad 恒紧凑（常规 / 分屏紧凑 / nil 三种输入）；内容层 iPad 原样（`.regular` 保持、分屏 `.compact` 也不是被强制的）；iPhone 两层都不动；外加一条**渲染探针**用例，把「外壳紧凑档已继承下来 → 内容层换回真实值」这条链原样搭出来（含反证：不挂内容层那一句读到的就是紧凑档），从视图体内读回实际生效的值（`ImageRenderer`）。判据取渲染后实际生效的环境值而不是常量：iPad 版式的全部分叉（rail 尺寸、网格列数、详情页头部与留白）都由它决定。跑分：`OcPlayer-iOS`（iPhone 17 模拟器）**596 条 0 失败**、`OcPlayer-macOS` **578 通过 / 0 失败 / 18 跳过**。
  - **一条与本改动相关、已在紧随其后一批里修掉的用例缺陷**：destination 换成 iPad 模拟器时 `AppModelAvatarTests.testTabIconBakesCircleSizeAndRenderingMode` 会红 —— 它断言烤出来的图标是 `AppModel.userAvatarPixelSize`（写死 `28 × 3 = 84`，@3x 口径），而 iPad 屏是 @2x，实测 56。功能无碍（图片自然尺寸仍是 28pt），是该用例只能在 @3x 机型上成立；CI 跑 iPhone 所以一直没暴露。修法与跑分见上面「`AppModelAvatarTests` 只能在 @3x 机型上过的既有缺陷」那条。
  - **实拍判据（本次唯一靠推理定不了的一步）**：给 `TabView` 那层钉紧凑、把**内容**换回常规，标签栏会不会被内容顶回系统默认的顶部胶囊？先用最小探针 App 在 iPad Pro 13″ / iPadOS 26.3 模拟器确认（标签栏仍在底部 + 内容层读到 `.regular`），再用**真服务器 + 真账号**跑整机 A/B：同一个构建、同一台设备、同一条目，只把 `contentSizeClass` 临时换回 `shellSizeClass`（复现改动前形态）重建对照 —— **详情页** 290pt 通栏横幅 + 剧名居中 + 通栏播放条 ➜ 左竖版海报 + 横排元数据 + 小胶囊钮；**媒体库** 9 列小卡 ➜ 4 列大卡；**首页**与**设置**同为 iPad 档；底部标签栏在两种状态都在底部。截图与做法见 `Reports/ipad-content-layout-20261016/`（本地 gitignore 目录）。

### 性能

- **承接上一批那句「`P2-29` 下一批应当先给它一个计数器量级，再决定改不改」**：
  本批已按该指令做完 —— 量化方式与结论见下面 `P2-29` 那条。
  （上一批那段文字属于已合并的历史记录，**不回改**；在此注明它已被执行。）

- **`P2-29` 关闭后的台账终态（承接上一批的「1 待办」）**：
  上一批那张表里 `P2` 的「待办 1（`P2-29`）」现已关闭，故终态为
  **51 已修 · 27 判定不改 · 0 待办（合计 78）**：
  `P1` 16/1/0、`P2` 20/20/0、`CORR` 8/1/0、`BLD` 5/3/0、`LIVE` 2/2/0。
  （上一批表格保留原样不改历史记录，本段是增量说明。）

- **`P2-29`（`collectionArtwork` 的 `@Observable` 依赖粒度）：实测后判定不改。**
  - **机制属实**：`collectionArtwork` 是 `@Observable` 的普通存储属性，
    `LibraryView` 的 `LazyVGrid ForEach` 里每张卡都在 **`PosterCard(...)` 的实参位置**
    调 `app.collectionPosterURL(for:width:)`（读 `collectionArtwork[item.id]`）。
    `@Observable` 的依赖登记是**属性级**的（方法内读同样登记），而 `PosterCard`
    **既不是 `Equatable`、网格也没挂 `.equatable()`** —— 所以任一写入都会让
    **所有已挂载卡的 `body` 真的重跑**（整棵 `Button/VStack/MediaArtwork/Text`
    加修饰符全部重建，不只是那两个纯函数）。
  - **量化（每一条都给出方法，便于复算）**：
    - `collectionPosterURL` 的完整调用链（字典查 + `nearest(to:)` + 现建
      `URL(string:)`）单次 = **1.38 µs**。方法：独立 `swiftc -O`，40 键字典，
      5 轮 × 2 万次取最优。**取的是三次测量里最保守的**（我本机另测两次得
      0.776 / 0.951 µs —— 说明这个量对测法敏感，故按最不利值给结论）。
    - 总可消除量 = `R × M × 1.38 µs`：

      | 场景 | 总成本 |
      |---|---|
      | R=12、M=20（浏览一屏 + 少量滚动） | **0.33 ms** |
      | R=20、M=50 | 1.38 ms |
      | R=20、M=100 | 2.76 ms |
      | R=30、M=200（快速扫过大量合集） | **8.28 ms** |

    - **真正该看的是「同一帧内最多几次写入」**：解析器有
      `collectionArtworkConcurrency = 2`，所以**同帧最多 2 次写入**
      （这比「缓存命中也要毫秒级」那种推测性论据硬）。
      单帧不可消除的纯计算 = `2 × R × (0.776 + 1.46) µs`：

      | R | 单帧纯计算 | 占 16.7 ms 帧预算 |
      |---|---|---|
      | 12 | 54 µs | 0.32% |
      | 20 | 89 µs | 0.54% |
      | 30 | **134 µs** | **0.80%** |

      （`+1.46 µs` 是 `PosterCard.body` 里的 `item.imageTarget(...)` —— `P2-20` 已实测。
      注意它**即使 `posterOverride != nil` 也照样算完再丢弃**，属白付。）
  - **判定：不改。** 两个理由：
    ① **单帧占比上限 0.8%**（按并发上限 2 与最不利单价算），远低于任何可感知阈值；
       总可消除量 8.28 ms 是**跨数百毫秒的累积**，不是单帧尖峰。
    ② 与已归档的 `P2-19`（5.13 µs/行）/ `P2-20`（1.46 µs）/ `P2-27`（1.41 µs）
       **同一量级与同一口径**。
  - **但「只能靠架构改动」是假二选一，如实记下两条更小的选项**（本批未做，因为
    台账口径是「µs 级判不改」，做了反而与既有口径不一致；留档给后来者）：
    ① **`noteCollectionArtwork` 没有同值去重** —— 详情页每次 `loadCollectionOverlay`
       的 `apply` 都无条件写（`DetailViewModel.swift:547`），一次进页最多两次**同值**写
       → 两次全网格失效。加 `guard collectionArtwork[itemID] != posterPath else { return }`
       即可，**两行、语义不变**。
    ② **让 `PosterCard` 实现 `==`**（比 `item.id` / `width` / `posterOverride`，忽略 `onTap`）
       + `.equatable()`，未变的卡直接跳过 body 重跑 —— 也是局部改动。
    两条都不是架构级。真要动手时从 ① 开始最划算。
  - **⚠️ 我在这条的量化上错过两次，都记下来**：
    第一版表格用 ~0.64 µs、正文却写 0.951 µs（**表与公式差 1.5 倍**，被审查用
    「反推单价四行都落在 0.63–0.65」当场抓住）；
    又把「一次重算的成本」说成 `0.951 + 1.46 = 2.41 µs`，但那是**两个纯函数**，
    真实重算还包含整棵视图树 —— 所以上表的绝对量应读作
    **「不可消除纯计算的下限」**，不是整卡重算成本。结论（不改）不受影响，
    但这两处口径都必须写准。

- **`P2-29` 关闭后的台账终态（承接上一批的「1 待办」）**：
  上一批那张表里 `P2` 的「待办 1（`P2-29`）」现已关闭，故终态为
  **51 已修 · 27 判定不改 · 0 待办（合计 78）**：
  `P1` 16/1/0、`P2` 20/20/0、`CORR` 8/1/0、`BLD` 5/3/0、`LIVE` 2/2/0。
  （上一批表格保留原样不改历史记录，本段是增量说明。）

- **`P2-29`（`collectionArtwork` 的 `@Observable` 依赖粒度）：实测后判定不改 —— 最后一条待办关闭。**
  - **机制本身是真的**：`collectionArtwork` 是 `@Observable` 的**普通存储属性**，
    而 `LibraryView` 的 `LazyVGrid ForEach` 里**每张卡**都调
    `app.collectionPosterURL(for:width:)`（它读 `collectionArtwork[item.id]`）。
    `@Observable` 的依赖粒度是**属性级**，所以任何一次写入都会让**所有已挂载的卡**重算。
    而写入点是 `noteCollectionArtwork`（每次合集海报解析完成写一次）——
    用户滚动扫过 M 张合集卡就是 M 次写入。
  - **按审查的建议先量化，再判定**（此前我含糊地写「需真机 Instruments，本机无该手段」，
    那是错的；本仓明明有计数/基准机具）：
    - 单次 `collectionPosterURL` = **0.951 µs**（release，字典查 + `TMDbImageSize.url`
      现建 `URL(string:)`；与已判不改的 `P2-20` 的 1.46 µs 同族）。
    - 总可消除量 = R × M × 0.951 µs：

      | 场景 | 总成本 |
      |---|---|
      | R=12、M=20（浏览一屏 + 少量滚动） | **152 µs** |
      | R=20、M=50 | 638 µs |
      | R=20、M=100 | 1.28 ms |
      | R=30、M=200（快速扫过大量合集） | **3.90 ms** |

    - **⚠️ 我第一版把「单次重算成本」算低了，这里更正**：`0.951 µs` 只是
      `collectionPosterURL` 这一句。但 `LibraryView` 里它是在 `PosterCard(...)` 的
      **参数位置**调用的，所以一次重算要连带重跑整个 `PosterCard.body` ——
      而 `body` 里还有 `item.imageTarget(server, kind: .primary, width: 400)`
      （**`P2-20` 已实测 1.46 µs**）。两者同属「每次重算都现算的不变值」。
      真实的每卡纯计算 ≈ **0.95 + 1.46 = 2.41 µs**（本机复核实测 0.758 + 1.46）。
    - **关键是「分散」而不是「总量」**：那 M 次写入分别由 **M 次异步解析完成**触发
      （网络/DB 往返，缓存命中也要毫秒级），不是同一帧内发生。
      单次写入引发的重算 = R × 2.41 µs ≈ **48 µs**（R=20），
      占 16.7 ms 帧预算的 **0.29%** —— 仍远低于任何可感知阈值。
  - **判定：不改。** 理由与已归档的 `P2-19`（5.13 µs）/ `P2-20`（1.46 µs）/
    `P2-27`（1.41 µs）同族 —— 可消除的计算量在 µs 级且分散在多帧。
    真要动它得改 `collectionArtwork` 的观察粒度（例如拆成 per-item 的
    `Observable` 容器，或让卡片自己持有 `@State`），那是**架构改动**，
    风险与收益不成比例。
  - **这条关闭后，第二批 78 条全部有了最终归属**：51 已修 · 27 判定不改 · **0 待办**。

### 收尾台账（第三十六批，零代码改动）

- **本仓审查清单共 `93` 条可追踪条目，分两批**：首轮 `FIX-01..15`（15 条，已在第一轮全部修完并落地）
  + 第二批 `P1/P2/CORR/BLD/LIVE` 共 `78` 条（`P1-04` 经实测推翻后移出，故净 `92` 条）。
  - **⚠️ 口径更正**：本文件此前有若干处笼统写「78 条审查条目」—— 那只是**第二批**的条数，
    不含首轮 15 条 `FIX`。凡是写「52 已修」的地方，口径也都是**第二批 78 条之内**，不是全部 93 条。
- **第二批 78 条的最终分布**：

  | 类 | 已修 | 判定不改 | 待办 | 合计 |
  |---|---|---|---|---|
  | `P1` | 16 | 1（`P1-04` 实测推翻） | 0 | 17 |
  | `P2` | 20 | 19（含 `P2-02` 残余判不改） | **1（`P2-29`）** | 40 |
  | `CORR` | 8 | 1（`CORR-05`） | 0 | 9 |
  | `BLD` | 5 | 3（`BLD-05`/`06`/`07`） | 0 | 8 |
  | `LIVE` | 2 | 2（`LIVE-03`/`04`） | 0 | 4 |
  | **合计** | **51** | **26** | **1** | **78** |

  - **⚠️ 这里修掉了我上一版台账的两个错**：
    ① 我把 `P2-29`（`collectionArtwork` 的 `@Observable` 依赖粒度）算进了「判定不改」，
       却在同一段的结尾写「唯一仍留观察的是 `P2-29`……才能决定改不改」—— **自相矛盾**。
       它从未被判定过（本文件 508 行原文是「**留待后续**」），必须如实计为**待办**。
    ② 旧台账写「70 已修 · 22 未修（`P1` 0 · `P2` 18 · `CORR` 1 · `BLD` 2 · `LIVE` 2）」——
       `18+1+2+2 = 23 ≠ 22`，且「已修 70」把多条**判定不改**也计进了已修。
- **`P2-29` 是唯一待办项，且它可以在本机量化（我此前说「本机无该手段」是错的）**：
  清单自身第 805 行就写着可用 `Self._printChanges()` 或 signpost 数 `PlayerScreen.body`
  求值次数 —— 同样手段可用于数 `collectionArtwork` 写入引发的重算次数。
  按本仓既有口径（能测的先测，µs 级就判不改），**下一批应当先给它一个计数器量级，再决定改不改**，
  而不是含糊地「留待真机」。
- **顺带补记 5 个此前从未以编号出现在本文件的条目**（按**编号**口径 —— 其中 `BLD-07` 的子项
  其实早已写在 `CORR-02` 那段里，所以不是「完全没被记录过」）：

  | 条目 | 核实结果 |
  |---|---|
  | `P2-02` | **残余判不改**（不是「已修完」，我上一版说错了）。代码事实：`BangumiHomeView.swift:605` 是 `body` 首句 `let episodes = partitioned`，`partitioned` 全文件只被引用一次，所以**每次 body 只扫一遍**。但清单要的 `@State + .task(id:)` **至今没做** —— `partitioned` 仍是 computed property、每次 body 照旧重扫。而那句 `let episodes = partitioned` 是 2026-08-22 的 `26a136b` 就有的写法（当时把「一次 body 扫 4 遍」降到 1 遍），**早于清单成文**。残余成本 ≤50 条，判不改。 |
  | `P2-35` | **不是 bug，是产品取舍**。`AppUpdateCheckerTests.swift:39` 有 `XCTAssertNil(checker.lastCheckedDate, "取消不算「检查过」，不落节流时间戳")`；照清单建议改「取消也落戳」会直接把该用例改红。真要治需区分「最近尝试过」与「最近成功过」两个时间戳 → 产品决策。 |
  | `CORR-05` | **残余判不改**（但理由要更正，见下）。 |
  | `BLD-06` | **有界开销，不必动**。`MetadataDatabase.swift:63` 的 `journal_size_limit = 8MB` 封住；全仓无 `wal_autocheckpoint` 覆盖，实测那约 4 MB 其实是**默认 1000 页 autocheckpoint**（1000 × 4096 B = 3.9 MiB）在起作用。两天尺寸没变即「不增长」的证据。 |
  | `BLD-07` | **不是活缺陷**。全仓无任何存储路径拿 `absoluteString` 拼（它只用于显示与日志）；孤儿目录手工删一次即可（`clean.sh` 拒绝 `$ROOT` 之外路径是**故意**的）。**其子项已修**：`AppStorageDirectories.imageCache` 已随 `CORR-02`（`597a8d6`）删除，现只剩 `root`/`importedSubtitles`/`screenshots`/`danmaku`/`databaseFileNames` 五个成员。 |

- **`CORR-05` 的判定理由更正（我上一版写的「唯一干净修法有风险」不成立）**：
  `ErikaPresenter.captureFrameRGBA` 的 `[UInt8](repeating: 0, …)`（33 MB 零填充）确实在
  `ErikaEngine.captureFrameRGBA` 的 `withLock` **之内**，而那把锁每帧被渲染线程 `renderTick` 长持
  （`ErikaEngine.swift` 同文件注释明写持锁会导致视频掉帧）。
  **但修法不是唯一的**：把「分配 + 清零」挪到**进锁之前**（`ErikaEngine` 先建好缓冲、presenter 改成
  接收缓冲）即可 —— 既保住可证的 memset，又不需要任何「内核会写满」的假设，锁内只剩 C 调用。
  所以正确判定是：**残余成本 = 一次截图在渲染锁内 memset 33 MB（约 2–4 ms，可能掉一帧），
  可挪出锁外，但收益极小** → 判不改。而不是「唯一修法要拿 memset 换内核写入假设」。
- **本节位置说明**：这 5 条里有 4 条不是性能项（`P2-35` 产品语义、`CORR-05` 正确性、
  `BLD-06`/`BLD-07` 构建与存储），按性质本应分到 `### 修复` 等小节。集中放在这里是为了
  让「台账收尾」这一件事可整体检索；**不表示它们都是性能改动**。

- **`P2-37` 判定为「不改」—— 我按清单建议实施后，发现了新引入的视觉缺陷，已完整回退。**
  - 问题本身是真的：`AppShellView.compactTabs` 里按「有没有头像」分裂成**两棵结构不同的
    `Tab` 树**，而 `userAvatarImage` 会随会话落地 / 换服务器 / 登出变化 ——
    一变整棵树的**类型**就变，SwiftUI 只能重建。
  - **我实施的改法**：新增 `AppModel.homeTabIcon`（始终返回一张烤好的图标：有头像用头像，
    没有就用 `house.fill` 按同规格烤），把分叉收进图片层，于是 Tab 树只剩一棵。
    macOS 构建、iOS 测试、反向变异（「忽略头像」→ 6 处失败）**全部通过**。
  - **但这个改法引入了两个独立缺陷，所以我把它整个回退了。两个都是审查实测出来的**：

    **缺陷 ①（我发现了）：颜色被固定成纯黑，失去 tint / 明暗模式 / 选中态。**
    `Tab(..., systemImage:)` 由系统绘制时图标自动吃 tint；而我烤的那张是
    `alwaysOriginal` —— 审查实测产物中心像素 RGBA = **(0, 0, 0, 255)**、
    `renderingMode.rawValue = 1`。无头像的用户会失去「未选中灰 / 选中高亮」，
    深色标签栏上纯黑 = 对比度趋零。

    **缺陷 ②（审查发现，更严重）：`house.fill` 被四边裁切。**
    28pt 画布装不下 `pointSize: 28` 的符号 —— 审查实测：

    | 项（iPhone 17 Pro / iOS 26.3 / @3x） | 数值 |
    |---|---|
    | `UIImage(systemName:"house.fill", pointSize: 28).size` | **39.33 × 33.00 pt** |
    | 画进 28×28 画布的绘制原点 | x = −5.67、y = −2.5（四边都溢出） |
    | 产物贴边像素数（alpha > 8） | 上 10 / **下 68（≈22.7pt）** / 左 11 / 右 11 |
    | 对照：同 28pt 画布的头像圆 | 上 18 / 下 18 / 左 18 / 右 18（正常相切） |

    底部 68px 贴边 = 房子的**底边被平切掉**。我的居中算法本身没错（墨迹中心 149.5 vs
    画布中心 150）—— 错的是**画布尺寸**，居中只是把溢出均分到四边。

  - **缺陷 ② 无法靠改 `renderingMode` 救回来**（这点必须记下来，否则下一个人会重踩）：
    审查实测 `house.fill` 的 pointSize → 实际点尺寸：

    | pointSize | symbol.size |
    |---|---|
    | 17 | 24.00 × 19.67 |
    | **20** | **28.00 × 23.33**（唯一能塞进 28pt 宽度的档） |
    | 22 | 31.00 × 26.00 |
    | 24 | 34.00 × 28.00 |
    | **28（我用的）** | **39.33 × 33.00** |

    要「不裁切」只能把 pointSize 降到 **20**，此时字形只有 **23.33pt 高** ——
    比 28pt 的头像圆明显小一圈，于是「两种状态同规格、切换不跳」的初衷落空。
    **「头像 28pt 圆」与「house 字形」本来就不是同一种几何**，这条路自相矛盾。
  - **为什么不能简单把回落图改成 `.automatic`**：那个文件第 2 条实拍约束要求位图必须
    `alwaysOriginal`（否则彩色头像会被当模板图渲染成一坨纯色）。那个要求是**为头像那张**
    定的 —— 头像是照片、不该吃 tint；而 `house.fill` 是**单色符号**、正需要吃 tint。
    而条件又不能下移到 `label:` 里（第 1 条约束：会画出 84pt 黑色圆角块）——
    在**已实拍验证过的手段**里，「两棵 Tab 树」就是这个约束下的正确形态。
  - **⚠️ 这条论证有边界，如实记下**：审查指出还有**第三条路尚未被排除** ——
    回落图走 **template**（单色 alpha 蒙版被标签栏染色，自动获得灰/高亮/明暗），
    头像继续 `alwaysOriginal`，仍是单一 `Image`，不违反「label 里不能 if/else」。
    但这依赖一个**未验证的假设**：「标签栏对 template 位图确实施加选中 tint」
    （第 2 条约束只证明了「彩色头像会被染成一坨」，推不出这个）。
    验证方法：最小探针 App，一个 Tab 用 template 烤图、另一个用 `systemImage`，
    深/浅色各截一张对比选中色。**在拿到那张对比截图之前，维持现状（不改）是对的。**
  - **结论**：`P2-37` **不改**。它记录的「两棵树」是三条实拍约束逼出来的必要代价；
    真正的成本（头像变化时重建 Tab 树）只在「会话落地 / 换服务器 / 登出」这几次
    发生，不是热路径。**用「每次渲染都正确的系统图标」换「偶发几次树重建」是对的取舍。**
  - **⚠️ 这也是一次教训**：我的改法通过了构建、通过了测试、通过了反向变异 ——
    但它仍然是错的。**审查实测确认：3 条新用例对一个「四边被切、纯黑、不变色」的图
    全部成立**（尺寸 28、`alwaysOriginal`、scale 一致 —— 每个谓词在缺陷图上都过）。
    变异只覆盖了「图标取哪张」，**覆盖不到「画出来对不对」**。
    视觉/渲染类改动必须有实际观感判断或像素级断言，不能只看测试绿。
    （审查给了一条能抓住它的判据：断言贴边像素数 —— 缺陷版底部实测 68px，
    正常圆头像约 18px。但既然本改动已整体回退，这条不再补。）

- **`P2-36`：氛围轮播补 tolerance；同时删掉一个**被写了却没人读**的死属性。**
  - **采纳**：换片循环每 12 秒醒一次、只为把 `ambienceIndex` 加一 —— 精确唤醒毫无收益，
    却是一次真实的 timer 唤醒。已补 `swapTolerance = 3 s`，让系统把唤醒攒进别的唤醒里
    （macOS / iOS 都做 timer coalescing），省电。
  - **⚠️ 审查抓到 1 条阻断级 + 5 条应修，其中阻断级是我写成「理由」的一条错误事实**：
    我原来在代码/CHANGELOG/commit 里写「`homeAmbience` 是 iOS 上所有自垫背景页面的图源，
    所以不能只在首页推进」。**这个前提是错的** —— 审查实测
    `git grep homeAmbience -- App Packages` 只命中声明 / 写入 / 注释，
    **零个生产读点**（读它的只有 AppTests）。真正被所有自垫背景页消费的是
    `currentAmbienceTarget`（读 `ambienceIndex`）。
  - **处置**：**删掉 `homeAmbience` 死属性**（`AppModel.swift`），
    `publishCurrentAmbience()` 保留为有注释的 no-op（它是「推进后同步」的语义锚点，
    且已有用例通过它驱动），并把 6 处引用它的过时注释全部改成真实链路
    （`AppModel` / `AppShell` / `DetailView` / `AmbientBackdropCarousel` /
    `MoviePilotDownloadsView` / `LaunchOptions`）。
  - **「不采纳清单另一半建议」的结论保留，但理由换成真的**：
    ① **iOS 上收益接近零** —— 前台时恒有一个 Tab 可见，而四个 Tab 根页各自读的就是
    `currentAmbienceTarget`；唯一能省的是「首页**栈根**可见」，可那会让**当前正在看的**
    设置子页 / 下载页 / 详情兜底背景停住。
    ② **macOS 上会冻住整窗背景** —— `AmbientBackdropCarousel` 挂在 `AppShell` 根节点
    整窗层，任何分区都可见；按 `selectedSection == .home` 门控会让 macOS 用户切到别的
    分区时全窗口背景静止。
    清单方案 (b)（`sessionPool` 读固定一张）也有真代价：`Docs/AMBIENCE.md` §三.1 的
    「push 时背景连续」正是靠同 URL 命中缓存实现的。
  - **⚠️ 我另外两处写错、审查更正的**：
    ① **「容差太大会把两次唤醒攒成一次、观感跳片」是错的**。实测 tolerance 是
    **绝对时长、单边（只晚不早）**：`12 s + 容差 3 s` 实际睡 **14.87 s**；
    `200 ms + 容差 3 s` 跑 20 次 min 2.91 / avg 3.00 / max 3.10 s，无一次早醒。
    串行循环里相邻换片永远 ≥ 12 s，**不可能跳片**。真实代价只是「同一张最多停 ~15 s」，
    一轮 96 s → 96–120 s。注释与用例已改。
    ② **第一版 2 条用例是空转的** —— 只读两个常量，把循环里的 `tolerance:` 参数
    整个删掉也不会有断言变红（审查实测）。已加**可注入的 `AmbiencePool.sleepForSwap`
    钩子**（与 `AmbienceImageWarmup.warm` 同款），用例现在能真正跑进循环、
    断言「生产代码传下去的 interval / tolerance 是什么」。
  - **用例 3 条，反向变异 2 个全部抓红**：
    · tolerance 传成 `swapInterval`（传错）→ **红**
    · tolerance 传成 `.zero`（等于没容差）→ **红**
    另外 `testSwapToleranceIsSane` 守「容差 > 0 且停留上限 ≤ 20 s」；
    `testSwapIntervalStaysAtCalibratedValue` 守 12 s / poolSize 8 这两个标定值。
  - **⚠️ 写用例时我自己踩的坑**：注入的 sleep 第一版「记完就 return」，
    于是 `while !Task.isCancelled` 以 CPU 满载速度狂转（没有让出点），
    测试 App 卡在 99.7% CPU 不结束。改成「记完后真的挂起 60 s」才让主 actor 空闲、
    取消得以执行。
  - **顺带修掉 `main` 上的一处 CHANGELOG 损坏**：上一批的强制推送在 `P2-10` 标题上留下
    **重复拼接**（`…从- **\`P2-10\`…从「…」。**`），且里面还写着已被更正的「6 遍」。
    两者都已修好（现为「3–6 遍」）。**注意：我上一版 commit 里声称「已加自动检查」——
    那句话不成立**（仓库里没有该检查），本批已把它从描述里删掉。

- **`P2-38`（其二）：弹幕 `p` 字段解析快 7.6×（**生产路径** `entries` 省 13.6 ms / 万条）。**
  - `DanmakuJSONConverter.fields(from:)` 原先两处白付：
    ① `p.split(separator: ",", omittingEmptySubsequences: false)` —— 按 **Character**
       （字素簇）切分并**分配整个 `[Substring]` 数组**，而 `p` 有 8 段
       （`userId` / 时间戳 / 校验串…）**我们一个都不看**。实测 **1173 ns/条**，占 ~80%。
    ② `comment.m.trimmingCharacters(in: .whitespacesAndNewlines)` —— 结果**被丢弃**
       （只为判空，返回值用的还是原文），却为**每一条弹幕**分配一个新字符串。
       实测 **63.9 ns/条**。
  - **修法**：按 **UTF-8 字节**扫到第 2 个逗号就停（前三段一定是 ASCII 数字），
    再构造三个短 `String`（≤15 字节走小字符串优化、不落堆）；判空改成
    **`unicodeScalars` + `CharacterSet.whitespacesAndNewlines`**（零分配）。
    后面那些可能含非 ASCII 的段（用户昵称之类）**根本不会被读到**。
  - **端到端实测（release，1 万条弹幕，真实生产函数）**：

    | 函数 | 旧 | 新 | 提速 | 节省 |
    |---|---|---|---|---|
    | **`entries(from:)`（生产路径）** | 15.70 ms | **2.07 ms** | **7.6×** | **13.63 ms** |
    | `erikaJSON(from:)`（**当前版本不调用**） | 31.09 ms | 17.62 ms | 1.76× | 13.47 ms |

    单条 `fields`：**~1300 ns → ~200 ns**。
  - **⚠️ 审查抓到 2 条阻断级，全部成立，已按它的方案修**：
    ① **判空写法不等价（我自己只抓到一半）**：我先发现了 `Character.isWhitespace`
       与 `CharacterSet.whitespacesAndNewlines` 差 **U+200B** 一个码位并补上了，
       但**漏了更隐蔽的一层** —— `isWhitespace` 判的是**整个字素簇**，而
       `trimmingCharacters` 按 **scalar** 裁。于是 `" " + U+0301`（空格 + 组合符）
       旧实现 trim 后剩 `U+0301` → **接受**，而 `isWhitespace` 认为整个簇是空白 → **拒绝**。
       随机字素簇 20 万条差分实测 **265 条不一致**。
       **审查给出了更好的解**：`unicodeScalars.contains(where: { !CharacterSet
       .whitespacesAndNewlines.contains($0) })` —— 同集合、同粒度，
       穷举单码位 + 20 万随机簇 **差异 0**，而且只要 **20.2 ns/条**
       （比我的写法 72.8 ns 还快 3.6×，因为 `Character` 迭代要先做字素簇边界分析）。
       已采用，并删掉了那个 `zeroWidthSpace` 常量。
    ② **「与 `split` 完全等价」不成立**：`split` 按**字素簇**切，而字节扫描按字节切 ——
       逗号紧跟 Extend 类字符（组合符 / VS16 / ZWJ）时会少一个切分点。
       实测 `p = "1,1,100,\u{0301}5"` 旧实现 nil、新实现接受 `(1,1,100)`；
       20 万条含组合符随机输入 **11 条差异**，去掉组合符后 **0 条**，方向**单向**
       （只会多收、不会丢）。已把结论从「完全等价」改成**如实记录这个差异**：
       `p` 第 3 段之后是 userId / 时间戳 / hex，那些位置出现「逗号追组合符」
       在真实数据里不成立，且多收不会让正常弹幕丢失。
  - **⚠️ 审查还纠正了我的一个事实错误**：我原先拿 `erikaJSON` 当头条，但
    `PlaybackController.danmakuPayloadFormat` **恒为 `.overlay`**
    （源码注释：「当前版本内核弹幕被禁用，恒为 overlay」）→ `json: nil` →
    **`erikaJSON` 在生产里从不被调用**。头条已换成真正跑的 `entries`。
  - 另外按审查建议去掉了 `@inline(__always)`（private、单调用点、含循环，无必要）。
  - **语义验证**：穷举单码位 0x10FFFF + 随机字素簇 20 万条 → 判空**差异 0**。
    用例 8 条覆盖：不足三段 / 空段 / 多余段 / 非 ASCII 尾段 / 数值校验 /
    正文判空 / 零宽空格 / 输出不 trim。
  - **⚠️ 这批用例不守性能**（守性能要写耗时断言，而耗时断言已在 CI 咬过我三次）。
    **性能只有实测支撑**：本机 release 构建、1 万条真实长度弹幕、多次取均值。
  - **下一块更大的石头（本批未做）**：审查实测
    `DanmakuIntroDetector.detect` **126.4 ms / 万条**（新 `entries` 的 64×），
    而且就在 `payload()` 里 `entries` **之前**跑；其中 `commentTime` 与 `commentUID`
    每条**又来两次全量 `p.split`** + 一次 `trimmingCharacters` 分配
    （`split` ~0.88 µs/次 ⇒ 约 17.6 ms，占 detect ~14%）。同一个 `p`、同一个调用栈邻居，
    应作为下一条处理。

- **修掉 `DanmakuCacheTests` 的 CI 假红（第二次，`CORR` 类）**。
  - PR #60 的 CI 挂在 `testStaleMemoryDoesNotDeleteFileWrittenElsewhere`：
    `("nil") is not equal to ("Optional("fresh")")` + 「内存快照过期不得删除盘上文件」。
    **本批 diff 完全没碰 `DanmakuKit`**（`git diff main...HEAD --stat` 可证），
    本地复跑全绿 —— 是**既有的 CI flaky**，不是这批引入的回归。
  - **为什么会假红**：这条用例要同时满足**两个方向相反的时间约束** ——
    ① 内存条目必须过期（`sleep > staleTTL`，才会走到磁盘路径）；
    ② 盘上那份不能被判过期（「`other` 写完 → `stale` 读」的间隔 `< staleTTL`）。
    前两版取 `staleTTL = 0.05` / `0.5` 秒，约束 ② 的预算只有 50 / 500 ms ——
    慢 runner 上一次调度抖动就击穿，于是 `stale` 的 `diskComments` **合法地**
    认为那份也过期（同一 TTL 配置下它确实过期了）→ 删掉文件 →
    三条断言全红，与产品 bug 的表现**一模一样**。
  - **修法**：`staleTTL = 3 s`、`sleep = 4 s`。
    约束 ① 有 1 s 余量；约束 ② 的窗口从 0.5 s 提到 **3 s（宽 6 倍）**。
    代价是这条用例要跑 **4 秒**，但它是**确定性**的，不再靠赌 CI 的调度运气。
  - **⚠️ 我第一次改写是错的，也记下来**：我试过 `staleTTL = 0.001`（想用「极小 TTL」
    避开长 sleep）—— 那是**根本不成立**的路子：1 ms 的实例会**合法地**认为盘上那份
    过期并删除（产品行为如此）。CI 当场把它打回来（第二次失败）。
    教训：这条用例的时间约束是**双向**的，「取更小的 TTL」只会让约束 ② 更糟。
  - **双向验证**：
    · 回退成修前 bug（内存过期就直接删文件）→ **红**（仍能抓住原 bug）；
    · **12 个 `yes` 进程压满 CPU** 下复跑 → **稳定通过**（4.27 s）。

- **`P2-10`：`BangumiChapterSection` 的三个章节分类从「一次 body 扫 3–6 遍」改成「扫一遍」。**
  - 与 `P2-09` **同形状、不同文件**（清单原文就注明「同形状、不同文件」）：
    三个独立 computed property 各含一次 `episodes.filter`，而 `episodeContent`
    一次 body 里读了 **3–6 次**（三个 `if !xxx.isEmpty` + 三次 `episodeGrid(xxx)`）。
    1000 集时就是 3–6 遍全量 filter + 同样多份临时数组（DTO **384 B**），
    而 `body` 会随 `isLoading` / `loadError` / 进度标记变化反复重算。
    （审查实测每 body 的谓词调用数：空 **0**、只有本篇 **4000（4 遍）**、
    本篇+SP **5000（5 遍）**、三组都非空 **6000（6 遍）**）
  - **修法**：直接复用上一批为 `P2-09` 抽出来的包函数
    `Array<BangumiEpisodeDTO>.partitionedByEpisodeType()`，
    `episodeContent` 开头取一次 `EpisodePartition`，6 处读取全走
    `parts.isEmpty(for:)` / `parts.episodes(for:)`。**没有新增任何分区逻辑**，
    等价性由 `P2-09` 的 6 条包用例（含「与旧三个 filter 逐条等价」「tab 映射正确」）继续守着。
  - **⚠️ 顺带修掉一处既有误用**：`episodeContent` 上的 `@ViewBuilder` 其实是空转 ——
    它只包着一个 `VStack` 表达式。而我为了写 `let parts` 加了显式 `return` 之后，
    编译器直接警告：
    > `application of result builder 'ViewBuilder' disabled by explicit 'return' statement`

    这说明 builder 根本没起作用。已去掉该标记（单表达式 `some View` 语义不变），
    并用**真实 5 分支结构**（`ErrorNotice` + `LazyVGrid` + 两个带标题的 Tuple +
    末尾 `Text`）做动态类型对照，新旧完整类型字符串**逐字相同**。
    （第一版我用的是简化模型 `VStack<TupleView<(Text, Optional<Text>)>>`，
    结论对但证据偏弱；审查指出后已用真实结构重验。）
  - **⚠️ 我自己发现并补上了一个防线缺口**：改完后虽然只分区一次，但视图里仍要手写
    三段 `if !parts.isEmpty(for: .x) { 标题; grid }` —— **把 `.main` 写成 `.sp`
    编译器不会报**（两边都是 `[BangumiEpisodeDTO]`），也没有视图测试能抓。
    这与上批 `P2-09` 踩的坑同型（那次是 `parts.main` / `parts.sp` 接反）。
  - **补法**：把「哪三组、什么顺序、每组标题、组内是什么」也收敛进包里 ——
    新增 `EpisodePartition.displayGroups`（+ `DisplayGroup` 描述结构）。
    视图只写：
    ```swift
    ForEach(parts.displayGroups) { group in
        if let title = group.title { Text(title)… }
        episodeGrid(group.episodes)
    }
    ```
    顺序（本篇 → SP → 其他）、标题（本篇无、SP「SP」、其他「其他」）、
    **空组不出现**全部由包决定，并有用例钉住。
  - **用例 7 条**（包内，新增 1 条 `displayGroupsMatchLegacyStructure`）：
    `displayGroups` 的顺序 / 标题 / 空组省略 / 组内元素全部断言。
  - **反向变异验证（4 个，全部抓红）**：SP 排到本篇之前 / 本篇也带标题 /
    空组也出现 / **SP 组里放 other 的数据**（就是「接线接错」那一类）。
  - **实测收益（release，真实 DTO 384 B，只测分类不含视图构造）**：

    | 场景 | 旧 | 新 | 提速 |
    |---|---|---|---|
    | 混合 1000 集（三组都有） | 410.37 µs | **63.82 µs** | **6.43×** |
    | 全本篇 1000 集 | 285.14 µs | **65.25 µs** | **4.37×** |
    | 1 集 | 0.42 µs | 0.13 µs | 3.29× |
    | 空 | 0.01 µs | 0.01 µs | 持平（10 ns 噪声，不算回退） |

    `MemoryLayout<EpisodePartition>.size` = **24 B**（3 个 Array 头）。
  - **⚠️ 一处我说错、审查更正的**：「`isEmpty(for:)` / `count(for:)` 是为了省数组拷贝」
    —— 这个前提**不成立**。`episodes(for:)` 返回的是存储的 Array，只是 retain（COW），
    实测 `parts.episodes(for: .main)` 与 `parts.main` 的 buffer 地址**相同**，
    `.isEmpty` 本来就 O(1)。这层 API 的价值是**便利与可测**，不是性能。
  - **⚠️ 另一处：不该把分区缓存进 `@State`**。`episodes` 有 **4 个写点**
    （`load()` 两处清空、`readLocal` 的 `episodes = cachedEpisodes`、sheet 重新关联的清空），
    且 `readLocal` 还会被播放结束的失效通知再次调用 —— 缓存要在 4 处同步失效，
    漏一处就显示错组（正是 generation 计数在防的那类漂移）。
    1000 集一次 body 才 65 µs，body 本来只在状态变化时重算，不值得冒这个风险。
  - 包内合计 **78 条 0 失败**。

- **`P2-09`：Bangumi 详情页的三个章节分类从「一次 body 扫 3–7 遍」改成「扫一遍」。**
  - 原先是三个独立 computed property，各含一次 `episodes.filter`：
    ```swift
    private var mainEpisodes  { episodes.filter { $0.type == .main } }
    private var spEpisodes    { episodes.filter { $0.type == .sp } }
    private var otherEpisodes { episodes.filter { $0.type != .main && $0.type != .sp } }
    ```
    `episodesSection` 一次 body 里把它们读了 **3–7 次**（取决于 sp / other 是否为空）：
    外层 `if !spEpisodes.isEmpty || !otherEpisodes.isEmpty` 会**短路**，实际 1–2 次；
    Picker 里 0–5 次；`currentList` 的 switch 1 次。

    | sp 空 | other 空 | 读取次数 |
    |---|---|---|
    | ✓ | ✓ | 3（不进 Picker） |
    | ✓ | ✗ | 5 |
    | ✗ | ✓ | 6 |
    | ✗ | ✗ | 7 |

    1000 集时一次 body 要扫 3000–7000 个元素、建同样多份临时数组（DTO **384 B**），
    而 `body` 会因 `updatingEpisodeID` / `isLoading` 变化反复重算。
  - **修法**：分区逻辑抽成 `BangumiKit` 的 `Array<BangumiEpisodeDTO>.partitionedByEpisodeType()`
    （一次 `for` 扫完、只建三个数组），**连「tab → 列表」的映射一起**放进包的
    `EpisodePartition` 结构（`episodes(for:)` / `count(for:)` / `isEmpty(for:)`）。
  - **`EpisodeTab` 也从视图搬进了包里**：映射在视图里的话，把 `parts.sp` 接成 `parts.main`
    编译器**不会报**（两边都是 `[BangumiEpisodeDTO]`），只有用户会发现「点 SP 显示本篇」。
    搬进包之后用例能直接断言映射。
  - **等价性**：第三条原先写 `type != .main && type != .sp` —— `BangumiEpisodeType` 有
    7 个 case（main/sp/op/ed/trailer/mad/other），也就是后 5 个**全部**归「其他」。
    新实现用 `switch` 的 `default` 承接，逐条等价。
  - **实测收益（release，真实 `BangumiEpisodeDTO` 384 B，1000 集，200 次取最优）**：

    | | 耗时 |
    |---|---|
    | 旧（3 次读取，最短路径） | **98.94 µs** |
    | 旧（7 次读取，最长路径） | **225.90 µs** |
    | **新（一次 for）** | **44.94 µs** |
    | **提速** | **2.20×（3 读）～ 5.03×（7 读）** |

  - **用例 6 条**（`BangumiKit`，swift-testing）：七种 case 全覆盖（并断言
    `allCases.count == 7` 作绊线）/ **与旧三个 filter 逐条等价（比整个元素，不只比 id）** /
    **tab → 列表映射正确** / 分类内部保持原顺序（夹具让 other 段**逆 rawValue**）/
    空数组与单一分类 / 1000 集大输入。
  - **反向变异验证（5 个，全部抓红）**：拷贝后改字段 / 整体按 type 排序 /
    **tab 映射接错** / `default` 漏条目 / `op` 错并进本篇。
  - **⚠️ 我在这批里犯的三个错，都被审查抓出来并已修正**：
    ① **把读取次数写成「8 次」是错的** —— 外层 OR 会短路，实际是 **3–7 次**。
       这个错误同时写进了代码注释、CHANGELOG 和 commit message，属立项依据出错。
    ② **第一版「实测收益」表是错的**：我的基准里 `old()` 跑了 `8 × 3 = 24` 次 filter
       （8 是读取次数、3 是分类数，两者不能相乘），把旧值高估约 3 倍，
       于是喊出「22×」。用真实 DTO 重测后是 **2.20–5.03×**。
    ③ **第一版测试只比 `.id` 不比元素内容** —— 「拷贝后改字段」的变异全绿；
       且**顺序用例的夹具在每类内部本来就是升序**，抓不到「整体按 type 排序」。
       两处都已改。
  - **这是「测试没接上生产路径」的第 4 次**（前三次：`P2-34`、`P2-32`、`P2-33`）。
    这次的解法是把映射搬进可测的包，而不是继续在视图里靠命名。


- **`P1-06`：`TMDbBatch.enrichAll` 从全串行改成 **4 路有界并发**（弱网下 1.6–3.5×）。**
  - 原实现是 `for item in items { await performRefresh(item) }` —— **完全串行**。
    而 `TMDbRateLimiter` 的配置是 `maxConcurrent: 4, minimumInterval: 0.12`
    （全局 8.3 req/s 上限），**那个 4 从来没被用上**。
  - **为什么原先被判「不值得改」**：串行吞吐 = `1 / max(单次延迟, 0.12)`。
    延迟 ≤120 ms 时已经打满限流器上限，并发确实无收益 —— 这大概是当时的判断依据。
    但**延迟一旦超过 120 ms 就开始亏**：

    | 单次延迟 | 串行吞吐 | 占上限 | 4 路并发实测 |
    |---|---|---|---|
    | ≤120 ms | 8.3 req/s | 100% | 无收益（如实记录） |
    | 200 ms | 4.8 req/s | **58%** | **1.58×** |
    | 300 ms | 3.2 req/s | **38%** | **2.25×** |
    | 500 ms | 1.9 req/s | **23%** | **3.48×**（模拟值） |

    `api.themoviedb.org` 在国内 / 移动网络下 **200–400 ms 是常态**。
  - **修法**：`withTaskGroup` + 窗口填充（宽度 = `min(4, items.count)`）；
    worker 只返回一个 `Contribution` 结构体，**计数器全在父任务里聚合**（无竞争）；
    取消仍走 `Task.isCancelled` → `cancelAll()`。
  - **实测（release，生产限流器配置，非阻塞延迟 stub，20 条）**：
    延迟 200 ms → **7.63 req/s**（串行 4.79，**1.58×**，在飞峰值 2）；
    延迟 300 ms → **7.31 req/s**（串行 3.16，**2.25×**，在飞峰值 3）。
  - **⚠️ 测量上踩到一个坑，记下来**：第一版 stub 用 `usleep` 模拟延迟 ——
    它把 `URLProtocol` 的队列**堵住**了，于是并发实现也测出 4.82 req/s
    （与串行一模一样），差点让我误判「并发没生效」。改成
    `DispatchQueue.asyncAfter` 的非阻塞延迟后才对称。
  - **用例 7 条，判据全是确定性的**（耗时断言已在 CI 咬过我三次）：
    并发性（在飞峰值 ≥2）/ **窗口宽度 ≤ 上限**（数同时存活的 worker）/
    结果四类计数之和 = 总数 / 非视频类型仍计入 `processed` /
    `processed` 必须走 `Contribution` 聚合（预取消场景下应为 0）/
    取消后不得继续派发 / 取消仍生效。
  - **⚠️ 审查抓到 3 条应修，全部成立并已修**：
    ① **整块公共文档挂错了对象**：我把 `enrichAll` 的 30 行文档连同
       `- Parameter items:` 一起留在了 `static let enrichmentConcurrency` 上方
       （中间没有空行）—— Swift 会把整块绑定到属性，而 `enrichAll` **反而没有文档**。
       编译器不报错、测试也不查。已把并发上限的说明单独放属性上方，
       其余留在 `enrichAll` 上方。
    ② **`group.cancelAll()` 是死代码（实测）**：审查指出删掉它 5 条用例全绿。
       我做了同构最小复现验证 —— 有/无 `cancelAll()` 的 `(processed, launched)`
       **完全相同**（都是 `(4, 4)`）。原因：worker 唯一的协作检查点是**进入时**的
       guard（早已通过），之后 `URLSession.data(for:)` 不会因 Task 取消而中断；
       而「不再派发」本来就由 `Task.isCancelled` 分支保证。
       **处置：删掉那行**，并在原处写明理由 —— 留一行看似更安全、实则不生效的调用，
       会让下一个人误以为「在飞任务已被掐断」，比不写更糟。
    ③ **「HTTP 在飞峰值 ≤ 4」守不住窗口宽度**：`TMDbRateLimiter` 自己就把并发压在 4，
       所以把 `width` 改成 `items.count`（无界派发）后那个峰值**仍然是 4**。
       已改成数**同时存活的 `contribution` 个数**（新的 `workerObserver` 接缝，
       `internal` 仅测试可用）。
  - **反向变异验证（4 个，全部抓红）**：并发上限改成 1（等价串行）/
    去掉上限（`width = items.count`）/ 去掉 worker 的取消守卫 /
    `processed` 硬编码成 `+= 1`（不走 `Contribution` 聚合）。
  - **⚠️ 一条我写错过又改正的用例**：取消用例最初断言「`cancelAll()` 让已派发的任务
    立刻抛错 → `processed ≈ 0`」，**实测是 4** —— 因为取消只对协作检查点生效。
    已改成守真实契约（「取消后不得继续派发 → 已处理条数止于窗口量级」）。

- **`P2-38`（其三）：`DanmakuIntroDetector.detect` 快 **23.5×**（1 万条 353 → 15.0 ms）。**
  - `detect` 原先对**每条弹幕**付 **2 次全量 `p.split`**（`commentTime` 取第 1 段、
    `commentUID` 取第 4 段，各切一遍全串）+ **19 次 `String` 关键词搜索**
    （5 报点 + 10 着陆 + 4 正片），外加报点命中时一次**行内正则**。
  - **修法**：① `p` 用**一遍字节扫描**同时取前 4 段（`parseTimeAndUID`）；
    ② `m` 用**一遍字节扫描**同时找全部 19 个关键词（`scanKeywords`）；
    ③ 关键词预计算表提到 `static let`；④ 时间戳正则提到 `static let`。
  - **等价性是可证明的，不是「应该差不多」**：
    · `p`：先扫一遍字节，**遇到任何 ≥ 0x80 就整条回退**到旧的 `String` 实现。
      纯 ASCII 串里「字素簇 == scalar == 字节」，字节切分与 `split` **完全等价**
      （可证明，不是采样出来的）。真实 `p`（数字/hex/逗号）永远是纯 ASCII。
    · `m`：字节匹配与 `String` 匹配的差异只出现在「关键词末尾的字与后续组合符合并成
      一个字素簇」时（`"跳伞\u{0301}"` 的 `contains("跳伞")` 是 false）。
      所以**命中时**把字节偏移换成 `String.Index` —— 不在字符边界上返回 **nil**。
      **两端都要校验**：起点也可能落在簇中间（Prepend 类字符如 U+0600）。
  - **⚠️ 三处都是「看着像常量、其实每次都重算」**：
    ① **关键词预计算表**（19 个词的 `Array(utf8)` + 首字节分桶）原先在
       `scanKeywords` 里**每条弹幕重建一遍** —— 实测 **2902 ns/条**，
       占优化后 `detect` 的一半以上。提 `static let` 后归零（51.7 → 17.5 ms）。
    ② **时间戳正则**原先写成**行内字面量** `firstMatch(of: /(\d{1,2})…/)` ——
       看上去是常量，实际**每次调用重新编译**。审查实测 **82 µs/次**；
       提 `static let` 后 **7.8 µs/次（10.5×）**。`detect` 每条命中报点词的弹幕都会调它。
       Swift 6 下 `Regex` 非 `Sendable`，必须写 `nonisolated(unsafe)`（否则编译报错）。
    ③ 顺带清了 `jumpTarget` 里为 5 个报点词**再扫一遍**的重复。
  - **验证**：把**旧实现逐字抄进测试当 oracle**，差分比对 ——
    `p` 定向 36 形态 + 随机 2 万条（含组合符 / 全角 / NBSP / 逗号连排 / 空段 /
    前后空白）→ **time 差异 0、uid 差异 0**；
    关键词 定向 17 形态 + 随机 8000 条 × 19 词（含组合符 / VS16 / ZWJ / emoji /
    Prepend）→ **差异 0**。
    审查另用 **4 层穷举 41 370 条 + 9 万条随机（3 个独立种子）+ 6 万条关键词 fuzz
    + 旧 enum 整段副本做 400 组端到端 A/B** 独立复核，`DanmakuIntroHint` 输出完全相同。
  - 用例 8 条：`p` 定向差分 / `p` 随机差分 / 关键词随机差分 /
    **首次命中位置** / **关键词数组序遍历顺序** / **非 ASCII 出现在第 4 段之后仍回退** /
    **预计算表完整性** / **关键词无 Unicode 规范分解**。
  - **⚠️ 踩到并修掉的两个真 bug**：
    ① 为省事在「已收齐 4 段」时提前 `break` → **后面那个非 ASCII 字节没被看到** →
       没回退 → 用字节切分算出错的 uid（`"5+a.,3Z3+ ,.2,8,\u{0301}a"`：字素切分第 4 段是
       `"8,\u{0301}a"`、字节切分给了 `"8"`）。差分测试当场抓到。
    ② **我写了一条恒真用例**（`testJumpTargetConsistentWithScan`）：`jumpTarget(in:)`
       的唯一实现就是 `jumpTarget(in: scanKeywords(...))`，两条路径逐字相同，
       把内部实现改成 `return 42` 它**仍然 pass**。审查实测指出后已删除（连同
       testing-only API）。这是本项目**第三次**栽在「测试没接上生产路径」上。
  - **反向变异验证（5 个，全部抓红）**：去掉起点边界校验 / 去掉 ASCII 回退 /
    「4 段后提前 break」/ 记录最后一次命中而非首次 / 反转跳词遍历顺序。
  - **端到端实测（release，1 万条，24 字正文语料）**：

    | 报点词命中率 | 耗时 |
    |---|---|
    | **0%（纯噪声）** | **15.0 ms** |
    | 0.1% | 15.1 ms |
    | 1% | 15.9 ms |
    | 10% | 23.7 ms |

    对照旧实现同语料 **353 ms** → **23.5×**。
    ⚠️ **提速幅度与语料形态有关**（审查指出）：正文越长、关键词越多，收益越大；
    短文本（8 字）+ 高命中率时收益会显著下降（那种情形下 `parseTimestamp` 占比上升）。
    上游真实弹幕正文长度分布以 10–30 字为主，命中率远低于 1%。

- **剩余 `P2` 条目：逐条实测后判定不改（保持与之前 `P2-15/17/30` 同一标准）**
  - 本批把剩下 9 条全部做了**忠实复刻基准**（本机 release、warmup + 多次取均值）。

    | 条目 | 实测 | 判定 |
    |---|---|---|
    | `P2-19` 地址表每行重算 | `list()`（n=3）**5.13 µs/行**；单次归一化 2.40 µs | 不改（与已回退的 `P2-30` ~5 µs 同量级） |
    | `P2-20` 每张图重建 `URLComponents` | **1.46 µs/张** | 不改 |
    | `P2-27` `isConfigured` 派生链 | 全链 **1.41 µs**（URL 归一化 0.95 + 2 次凭据读各 0.30） | 不改 |
    | `P2-28` `stableContentHash` 兜底 | **4.70 µs/次**（18 字段订阅） | 不改（且只在主键与名称都缺失时才走） |
    | `P2-10` 章节三个 computed 一次 body 读 6 次 | 500 集时 **2.71 µs/body** | 不改（`filter` 单次 1.72 µs） |
    | `P2-06` 首页 `.motion` 挂在根 `ScrollView` | — | 不改：动画**范围**问题，不是可基准化的计算量；清单自己已按 `REJ-01` 降级 |
    | `P2-07` 两个常挂载不可见玻璃面板 | — | 不改：需 Instruments 确认 `opacity 0` 子树是否真被剔除，本仓无该手段 |
    | `P2-16` `ExpandableOverview` 布局两遍 | — | 不改：SwiftUI 布局成本无法在单测里测；清单建议的 `measured` 门控会改变「量到前不出按钮」的时序，属行为改动 |
    | `P2-08` 弹幕 sheet 整面 Liquid Glass | — | 不改：清单自己标注「属视觉决策，非纯性能项」 |
    | `P2-29` 合集封面观察粒度错配 | — | **留待后续**：这是 `@Observable` 依赖粒度问题（一次写让所有读它的卡片重算），量级取决于可视卡片数与写入次数，**无法用本机基准代表**；要量它得在真机用 Instruments 的 SwiftUI 模板 |

- **`P2-38`（其一）：`FileHash.head16MiBMD5(from:)` 原先**真的会把整部电影下载下来**。**
  - 这是**真缺陷，不只是性能**。旧实现是
    `let (data, response) = try await session.data(for: request)` ——
    **`data(for:)` 会把整个响应体读完才返回**，而「服务器有没有老实按 Range 返回」
    是在**之后**才校验的。服务器一旦忽略 `Range` 返回 `200 + 整个文件`，
    就会先把整部电影（几 GB 到几十 GB）**读进内存**，然后才抛 `rangeUnsupported`。
    旧注释写的 "this method can never download an entire movie"
    **在传输层根本不成立** —— 它只是「不会把整部电影拿来算哈希」。
  - **修法**：改用 `URLSessionDataDelegate` 驱动 —— **响应头一到就决策**
    （`didReceive response`），不合格立刻 `.cancel`，响应体一个字节都不会被消费；
    合格才下传，且累计量硬顶在 16 MiB + 1（超了 cancel 并报 `readFailed`）。
    内存占用与流量从此都有**硬上限**，与服务器行不行善无关。
  - **为什么不用 `session.bytes(for:)`**：那是 `AsyncSequence<UInt8>`，要按字节迭代
    1600 万次异步跳（旧注释也记着这条路「慢几个数量级」）。也不用 `data(for:)`：
    它读完整个 body 才返回。delegate 是唯一两者兼顾的路。
  - 判定逻辑抽成纯函数 `RangePolicy.decide(statusCode:contentRange:expectedFileSize:)`，
    可表驱动测试；生产路径在 `didReceive response` 里调它，
    所以「决策」与「收字节」是同一个时刻。
  - **测试**（`FileHashRangePolicyTests`，7 条）：
    · 判定表 4 条 —— 合法 206（大/小文件）、`200` 且整文件 ≤16 MiB 才接受、
      **`200` 且大小未知必须拒绝**（这条就是「不能下整部电影」的判据）、
      6 种畸形/意外 `Content-Range`、其它状态码原样报出；
    · **「不碰 body」的硬证据**：桩先给响应头 + 第一块 body，再每 0.3 s 慢慢发
      （共约 3 s）。修好后 **0.006 s** 返回；退回 `data(for:)` 是 **3.08 s**。
    · 对照组：`200` 且整文件确实很小 → **要**把 body 收下来并算对哈希
      （防止「为了不读 body 连该读的也不读」）。
  - **⚠️ 一条测试方法学的坑（记录下来）**：`URLProtocol` 会把响应头**缓冲到第一块
    body 到达时**才投递（实测头与 body 同时到）。所以「头到了、body 永不来」的桩
    **测不出**立即取消 —— 那是在测 mock 的缓冲。桩必须「先给一小块、再慢慢发」。
  - **⚠️ 我自己在改的过程中引入了第二个回归，自查发现并修掉**：换成 delegate +
    `dataTask` 之后，**`Task.cancel` 的传递断了** —— 旧实现用 `session.data(for:)`，
    它天然响应取消；新实现没有把取消传给 `dataTask`，父任务取消后会一直跑到下载结束。
    实测 **3.08 s**（应 <1.5 s）。而调用方
    `DanmakuLoadOrchestrator.mediaHash` 是**显式处理取消**的
    （`catch where CancellationClassifier.isCancellation(error) { throw CancellationError() }`），
    传不下去那段代码就成了死码 —— 换片 / 关页时会白等一轮完整下载。
    **修法**：`withTaskCancellationHandler` 的 `onCancel` 里
    `collector.cancelForParentTask()` + `task.cancel()`；collector 用一个
    `cancelledByParent` 标记把错误映射成 `CancellationError`（而不是 `readFailed`）——
    否则调用方会分不清「取消」与「真故障」。
    用例 `testParentTaskCancellationStopsTheRequest` 钉住它：取消后总耗时从 **3.47 s**
    降到 **0.115 s**（整组 8 条）。
  - **⚠️ 审查又抓到 3 条，全部成立并已修**：
    ① **`cancelledByParent` 在锁外读 —— 真数据竞争**：`cancelForParentTask()` 由
       `withTaskCancellationHandler` 的 onCancel 在**另一条线程**写，
       而 `didCompleteWithError` 在 `lock.unlock()` **之后**才读它 —— 无同步的并发访问，
       Swift 6 下是 UB。最坏把「已完成」翻成「已取消」，或把取消读丢成 `readFailed`
       （调用方会把后者当**故障**而不是静默）。已改成**锁内捕获**。
    ② **`bodyLimit` 硬顶零测试覆盖**：把它改成 `if false`，本包其余用例**全绿**（实测）。
       这是「内存/流量硬上限」的核心防线，只被注释保护不够。
       已补 `testOversizedBodyIsCutOffByHardLimit`：合法 `206` 声明收 16 MiB、
       实际 100 MiB 一直发，断言 **2 秒内**抛 `readFailed`（不设限要 ~5 秒）。
    ③ **取消→`CancellationError` 的映射无断言**：删掉那个 `else if` 之后
       取消用例**仍绿**（它只断言 `threw`，不校验类型）。而
       `DanmakuLoadOrchestrator` 依赖 `CancellationClassifier` 区分取消/故障 ——
       退化成 `readFailed` 会让换片那次被记成真故障。已补 `error is CancellationError` 断言。
  - **顺带修掉审查指出的一个潜在窗口**：`attach` 的 `finished` 分支原先不看取消 ——
    若 `didComplete` 抢在 `attach` 之前完成，取消会当 `(nil, empty)` 返回，
    `expectedFileSize == 0` 时甚至返回空文件的 MD5。已在该分支也抛 `CancellationError`。
  - **⚠️ 又踩了一次「耗时断言在 CI 上假红」**：`bodyLimit` 那条我第一版断言
    「2 秒内抛错」—— 本地 0.91 s 稳定，**CI 上 3.03 s 直接红**
    （GitHub runner 慢 + 调度抖动）。这已经是这个演进方向上**第三次**
    被耗时断言咬到（前两次是 `P2-33` 并发用例、以及本次的取消用例）。
    **改法**：断言**桩实际发出去的字节数 / 块数**，不用耗时 ——
    硬顶生效时桩会停在 ~17 块，没有硬顶会发满 100 块；
    拒绝用例同理停在 1–3 块（共 11 块）。这是**确定性**的，与机器快慢无关。
    改完在 8 个 `yes` 进程压满 8 核的情况下复跑：**0.551 s 稳定通过**。
  - **反向验证**：① 退回 `data(for:)` → **红**（桩发满整个 body）；
    ② 去掉 `withTaskCancellationHandler` → **红**；
    ③ 去掉 `bodyLimit` 硬顶 → **红**（桩发满 100 块）；
    ④ 去掉取消→`CancellationError` 映射 → **红**。
    DanmakuKit 全量 **212 条 0 失败**。

- **`P2-33`：侧车字幕从「N 条串行往返」改成「有界并发取、按原序串行挂」。**
  - 原实现 `for subtitle in subtitles { try await downloadSubtitle(subtitle) }` ——
    **N 条字幕 = N 个串行网络往返**。局域网单次往返几十毫秒、跨网几百毫秒；
    一集挂 4–8 条（zh-Hans / zh-Hant / en / ja…）时首屏要多等好几百毫秒，
    而且那段时间字幕菜单是空的。
  - **修法**：新增 `downloadExternalSubtitles(_:limit:download:)` —— 默认 **4 路并发**
    （命名常量 `externalSubtitleConcurrency`），但**返回数组严格按入参顺序**。
  - **为什么顺序不能乱**：挂载顺序决定内核里的轨道序号，也决定「上次选的字幕
    （按 id 记住的偏好）」指向哪一条 —— 乱了就会选到别的语言上。
  - 语义三条都保留：**顺序**、**失败隔离**、**取消**（父任务取消后不再派发新任务）。
  - **⚠️ 审查抓到 3 条，全部成立并已修**：
    ① **测试仍与生产接线脱钩（第三次同类问题）**：9 条用例全在测 helper
       `downloadExternalSubtitles`，`AppTests` 里 `loadExternalSubtitles` 引用 **0** 次。
       更隐蔽的是**默认值 `limit: 4` 从未被执行**（用例全都显式传 `limit:`）——
       把它改成 **1（生产等价串行）用例仍全绿**。
       **修法**：把 4 提成命名常量 `externalSubtitleConcurrency`，并补两条用例 ——
       `testProductionConcurrencyDefaultIsFour`（断言常量值）与
       `testDefaultLimitActuallyRunsConcurrently`（**不传 `limit`**，走生产默认值，
       8 条 × 60 ms 须 < 420 ms）。已反向验证：**常量改成 1 → 红**。
    ② **换片取消会刷 warning**：一次取消打 **4 条**「下载外挂字幕失败」（等于在飞数）。
       旧实现 `catch is CancellationError { return }` 是 0 日志。违反仓库口径
       （`EmbySession`「取消不是故障，不记请求失败」）。
       **修法**：`catch` 里先用 `CancellationClassifier.isCancellation(error)` 判断，
       是取消就直接 rethrow、不打日志。
    ③ **耗时断言会假红**：原阈值 350 ms。审查实测**低 QoS 调度下**
       （`taskpolicy -b`，CI 上常见）同样的 4 路并发会涨到 **318 ms**，
       叠加忙进程后 10/10 全部 ≥350 ms（min 358.9 / p50 449.1）—— 假红。
       已放宽到 **420 ms**（串行下界 480、最慢实测并发 320，留出安全间隔）。
  - **⚠️ 一条已知的覆盖边界（不假装覆盖）**：接线级用例（真的驱动
    `loadExternalSubtitles`）没写 —— 它需要完整的播放会话就绪状态
    （`waitUntilSourceReady` + `activePlaybackIdentity` + `isSourceReady`），
    而能驱动它的 `GatedFakeEngine` fixture 是 `PlaybackControllerOpenTests` 里的
    `private` 嵌套类型，跨文件用不了。**「生产循环用的是并发版」这一点由代码评审保障**，
    本批只钉住了「helper 是并发且有序」+「生产默认值确实是 4 且真的被用上」。
  - 用例 9 条：**并发性**（8×60 ms < 420 ms）、**顺序**（故意逆序完成）、
    **失败隔离**、**并发上限**（峰值须 ≤2 且 ≥2）、**默认值常量**、
    **默认值真的被执行**、空输入、非法 `limit`、`limit` 大于条数时钳到条数。
  - **本轮工作方式改成「先反向验证再写正向用例」**，抓到 4 个变异：
    改回串行 → 红；按完成顺序收集 → 红；去掉并发上限 → 红；**默认值改成 1 → 红**。


- **`P2-32`：`nowPlayingInfo` 从「每秒跨进程写一次」降到「约 10 秒一次」。**
  - `nowPlayingInfo` 的 setter 会**跨进程同步**。原实现「快照 != 上次就发」，而快照含
    **整秒位置** —— 播放中位置每秒变一次，就等于**每秒一次写入**。但系统本来就按
    `playbackRate` 自行外推进度（`MPNowPlayingInfoCenter.h` 原文：
    "the elapsed time will be automatically extrapolated … updating this property
    frequently is not required (or recommended)"），那些写入几乎没有信息量。
  - **修法**：把重发判据抽成纯函数 `needsRepublish`，只在四种情况下真写：
    ① **首次**；② **内容变化**（标题 / 副标题 / 时长 / 速率 —— 暂停恢复、变速、换集）；
    ③ **seek**（实际位置偏离「按上次发布外推的位置」超过容差）；
    ④ **心跳**（距上次发布满 10 s，把系统外推可能的漂移收回来）。
    正常播放时只命中心跳 → **写入量从 1 Hz 降到 0.1 Hz**。
  - **⚠️ 第一版被审查抓到 4 条，全部成立并已修**：
    ① **阻断级：9 条用例全都不经过 `publish()`** —— 把 `publish` 里对判据的调用
       整段删掉，用例**仍然全绿**。测试等于在测「一个可能与生产无关的函数」。
       **修法**：给 `PlaybackNowPlayingCenter` 加了两个注入接缝
       `writeNowPlaying` / `writePlaybackState`（默认写系统，测试换计数器桩），
       于是用例能**真的驱动 `publish()` 并数「写了几次」**。已验：删掉接线 → **红**。
    ② **`rate != 1` 的外推一次都没测**：把 `last.rate * elapsed` 改成 `elapsed`，
       当时 9 条全绿。而 `rate=2` 在生产里可达（长按快进 `applyRate(2.0)`）。
       已补 `testTwoTimesPlaybackExtrapolatesWithRate`；变异 → 红。
    ③ **暂停中的小 seek 永远收不回来**（不是「最多 10 s」）：心跳**不是定时器** ——
       `publish()` 的触发源只有「1 Hz 的 displayPosition」（仅播放中变化）、state 变化、
       元数据变化。暂停后进度 tick 停了 → 再也不会有 `publish()` → 心跳永远不响。
       原 2 s 容差下，暂停中拖 1.9 s（90 s 短片的滑条约 8 pt）会一直停在旧值。
       **修法**：暂停（`rate == 0`）时容差**归零**（没有外推误差可混淆，任何位移都是用户操作）。
       已补 `testPausedSmallSeekWritesImmediately`（走真实 `publish()`）；变异 → 红。
    ④ **时间基准/时钟不可注入导致计数测试无意义**：测试里 `publish()` 循环瞬间跑完、
       `systemUptime` 几乎不动 → 心跳永不触发、seek 判据反而每几秒误触发，
       实测跑出 **1201 次**这种数字。加了 `now: () -> TimeInterval` 注入点后正常。
  - **⚠️ 顺带更正两处我先前的表述**：
    · 注释里曾说「心跳先判是为了避免用过去很久的外推做 seek 判定」——
      审查实测**顺序不可观测**（两个分支都 `return true`、无副作用），
      已改成实话「顺序不影响结果，放前面只是短路」。
    · `systemUptime` 不是「系统运行时长」——它**扣除睡眠**（本机实测差约 239 s）。
      对本案恰好正确（睡眠时媒体位置也不动），注释已补。
  - 用例 14 条：**8 条走真实 `publish()`**（首次 / 内容变化 / 暂停 / seek / 30 秒只写 4 次 /
    一小时约 361 次 / 暂停小 seek / inactive 清空），
    6 条测纯函数边界（rate=2 外推 / 精确基准 / 暂停容差 / 心跳三档 / 常量 / inactive）。
  - **变异验证**：删接线 → 红；丢 rate 因子 → 红；暂停容差回 2 s → 红；
    恢复每秒都发 → 红；心跳改 1 s → 红。


- **`BLD-05`（Release 开 LTO）：A/B 实测后**不采纳**，但**理由与清单原文都错了，已重写**。**
  - 清单建议「试 `YES_THIN` 并 A/B 体积与链接耗时」。本批做了 A/B：

    | 变体 | 构建耗时 | 可执行文件 |
    |---|---|---|
    | A：不改（无 LTO） | **307 s** | 89.4 MB |
    | B：`LLVM_LTO = YES_THIN` | **1109 s（3.6×）** | 89.41 MB |

  - **结论仍是不采纳**：体积**无可分辨差异**，而构建时间是 **3.6×**。
  - **⚠️ 我为此写的第一版「硬依据」是错的，必须记下来**：我声称
    「`liberika_capi.a` 是机器码、没有 `__LLVM` 段，LTO 结构上无法处理它」。
    **实测推翻**：直接 `otool -l | grep -c "__LLVM"` 在归档里有 **792** 个 `__LLVM` 段；
    逐个成员检查有 **396 个成员带内嵌 bitcode**（含最大那个 Rust codegen unit，14.5 MB IR）。
    **我的检查方法错了**：命令写成
    `otool -l ... | grep -A 3 LC_SEGMENT_64 | grep __LLVM` —— 而 `__LLVM` 段的描述
    不在 `LC_SEGMENT_64` 后 3 行内，被那个 `-A 3` 过滤器筛掉了，于是我看到 0。
    **这是「测出来的假阴性」，比没测更糟**：它给一个错误结论披上了实测的外衣。
  - **真实边界（审查用 20 秒实验证明）**：把 `-fembed-bitcode=all` 的 fat 对象打进 `.a`、
    链接加 `-flto=thin` → hidden 的 `a_internal` 符号消失（被内联/内部化）；
    不加 LTO 时保留。即 **ld64 的 thin-LTO 确实会消费静态库成员里的内嵌 bitcode**。
    LTO 的作用域因此是：**Rust 部分有 IR（396/397 个成员）**、
    **FFmpeg/libass 的 C 部分没有 IR（139 个 C 成员一个都没有）** ——
    不是「整个预编译库 LTO 无效」。
  - **所以为什么最后仍不采纳**：只剩 A/B 实测那一层证据（体积无可分辨差异 + 3.6× 构建时间），
    **不再声称任何「结构上不可能」**。这也说明清单原文「LTO 对 Rust/FFmpeg 静态库无效」
    这个前提本身就错 —— 我照抄了它，还给它补了个更错的论证。
  - **⚠️ 三处方法学问题一并更正**：
    ① 「差 < 0.01%」**超出精度**：`89.4 MB` 是 1 位小数（±0.11% 窗口），撑不起 0.01%；
    ② 「480 s / 368 s」是**整个打包 job** 的时长、不是编译段 —— 不能直接乘 3.6。
       真实增量 ≈ 编译段 × 2.6 ≈ **+13 min/平台**；
    ③ 整体文件大小相同**不等于代码段相同**：发布产物的 `__LINKEDIT` 占 41%，
       0.1 MB 的分辨率对「代码段有没有缩小」几乎没有推断力（要看 `size -m`，
       而 B 的产物已被清理）。
  - **构建耗时也不可复核**：仓内无日志、产物已删（`clean.sh`），单次测量。
    reflog 时间线放得下，但没有可复现证据 —— **这个数字只能当「一次观测」**。

- **`P2-34`：`schedulePreparationDismiss` 的 100 ms 轮询循环加总时限（**看门狗 + 30 s**）**。
  - 那是一个每 100 ms 唤醒一次主 actor 的轮询循环，原本只靠三条 `return` 退出：
    ① 首帧已上屏 ② `state == .error` / `setupError` ③ playing 持续 2.5 s。
  - **三条都可能在真实可达的状态下一直不成立**：`.ready`（打开成功、内核已 init，
    但网络饿死迟迟不出帧又不报错）**原本无上限**；`.paused` 也可达 ——
    macOS 的键盘监听是全局 `NSEvent.addLocalMonitorForEvents`，loading 期间按空格会
    触发 `pause()`，若此时尚无渲染帧，`hasRenderedFirstFrame` 永远 false。
  - **修法**：把循环的**完整决策**抽成纯函数 `preparationDismissDecision`，循环体只剩
    「取状态 → 调它 → 按结果清态返回」。时限 = **打开看门狗 + 30 s**。
  - **⚠️ 第一版把时限设成 30 s，那是回归**（审查实测指出）：看门狗是 60 s，
    30 s 到点只撤 loading、`presentedPlayer` 不动 → 露出 `PlayerScreen`，
    而首帧没出、state 还是 `.opening`/`.ready` —— 而
    `showsBufferingIndicator` **只对 `.playing` 为真**，所以那 30 秒是
    **纯黑屏、无转圈、无文案**，直到 60 s 看门狗才出错误徽章。
    等于把一个「有反馈的等待」变成「无反馈的黑屏」。已改成看门狗之后，
    并用用例 `testDeadlineIsBeyondOpenWatchdog` 钉住「时限必须大于看门狗」。
  - **⚠️ 第一版只抽了「是否超时」一条，测试等于没测生产逻辑**（审查实测）：
    把循环里对它的调用整段删掉，4 条用例**仍然全绿**。只测一个布尔表达式
    等于在测 `>` 运算符。现在抽的是完整决策，表驱动用例覆盖所有分支：
    换片先 `.stop`（不动 loading）/ 控制器没了 / 首帧已上屏（**无论 state**）/
    出错 / playing 宽限 2.5 s / 超时 —— 外加 `.ready` 饿死与「全部非终态都被时限兜底」
    两个真实场景，以及 2×2×2×8×2×2 的**组合收敛性**（1000 s 后绝无 `.wait`）。
  - **⚠️ 覆盖边界（不假装覆盖得更多）**：表驱动用例覆盖的是**分支逻辑**，
    **不覆盖「循环是否真的调用了它」** —— 审查实测：删掉接线，用例仍全绿。
    要覆盖那层需要给 `PlaybackController` 注入可卡住首帧的桩，
    而 `AppModel.playback` 是具体类型不是协议，成本远超本次范围。
    **接线由代码评审保障**，已在函数注释与 PR 说明里写明。
  - **⚠️ 第一版还有一套假测试（已删）**：试图直接观测「循环在时限后退出」，
    但测试里 `playback` 恒 nil、循环立即退出到不了时限分支，我甚至写了
    `XCTAssertNotNil(x == nil ? true : true)` 这种永真占位断言。

- **`P2-30`（详情快照 LRU 读路径 O(n) 簿记）：实测 ~5 µs，仍不改，但数字已更正**。
  - 我原先测到 n=40 是 **0.65 µs**，据此判定不改。**审查复测是 4.9–6.0 µs（差 8–10×）**，
    并给出理论下限推算：谓词对每个不匹配元素都要做一次字典查找（hash），
    39 次 hash + 39 次 `==` ≈ **6.2 µs 下限** —— 我的 0.65 µs **低于下限**，
    只可能是基准里谓词被短路掉了。
  - 频次核算：每次进详情页约 2–4 次调用 → 按 5 µs 算是 10–20 µs/页，
    相对一次详情页加载（毫秒级）仍可忽略 → **「不改」的结论不变，但用错的数字
    支撑正确的结论是危险的**（下次别人复现不出来会连同结论一起推翻），已更正。
  - n=1000 → 实测约 **125 µs**（我原写 9.30 µs）；那是超出生产上限的外推，
    只作「复杂度形状」证据。

- **`P2-22`：MoviePilot 的 JSON 解析从「三遍」压到「一遍」（**4.4–5.0×**，真实负载省 **0.6–1.6 ms**）**。
  - `MPMediaInfo` / `MPDownloadTask` / `MPSubscribe` / `MPSite` 都不是 `Codable`
    —— 它们要原始 `[String: JSONValue]`（下载时整个对象原样回传服务端）。
    原路径是：
    1. `unwrap(data)` → `JSONSerialization.jsonObject`（**全量解析成 Any 树**）
    2. → `JSONSerialization.data(withJSONObject:)`（**再序列化回 Data**）
    3. → `JSONDecoder().decode([[String: JSONValue]].self, ...)`（**第二遍全量解析**，
       且是 `try?` 瀑布：每个值依次 `try?` Bool / Double / String / Array / Object）
    **一份数据解析三遍。**
  - **修法**：新增 `MPEnvelope.unwrapObjects(_:)` —— **只解析一遍**：
    `JSONSerialization` 拿 `Any` 树，剥信封后直接 `JSONValue(any:)` 转换。
    4 个调用点（`searchMedia` / `sites` / `downloadingTasks` / `subscribes`）切过去。
  - **实测（按真实负载分档，包测试 Debug 口径）**：

    | 场景 | 大小 | 旧 | 新 | 倍数 | 省 |
    |---|---|---|---|---|---|
    | **真实下载页（10 任务）** | 3.6 KB | 0.78 ms | 0.17 ms | 4.5× | **0.60 ms** |
    | 下载页极端（50 任务） | 17.9 KB | 3.50 ms | 0.71 ms | 5.0× | 2.80 ms |
    | **真实搜索（24 条）** | 15.6 KB | 2.07 ms | 0.47 ms | 4.4× | **1.59 ms** |
    | 搜索极端（100 条） | 65.3 KB | 8.59 ms | 1.96 ms | 4.4× | 6.63 ms |

  - **⚠️ 一处我先前夸大的数字，已更正**：我最初写「28.47 → 7.92 ms / 省 20.6 ms」
    「98.98 → 21.69 ms / 省 77.3 ms」——那些用的是**合成的 232–243 KB / 300 对象**
    负载，而**真实下载页只有 10 个任务约 3.6 KB**。审查指出后重测：真实负载只省
    **0.6 ms**（下载页）/ **1.6 ms**（搜索）。
    倍数（4.4–5.0×）是真的，但**绝对值必须按真实负载报** —— 否则就是在用
    合成负载给改动贴金。
  - **那为什么还保留**：① 倍数真实、无风险；② 它同时是下面那个正确性 bug 的
    依赖路径（新路径走 `JSONValue(any:)`，必须先把 `init(any:)` 修对）；
    ③ 真实负载 0.6 ms 虽小，但下载页是 **5 秒轮询**，且这条路径也在**搜索结果**
    与**订阅列表**上（各 1.6 ms）。**不声称它是大收益** —— 按真实量级记账。

- **顺带修掉一个既有正确性 bug：`JSONValue.init(any:)` 把 JSON 数字 `0`/`1` 当成布尔**。
  - Swift 的 `NSNumber` → `Bool` 桥接**对 0 和 1 也成立**：实测
    `NSNumber(value: 0) as? Bool` 得到 `false`、`1` 得到 `true`。
  - 而 `init(any:)` 原先**先** `case let value as Bool`，于是 JSON 里任何 `0`/`1`
    数字都变成 `.bool(...)`。而 `JSONValue.intValue` / `doubleValue` **只认 `.number`**
    —— 这些字段于是变成 `nil`。
  - **生产影响**：SSE 资源搜索用 `torrentRaw.mapValues(JSONValue.init(any:))` 把整个
    `torrent_info` 收进 `MPTorrent.raw`。于是 `seeders` / `size` 取到 **0 或 1** 的
    资源，那些字段**直接消失**（`raw["seeders"]?.intValue == nil`）。
  - **修法**：布尔判定改问 CoreFoundation 的**真实类型** ——
    `CFGetTypeID(value) == CFBooleanGetTypeID()`（只有 `__NSCFBoolean` 才是布尔，
    普通数字 `NSNumber` 不是）。
  - 用例钉住：数字 0/1 必须是 `.number` 且 `intValue` 可读；真布尔仍是 `.bool`
    且 `intValue` 为 nil；其它数字、字符串、null、数组、嵌套照常；
    以及**真实形态**（`seeders: 0` 的资源对象字段不丢）。
  - **变异验证：把实现改回原始的 `case let value as Bool` → 3 条用例红。**

- **`P2-15`（详情页选集轨道每 body O(n) 复制）实测量级太小，不改**。
  - 实测 `Array(slots.reversed())` + `itemsIdentity` 哈希合计：
    n=24 → **0.43 µs**、n=100 → 1.92 µs、n=500 → 8.86 µs、n=1000 → **17.9 µs**。
  - n=1000（比现实中的长番还多）也只有 17.9 µs —— 与上一批回退的几条同一个量级，
    **按同一标准不改**。

- **`P2-18`：详情页 `metaRow` 的 `ForEach` 身份改用内容（**正确性修复，不是性能修复**）**。
  - `metaParts` 是动态拼的（年份 / 类型 / 时长 / 季数），**任一字段缺失会让后面元素
    整体前移**。原实现用 `\.offset`（下标）当身份 —— 前移等于「第 N 个元素换成了
    别的内容」，视图身份与数据身份脱节。
  - 修法：身份用**内容**（`id: \.element`），分隔符仍用 `index > 0`（位置信息确实需要）。
  - **⚠️ 不声称性能收益**：独立审查明确指出并核实了 —— 4 个 `Text` 的 `HStack`
    无论用哪种 id 都无感；我原先在注释里写的「与 `Motion.standard` 翻转动画叠加会抖」
    **没有任何录屏或计数证据**，而且那段翻转发生时 `metaParts` 本就不变。
    所以注释已重写为「这是身份语义问题，不是性能问题」。
  - **唯一性前提**（必须成立，否则 `ForEach` 收到重复 id 是未定义行为）：四类内容的
    **文本形态互斥** —— 年份纯数字 / 类型含 `" / "` / 时长含「小时」或「分钟」/ 季数含「季」。
    `MetaPartsShapeTests` 用**穷举**钉住这条前提（年份 1900–2100 × 时长 1–300 分钟 ×
    季数 1–20，逐对求交集必须为空），并断言每类产物的判别特征。
  - **⚠️ 第一版设计被审查推翻**：我先做了一个 `identified()`，把身份拼成
    `"内容#出现序号"`。审查实测 `identified(["A","A","A#1"])` → `["A","A#1","A#1"]`
    —— **仍会产生重复 id**，因为字面值 `"A#1"` 与第二个 `"A"` 生成的 `"A#1"` 撞车。
    自造的 8 条用例里也没有一条能抓住这个（它们只测 `identified` 本身）。
    现已按「形态互斥」的前提简化掉，并在注释里写明：将来若要加同形态字段，
    必须改成**结构化 ID**（`struct ID: Hashable { text; occurrence }`），**不要拼字符串**。
  - **⚠️ 另一处不实陈述已删**：第一版 CHANGELOG 写「变异①改回 `id: \.offset` → 红」。
    **这是假的** —— 那 8 条用例只调用 `identified`，`.offset` 回退发生在 `metaRow` 内部、
    根本不经过它，改回去后 8 条仍全绿。审查实测确认。

- **`P2-17`（`ISO8601DateFormatter` 共用）实现后**全部回退** —— 机制真实，但价值无可感知**。
  - 机制本身成立：`\(ISO8601DateFormatter().string(from: Date()))` 每次新建 formatter，
    本机 `-O` 实测**构造 56.4–81.8 µs**、共享实例 `string(from:)` **1.117–2.286 µs**
    （比值 25–69×，与机器/轮次相关）。`Date()` 本身只占 0.109 µs，所以那几十微秒确实是构造。
  - **但按我自己回退 `ByteCountFormatter` 的同一标准，这条也该回退**：
    `makeText` **每次导出只调 1 次** headerLines，而导出本身要读 8 MiB 日志 + 4 MiB trace
    并过正则 —— **省 70 µs/次用户完全不可感知**。标准要一致，不能只对自己想留的条目宽松。
  - **⚠️ 两条辩护理由都与事实不符**（审查核实）：
    ① 我在注释里写「只在主线程的导出路径上用」—— **假**，
       `SettingsPagesMaintenance.export()` 是在 `Task.detached` 里调的；
    ② 我写「Apple 文档：the formatter is thread-safe」—— 在 SDK 的
       `NSISO8601DateFormatter.h` 与当前 Apple 页面摘录里**都找不到这句**，
       而且该类在 SDK 里**没有**标 `Sendable`。属于可疑引证。
  - **有更好的写法**（若将来真要修）：`Date.ISO8601FormatStyle` 在 swiftinterface 里
    是 `Sendable`，同一日期输出**逐字节相同**，实测 `.format(d)` **0.236 µs**
    （比共享 `ISO8601DateFormatter` 还快），且**零 unsafe**。仓库同类问题既有做法是
    `@unchecked Sendable` holder（`DiagnosticsKit.TimestampFormatters`、
    `BangumiKit.BangumiCollectionTimestamp`），**没有 `nonisolated(unsafe)` 的先例**
    —— 我用的是最弱的逃逸，不该开这个头。
  → **代码全部回退**（`DiagnosticsExport.swift` 与 main 一致）。

- **`ByteCountFormatter` 那一半也维持回退（本批复核确认）**。
  - 我先前测到「静态便捷方法 4.153 µs vs 共用实例 3.104 µs（25%）」是**假象**
    （warmup 不足 / 未开优化）。`-O` 充分 warmup 后：静态方法 2.046–2.115 µs、
    共用实例 2.068–2.162 µs —— **无差异，新写法还略慢**。
    「类静态便捷方法每次新建 formatter」这个假设本身也不成立。

- **本批教训（连续第三批被审查推翻，这次是「标准不一致」）**：
  我在同一批里，用「省 70 µs 但每次导出只调一次 → 不值得」的标准回退了
  `ByteCountFormatter`，却把**同样量级**的 `ISO8601DateFormatter`（省 70 µs、
  每次导出调一次）留下了。**标准必须一致**，否则「留着的那条」就是靠叙述撑起来的。
  另外：**变异验证必须真的触达被测代码路径** —— 我声称的「改回 `.offset` → 红」
  根本没经过被测函数。

- **`P2-01` / `P2-03` / `P2-04` / `P2-05`：实现后**全部回退**，理由都是「机制假设被实测推翻」。**
  - 这一批我按清单做了四处「少挂材质 / 少挂投影 / 去掉玻璃容器 / 骨架屏减块」的优化，
    独立审查用 `NSHostingView` + `bitmapImageRepForCachingDisplay` 的 2x 离屏快照
    逐像素实测后，**四条的理由全部站不住**。代码已**全部回退到 `main`**，只留下这份记录。

  - **`P2-01`（行式卡片磨砂改纯色）—— 我造成的是可见视觉回归，不是「近似」。**
    我把无条件的 `.ultraThinMaterial` 换成 `Color.primary.opacity(0.04)`，并声称
    「同色系纯色近似」。实测（同一像素、深浅两种外观）：

    | 背景 | 外观 | 原 material | 我的纯色 | 最大通道差 |
    |---|---|---|---|---|
    | **真实层级**（行在磨砂卡内） | 浅 | (248,229,165) | (242,213,110) | **55** |
    | 同上 | 深 | (129,112,29) | (182,156,33) | **53** |
    | 蓝 | 浅 | (132,172,236) | (49,124,223) | **83** |
    | 黑 | 浅 | (107,107,107) | (0,0,0) | **107** |

    **根因**：material 在浅色是「提亮纱」、深色是「压暗纱」，而 4% primary 在浅色是压暗、
    深色是提亮 —— **方向相反**，不可能近似。只有纯白背景浅色下碰巧接近（Δ1）。
    更糟的是两处调用点的 `.onHover` 直接赋值、**没有动画**，于是悬停瞬间从纯色硬切到
    模糊材质，实测跳 ~50 级；原来 material 常驻、只有填充变，跳变小得多。
    → **回退。** 这条本质是**视觉取舍**（和 `P2-08` 同类），不是性能项；
    要动它必须有设计决策，不能靠「看起来差不多」。

  - **`P2-03`（去掉卡片内的 `GlassEffectContainer`）—— 性能理由与 Apple 文档相反。**
    我写的理由是「容器里只有 2–3 个胶囊、融合域太小、却每开一个容器付一次离屏合成」。
    Apple 文档原文是：**「Use GlassEffectContainer when applying Liquid Glass effects on
    multiple views to achieve the best rendering performance」**、
    **「applying too many effects to views outside of containers can degrade performance」**
    —— 容器是**批处理**，去掉之后每张卡的玻璃变成容器外的独立 effect，
    正是文档警告的反模式。
    静态观感实测**没有**差异（container vs 无 container 全图 maxΔ=**0**，深浅两色），
    所以不是视觉 bug，但「性能收益」未验证且**大概率反向**，不能作为合入理由。
    → **回退。** 正确方向是「列表外层共用一个容器」（我原注释里自己都写了这句），
    那是结构性改动，另立条目。

  - **`P2-04`（`radius: 0` 的投影改条件挂载）—— 我的核心假设是错的。**
    我假设「`.shadow(radius: 0)` 仍会为投影单独建一层合成路径」。层树实测：
    无 shadow 是 `NSViewBackingLayer + CALayer`（2 节点）；`.shadow(radius: 0)`
    **仍是 2 节点**（`shadowOpacity`/`shadowRadius` 就设在同一个内容 layer 上）
    —— **不存在「单独一层」**。
    radius-0 确实被光栅化（144 px 有差、maxΔ=**3**，仅抗锯齿边、肉眼不可见），
    而我自己也测不出成本（0.0523 vs 0.0507 ms/帧，噪声级）。
    更糟的是我加的 `.compositingGroup()` 反而**多建一个 CALayer 子层**（3 节点）；
    全仓 `shadowed: true` 只有 1 处，所以代价极小，但**方向是负的**。
    → **回退。** 注释里「否则投影会对每个子层各做一遍」「类型擦除成 AnyView」两处说法也不成立。

  - **`P2-05`（骨架屏 108 块每帧重算）—— 我说「没有 Instruments 无法验证」，这个理由是错的。**
    审查用同一个 `NSHostingView` 快照法就能验证观感等价（渲染旧/新 shimmer 两块即可），
    **不需要 Instruments、不需要构建整个 App**。骨架块数也是静态可数的
    （Library 36×2=72、Home 搜索 24×2=48、MoviePilot 10×3=30）。所以我该说
    「本批不做 / 优先级低」，不该说「没法验证」。**本批不做**（修法是容器级单条亮带 + mask，
    属结构性视觉改动，应单独立项）。

  - **这一批的教训**：这四条我给的都是**机制推导**，而机制本身是错的。
    「性能优化」的理由如果是「某个 SwiftUI 行为应该会怎样」，那它就是一个**待验证的假设**，
    必须先测（层树 / 像素 / 计时）再动手 —— 本批四条里三条的假设都测反了。
    唯一可复制的方法是审查用的那套：`NSHostingView` + `bitmapImageRepForCachingDisplay`
    + `colorAt` 的离屏快照，以及递归打印 `CALayer` 树。

- **`P2-13`：MoviePilot 搜索结果「是否已订阅」从每行 O(M) 全表扫改成 O(1)**。
  - 原先每行都调 `isMediaSubscribed(media)`，内部是 `subscribes.contains { ... }`
    —— 对**每一行**做一次 O(M) 全表扫描（M = 订阅数），4 个字段各比一次。
    搜索结果 R 行就是 O(R×M)，而这一整段在同一次 body 里、`subscribes` 根本没变。
  - 修法：新增 `SubscribedIndex`，在 `ForEach` 前**建一次** 5 个 `Set`
    （本地 id / tmdb / douban / bangumi / 片名），之后每行哈希查找。
  - 用例 13 条：逐字段语义 + **`nil` 与 `nil` 不算匹配**（旧实现要求两侧非 nil，
    若索引把缺失字段收成默认值，会变成「所有无 tmdb 的媒体都算已订阅」）
    + **大小写必须敏感**（旧实现是精确等值）+ **空串行为与旧实现一致**
    + 订阅侧只有 `title` 字段时的回退 + 重复值 + **用旧实现当 oracle 的穷举对照**。
  - 变异验证：片名判据从「完全相同」改成「包含」→ **红**。
  - ⚠️ 记两次**无效变异**：① 把「订阅侧 `nil` 字段收成 0」当变异 → 绿，因为媒体侧
    取不到字段时根本不会去查那个 Set，变异不产生行为差异；② 审查实测把索引与查询
    都改成 `lowercased()` → 当初 9 条全绿，因为 fixture 没有「只差大小写」的样本。
    后者已补 `testTitleMatchIsCaseSensitive`。

- **`P2-12`：订阅页的派生数据不再一次渲染算 6 遍**。
  - 原先 4 个独立 computed property（`displayedSubscribes` 被读 2 次 +
    `movieCount` / `tvCount` / `watchingCount`），一次渲染 **5 次全表 filter**。
  - **⚠️ 我第一版改错了，反而更慢**：把 4 个属性合并成一个纯 computed property
    `subscribeSummary` 后，读取点变成 5 个（header 三个计数 + 空态判断 + `ForEach`）——
    每次访问都完整跑一遍循环，macOS 上 **6 次**、且每次新建两个数组。
    独立审查用微基准实测：旧 0.178 s vs 新 0.254 s（N=2000，2000 次渲染）
    —— **慢 1.43 倍**。这是我自己引入的回归。
  - 正确修法（两步）：① 在 `subscriptionsView`（那些读取点的**共同父层**）hoist
    一次，把 summary 当参数传给 `headerControlBar` / `subscriptionsGrid`；
    ② 加 `@State` 缓存（`subscribes` 的内容指纹变了才重算），覆盖
    `navigationSubtitleText` 那种跨 computed property 的读取点。
  - 分类语义与旧实现逐字对应（`isMovie` / `isTV || !isMovie` / `state` 缺省按 "R"
    且大小写不敏感）—— 审查逐条核过。

- **`P2-14`：设置 → 首页栏目不再一次 body decode 17 次**。
  - `layout` 是 computed property，每次访问都完整跑 `HomeSectionPreference.decode`
    （trim / split / 逐 token / Set 构造 / `allCases.filter`）。这一屏一次 body
    读了它 **≥17 次**。
  - 修法：`body` 开头 hoist 成局部常量，一次 body 只 decode **一次**。
  - **⚠️ 只 hoist 读路径**：写路径（`moveHomeSection` / 开关的 `set`）保留现读现取 ——
    那是防「连拨两个开关时拿旧快照互相覆盖」的（原作者注释专门说明了这点）。
    开关的 `get` 用本次 hoist 的那份，`set` 仍现读。
  - 审查用 swiftc 实测确认 `let layout = layout` 这种遮蔽写法语义正确、无自引用。

- **`P2-11`：日历页搜索不再每敲一个字扫两遍全表并重复 `lowercased()`**。
  - `filteredDays` 是 computed property：每次 body 全表扫（100–300 条 ×
    name/nameCN/summary 三处 `lowercased().contains`），而 `displayDays` 又调它一次
    → 每敲一个字至少两趟全表。
  - 修法三层：① 结果进 `@State` 缓存，由 `.task(id:)` 变化时算一次；
    ② `lowercased()` 产物**预计算成索引**（只取决于 `days`、与关键词无关）；
    ③ 三条字段拼成一个串（`contains` 只关心「有没有」，等价但省两次调用）。
  - **⚠️ 第一版的缓存失效条件写错了，会造成「永久过期」**：我用
    `.task(id: days.count)` 当数据变更信号，理由是「DTO 没实现 Hashable 等价性」
    —— **那理由是错的**，`BangumiCalendarDayDTO` 明确是 `Hashable`。而
    `getCalendar` 的契约就是「按周一至周日 **7 天**分组」，`days.count` **恒为 7**：
    刷新日历后数据整体换了一批、`count` 还是 7，`.task` **不重跑** →
    搜索要么命中 0 条、要么**用旧名字命中新条目**，且搜索态下一直显示旧结果。
    独立审查用 SwiftUI 探针实测（内容 `[1,2,3]` → `[9,2,3]` 时 `runs` 仍为 1）。
    已把 `id:` 改成 `days` 本身。
  - 另一处：缓存改成**带关键词**的。`.task(id: searchKeyword)` 是异步的，
    改关键词后至少一帧还在读旧 cache —— 第一版只存 `[DTO]`，那一帧会显示
    **上一个关键词的结果**（清空搜索时闪一下）。现在读到关键词不匹配就当场算一份。
  - 用例 7 条：三条字段都可搜、大小写不敏感、**字段间不串味**（`\u{1F}` 分隔符）、
    过滤只留命中且丢空天、**索引路径与即时路径结果必须一致**、
    以及**空关键词会被清空**（`String.contains("")` 返回 **false**，所以调用方
    必须自己 guard —— 这条我最初断言写反了，是实测纠正的）。
  - 顺带：`filter` / `searchableText` 标了 `nonisolated` —— 它们是纯函数，
    而 `View` 的静态成员默认受主 actor 隔离，从非隔离测试上下文调用会失败。

- **CI flaky：`DanmakuCacheTests.testStaleMemoryDoesNotDeleteFileWrittenElsewhere` 的 TTL 余量不足**。
  - 现象：PR #46 的 CI 红在这个用例（三处断言全红），**本机同一条 0.136 s 通过**；
    而本批改动完全没碰 `DanmakuKit`。
  - 根因：这条用例有**两段时间**需要余量，而且方向相反：
    ① **等内存条目过期**：`stale` 自己的 TTL 必须**小于** `Task.sleep` 时长，
       否则 `comments(for:)` 直接命中内存、走不到磁盘路径；
    ② **读盘上那份新数据时不能判它过期**：`diskComments` 用的是 **`self.commentsTTL`**
       （即 `stale` 的 TTL）去判**盘上文件的 `fetchedAt`**，而那份文件是 `other`
       刚写的（`now - fetchedAt ≈ 0`）—— 所以这个 TTL 反而要**足够大**以吸收 CI 抖动。
  - 原值 `0.05 s TTL + 120 ms sleep`：②只有一个 **50 ms** 余量，慢 runner 上不够。
    改成 `0.5 s TTL + 800 ms sleep`：①300 ms 余量、②500 ms 余量。
  - **⚠️ 我第一次改错了方向**：把 TTL 改成 `0.001 s`（以为「余量 = sleep − TTL，越大越好」），
    结果 ② 的余量从 50 ms 缩到 **1 ms**，全量跑时反而立刻红（203 条里 3 失败）。
    弄清 ② 的机制后才改对。
  - 变异验证：把「内存过期时删盘上文件」重新引回去（即这个用例防的原 bug）→ **红**。
    说明放宽时间余量没有让它失去判别力。

- **`LIVE-02`：补上冷启动那段 865 ms 的日志盲区**。
  - 真实会话实测：`2 ms 应用启动` → **`867 ms 首页磁盘缓存预热`**，中间**一条日志都没有**，
    诊断包无法归因这段花在哪（会话恢复？`ServerStore` 解码？SQLite 首次 attach？
    `MetadataHydrator.home()` 的读？）。
  - 新增两条打点：
    - **「冷启动分段」**（`bootstrap`）：`setupKickoffMs`、`restoreMs`、`activateMs`、
      `totalMs`，外加 `restored` 布尔（走 onboarding 时 `activateMs` 接近 0，
      单看数字会误以为「装配很快」）。
    - **「首页用磁盘缓存预热」加 `readMs`**：`hydrator.home()` 的读盘/解码耗时。
  - 用**单调时钟** `ContinuousClock` 而不是墙钟：墙钟会被 NTP / 用户改时间污染。
  - **⚠️ 第一版把第一段叫 `setupMs` 并在注释里写「建库」，是错的**：
    `bangumi.setup()` / `metadata.setup()` 内部是 `Task.detached` 建库后**立即返回**，
    所以那个数通常≈0，根本不是「建库花了多久」。真正等库发生在 `activate` 的
    `metadata.wrap`（已计入 `activateMs`）。审查实测确认（mock 里 detached 建库 865 ms
    → `setupMs = 0 ms`）。已把字段改名为 **`setupKickoffMs`**，注释写明它只是「发起」。
  - 顺带记下两处踩坑：① 把整段写成一个大的字典字面量会让类型检查器超时
    （`unable to type-check this expression in reasonable time`），必须拆成局部常量；
    ② `Duration` 不能直接转 `Int64`，只能拆 `components`，抽了 `elapsedMs(from:to:)`。

- **`LIVE-03`：relief 的日志读数改对了；「没收益就早退」**被评估并否决**（我此前加了，已撤销）**。
  - 真实实测（四拍 +2s/+25s/+60s/+120s），`physFootprint` 变化 **≤0.1 MB**，
    后三拍看起来是纯开销 —— 我据此加了「某拍回收 < 1 MB 就不再排后续拍」的早退。
  - **⚠️ 这是一个我自造并已撤销的错误优化**：这个函数**自己的注释**就写着
    「+2s/+25s 时内核媒体会话尚未释放完，relief 无页可收」，`+60s/+120s` 才是收内核尾巴的。
    也就是说**前两拍本来就该是 0** —— 拿第一拍的结果决定要不要排后两拍，判据逻辑上无效。
  - **成本实测才是决定性证据**：一次全 zone relief sweep = **58 ns**，一次 `TASK_VM_INFO`
    = **1.18 µs**。省下的是**纳秒级**，而丢掉的是「几百 MB 内核尾巴」这个功能存在的理由。
    → **四拍原样保留。** 这也说明清单 `LIVE-03` 里「省掉三次无用的 zone 遍历」这个
    预期收益**基于错误的成本模型**（把 58 ns 当成可观开销），不值得为它冒风险。
  - **日志读数改对**：原来同时打 `physFootprint` 与 `malloc size_allocated`，两者都不是
    「这一拍到底拿回多少」的好读数。现在报 **`malloc_zone_pressure_relief` 的返回值**
    （`malloc.h` 语义是 "number of bytes released"），footprint 只留作对照。
  - **⚠️ 一处我说错并已更正**：我曾断言 `size_allocated`「结构上不可能因 relief 而变」。
    审查指出这不成立 —— `size_allocated` 语义是 "reserved in memory"，而 relief 做的是
    munmap，munmap 可以降低 reserved VM。删该字段的**真实理由**只是「它作为本拍收益的
    读数不好用」，不是「它必然不动」。
  - 同时删掉了自造的 `MallocPressureReliefTests`：那条断言「relief 不改已分配字节」在本机
    **恒真**（relief 到处返回 0，把它整个删掉 delta 仍是 0），无法失败，留着是假保护。

- **`LIVE-01`：弹幕匹配期间显示已等待时长（11 秒不再像卡死）**。
  - 真实会话实测：弹幕首次装载 **11.1 s**，其中 **10.4 s 是网关往返**
    （+8.6 s 首次请求以 500 失败 → +11.1 s 重试成功）——**不是 App 的计算**
    （同集第二次装载仅 575 ms）。
  - **「重新匹配」入口其实已经有了**（`PlayerHUDActions` 的 `arrow.clockwise`，任何状态可点），
    所以清单说的「缺一个可操作状态」并不完全准确 —— 真正缺的是**进展感**：那 11 秒里
    HUD 只显示静态的「正在匹配」，用户分不出「在慢慢跑」还是「已卡死」。
  - 新增 `statusElapsedSeconds`，UI 显示「正在匹配 · 6s」。**只在**
    `.matching` / `.loadingComments` 期间推进，其它状态停表清零。
  - **⚠️ 第一版是「每秒 tick +1」，已改掉**：审查实测主 actor 阻塞 5 s 只 +1 —— 
    而那正是最需要它准确的场景（卡顿时少算）。现在存 `statusStartedAt`（单调时钟），
    每次 tick 用**墙钟差值**重算秒数，卡顿后下一次 tick 会直接跳到真实已用时长。
  - 另外两处细节：① `matching → loadingComments` 连跳时**保留原起点**（否则秒数被打回 0、
    看起来像重新开始）；② 加 `deinit` 兜底 cancel ticker（协调器被整个释放时没人做状态迁移）。
  - **没有压超时**：实测首次请求 **8.6 s 就返回了 500 错误**（超时设的是 15 s），
    说明瓶颈是网关慢/失败重试，压超时解决不了，反而会砍掉本该成功的请求。
  - **⚠️ 已知局限**：这个计数只在「更多 → 弹幕」面板与「选择弹幕」sheet 里可见，
    **常驻 HUD 没有变化**。若目标是「不翻菜单就能看到在动」，本改动到不了 —— 需要
    另做常驻指示，本批没做。
  - **失效代价有界**：`DanmakuCoordinator` 是 `@Observable`，每秒变一次会让**读它的视图**
    每秒重算；当前唯一读它的是那个条件构建的弹幕面板 / sheet，不是常驻 HUD。

- **`P1-13`：iOS 触摸热路径不再每事件重算整个播放器根 body**。
  - `touchTranslation` 是 `@State`，而它**每个触摸事件都要写**（`handleTouchChanged`
    里两处），却**只在长按判定的 Task 里读一次**（判 `movementSlop`）。
  - **`@State` 的失效粒度是整个视图**：一写就标脏 `PlayerScreen`，于是每次
    `onChanged` 都让根 body 重算一遍 —— HUD 挂载时那一整棵 Glass 树（11 面玻璃）
    跟着每个触摸事件重跑。同文件的 `panSession` 早就因为同一原因换成了
    `@Observable PlayerPanFeedback`，但 `touchTranslation` 当时漏了。
  - **修法**：`@State private var touchTranslationStore = TouchTranslationStore()`
    —— `@State` 负责**跨 body 重算保住引用**，而容器**不是 `@Observable`**，
    所以写它的属性**不触发任何视图失效**。两者结合才是目标形态：持久 + 不重算。
  - **⚠️ 第一版写成 `@ObservationIgnored private let`，是阻断级错误**：
    `PlayerScreen` 是 struct，每次 body 重算都会重新构造它，那个 `let` 属性
    **每次重算都新建一个空容器** → 触摸位移丢光 → 长按 `movementSlop` 判定永远
    读到 `.zero`（2x 长按失效）。独立审查用 SwiftUI 探针实测复现
    （`INIT store#0` → 重算 → `INIT store#1` → 长按读 `store#0` 的 0.0）。
    已改成 `@State` 持有，注释里写明「为什么必须是 `@State` 而不是 `let`」。
  - 顺带核对：`panAreaSize` 虽然也是 `@State`，但它**只在尺寸变化时写**（不是
    每事件），不构成热路径问题 —— 不改。

- **`P1-14`：iOS 音量纵滑不再每个事件都穿进程写系统音量**。
  - `MPVolumeView` 的系统音量是 **1/16 量化**的（步长 0.0625），而纵滑手势给的是
    连续 `0...1`。原先的守卫是「`abs(slider.value - value) > **0.005**` 就写」——
    **0.005 远小于 1/16**：`MPVolumeView` 会把写入值自己取整，`slider.value` 读回来
    是取整后的值，于是下一次比较「差」仍大于 0.005，**绝大多数触摸事件都通过守卫**。
  - 一次 1 秒纵滑 ≈ **数百次跨进程系统音量写入**，再经 KVO + 主 actor Task 回写。
  - **修法**：先把目标**量化到 1/16 档位**，再用**半档容差**（0.03125）比较。
    档内连续拖动**一次都不写**，写入次数从 O(事件数) 降到 O(跨越的档数)。
    顺带切断了「写 → KVO 回声 → 再进 `updateUIView` → 再写」的放大环。
  - 量化与守卫都放在**跨平台纯逻辑文件** `PlayerPanGestures.swift`
    （`quantizedVolume` / `shouldWriteVolume`）而不是 `SystemVolumeControl`
    —— 后者在 `#if os(iOS)` 里，macOS 测试靶根本编不进去、没法测。
  - **⚠️ 第一版只把 `quantizedVolume` 抽出来测，守卫仍嵌在 `updateUIView` 里
    —— 结果本批真正改变行为的那 4 行零覆盖**：独立审查实测「把守卫改回 `> 0.005`，
    7 条用例**全绿**」。现在守卫也抽成纯函数 `shouldWriteVolume(current:target:)`，
    补 3 条行为用例（同档不写 / 恰好半档写 / 偏差网格值），删掉一条恒真的同义反复。
    验红：守卫改回 `> 0.005` → **3 条用例红**（此前全绿）。
  - 用例 9 条：1/16 倍数、越界夹住、**档内恒定**、**跨档必变**、±0.5 档边界、
    半档 = 步长一半、**守卫的半档语义**、**老 0.005 与半档在中间区间结论相反**、
    **偏离网格的 `current`**。
  - **⚠️ 「1/16 量化」是无 Apple 文档支撑的经验假设**（只查到社区惯例）。
    修复的正确性建立在「`slider.value` 与本函数的网格同相」上：同相时差值必是
    1/16 的整数倍、半档容差永不落进死区。若某个输出（蓝牙 / AirPlay / 未来 iOS）
    报更细或偏移的粒度，恰好半档时该档会**永不写入**。需真机采样
    `AVAudioSession.outputVolume` 才能定论 —— 本机无 iOS 真机，**未验证**。
  - **⚠️ 写用例时自己错了一次**：最初拿 `4.9 档` 与 `5.1 档` 断言「跨档必变」，
    跑出来相同 —— 因为档位边界在 **±0.5 档**，4.9 与 5.1 都在第 5 档内。
    改成 4.4 / 5.6 后才正确，并单独加一条用例钉住这个边界语义。

- **`CORR-08` 补强：找到并修掉 `ServerEndpointWiringTests` 假红的**真因**（不是 runner 抖动）**。
  - **现象**：`main` 在 2026-10-19（`db23061`）红在
    `testResolvedAddressIsPersistedAndPublished`，报「等待超时 3.0 s」。
    诊断信息本身是对的（`CORR-08` 的可诊断性修复生效），所以我第一版判断成了
    「runner 太慢、放宽超时到 10 s」。
  - **但那段慢的根因不是 runner**：核实 CI 日志发现，同套件的
    `testCallbackFromReplacedSessionIsIgnored` 跑了 **macOS 35.25 s / iOS 53.44 s**，
    而本机只要 **0.012 s** —— 慢 **4000 倍**。纯 runner 抖动不会这么规整。
  - **真因**：`attachEndpoints` 末尾是 `Task { await directory.refresh() }` ——
    一次 **fire-and-forget 的多地址探活**。而那条用例**没设
    `MockURLProtocol.handler`**，于是这次后台探活落到真实网络路径、
    每个候选地址各等一次默认超时；它还会**跨用例泄漏**，拖慢同套件后面的
    `testResolvedAddressIsPersistedAndPublished`，让它的 3 s 等待假红。
  - **修法**：① 给该用例设 mock handler；② 在清 handler 之前**显式等那次后台探活
    落地**（判据用「探活计数 > 0」，不用固定 sleep —— 固定 sleep 是恒真断言，
    探活整个坏掉时照样绿）。
  - **实测**：`testCallbackFromReplacedSessionIsIgnored` **35.25 s / 53.44 s → 0.05 s**
    （本机；多出的 0.04 s 就是新增的显式等待）。同套件其余用例不受影响
    （`testPinnedAddressWins` 0.21 s、其余 0.008–0.05 s）。
  - **超时放宽到 10 s 的理由也变了**：不再是「runner 抖就放宽」，而是
    「这条链路上有一次后台探活，正常毫秒级、CI 上可能被拖到秒级」——
    留余量，同时不掩盖「真的等不到」（真失败仍显式 `XCTFail` 并打出实测状态）。

- **`SkipPreferenceTests` 的 3 s 等待同样放宽到 10 s（有 CI 真凭据，不是预防性改动）**。
  - `main` 在 2026-10-19 **连红两次**（`db23061`、`7b598c9`）都指向本套件：
    ```
    等待超时：引擎事件落到状态机（playing + 片长 + 位置）
    （实测 state=playing duration=0.0 seconds position=0.0 seconds）
    ```
    后面紧跟着看起来像「钳位算错」的断言失败（`[] ≠ [1197.0 seconds]`）——
    其实只是**夹具没等到**，与钳位逻辑无关。
  - 被等待的是「引擎替身发出的事件落到状态机」，正常亚秒级；而同一批 CI 运行时，
    同类链路（`ServerEndpointWiringTests`）实测被拖到 **35.25 s / 53.44 s**（本机 0.012 s）。
  - 放宽到 10 s：代价只有「真失败时多等 7 s」（本套件 2 处等待），
    收益是不再让 runner 抖动伪装成「钳位算错」这种假 bug。
  - **仍不动的**：`AppBackgroundPlaybackTests` / `PlayerHUDGatesTests` /
    `SubtitlePreferenceTests` 保持 3 s —— `main` 最近 12 次失败里没有它们的记录。
    一次只改有证据的那一处。

- **`BLD-01`：本地「先 build 再 package」不再重复编译第二遍（约省 450 s）**。
  - 根因：`build-macos.sh` 的 `BUILD_DIR` **写死** `.local-build/current`，而
    `package-macos.sh` 默认 `.local-build/release` —— 刚编译完的产物在新根里看不见，
    打包要**从头再编一遍**。
  - 修法：`build-macos.sh` 的 `BUILD_DIR` 支持环境变量覆盖，与 `package-*.sh` 的
    `BUILD_ROOT` 对齐即可复用。用法示例（**必须绝对路径**）：
    ```
    BUILD_DIR="$PWD/.local-build/release" Scripts/build-macos.sh release
    BUILD_ROOT="$PWD/.local-build/release" Scripts/package-macos.sh v0.2.1
    ```
  - **公平的收益表述**：旧流程 = build(≈480 s) + package(≈480 s) ≈ **960 s**；
    新流程 = build(≈480 s) + package **增量 27 s（零编译，只做链接）** ≈ **507 s**。
    省掉的是**第二次重复的全量编译**（≈450 s），**不是**「构建从 480 s 提速到 27 s」。
  - **守卫**：`BUILD_DIR` 覆盖必然带来误删风险，所以先**规范化**再做前缀检查。
    实测挡住的向量（全部 9 种）：`../..` 路径穿越、`nope/../../..`（中间组件不存在）、
    `evil -> /tmp` 符号链接、尾斜杠形式、精确等于 `.local-build`、相近前缀
    （`.local-buildX/`）、越界绝对路径、**相对路径**（对绝对前缀，fail-closed）。
    实现：自写 `normalize_path`（macOS 的 `realpath` 没有 `-m`）+ `physical_path`
    （解析已存在前缀的符号链接），然后再规范化一次。
  - 记录：CI 里**不会**连跑这两个脚本（`release.yml` 只调 `package-*.sh`），
    所以这是**本地开发流程**的收益，不影响 CI。

- **`BLD-08`：iOS 测试步的「模拟器启动 + 装机」加了预热与预算告警**。
  - 清单实测（PR #30 四次运行）：从编译完成到打出首条 App 日志之间**日志全静默**，
    那段耗时 **185 / 162 / 331 / 181 s，波动 ±170 s** —— 它是 iOS 步波动的主因，
    **不在编译里**，缓存对它完全无效（`BLD-02` 命中缓存后 iOS 步仍 534 s）。
  - 现在做三件事：
    1. `simctl boot` + `simctl bootstatus -b` 在 `xcodebuild` **之前**预热模拟器，
       并把这段单独打点（`[BLD-08] simulator ready in Ns`）；
    2. destination 改用 `id=<udid>` —— 跳过 `xcodebuild` 内部的机型解析/可用性探测；
    3. 给**预热那段**加预算告警（`IOS_SIM_BUDGET_S=120`，超了打 `::warning`，
       **不 fail**）。**只量 `sim_ready`，不量整个 `xcodebuild`** —— 第一版比的是
       「预热 + 整个 xcodebuild test」，而 iOS 步本来就 462–627 s，`>120` 恒成立，
       等于每次运行都告警、纯噪声。
  - **本机实测**：冷启动 `boot + bootstatus` 仅 **8.9 s**；已 boot 时 0 s（幂等）。
    CI 上那 162–331 s 的主要部分不是 boot 本身，而是**首次装机 + test runner 拉起 +
    runner 磁盘冷缓存** —— 所以这里只做「预热 + 打点」，**没有声称能省掉那 170 s**；
    真正的量化要等 CI 上跑几次看 `[BLD-08]` 那行数据。

- **`BLD-03`：两个打包 job 补上 SPM checkouts 缓存（并解决「tag 缓存不能跨 tag 复用」）**。
  - 清单已校订过三点，这里逐条落实：
    ① 只缓存 `<root>/DerivedData/SourcePackages`（打包脚本要求 checkouts 存在），
       **不缓存 `Build/`** —— Release 产物跨版本本来就不能复用，缓存它只是白占额度；
    ② **tag 上建的缓存不能跨 tag 复用**（`BLD-04` 四次校订的结论）—— 所以只在
       `release.yml` 里加缓存是**无效的**；
    ③ 因此**播种点放在 `test.yml`**：新增「`Seed release SPM checkouts (main only)`」
      步骤（**仅 `refs/heads/main`**），用 `xcodebuild -resolvePackageDependencies`
       解析一次（不编译）并写进两个平台的 `SourcePackages`。
  - **⚠️ 两个必须踩对的细节（第一版都错了，审查实测抓出）**：
    ① **`-derivedDataPath X` 时 `SourcePackages` 在 `X/` 下，不是 `X/DerivedData/` 下**。
       打包脚本传的是 `-derivedDataPath "$BUILD_ROOT/DerivedData"`，所以 checkouts 在
       `$BUILD_ROOT/DerivedData/SourcePackages`。播种步骤必须传
       `-derivedDataPath .local-build/release/DerivedData` 才与之一致 ——
       第一版少写这一层，`cp` 必然 `No such file or directory`、`set -e` 下整步失败，
       **main 每次 push 都会红**。
    ② **同一 key 但 path 列表不同 = 必然静默 miss**（不是「互相顶掉」）：
       `actions/cache` 的条目身份 = key + **version**，version 是 path 列表的哈希。
       所以播种、macos job、ios job 三处的 `path:` **必须逐字相同**（都列两条）。
       第一版三处各不相同 → 三个 version 全不同 → 两个 job 都 miss。
  - **key 前缀选 `spm-pkg-`**，与既有的 `spm-test-`（`ci-test` + `Packages/*/.build`）、
    `spm-release-`（`ci-release-test` + `Packages/*/.build`）三者互不冲突。
  - **额度核算**：当前 **4.03 GiB / 10 GiB**（3 条），余 5.97 GiB；本地
    `SourcePackages` 实测 **556 MB**（未压缩），新增一条压缩后约 0.6–0.9 GiB，安全。
  - **收益边界（如实记录）**：只覆盖 resolve/clone 那一段，**省不掉 480 s / 368 s 的
    编译本身**（PR 门禁是 Debug，与 Release 不同配置，本来也不能复用）。

- **`P2-23`：`MetadataHydrator.home()` 从 4 次读事务合成 1 次（比例稳定在 −17% ~ −20%）**。
  - 改前四个独立 `await`（`libraries` + 三条 `rail`），每个都是一次 `database.read`。
    **读事务本身就要 ≈29–37 µs** —— 实测：4 个事务跑 4 条 trivial `SELECT 1` 要
    147.0 µs，合成 1 个事务跑 4 条只要 59.0 µs（差 88 µs / 3 个事务）。
  - 新增 `MetadataStore.homeSnapshotParts(tenant:)`：**一次读事务**里取库列表，
    三条 rail 用**一条** `IN (?, ?, ?)` 取回（不是三次 `rail(...)`）。
  - 真实数据 A/B（8 个库 + 3 条 rail × 20 条 `MediaItem`，交替 300 次取 p50）：
    本机 **751.0 → 602.0 µs（−19.8%）**；独立审查在另一台负载上测到
    **−17.1%** 与 **−18.3%**。
    **绝对值随机器/数据规模变，比例稳定在 −17% ~ −20%**，引用请以比例为准。
  - **⚠️ 这条我上一批曾错误地判为「量不出来」**：当时把「读」当成不可拆的整体，
    只算了跳转（0.29 µs），得出「合并只省 0.9 µs」的结论，差约两个数量级。
    独立审查用真实数据推翻后，本批按正确口径重做并实测确认收益。
  - **失败语义有意变更**：整个读事务失败（库损坏 / 表缺失）现在**抛错**，由
    `home()` 决定降级为「返回 nil、保持骨架屏等重试」；而不是像第一版那样
    `try? ... ?? ([], [:])` 把失败压成「全空」、与「服务端确实是空的」不可区分
    （那会丢掉本来还能显示的部分）。单条 rail 解码失败仍只跳过那一条。
  - 用例钉五件事：与四个独立读逐字段一致、**跨租户不串读**、**按 position 排序**
    （构造 position ≠ rowid 才能观测）、空缓存全空、**真实读失败会抛错**
    （把 `rail` 表改名制造失败，修好后能恢复）。
    变异（rail 去掉 tenant 过滤 / 读失败压成空 / 去掉 `ORDER BY position`）→ 全红。

- **`P2-25`「翻页 O(P²)」——核实后确认存在，但我的「优化」实测是负收益，已撤销**。
  - **先纠正一个错误判定**：我一度说 `cacheLibraryPage` / `libraryPages`「已不存在」，
    那是我只 grep 了 `Packages/` —— 它们在 **`App/Shared/AppModel.swift`** 里活得好好的
    （`App/` 下 12 处引用）。清单描述的 O(P²) 确实存在：`LibraryView` 每翻一页都把
    **累积至今的全部条目**交进去，而 `cacheLibraryPage` 内部 `filter` 重建整个字典
    再 `reduce` 全量求和。
  - **但实测我的增量维护方案是负收益**：40 页 × 100 条（累积 4000 条）场景下
    旧实现 **14.95 ms**、新实现 **19.56 ms**。原因是这份数据的主要成本是
    `cached.items = cumulative` 的**数组拷贝**（`MediaItem` 是 struct），
    而 `reduce` / `filter` 在这个规模（4000 条 / 41 个 key）本来就很便宜。
  - **已撤销**，不改代码。结论：这条在当前规模下**不是瓶颈**；真要优化得先解决
    「每页都把累积数组整体拷一遍」这个上游问题（那是 `LibraryView` 的传参方式，
    属于另一处改动），而不是在 `cacheLibraryPage` 内部换数据结构的维护方式。

- **`P2-24`：Bangumi 批量落库从 N+1 改成一次批量读（31.2 → 16.8 ms，1.9×）**。
  - 改前 `saveSubjects` 是 N+1：每条先 `ensureSubject` → `fetchSubject`（**单条 SELECT**），
    再 `upsertSubject`。收藏全量同步一页 100 条就是 100 次 SELECT + 100 次 UPSERT。
  - **先测后改**（100 条已存在时的更新路径）：**31.20 ms / 页，每条 312 µs**。
  - 这个文件里**本来就有** `fetchSubjectsById`（`IN (...)` 批量读、按 id 建字典），
    只是 `saveSubjects` 没用 —— 复用后 SELECT 从 N 次降到 1 次，
    **31.20 → 16.84 ms（1.9×）**，每条 168 µs。
  - 顺带覆盖同批次内既有「更新」也有「新建」、以及重复 id 的情形。
  - **坑**：我一开始拿 `eps` 当「更新 vs 新建」的判据，结果正常版本也红 ——
    `update()` 对 `eps` 是**无条件覆盖**（`if eps != item.eps { eps = item.eps }`），
    DTO 没带 eps 时本地值本来就会被冲成 0，那是**既有语义**、与批量读无关。
    改用 `interest`（`update()` 对它才是「带了才覆盖」）作判据，变异才真正被抓到。

- **`P2-23`「合并 `MetadataHydrator.home()` 的 4 次读」——值得做，但本批未做；我第一次的结论错了**。
  - **⚠️ 先记错误**：我最初量到「纯跳转 0.29 µs、单次读 89.78 µs」，就写结论说
    「合并只能省三个跳转 ≈ 0.9 µs，量不出来，这条不是性能问题」。**错了约两个数量级。**
  - 错在把「读」当成不可拆的整体 —— **合并省掉的主要不是跳转，是读事务**。
  - 独立审查用真实数据（8 个库 + 3 条 rail × 20 条 `MediaItem`）交替 A/B 实测：

    | 变体 | p50 |
    |---|---|
    | `home()` 原样（4 个读事务） | 966.2 µs |
    | 一次 `read` + 一条 SQL 取三条 rail | **789.8 µs（省 18.3%）** |
    | 只合并事务、仍 4 条查询 | 省 11.1% |

  - 我复测了「每个读事务」的单独成本：**≈29.3 µs**（4 个事务 147.0 µs vs 1 个事务
    跑 4 条查询 59.0 µs，差 88 µs / 3）；审查测到 ≈37 µs，同量级。
    所以 4 次读里约 **90–150 µs 是事务 / 连接 checkout 开销**，合并真能省下。
  - **本批不做**的理由不是「不值得」，而是**收益不足以撑起一次数据层 API 变更**：
    要给 `MetadataStore` 加「一次 read 里取库 + 三条 rail」的方法，和本批的 Bangumi
    N+1 混在一起会让回滚粒度变粗。留给下一批（可与 `P2-25` 翻页 O(P²) 一起做）。
  - 已在 `MetadataHydrator.home()` 留注释记下两次测量与真实结论，
    **别再照着第一版那句「量不出来」放弃它**。

- **`P2-24` 补充：同页重复 id 的语义坑（本批自己踩到并修掉）**。
  - 「一次批量预读 + 逐条 upsert」相比「逐条写、每条都能读到前一条结果」，在
    **同页重复 id** 时语义不同：前一条贡献的「非 nil 才覆盖」字段（`images`）会被
    后一条的 `nil` 冲掉（因为后一条基于页前快照、走了「当新建」的重造分支）。
  - 实测（库中无 5200，本页 `[DTO(images:"NEWFIRST"), DTO(images:nil)]`）：
    **改前 `images="NEWFIRST"`、改后 `nil`**。
  - 修法是去重时**按「后覆盖前、但只覆盖非 nil 可选字段」合并**（与
    `BangumiSubject.update` 的语义对齐），而不是简单丢弃前面的条目 —— 后者会让那些
    字段**从未被写入**（实测同样是 `nil`）。
  - **判据必须选对**：`name` 不行（两条都写了）、`interest` 不行（权威路径会清空）、
    **`images` 才行**。变异（去重退化成「只留最后一条」）→ 红；变异（完全不去重）→ 红。
  - 顺带修掉本 diff 引入的一条编译告警（`if var found` 对 class 无意义）。

- **`P2-21`：MoviePilot 裸数组响应不再被解析两遍（**66.6 → 0.27 µs，244×**）**。
  - 改前 `MPEnvelope.unwrap` 对**每一个**响应都先 `JSONSerialization.jsonObject`
    全量解析（Foundation 的 `Any` 树：装箱 + `NSNumber`/`NSString`），带信封时再把
    `data` 序列化回 `Data` 交给 `JSONDecoder` —— **一次响应解析两遍**。
  - 改成先看**首个非空白字节**：`[` 不可能是信封（信封是对象）→ 直接原样返回，零解析。
  - **实测**（7.6 KB 的 120 条任务列表 = `downloadingTasks` 的实际形态，与改前实现并排跑）：
    裸数组 **66.61 → 0.27 µs（244×）**；带信封 **163.2 → 153.0 µs（快 7%）**。
  - **⚠️ 顺带修掉两个既有崩溃**：`JSONSerialization.data(withJSONObject:)` 只接受**容器**，
    顶层 `String` / `NSNumber` / `NSNull` 会抛 **NSInvalidArgumentException** ——
    那是 ObjC 异常、`try?` **接不住**，App 里直接崩（独立可执行实测 exit 134）。
    `{"success":true,"data":"..."}` 与 `data:null` 两种形态在真实响应里都存在。
    XCTest 里同一异常表现为**测试失败**而非进程崩溃，所以差分会看到红色失败。
  - **⚠️ 第一版守卫选错了，被审查实测推翻**：我用的
    `JSONSerialization.isValidJSONObject(inner)` 是**深遍历** —— 实测 7.6 KB 的
    120 对象数组要 **72.35 µs**（而整个 `data(withJSONObject:)` 才 84.59 µs），
    于是**信封主路径被拖慢 19%–58%**（审查实测 5.4 / 7.6 / 15.5 KB 与 1.1 MB 四档），
    而代码注释自己说「大多数路由都会自动包信封」—— 那是**净负收益**。
    改成纯类型判断 `inner is NSArray || inner is NSDictionary`：实测 **0.03 µs（2410×）**，
    与 payload 大小无关。修完信封路径也变快 7%。
  - **等价性靠差分测试**：16 条语料（含前缀空白、BOM、`data` 为 `null`/标量/嵌套、
    非 JSON、空数据）与参考实现逐字节比对。参考实现**刻意保留了本批新增的守卫**
    （否则基准自己会崩），所以它只证明「浅判定不改变行为」，
    **崩溃修复由 `testScalarDataPayloadDoesNotCrash` 单独钉**。
    变异（去掉 `is NSArray` 守卫）→ 红（崩溃/失败）。
  - **更正一句错的**：初版 CHANGELOG 写「变异（去掉浅判定）→ 红」—— **不成立**，
    去掉浅判定后 10 条用例**全绿**（它们都是输出等价断言，观测不到快路径）。
    快路径的收益只能靠基准测，不能靠功能用例钉。

- **`P2-26`：请求体编码器提成静态量**。
  - 代码本身安全（审查并发实测：8 线程 × 500 次共享实例 encode，0 错误、0 字节差异，
    TSan 无报告；10 000 次抛异常后再 encode 输出与全新实例逐字节一致）。
  - **⚠️ 但初版引用的数字错了约 20 倍**：我写「每次现建多花 2.08 µs」，审查实测
    `JSONEncoder()` 是 **126 ns**、`JSONDecoder()` 是 **134 ns**；encode 小 Codable 体
    fresh 1.522 µs vs shared 1.420 µs（**只差 102 ns**）。所以
    「encoder 2.08 / decoder 0.1，二十倍不对称」这个论据**不成立**
    （我那次量到的是首轮未预热的值）。改 encoder 的决定本身无害（少一次分配），
    但**实际收益是百纳秒级**，不是微秒级。
  - 真正值得改的是「**每请求新建**」这件事本身（分配 + 首用初始化），
    而不是某个夸张的倍数。全仓还有 4 个同类高频站点未提
    （`AniSkipIDResolver` / `AnimeSkipClient` / `GatewayClient` / `PayloadCodec`），
    留给后续批次。
  - `JSONEncoder` **确实持有可变状态**（`outputFormatting` / `dateEncodingStrategy` 等
    open var），SDK 只是标了 `@unchecked Sendable`。当前安全的**前提是「初始化后从不修改」**——
    注释已按这个口径写，将来任何调用点改配置都会跨请求串台并引入竞争。

- **`P1-05`：探活会话复用**（`ServerProbe`）。
  - 改前每次 `probe` 都「copy 配置 → 新建 `URLSession` → `defer invalidateAndCancel`」。
    两个代价：① 每次现建会话；② **`invalidateAndCancel` 让连接池当场作废** ——
    每次探活都重新付 DNS + TCP + TLS。
  - **这不只是慢，是判据被污染**：探活测出的 `latency` 正是「挑最快地址」的判据输入，
    而局域网 / Tailscale / 反代的握手成本各不相同，串进延迟里会让选路偏。
  - 改成缓存会话，第二次起走 TCP/TLS 复用。
  - **⚠️ 第一版只按 `timeout` 做键，被审查实测出串台**：同 timeout、不同
    `sessionConfiguration`（正是测试注入口，塞 `URLProtocol`）会拿到第一次建的会话 ——
    实测两个配置分别挂 ProtoA/ProtoB、timeout 都是 2，结果 `r1=A r2=A`，第二个配置**完全没生效**。
    AppTests 里不同套件用不同 mock、timeout 都是 2，存在顺序相关的随机串台。
    改成键含**配置指纹**（`protocolClasses` 身份集合 + `waitsForConnectivity` +
    `allowsCellularAccess` + timeout）。
  - 顺带夹住非法 timeout：NaN 做键**永不命中**（每次新建、键表无界增长），
    负数 / infinity 会被 `URLSession` 接受但行为诡异 —— 入口 `guard timeout.isFinite && > 0`。
  - 用例直接钉「新建过几个会话」：同一 timeout 探活 5 次只建 **1** 个；不同 timeout 各一档。
    变异（退回每次新建 + `invalidateAndCancel`）→ 红。

- **`P1-02`：弹幕手动搜索的别名链不再阻塞主检索**。
  - 改前「主检索 `await` 完 → 再 `await` 别名链」：最坏两段**串行 RTT**
    （网关 `timeoutIntervalForRequest = 10` / `ForResource = 20`，即 ≤10–20 s），
    而这期间**网关已经成功返回的结果上不了屏**。
  - 改成：别名链**并发起飞**，主检索回来后最多再等 `aliasBudget`。
    **⚠️ 第一版把 `aliasBudget` 设成 1.5 s、还声称「主检索回来即可用」—— 这是错的。**
    返回值只有一个，主检索回来后仍要 `await` 别名链才能组装最终结果。独立审查用
    同构场景实测（main 10 ms / alias 900 ms / budget 1500 ms）：
    `mainReadyAt=11ms returnedAt=957ms` —— 调用方多等 **946 ms**，
    等于把「串行 10–20 s」换成「串行 min(别名, 1.5 s)」，典型场景收益接近零。
    **按清单原本的建议改成「给该步单独设短超时」= 300 ms。** 别名是增强、不是前提。
  - **踩了一个真坑**：第一版用 `withTaskGroup` 竞速，实测**超时失效** ——
    group 在作用域结束时会等所有子任务，于是超时分支返回后仍被慢任务拖住。
    用例实测「预算 50 ms + 慢任务 1 s」耗时 **1.110 s**（应 <500 ms）。
    改成「计时的 Task + 结果槽（锁 + 一次性 continuation）」：两边互不阻塞，
    同一用例降到 **0.054 s**。
  - 用例覆盖（8 条）：工作先完成→原值返回；工作慢于预算→**及时**返回 nil（用耗时判）；
    被放弃的工作**仍能自然完成**（实测 `waiter.cancel()` 不会取消底层 `work`）；
    `aliasBudget` 取值合理；**别名链契约**4 条（命中即停 / 跳过同名 / 全不命中 / 被取消提前退出）。
  - **另修两条审查发现**：① 主检索抛错时 `aliasSearch` 曾是无人管的孤儿任务（会跑满网关
    10/20 s，重试还会叠加）→ `defer { aliasSearch.cancel() }` + 循环里检查 `Task.isCancelled`；
    ② `aliasHit` 语义从「别名链返回非空」变成「别名带来新增条目」，改名 `aliasAdded` 以免误读历史日志。

### 安全 / 正确性

- **`CORR-03`：条目与 rail 现在真的在同一个事务里写**。
  - `CachedMediaServer.record` 的注释一直声称「条目与 rail **必须同一次写**」，而实现是
    `saveItems` + `saveRail` **两次 `await`、各自开事务**。进程在两次写之间被杀会留下
    「**新 rail + 旧条目**」的不一致快照 —— 首页显示的条目详情与 rail 里的对不上。
  - 新增 `MetadataStore.saveItemsAndRail`：**一个 `database.write`** 里既 upsert 条目又
    写 rail。两次 payload 编码仍在**事务外**（沿用 `saveItems` 里那条注释的理由：
    编码是纯 CPU，占着写事务会挡住别的写）。
  - **判据不能只看「都写进去了」**（分开写也能都写进去）。用例用 SQLite 触发器让
    **rail 那次写必然失败**，然后断言**条目也没落盘**：
    同一事务 → 一起回滚 ✅；两个事务 → 条目已提交 ❌。
    另配一条对照用例证明「分开写确实会留下条目」，说明判据有效。
  - 变异验证：退回两次独立写 → 红。

- **`CORR-04`：兜底 attach 启动帧驱动前复核 surface**。
  - `finishOpening()` 的兜底路径 `setAttachedView(view)` 之后用
    `Task { @MainActor in loop.start(on: view) }` 启动 —— 而跳 main actor 之前有一段
    间隙，宿主可以在那里 `detach()`（`detach` 不受让位契约保护，随时可调）。
  - 不复核的后果：渲染线程在**已 detach 的 surface** 上继续 tick，且**无人 `stop()`**
    —— 帧驱动就这样漏下去直到下一次 attach。
  - 改成与该文件已有的 `restartRenderLoop` 同款守卫：启动前
    `guard storedAttachedView() === view`，不等则 warning + 返回。

- **`CORR-07`：「取消不是失败」的判据收成**一个真源**，并修掉一处用户可见的日志噪声**。
  - 正常取消有**两种类型**且不是同一个东西：`CancellationError`（`Task` 抛的）与
    `URLError(.cancelled)`（`NSURLErrorDomain` 码 **-999**，`URLSession` 抛的）。
    只写 `catch is CancellationError` 的站点**接不住第二种**。
  - 最实在的一处是 `ImagePipeline.load`：请求被取消时 `-999` 掉进通用 `catch`，
    先试离线兜底、再记一条**「图片加载失败」warning**，最后把 `URLError(-999)` 原样抛出。
    快速滚动列表**天天发生**，warning 把真正的故障淹掉。
  - 新增 `DiagnosticsKit.CancellationClassifier`（`isCancellation` / `normalized`）作为
    **唯一真源** —— `AppDesignKit` / `DanmakuKit` / `BangumiKit` / `JellyfinKit`
    **都依赖 `DiagnosticsKit`**，放这里才能各包共用而不漂移。
    `JellyfinKit.JellyfinError.isCancellation` 改为委托到它（消除第二份实现）。
  - 库内 **9 处** `catch is CancellationError` 换成 `catch where CancellationClassifier.isCancellation(error)`：
    `ImagePipeline` 1 处、`DanmakuLoadOrchestrator` 7 处、`BangumiAPIClient` 1 处、
    `JellyfinLoginSession` 1 处。
  - **判据必须两头都钉**：既要有「`-999` 算取消」，也要有「超时/断网/连不上/DNS/
    连接中断/同域不同码**都不算**取消」—— 放宽成「所有 URLError 都是取消」会吞掉真故障。
  - 接线用例用 `URLProtocol` 直抛 `-999`，断言 `load` 抛的是 `CancellationError`
    而不是 `URLError`；另配一条超时对照，确保没被放宽。变异（退回
    `catch is CancellationError`）→ 红，报 `NSURLError Code=-999`。

- **`CORR-06`：改掉一句不成立的注释**（清单自己判定「是注释准确性问题，不是性能问题」）。
  - `ErikaEngine.latestOutputSnapshot` 原写「与 `latestOutputEncoding` 共用同一把锁与
    同一个 C 调用…**不会调两次内核**」—— 后半句不成立：两者各自走一遍
    `currentOutputStatus()`（一次主锁 + 一次 `get_output_status`）。
  - 实测后确认不值得动实现：驱动这两个读点的是 `PlayerHUDChrome` 的
    `TimelineView(.periodic(by: 1))`（**1 Hz**），且面板由 `showInfoPanel` 门控、
    **默认关闭** —— 真实速率约 3 次/秒且只在面板打开时。所以只改注释。
  - 顺带记录：清单原文按「100 ms 一次」估，是把 `PlayerTimeline.progress` 的 100 ms
    发布张冠李戴了（那条由 `PlayerHUDBottomDock` 消费，与本面板无关）。


- **修掉两处「凭据明文进导出包」的脱敏泄漏**（都由第十批的守卫式跳过引入，独立审查 + 自查发现）。
  - **① 内嵌 NUL**：守卫用 `withCString` + `strstr`，而 C 串在 `\0` 处截断 ——
    「NUL 之后才出现的关键词」看不见，整趟跳过，凭据原样留下。
    ```
    输入      "prefix\0token=SUPERSECRET123"
    修复前    "prefix\0token=SUPERSECRET123"   ← 泄漏
    强制全跑  "prefix\0token=<redacted>"
    ```
    日志里出现 `\0` 不是天方夜谭：错误文本会插服务端响应体，畸形响应就带 NUL。
    修法：`Array(utf8)` + `memmem`（显式长度）。试过四版逐版实测：
    `strstr`（0.67 µs，截断）→ `strnstr`（仍截断）→ `memcmp` 循环（407 µs）→
    **`memmem`（1.28 µs，正确）**。
  - **② U+017F `ſ`（长 s）**：守卫用 `String.lowercased()` 折叠，而正则的 `(?i)`
    走 **ICU** 折叠 —— 两者**不是同一套算法**。ICU 认为 `ſ` 等于 `s`，
    `lowercased()` 不折叠它。于是 `ſecret=<凭据>`、`baſic <凭据>` 整趟跳过。
    ```
    输入      "ſecret=Zx9QwErTyUiOp42"
    修复前    "ſecret=Zx9QwErTyUiOp42"   ← 泄漏
    强制全跑  "ſecret=<redacted>"
    ```
    修法：换用**同一套 ICU 折叠** `folding(options: .caseInsensitive, locale: en_US_POSIX)`。
    **穷举验证**：全部 1,114,112 个 Unicode 标量 × 26 个 ASCII 字母，
    两种视角**零分歧**。顺带比 `lowercased()` 还快（1.24 KB 中文 9.6 vs 17.5 µs）。
  - 两处都补了回归用例（含 6 种 NUL 位置、4 种 `ſ` 位置、字节级边界）。
  - **教训**：差分测试用 300+ 条语料是绿的 —— 因为语料里既没有 NUL 也没有 `ſ`。
    「语料要覆盖编码陷阱」比「语料要多」重要。

- **关键词表与正则的同步现在有测试守着**（审查 S2）。
  - 审查实测：去掉表里的 `passwd` / `client-secret` / `access-token` / `x-emby-token`，
    **84 条用例全绿** —— 因为 `assignmentKeywordsForTesting` **全仓无人调用**，
    注释声称的「用例据此校验同步性」并不存在。而表漏词的方向就是**真泄漏**。
  - 补了**三个方向**的用例：
    1. 表里每个词必须**单独**能被守卫查到（不能用「整表是否命中」判 —— 会被别的词顺带命中）；
    2. 正则里每一族关键词必须在表里有形态（子串口径，允许 `cookie` 覆盖 `set-cookie`）；
    3. 表里每个词必须能追溯到正则的某个形态（防「表与正则分家」，如塞进 `credential`）。
  - 变异验证：去掉 `passwd`/`cookie`/`password` → 红；加无关词 `credential` → 红。
    （`x-emby-token`/`access-token`/`client-secret` 去掉仍绿，因为表里的 `token`/`secret`
    是它们的子串、本就冗余 —— 已在注释里写明这层关系。）

- **导出预算的记账改成「按实际读到的字节数」**（审查 S3）。
  - 早先按 `file.size` 记账，而 `readTail` 会额外丢掉残首行；若归档最后一行被撕开、
    且残行比可用预算还长，整段读不出一个换行 → 返回空，**但那笔预算已经被扣掉**。
    后面的（更旧的）文件明明还有额度却被整份跳过，排障价值无声缩水。
  - 改成边读边按实际字节记账：读不出来的文件**不扣预算**，并留一条 OSLog 痕迹。
  - 用例构造了「中间文件以 50 KB 无换行残行收尾」的场景，断言最旧那批记录仍在。
    变异（读不出来也照扣）→ 红。
  - 顺带修 O4：无预算路径的 `Data(capacity:)` 早先只预留头部长度，随后 append
    几十 MB 会走几何扩容（多次 realloc + 整份拷贝），比旧实现的 `+` 拼接还多几次。
    现在由 `exportByteCount` 给出正文总量一次预留。

### 性能

- **诊断包导出：峰值内存 112 MiB → 32 MiB（−71%）**（性能审查清单 `P2-31` 前半）。
  - **实测（先测后改）**：造 48.4 MB 日志（单文件 20 MB / 总量 50 MB 上限的生产同量级），导出时 `peakRSS` **668 → 781 MiB**，即 **112 MiB 尖峰（2.44×）**。清单估的「~150 MB / 3×」略偏大，机制说对了。
  - **尖峰来自三份同时存活的大对象**：`backend.exportData()` 的 `Data`、`String(decoding:)` 的 `String`、以及 `header + body` 的 `+` 拼接。50 MB 日志在 iOS 上是现实的 jetsam 风险（本 App 真实峰值 RSS 到过 435 MB）。
  - **改法**：`exportText` 新增 `bodyByteBudget: Int? = nil`。给定预算时只保留**最新**的一段（按行对齐、丢掉被切一半的残首行），并把构造改成「头部字节先写进同一个 `Data`」——去掉 `+` 拼接的第三份。峰值于是 ≈ 2× 预算：**实测 32 MiB**。
  - **App 侧接上 8 MiB 预算**：按每条 ~1 KB ≈ **8000 条**，远超任何一个 issue 需要贴的量；头部说明行自动标注「日志正文只保留最新的一段（上限 8 MB，已截断）」，措辞与同文件内核 trace 段一致。
  - **顺带把 `Data(text.utf8)` 挪出主线程**：改前它在 `fileWrapper` 里做，而 `fileWrapper` 由 SwiftUI 在**主线程**调用 —— 导出瞬间多一次主线程大块分配。现在文档直接持 `Data`，转换在 `Task.detached` 里完成。
  - **默认路径零变化**：`bodyByteBudget: nil` 时输出与改前**逐字节相同**（有黄金对拍用例守着）。

- **日志脱敏：长消息大幅变快，短消息持平**（性能审查清单 `P2-31` 后半）。
  - **实测（改前）**：短消息「播放状态变化」**7.44 µs**、1.2 KB 消息 **97.83 µs**（线性放大）、
    URL 型消息 **25.17 µs**、字段字典（2 个字段）**42.08 µs**。对照 `P2-39` 之后一条典型
    error 日志总共 29.9 µs —— **脱敏几乎是全部成本**，而它跑在**调用方线程**上。
  - **实测（改后）**：1.2 KB **97.83 → 36.0 µs（−63%）**、URL 型 **25.2 → 15.4 µs（−39%）**、
    字段字典 **42.1 → 33.6 µs（−20%）**、短消息 **7.44 → 7.30 µs（持平）**。
    **短消息只是持平，不是变快** —— 如实记下，别按「全部变快」宣传。
  - **没有照抄清单建议「脱敏下移到写盘队列」**：那要求消息先以未脱敏形态入队，
    任何绕过 logger 直写 backend 的路径都会把凭据写出去；且它只把成本从调用线程
    挪到写线程，**总 CPU 不变**。改成**守卫式跳过**：每趟正则都有严格必要条件
    （不含 `://` 就不可能命中 URL 规则），不满足就整趟跳过。真省功、安全语义未改。
  - **性能这条路踩了四个坑，都记下来**（每一版都实测过）：
    1. `String.range(of:options:.caseInsensitive)` 做守卫 —— 单次几微秒，
       问十几个关键词后**比不设守卫慢 5 倍**（短消息 7.4 → 38 µs，1.2 KB → 2585 µs）。
    2. 改用一次 `lowercased()` 共享 —— 但 `String.contains` 走 **Character（字素簇）视图**，
       对 1.2 KB 中文文本问 10 个关键词要 **213.6 µs**（每次 ≈21.5 µs）。
    3. 换 `strstr` 在 UTF-8 字节上搜：**6.8 µs（31×）** —— 但这就是那个 **NUL 漏洞**的源头。
    4. 换 `Array(utf8)` + `memmem` 修好 NUL，却**每次调用各转一遍干草堆与针**；
       关键词表 18 个词 → **36 次小分配**，短消息脱敏**从 7.44 涨到 11.63 µs**
       （比不设守卫还慢）。最终把针全部预计算成静态量、干草堆只转一次，才落到 7.30 µs。
  - **等价性靠差分测试证明，不靠推断**：`redactWithoutGuards` 保留「加守卫之前」的六趟，
    与带守卫实现在 300+ 条语料（真实日志行 / 各类 URL / 用户路径 / App 容器 / JWT /
    JSON 凭据 / emoji / 制表符 / 换行 / 大小写变体）上**逐字节比对**。另有
    「每类敏感值原值不出现」的安全判据。
  - **⚠️ 差分测试的盲区教训**：那 300+ 条语料是**绿的**，而上面两处泄漏（NUL、`ſ`）
    全都漏掉了 —— 因为语料里既没有 NUL、也没有 `ſ`。**「语料要覆盖编码陷阱」比
    「语料要多」重要**。两处修完都补了专门的回归用例。
  - **顺带记录一个既有事实**：脱敏**不是幂等的** —— `https://h/a?b=c` 第二趟会把
    `?<redacted>` 再替换成 `?<redacted><redacted>`。管线里每条只脱敏一次，
    不影响正确性，但加了一条用例把这个事实记下来，免后人重复脱敏。

- **关键词表与正则的同步现在有测试守着**（审查 S2）。
  - 审查实测：去掉表里的 `passwd` / `client-secret` / `access-token` / `x-emby-token`，
    **84 条用例全绿** —— 因为 `assignmentKeywordsForTesting` **全仓无人调用**，
    注释声称的「用例据此校验同步性」并不存在。而表漏词的方向就是**真泄漏**。
  - 补了**三个方向**的用例：
    1. 表里每个词必须**单独**能被守卫查到（不能用「整表是否命中」判 —— 会被别的词顺带命中）；
    2. 正则里每一族关键词必须在表里有形态（子串口径，允许 `cookie` 覆盖 `set-cookie`）；
    3. 表里每个词必须能追溯到正则的某个形态（防「表与正则分家」，如塞进 `credential`）。
  - 变异验证：去掉 `passwd`/`cookie`/`password` → 红；加无关词 `credential` → 红。
    （`x-emby-token`/`access-token`/`client-secret` 去掉仍绿，因为表里的 `token`/`secret`
    是它们的子串、本就冗余 —— 已在注释里写明这层关系。）

- **导出预算的记账改成「按实际读到的字节数」**（审查 S3）。
  - 早先按 `file.size` 记账，而 `readTail` 会额外丢掉残首行；若归档最后一行被撕开、
    且残行比可用预算还长，整段读不出一个换行 → 返回空，**但那笔预算已经被扣掉**。
    后面的（更旧的）文件明明还有额度却被整份跳过，排障价值无声缩水。
  - 改成边读边按实际字节记账：读不出来的文件**不扣预算**，并留一条 OSLog 痕迹。
  - 用例构造了「中间文件以 50 KB 无换行残行收尾」的场景，断言最旧那批记录仍在。
    变异（读不出来也照扣）→ 红。
  - 顺带修 O4：无预算路径的 `Data(capacity:)` 早先只预留头部长度，随后 append
    几十 MB 会走几何扩容（多次 realloc + 整份拷贝），比旧实现的 `+` 拼接还多几次。
    现在由 `exportByteCount` 给出正文总量一次预留。

### 性能

- **诊断包导出：峰值内存 112 MiB → 32 MiB（−71%）**（性能审查清单 `P2-31` 前半）。
  - **实测（先测后改）**：造 48.4 MB 日志（单文件 20 MB / 总量 50 MB 上限的生产同量级），导出时 `peakRSS` **668 → 781 MiB**，即 **112 MiB 尖峰（2.44×）**。清单估的「~150 MB / 3×」略偏大，机制说对了。
  - **尖峰来自三份同时存活的大对象**：`backend.exportData()` 的 `Data`、`String(decoding:)` 的 `String`、以及 `header + body` 的 `+` 拼接。50 MB 日志在 iOS 上是现实的 jetsam 风险（本 App 真实峰值 RSS 到过 435 MB）。
  - **改法**：`exportText` 新增 `bodyByteBudget: Int? = nil`。给定预算时只保留**最新**的一段（按行对齐、丢掉被切一半的残首行），并把构造改成「头部字节先写进同一个 `Data`」——去掉 `+` 拼接的第三份。峰值于是 ≈ 2× 预算：**实测 32 MiB**。
  - **App 侧接上 8 MiB 预算**：按每条 ~1 KB ≈ **8000 条**，远超任何一个 issue 需要贴的量；头部说明行自动标注「日志正文只保留最新的一段（上限 8 MB，已截断）」，措辞与同文件内核 trace 段一致。
  - **顺带把 `Data(text.utf8)` 挪出主线程**：改前它在 `fileWrapper` 里做，而 `fileWrapper` 由 SwiftUI 在**主线程**调用 —— 导出瞬间多一次主线程大块分配。现在文档直接持 `Data`，转换在 `Task.detached` 里完成。
  - **默认路径零变化**：`bodyByteBudget: nil` 时输出与改前**逐字节相同**（有黄金对拍用例守着）。

- **日志脱敏：1.2 KB 消息 97.8 → 54.5 µs（−44%）**（性能审查清单 `P2-31` 后半）。
  - **实测三段**：短消息「播放状态变化」**7.44 µs**、1.2 KB 消息 **97.83 µs**（线性放大）、URL 型消息 **25.17 µs**、字段字典（2 个字段）**42.08 µs**。对照 `P2-39` 之后一条典型 error 日志总共 29.9 µs —— **脱敏几乎是全部成本**，而它跑在**调用方线程**上（播放/渲染热路径每条日志都要付）。
  - **没有照抄清单建议「脱敏下移到写盘队列」**：那要求消息先以未脱敏形态入队，任何绕过 logger 直写 backend 的路径都会把凭据写出去；且它只把成本从调用线程挪到写线程，**总 CPU 不变**。改成**守卫式跳过**：每趟正则都有严格必要条件（不含 `://` 就不可能命中 URL 规则），不满足就整趟跳过。真省功、安全语义一字未改。
  - **踩了两个坑，都记下来**：
    1. 第一版用 `String.range(of:options:.caseInsensitive)` 做守卫 —— 单次就要几微秒，问十几个关键词后**比不设守卫慢 5 倍**（短消息 38 µs vs 7.4 µs，1.2 KB 消息 2585 µs vs 97.8 µs）。改成一次 `lowercased()` 共享。
    2. 但 `lowercased()` 只占 17.7 µs，真正的大头是 **`String.contains` 走 Character（字素簇）视图** —— 对 1.2 KB 中文文本问 10 个关键词要 **213.6 µs**。改用 `strstr` 在 UTF-8 字节上搜：**6.8 µs（31×）**。安全性不受影响：ASCII 字节永远不会出现在多字节 UTF-8 字符内部（UTF-8 自同步），字节级匹配不会切在字符中间。
  - **最终**：短消息 7.44 → **5.24 µs**、1.2 KB 97.8 → **54.5 µs**、URL 型 25.2 → **12.3 µs**、字段字典 42.1 → **32.0 µs**（全路径都变快，不是只快简单路径）。
  - **等价性靠差分测试证明，不靠推断**：`redactWithoutGuards` 保留加守卫前的六趟，与带守卫实现在 300+ 条语料（真实日志行 / 各类 URL / 路径 / JWT / JSON 凭据 / emoji / 制表符 / 换行 / 各种大小写变体）上**逐字节比对**。另有「每类敏感值多个变体，断言原值不出现」的安全判据。
  - **顺带记录一个既有事实**：脱敏**不是幂等的** —— `https://h/a?b=c` 第二趟会把 `?<redacted>` 再替换成 `?<redacted><redacted>`。管线里每条只脱敏一次，不影响正确性，但加了一条用例把这个事实记下来，免后人重复脱敏。

- **（顺带修）`testWaterfallRespectsTotalBudget` 的机器相关性断言**
（第七批引入，本批暴露）。
  - CI 上它红了两次，两个原因都记一下：
    1. **请求数不能用固定区间**：本机 250 ms 预算发出 2–3 个请求，而 CI runner 调度慢，实测只发出 **1 个** —— 区间 `2...3` 当场红。改成「> 0 且 **严格少于**无界的一半」（必须严格：只做层间检查时恰好是 4 个 = 8 的一半，用 `<=` 抓不住那个变异）。
    2. 同一轮 CI 里还出现过 `ImageCacheLegacyPurgeTests` 的 SQLite `disk I/O error`（`error-code=10`）—— 与本批改动无关的 runner 磁盘抖动，重跑后该用例转绿。
  - 两个变异在新判据下仍红：`deadline` 立即过期 → 0 个请求红；删掉层内闸门 → 4 个请求红。

- **卡片 body 里的三处「不变的值反复现算」**（性能审查清单 `P1-10` / `P1-12` / `P1-11`）。三条实测合计从 **~634 µs / 屏**降到 **~22 µs / 屏**。
  - **`P1-12` `authorizationHeader` 加进程级缓存（11.49 µs → 0.66 µs，17.5×）**：`JellyfinServer` / `EmbySession` 的 `authorizationHeader` 都是计算属性，`DesignSystem` 里 7 处在 `imageTarget` 系列里读它 —— 每张卡每次 body 都走。拼一次头要读 2 次 UserDefaults（各带 NSLock）+ 2 次 Info.plist 查询。**关键取舍：缓存整条拼好的头，而不是分别缓存 `deviceID`/`deviceName`/`version`。** 因为 `version(in: bundle)` 是可注入 Bundle 的，`ClientIdentityTests` 用临时 Bundle 连测了 5 种版本组合，给它加无键全局缓存会**跨用例串台**（清单点名的坑）。缓存整条头绕开这件事，`version(in:)` 一行没动。缓存键**同时含 scheme + userId + token** —— 只按 userId 缓存会让 token 轮换后仍发旧 token（表现为「重新登录了还是 401」）。
  - **`P1-10` 十六进制改查表（15.04 µs → 5.33 µs，2.8×）+ 加载键提到 `init`**：`loadKey` 原来是计算属性，**每次读**都要跑一遍 SHA256 + 十六进制编码。读取点共 3 个：**body 里 1 次**（`.task(id:)` 的 id）+ **task 闭包里 2 次**（guard、成功赋值）。拆开实测发现**钱不在 SHA256 上**：`String(format: "%02x", $0)` 八次就要 **13.74 µs**（占 91%），SHA256 本身只占 9%。换成字符表编码后单次 **15.04 → 5.33 µs**。
    - **「提到 `init`」的真实收益要说准**：SwiftUI 重建 View 时会**重新调 `init`**，所以它不是「整卡只算一次」。准确说法是：**每次 body 省 1 次**（改前 1 次/body，改后 0），**每次 task 启动省 2 次**（闭包里那两次读变成读存储属性）。初版写「body 里 3 次 → 每次 body 省 2 次」是错的（把 task 闭包里的读取算进了 body），已由独立审查纠正。
  - **`P1-11` `imageURLString` 整条记忆化（7.05 µs → 1.32 µs，5.3×）**，并**撤销了清单建议的 `domains` 记忆化** —— 实测证明那一步净收益为零：
    | 步骤 | 实测 |
    |---|---|
    | 读镜像键 `UserDefaults.string` | **1.34 µs**（冷路径量级；审查 `-O` 热读复核为 0.29–0.35 µs） |
    | `BangumiDomains` 本体 | 0.50 µs |
    | NSLock 加解锁一对 | 0.38 µs |
    「带失效检查的记忆化」= 读 UserDefaults(1.34) + 锁(0.38) ≈ **1.72 µs**，而直接算 = 1.34 + 0.50 ≈ **1.84 µs** —— **一样快**，白加锁。想真省 1.34 µs 只能靠 `didChangeNotification` 失效，而本 App 用户操作时频繁写默认值，会反复清空缓存。而 `domains` 的主要调用点是 `api` / `next` / `main`（BangumiServices 与 AuthService 共 **10 处**），只有 **1 处**在 `imageURLString` 内部 —— 初版把这条写反了，已由审查纠正。
  - **顺带发现：镜像域名是死配置** —— `dev.jumusu.ocplayer.bangumi.mirrorRootDomain` 全仓**只有读、没有写入点**，所以运行时恒为官方域名。失效逻辑仍按正确语义写好（用**原始字符串**而非规范化后的域名当失效键，否则 `"x"` 与 `"https://x"` 的切换会被当成没变），但现实里永不触发。
  - **⚠️ 初版有一处注释是错的，独立审查挑出并已修**：我原先写「`imageURLStringCache` 里镜像变化时的 `removeAll` 只是内存回收，去掉也不会被任何用例发现」。**这是错的** —— 该缓存只记一个整表代次标签，所以只在新代次里写一个 key 就会推进标签，旧代次的**其余** key 会以新代次身份被命中（返回旧域名 URL → 图裂）。审查给出的反例已复现：
    ```
    store("OFFICIAL-A", k1, nil); store("OFFICIAL-B", k2, nil)
    store("MIRRORED-C", k3, "mirror.example")
    value("k1", "mirror.example")   有清空 → nil（正确）；无清空 → "OFFICIAL-A"（错）
    ```
    已把注释改成「正确性必需、删不得」，并补 `mirrorChangeInvalidatesAllKeysNotJustTheNewOne` 等 2 条用例 —— 现在删掉清空会红。
  - **⚠️ 容量策略也按审查实测改了**：原先超上限是**整表清空**，实测「滚到底再回顶」N=512 命中 50%、**N=513 直接掉到 0%**（每次第 513 个新 key 触发清空）。而 Bangumi 缓存是**进程级**的，中等收藏（1000+ 条目）一次浏览就超 512。改成 **FIFO 只丢最旧一条**。
  - **⚠️ 修了一个 TOCTOU**：`imageURLString` 先采样镜像当代次标签，而 `composeImageURLString` 内部又走 `domains` **重读一次** UserDefaults —— 两次读之间镜像若变，会把「B 代次算出的 URL」存进「A 代次的标签」，之后永久命中错值。改成把采样到的 mirror **传参**进 compose。
  - **⚠️ 一处已知的测试盲区（诚实记录）**：镜像键全仓只有读、没有写，测试环境里 `mirrorRootDomain` 恒为 `nil`，所以「入口传 `mirrorRootDomain`」与「传 `nil`」**结果完全相同** —— 审查的 N12 变异（入口把代次固定成 nil）在任何用例下都抓不到。能测的只有「`compose` 用了传进来的值」。防线是**结构上的单点采样**，已写进注释：将来接上镜像写入口时，务必补一条「设了镜像后入口返回镜像域名」的用例。
  - **⚠️ 一处「变异测不出」的诚实记录**：`imageURLStringCache` 里「镜像变了就 `entries.removeAll()`」那两句**去掉不会被任何用例发现** —— 因为正确性靠**代次检查**（读时 `mirror != current` 直接返回 `nil`），清空只是内存回收。这条写进了类注释，免得后人去为它补人为断言。
  - **验证（红 → 绿）**：新增 5 + 7 + 5 条用例。逐个变异验红：缓存键去掉 token（最致命的错法，会让重登后仍发旧 token）→ 红；十六进制高低位写反 → 红；用大写表 → 红；用规范化域名当失效键 → 红。
  - **⚠️ 测试并行的一个坑**：第一版 `BangumiURLCacheTests` 直接改 `UserDefaults.standard` 的镜像键来验失效，而 Swift Testing **默认并行跑用例** —— 全局键被改的瞬间别的套件读到镜像形态，当场红。改成**直接测缓存类**（`mirror` 本来就是方法参数），完全离线、不碰全局状态。
  - **收益基数说明**：~634 µs 是「20 张卡 × 每卡一次 body」的**上界**，滚动时并非每帧都跑满；这里不夸大成「省了 3.8% 帧时间」。

### 性能

- **登录页海报墙的 5 760 次文件判定搬离主线程**（性能审查清单 `P1-09`）。
  - **实测（先测后改）**：`cachedFileURL` 单次 **21.74 µs**；最坏情况 96 张候选 × 阶梯 3 档 × 身份池 20 = **5 760 次 = 125.2 ms**，改前这一整段跑在 `@MainActor` 上。而登录页正是用户点完「退出登录」马上看到的页面。
  - **实测（改后）**：同样的 5 760 次判定 **199.13 ms**、`pthread_main_np() == 0`（确在非主线程）。耗时数字比改前预算高，是因为探针用了全 miss 的最坏构造；关键指标是**不再占主线程**。
  - **改法**：把逐候选的判定与组装提成 `nonisolated static func resolvePosters(...)` / `resolvePosterFile(...)`。用 `nonisolated async` 而**不是** `Task.detached` —— 后者脱离结构化并发，离页后这 5 760 次判定仍会跑完；前者沿用结构化并发，取消会自然传播（并在循环内加了 `Task.isCancelled` 检查）。
  - **保留在主 actor 的只有**：读 `app.store.profiles`、拿 `activeStore`、`posterCandidates` 的 actor 调用。
  - **⚠️「离开主线程」是当前编译设置的产物，不是语法保证**（审查实测）：本工程（`SWIFT_VERSION=6.0`、无 `-enable-upcoming-feature`）下 `pthread_main_np()==0`；但打开 `NonisolatedNonsendingByDefault` 或 `ApproachableConcurrency` 后**同一段代码立刻变回 `=1`**（跑回主 actor）。也就是说将来谁为采用 Swift 6.2 并发默认值打开那个开关，这批收益会**静默还回去**，而别的用例一条都不会红。所以新增 `LoginWallOffMainTests`：用**主线程心跳计数**（另一个 `@MainActor` 任务每 1 ms 跳一次）钉住 —— 50 400 次判定跑 1 s 期间心跳必须仍 > 3 次。把 `resolvePosters` 改成 `@MainActor` 模拟退化即红。
  - **⚠️ 计划里标注「必须实测不能推理」的点**：SE-0338 保证 `nonisolated async` 不继承调用方 actor，但我没有靠推理结案 —— 用 `pthread_main_np()` 探针实测得到 `onMain=false`。Swift 6 在 async 上下文里**直接禁用 `Thread.isMainThread`**（"unavailable from asynchronous contexts"），这本身就是强提示，绕法就是 `pthread_main_np()`。

- **登录页首次出现时不再在主线程扫 URL 缓存库**（性能审查清单 `P1-08`）。
  - **实测（先测后改）**：本机真实缓存 `Cache.db` + `Cache.db-wal` 共 **2.0 MB**，扫描 **7.77 ms**，`onMainThread=true`。按 `URLCache` 512 MB 上限外推 **≈2.08 s**（理论最坏，非日常）。
  - **改法**：`scanURLCacheForIdentities()` / `authIdentities(in:)` 标 `nonisolated`；`discoveredIdentities()` 与 `identities(for:)` 改 `async`。全仓只有 1 个调用点（`LoginWallCatalogLoader`），async 化不外溢。
  - **两条不变式**：① `didScanURLCache` **必须在 `await` 之前同步置位** —— 否则两处并发进登录页会双扫、并可能重复写；② 扫描是提示不是依赖，失败照旧当没扫到，不阻塞登录。
  - **顺带发现**：这个编译错误本身就是 `P1-08` 的直接证据 —— 探针在非主线程上**编不过**（`call to main actor-isolated static method 'authIdentities(in:)' in a synchronous nonisolated context`），说明改前它确实只能在主线程用。
  - **⚠️ 第一版有 bug，自查发现并修了**：扫描加了「逐文件判取消」之后，**取消会返回部分结果**，而 `didScanURLCache` 已置位 —— 身份池于是被**永久截断、再也不补**（这个标志的语义就是「每进程只扫一次」）。而这正是它唯一的作用：多试几个身份、多找回几张海报。改成扫描返回 `(identities:wasCancelled:)`，**取消时复位标志让下次重扫**。`testScanSignalssCancellationSeparatelyFromEmptyResult` 钉住（取消处理改成恒 `false` 即红）。

- **下载页轮询在应用进入后台时停止**（性能审查清单 `P2-40`）。
  - **问题**：5 秒轮询循环只判 `Task.isCancelled`，macOS `⌘H` 隐藏 / iOS 进后台后进程还在跑，于是每 5 s 发一次请求（挂机 **720 次/小时**）。用户完全无感，但确实是白发的。
  - **改法**：`.task` → `.task(id: DownloadsPollingPolicy.taskID(scenePhase))`，循环前判 `shouldPoll`。**必须用 `.task(id:)`** —— `.task` 的闭包捕获的是启动那一刻的视图快照，循环里读 `scenePhase` 永远读到旧值（SwiftUI 经典坑），只有把相位放进 id 才会随相位重建任务。
  - **判据只认 `.background`，不认 `.inactive`**：本机实测 `⌘H` → `.background`、最小化 → `.inactive`。`.inactive` 不当作「不可见」，因为它还覆盖 iOS 上通知中心 / 切换器 / 来电那类**短暂**状态 —— 拿它去停轮询，重进前台时首帧会空一拍。
  - **⚠️ 一条被实测推翻的论据（结论不变、依据换掉）**：最初的注释写「`.inactive` 同时表示『应用不在最前』，用户点了别的 app 也是 `.inactive`」。独立审查用最小 SwiftUI app 实测**推翻了它**：macOS 26.6 上切到别的 app（`NSApp.isActive == false` 持续 2 s）**不产生任何相位变化**，`scenePhase` 一直 `.active`；本机 `.inactive` 主要来自**最小化**。所以「最小化仍每 5 s 发一次请求」现在是**明确的已知残余**，不是「安全取舍」。真要按窗口可见性判，得看 `NSWindow.occlusionState` / `miniaturized`，不是 `scenePhase`。
  - **⚠️ 明确不动的 5 个循环**：全仓 7 个 `while !Task.isCancelled` 里，`PlaybackReportingCoordinator` 心跳与 `PlaybackController` 的 4 个**必须**在后台继续（`UIBackgroundModes: audio` 下后台播放要照常上报进度）；氛围轮播（12 s）不产生网络请求、隐藏窗口不渲染，浪费接近零，且改它要动 `.task(id: ambienceTrigger)` 的重启语义，得不偿失。**别顺手统一。**
  - **⚠️ `.task(id:)` 的键只能随「轮询决定」变化，不能随相位逐个变**（第一版写错，自查 + 审查双向发现）：按相位逐个给 id 时，`.active ↔ .inactive` 每次切换都**取消并重建**轮询任务。实测（审查者的真实 SwiftUI 探针）：最小化 → `TASK START id=1 phase=inactive` + 新起一次 refresh。而在飞请求被取消后 `URLSession` 抛 `URLError(.cancelled)`（**不是** `CancellationError`）→ `MoviePilotError.ignore("请求已取消")` → `refresh()` 的通用 `catch` 写进 `loadError` → 用户最小化再还原就看到一张「请求已取消」错误卡片（审查实测最小化即触发重建）。改成 `taskID = shouldPoll ? 0 : 1`：`.active`/`.inactive` 共用一个键（它们本来就都轮），只有进出 `.background` 才重启。
  - **同时补一层**：`refresh()` 原本只 catch `CancellationError`，挡不住上面那条 `.ignore`。抽出可测的纯函数 `DownloadsRefreshSurface.shouldSurfaceError(_:)`：`CancellationError` 与 `MoviePilotError.ignore` 都不显示，真错误照常显示。
  - **验证（红 → 绿）**：`DownloadsPollingPolicyTests` 6 条 + `DownloadsRefreshSurfaceTests` 3 条。三个变异逐个验红：判据改成 `phase == .active`（`.inactive` 也停）、`taskID` 退回按相位逐个给、删掉 `.ignore` 判据。
  - **旁证**：审查者用真实 SwiftUI 探针实测确认了 `.task` 的陷阱 —— 普通 `.task`（无 id）下 `phaseInLoop` 在 `PHASE -> background` 之后**仍恒为 `active`**，`.task(id:)` 是唯一可靠形态。
  - **⚠️ 一处测试缺口（审查指出并已补）**：阶梯前两档 `(400,400)` / `(300,300)` 的两个数值**恰好相同**，所以只用这两档的 fixture 结构上发现不了「把 `step.maxWidth` 与 `step.maxPixelSize` 用反」——审查实测：用反后原 10 条用例**全绿**。第三档 `(720,360)` 是唯一**数值不对称**的一档，从没被写过。补 `testResolvePosterFileKeepsAsymmetricLadderStepParameters`（只写第三档）+ `testResolvePosterFilePrefersEarlierLadderStep`（两档都写、断言返回更靠前那档）。参数用反即红。
  - **测试缺口（审查指出并已补）**：只断言 `shouldPoll` 返回值时，把视图里的 `guard shouldPoll(...)` 删掉、或把 `.task(id:)` 改回普通 `.task`，**用例一条都不红**（审查实测：删掉 guard 后隐藏 16 秒仍 refresh 4 次）。所以把循环本体提成 `@MainActor static func runPollingLoop(phase:interval:fetch:)`，新增两条直接驱动它的用例：`.background` 时 `fetch` 一次都不被调用；`.inactive` 会转且取消后真的停。删掉 guard 即红。

### 性能

- **弹幕正文加有界内存缓存：同一集重开不再重读重解 0.1–0.8 MB JSON**（性能审查清单 `P1-15`）。
  - **问题**：`DanmakuCache` 的三层里，`mapping.json` 与 `intro-hints.json` 都有写穿内存缓存，唯独最大的一层——每集弹幕正文——**每次纯磁盘读**。换源、重试、手动选集都会重新装载同一集，于是每次都重读盘 + 重解码整份 JSON。
  - **实测（先测后改）**：本机真实缓存 23 个文件共 6.4 MB，最大一份 **756 KB / 8159 条**；单次 `comments(for:)` 冷读 **13.2 ms**，加内存层后**热读 0.001 ms**。清单原文估的「3–6 MB」偏大，实测平均 **279 KB/集**。
  - **⚠️ 没有照抄清单建议**：原文写「加写穿内存缓存（与同文件另两层同形）」。照抄会出事——那两层是几百字节的小字典，常驻无妨；弹幕正文每集 0.1–0.8 MB，**无界常驻几十集就是几十 MB**，而本 App 真实峰值 RSS 已到过 435 MB（`LIVE-04`）、`CHANGELOG 0.1.9` 记过 iOS jetsam 风险。所以按最近使用**只留 2 集**（当前这集 + 刚切走的那集），容量可注入，`0` = 关闭。
  - **三条容易漏的不变式**：① **命中内存也要校验 TTL** —— 否则长会话（>1 小时）里会一直返回过期弹幕，而磁盘路径本来会删掉它；② **淘汰只丢内存、不删盘上文件**，否则把 LRU 退化成「删缓存」；③ **内存快照过期后不能照着它删文件**，要落到磁盘路径按**盘上那份**的 `fetchedAt` 重新判断 —— 内存里是本实例的旧快照，盘上那份可能已被另一个实例刷新（预览 / 重建 `AppModel` / 测试里多实例同目录都是真实写法），照着旧快照删等于删掉别处刚写的新数据。解码失败**不进内存**（保持自愈，与 `loadMapping` 同策略）。
  - **验证（红 → 绿）**：新增 10 条用例（10 → 20）。逐条做过变异验证：删掉读盘回填 → `testDiskReadBackfillsMemoryCache` 红；内存命中不 `touch`（LRU 退化成 FIFO）→ `testMemoryCacheEvictsLeastRecentlyUsed` 红；解码失败做负缓存 → `testCorruptedCommentsDoNotEnterMemory` 红；把读路径改回「永不命中内存」→ 三条行为用例红。全部恢复后 20 条全绿。

- **弹幕自动匹配的降级瀑布补总预算，最坏从 ≈100 s 砍到 ≈45 s**（性能审查清单 `P1-16`）。
  - **实测把原文的机制搞清楚了**：清单写「最坏 7 × 15 s ≈ 105 s」。实测三档错误类型的请求数完全不同 —— **超时 / 5xx / 429 会被 `gatewayDown` 短路，只发 1 个请求**；**4xx / 解码失败不短路，发 4 个**（每层 1 个，首个请求即抛错，且返回快）；只有「**慢但 200 空结果**」这条路径会让层内查询循环全部走完，**最多 8 个请求** —— 那才是 100 s 的真正来源。所以这道闸门治的不是「网关挂了」，而是「网关慢但看起来正常」。
  - **闸门下沉到层内**：只做层间检查时上界是「预算 + **一整层**」（Tier 2 自己就串行发 3 个）。实测 120 ms/请求 + 250 ms 预算：关闸门 **8 个请求 / 1012 ms**，只做层间检查仍 **4 个 / 497 ms**，下沉后 **2 个 / 252 ms** —— 恰好是「预算 + 一次在途请求」。默认 `totalBudget = .seconds(30)`，`0` = 关闭。**契约是「预算 + 一次在途请求」≈ 45 s**（单请求超时 15 s），而且**重试对闸门不可见**（150 ms 预算下 Tier 1 仍会发满 3 次尝试）—— 所以别按 30 s 理解上界。
  - **预算提前放弃要报「可重试的失败」，不能报「未匹配到剧集」**：这是与 `P1-03` 同一条立场。审查给的反例：把唯一命中放在 Tier 4 —— `.zero` 预算能 `loaded`，250 ms 预算却落 `.noMatch`。那不是「服务端没有这一集」，是我们**没跑完**降级链。所以预算掐掉过请求且没有 `tierError` 时返回 `.failed("弹幕匹配超时，请重试")`；`.failed` / `.noMatch` 的其余映射规则不变。
  - **日志只在「真的掐掉过请求」时记**：判据从「结束时是否过点」改成 `budgetDidCut` 标记。否则四层全跑完、8 个请求全发出，只因为总耗时长也会记一条「超出总预算」—— 而这条日志存在的唯一理由正是区分「主动放弃」与「真的没匹配上」。
  - **验证（红 → 绿）**：新增 5 条用例（24 → 28），并对**每个变异**都实跑确认会红：闸门判据改恒真 → 红；删掉层内全部 `budgetOpen()`（只留层间）→ **4 个请求 / 418 ms 红**（原来是漏网，因为旧断言只有 `<= 4` 与 `< 600 ms`）；`deadline` 设成「一进函数就过期」→ **0 个请求红**（原来同样漏网）；诚实态改回 `.noMatch` → 红；撤销「指纹之后重置时钟」→ 红。
  - **⚠️ 阈值必须上下界都钉，且墙钟不能写绝对值**：审查实测发现，只写 `<= 4` 时「删掉层内闸门」（4 个）与「闸门立即失效」（0 个）**两个都绿** —— 它们恰好是最核心设计的两端。现在收成 `2...3` 个。**墙钟断言踩过一次坑**：先写成绝对阈值 `< 400 ms`（本机 3 个请求 312–324 ms，而「删掉层内闸门」在本机是 4 个 / 418 ms），**CI 上直接红了** —— 同样 3 个请求在 runner 上要 **421.9 ms**，与 418 ms 重叠，绝对阈值必然在某一侧误判。改成**和自己那一轮的 unbounded 基线比**（`< 0.75×`），同机同负载、机器无关；改完 M1 变异仍然红。
  - **⚠️ 第一版实现有 bug，自己测出来并修了**：预算时钟原本从 `runAutomatic` 开头起算，把**指纹下载**（`mediaHash` 拉媒体服务器前 16 MiB）也算进去了。而那段成本由 `URLSession` 自己的超时管着（request 15 s / resource 30 s），闸门既管不到也不该管。实测指纹 500 ms + 预算 300 ms ⇒ 进到 Tier 1 预算已耗尽，**零次搜索请求**，最后还落成 `.noMatch` —— **谎报「未匹配到剧集」**，慢媒体服务器上可达。改成**指纹之后再起算**；新增 `testSlowFingerprintDoesNotConsumeBudget` 钉住（摘掉重置两行即红：`("0") is not greater than ("0")` + `实际 noMatch`）。

- **暂停后不再每 10 秒重复上报进度**（性能审查清单 `P1-01`，属「纯浪费」——不改用户可见行为，只是不再白发请求）。
  - **暂停挂机 360 次 POST/小时**：心跳循环的终止态判据只认 `.stopped` / `.error` / `sourceOpenFailed`，`.paused` 于是落到通用的 `ticks % progressEveryTicks == 0` 分支 —— 每 10 s 发一次真实 `reportPlaybackProgress`。而暂停期间播放位置根本不再前进：**除第一条外，后面每一条都是同一条数据的复制品**（载荷逐字相同）。改成「进入暂停时报一次（服务端仍需要知道『停在哪 + 现在是暂停』），暂停期间不再重复，恢复播放后复位」。
  - **验证（红 → 绿）**：`testPausedDoesNotRepeatProgressReports` 修前 `XCTAssertEqual failed: ("17") is not equal to ("1") - 暂停期间不该重复上报`（200 ms 窗口里发了 17 条），修后通过。该用例同时钉住「暂停要报一次」与「恢复后照常上报」两条语义。

- **网关全挂时不再发第二轮注定失败的关键词检索**（性能审查清单 `P1-03`，同属「纯浪费」）。
  - **全失败时等待翻倍**：第二轮「放开类型过滤」用的是**同一批关键词**、只把 `filter` 从 `.anime` 换成 `nil`，所以网关全挂 / 断网时它必然也全失败，唯一效果是把等待翻倍（每轮 ≈ 关键词数 × 10 s 超时）。判据加在第一轮汇总处：**至少有一个请求真的到达了服务端**（`succeededSearches > 0`）才发第二轮。
  - **判据为什么不是 `lastError == nil`**：部分成功 + 部分失败时 `lastError` 也非空，而那种情形下放开类型过滤仍可能命中真人剧 —— 用后者会把这种情况一起挡掉。为此专门加了反证用例 `testPartialFailureStillAllowsTypeFilterRound` 守住这条边界。
  - **可测性**：`BangumiMatcher.searchAndPick` 新增一个**带默认值**的注入参数 `search:`（生产默认值就是原来那句 `BangumiSubjectService.search`，逐字不变），与 `ImagePipeline(cacheDirectory:)` / `BangumiAPIClient(sessionFactory:)` 同一模式 —— 失败路径在生产里无法稳定复现，只能靠注入。
  - **验证（红 → 绿）**：`testAllSearchesFailingSkipsTypeFilterRound` 修前红（第二轮照发、共 4 次请求），加守卫后通过。macOS AppTests 全量 **585 通过 / 18 跳过 / 0 失败**（xcresult `result=Passed`）。
  - **顺带清掉一个构建副作用**：本次构建把 `Package.resolved` 里的 swift-nio 从 2.101.3 顶到了 2.104.0（`originHash` 也变了）。那是解析器行为、与本次修复无关，**已还原**，没有混进提交。

- **macOS 弹幕描边不再实时转字形路径；时间轴对齐指针改二分**（弹幕上屏与 seek 两条热路径，双端共用同一份模型）。
  - **描边（`OverlayDanmakuCell`）**：原先两趟都走 `NSString.draw(at:withAttributes:)`、描边靠 `.strokeWidth` 文本效果 —— 那条路**每次绘制都要把字形实时转成 `CGPath`**（`CTFontCreatePathForGlyph` 实测 **237 µs/字形**：一条 13 字弹幕光描边就 **2.0 ms**，而填充只要 46 µs）。改成「同一行 `CTLine` 按 12 向圆环偏移画 12 次 + 画一次原色填充」，单条 **2.43 ms → 0.23 ms**（代码注释与 `OverlayDanmakuCellRenderTests` 在案）。缓存字形描边路径（`CGPath.copy(strokingWithWidth:)`）也能提速但只有 ~6× 且要多养 ~15 MB 字形缓存，**否决**；两圈（内 8 + 外 12）也试过并否决 —— 12 份副本的并集本就把环带填实，内环只多 5 个像素墨迹。
  - **换实现必须重新对基线**：旧路径在 y-up 上下文里的 `origin` 是**行盒左下角**，`CTLineDraw` 要基线 —— 换算成 `行盒高 − round(ascent)`，**不是** `round(descent)`：多数字号下两者相等，16pt 上不等（ascent 15.469 / descent 3.375 / 行盒 19 → 4 vs 3），写错就整条弹幕错位一个像素，而**不会让任何既有用例变红**。两行 `CTLine` 在 `displaying` 里**懒建 + `NSLock` 缓存**：`init` 跑在主线程、每条弹幕一次，两行约 52 µs 的主线程税不该付。
  - **iOS 走原路径**：`DanmakuAsyncLayer` 在 iOS 用 `UIGraphicsBeginImageContextWithOptions`（y-down 翻转上下文），CoreText 的文本矩阵约定与 macOS 的 y-up 不同，本机未验证，不冒险。
  - **时间轴对齐**：`comments.firstIndex { $0.time > now } ?? count` 是**线性扫描**，而每次 seek / 换源 / 改偏移都要对齐一次指针，一张热番 3k–30k 条。改成 `DanmakuOverlayController.upperBound(of:time:)` 二分（O(log n)，30k 条 ≈ 15 次比较），语义与线性扫描**逐字等价**。
  - **验证**：新增 `OverlayDanmakuCellRenderTests`（8 条 —— 填充趟与旧 `NSString.draw` **逐像素零差异**，12/14/16/18/22/26/30/36/44 九档字号；基线公式九档成立；描边确实在填充外缘加墨、权重与旧口径相当；极深字走浅描边；CoreText 路径显著快于旧描边）、`DanmakuOverlaySpawnCostTests`（3 条 —— 主线程上 300 条补发的模型构造 / `shoot` / 端到端成本，阈值取数量级判据）、`DanmakuOverlayTimelinePointerTests`（6 条 —— 与线性扫描逐点等价，含空表 / 恰好相等 / 重复时间戳 / 2000 条中段对照）。

- **一轮「热路径少算一遍」的收敛：弹幕匹配与加载、日期解析、目录扫描、日志与存储维护**（同一形状 —— 纯函数的入参没变却重算一遍，或每次调用都做一次全量系统调用）。
  - **弹幕匹配打分**：`DanmakuCandidateScorer.seasonScore` 原先自己再 `parse` 一遍候选标题，而调用点已经从同一个 `animeTitle` 的 `parse` 结果里拿到了 `seasonNumber`（单次 `parse` 含约 31 次 ICU 正则操作）；一次开播最多约 7 轮全量打分、长番可上千候选，且跑在编排器的 `@MainActor` 上。改为由调用方传入 `candidateSeason`。
  - **片头提示只在真会用到时才算**：`resolveIntroHint` 在「非强制重匹配 + 已有缓存」时直接返回**永久缓存**（`intro-hints.json` 在 `DanmakuCache.permanentFileNames` 里），现算结果**整个丢掉** —— 而 `DanmakuIntroDetector.detect` 要对每条弹幕做 2 次 `p.split` + 19 次子串搜索（3 万条 ≈ 57 万次 `String.contains`），全串行跑在弹幕上屏之前。`DanmakuService.payload` 新增 `detectingIntro:`，编排层先查一次**内存**缓存决定要不要算（`await` 不能写在 `||` 右操作数里 —— 那是 `@autoclosure`，不支持并发）。
  - **日期解析器共享**：`BangumiEpisodeDTO.airDateValue` 与 `TMDbAirDate.parse` 都**每次现建** `DateFormatter`（实测 **43.9 µs/次**，共享后 20 µs/次）。前者是无缓存计算属性、选集格一次 body 读 `aired` 7–8 次（一屏 40 格 ≈ 12.5 ms）；后者一季 1000 集 ≈ 44 ms 主 actor 开销、详情页一次加载重建 ≥3 次。两处改为共享持有（`DateFormatter.date(from:)` 本身线程安全），**时区口径一字不动** —— 必须与另一来源逐字一致，差一天会让同一集判成不同播出状态。
  - **`MetadataStore` 的 `library` payload 解码器共享**：冷启动首屏 `MetadataHydrator.home()` 那条读路径此前「每行新建一个 `JSONDecoder()`」，改用 actor 内共用的一份。
  - **占位集名正则预编译**：`TMDbOverlay.isPlaceholderEpisodeName` 在分集行渲染路径上（每行一次），原先逐条 `range(of:options:.regularExpression)` —— 每次都现场编译 ICU 正则，改成 `NSRegularExpression` 静态量。**反向的一处刻意不动**：`TitleNormalizer.normalize` 那 5 条 pattern **不换** —— 两套 API 的 `\d` 口径不同（`String.range(of:options:)` 的 `\d` 连「一/二/三/十/九」这类带数值的汉字都匹配，实测跨 BMP 命中 2023 个码点；`NSRegularExpression` 只认 `\p{Nd}`），换掉之后「阿松 第二季」不再被剥成「阿松」，已有用例当场红（已实测）。
  - **日志目录只在该开文件时保证**：`DiagnosticBackend.write` 原先**每条记录**都 `createDirectory` 一次（目录早已存在，纯白付一次系统调用 + 路径解析），而调用方包含每一次 Jellyfin/Emby 请求与每 10s 一次的播放上报；移进 `handle == nil` 的分支。
  - **图片缓存按字节数节流扫描**：`ImageBlobStore.store` 是「每张图一次」，而 `pruneIfNeeded` 要枚举整个缓存目录、**逐文件** `attributesOfItem` 再排序（上限内文件数可达数千），海报墙滚一屏就是几十次全目录 stat。改为累计写入 **4 MB** 才扫一次（上限的 1.6%，超限最多晚 4 MB 才修剪），进程内首次写入仍扫一次 —— 收掉上次会话遗留的超限。
  - **存储维护真的被合并**：`AppStorageMaintenance.requestMaintenance` 注释写着 "Coalesced"、实际每次调用都排一轮**完整**维护（日志保留策略 + 数据库 `refreshSize`/`itemCount`/`evictItems`，库超 200MB 还会 VACUUM 整库 + 三个受管目录全量枚举与逐文件 stat）。而调用点之一是**逐条下载侧车字幕的循环体**（一部带 12 条字幕的片源开播连打 12 次）。改为串行队列上 **30s** 最小间隔（日定时器仍是兜底，上限语义不变）；`lastPerformedAt` 只在 `queue` 上读写。
  - **Bangumi 匹配去掉末尾的无条件重打分**：`pickBestCandidate` 是纯函数，末尾那次重算的入参、`enumerated()` 位次、`queryInfo` 全没变，结果逐字相同；而它正好落在「标题不完全相等」这个最常见的模糊匹配分支上 —— 每个候选每次打分要 `parse` **两遍**标题（单次 `parse` 是 37–43 次现编译正则 + 100 次整串替换）。改为只在「放开类型过滤」那条候选集真变了的路径上重算。
  - **MoviePilot 搜索的纯进度事件不再触发整页重算**：批量回调里进度 / 帧间心跳的载荷与上一批**逐字段相同**，此前照样 `recomputeDisplayed()`（filter + sorted）+ `TorrentFilterEngine.options`（7 个 Set 各自 `sorted()`）+ 4 次 `@Observable` 写入把整页重算。一场「按标题全站搜索」有 60–120 个事件、绝大多数属于这一类；判据用**值比较**而不是条数（`replace` 事件可能条数相同而内容不同）。
  - **Jellyfin / Emby 的退避等待不再吞取消**：`try? await Task.sleep(...)` 会把 `CancellationError` 吞掉，循环继续走到下一次 attempt —— 退避被整个跳过（0 延迟立刻重发），调用方明明已经不要了却仍多推一格失败序列。两处对齐共享实现 `RetryPolicy.run` 的写法（改 `try await`）。
  - **设置页「图片缓存」用量统计挪出主线程**：`ImagePipeline.shared.diskUsage` 是**目录内每文件一次 stat + 全量排序**，512 MB 上限下可有数千个小文件，留在主线程就是进页卡顿（冷目录几十~几百 ms）。与同页「导出诊断包」「清空图片缓存」一致改走后台，回主 actor 只赋字符串。
  - **验证**：本批**不改行为语义**（等价重算、少一次系统调用、后台化），唯一有输出差异的是 macOS 弹幕描边的圆环近似 —— 由 `OverlayDanmakuCellRenderTests` 的逐像素 / 加墨量对照守住。实跑：`OcPlayer-macOS` scheme **578 通过 / 0 失败 / 18 跳过**（含上面三个新用例文件）、`OcPlayer-iOS`（iPhone 17 模拟器）**596 条 0 失败**、被改动的 7 个包（AppDesignKit / DiagnosticsKit / DanmakuKit / JellyfinKit / BangumiKit / MetadataKit / MoviePilotKit）各自套件通过。

- **内核逐帧失败日志不再占着渲染主锁；`poll_event` 失败补上节流**（性能审查清单 `P1-17`）。
  - **现象**：`ErikaEngine.step()` 持有一把主锁（UI 的 `play` / `pause` / `seek` / `tracks` 全在这把锁上等），而 4 处逐帧失败日志就打在 `lock.lock()` 与 `lock.unlock()` **之间**。一条 error 日志的成本 = 字符串插值 + `DiagnosticRedactor.redact` 6 趟正则 × 3 段（消息 / subsystem / category）+ OSLog 提交 + 入队，实测 **46.8 µs/条**（`emitToOSLog: false`，故为**下界**）。内核错误态下 60 Hz 就是**每秒 2.8 ms 全持锁**，等锁的 UI 直查跟着一起卡。
  - **`poll_event` 完全没有节流**：同一函数的 `.renderTick` 失败早在 `renderThrottle`（1 s）里，`.pollEvent` 失败却是裸调用。`PlayerState.apply(.failed)` 那边已按 `code|message` 去重（注释记着「一次 EOF stall 刷了 6302 条」）—— 同类问题在 App 侧修过，**引擎侧这条被漏掉了**。这也说明 `.failed` 事件本身不会二次放大，要处理的只是日志。
  - **修法**：锁内只攒纯 enum（`RenderFailure`），落盘统一挪到 `lock.unlock()` 之后（`emitFailures`）。**消息文本逐字节不变**，顺序仍在 `.failed` 事件 `yield` 之前，时间线与改动前一致。`poll_event` 加 1 s 节流，键 `poll-failure` —— **必须与 `render-failure` 不同键**：同键上谁先到谁就占住那 1 s 窗口、另一条被整段压掉，而内核同时坏 render 与 poll 时恰恰是最需要两种证据都在的时候。
  - **一条有意保留的例外**：`captureMemorySnapshotLocked()` 里那条 `PlaybackLog.error` 仍在锁内。它被 `memorySampleFailed` 门控，**一次会话最多一条**（不是热路径）；挪出去要把错误从采样函数里递出来、连带改 `open` / `stop` / `step` 三个调用点，收益与改动不成比例。已在注释里写明是**例外不是遗漏**。
  - **顺带记一个不改的东西**：`.failed` 风暴期间渲染档位**不降** —— `renderLoop.setTier` 只认 `.stateChanged`，`.failed` 反复而 `.stateChanged(.error)` 未到的窗口里渲染线程仍按 `active` 满速跑。这正是「逐帧一条」得以成立的前提。**本轮只记录不改**：改档位等于改渲染行为，风险不对等。
  - **⚠️ 没有红 → 绿**：`step()` 由渲染线程的 `CADisplayLink` 驱动、是 `private`，而构造 `ErikaPresenter` 需要真内核与 Metal —— 全仓没有任何运行时用例能覆盖它（驱动 `ErikaEngine` 的测试只碰 `open()` / `audioOnlyTick()` 这类同步入口）。新增的 `RenderFailureLogTests`（11 条）钉的是**契约**：哪种失败落哪条消息、带哪个节流键。这两件事改错了**不会有任何现象**，只能靠断言钉住。
  - **验证**：`swift test --package-path Packages/ErikaKit`（本机带真内核、不加 `--skip`）**64 个 swift-testing + 28 个 XCTest 全绿**；CI 口径（7 个 `--skip`）同样全绿。

- **诊断日志的常量脱敏从「每条记录」改成「`init` 一次」**（本轮新记 `P2-39`）。
  - **现象**：`DiagnosticLogger.submit` 每条记录都对 `subsystem` 与 `category` 各跑一遍 `DiagnosticRedactor.redact`（各 6 趟正则）。而这两个都是**不可变常量**，`redact` 又是纯函数 —— 纯浪费。实测这两段合计 **15.4 µs/条，占单条日志 46.8 µs 的 33%**。
  - **修法**：`init` 里各算一次存成 `redactedSubsystem` / `redactedCategory`，`submit` 直接用。**输出逐字节相同**；OSLog 那一侧仍用原始值（`Logger(subsystem:category:)` 不动）。
  - **实测**（2000 次 × 5 轮取均值）：单条 error 日志 **46.8 µs → 29.9 µs（−36%）**。口径同上，`emitToOSLog: false` 是下界，生产还多一次 OSLog 提交。
  - **验证**：新增 `testSubsystemAndCategoryAreRedacted` 钉住不变式 —— 谁要是为了省事直接写原始常量，含用户路径的 `subsystem` 就会漏进日志。`DiagnosticsKit` **70 条全绿**（原 69 + 1）。

- **播放日志的节流抑制计数终于能落盘**（本轮新记正确性项 `CORR-09`）。
  - **现象**：`PlaybackLog.flush()` 全仓**只有定义、没有调用点**。App 退出时只调 `AppDiagnostics.flush(timeout:)`，而抑制计数存在**各自的** `DiagnosticLogger` 实例里（两个实例共用同一个文件 backend，但 `throttles` 各一份）。于是 Playback 侧所有节流键的 `suppressed=N` **一直是丢的** —— 「`render_tick` 失败了多少次」查不到，只看得到首条。
  - **为什么本批必须先修它**：上面刚给 `poll_event` 加的节流，如果汇总落不了盘，等于把 59/60 的证据悄悄扔掉、只留一条「又失败了」。
  - **修法**：`PlaybackLog` 加 `flush(timeout:)`（有界版，供进程终止路径用；原无界 `flush()` 保留并注明「终止路径别用」）。macOS 退出（`OcPlayerApp.terminationHandler`）与 iOS `willTerminate`（`RootView`）各补一行调用，沿用既有的有界等待写法，**不新增阻塞风险**。
  - **一条更实在的害处（同一批测量顺带算出）**：单条记录 **264 B**，错误风暴 60 条/秒时填满 `maxFileBytes` 20 MB 只要 **22.1 分钟**、填满 `maxTotalBytes` 50 MB 只要 **55.2 分钟** —— 也就是「故障前那段有用历史」会被风暴在一个小时内整段轮转掉。节流 + 计数落盘正好把这条堵上。

- **复核 `P1-04`：主体结论推翻，但留下一条真实的小浪费**（性能审查清单 `P1-04` → 部分 `REJ-07` + 新记 `P2-40`）。
  - **原判**：下载页每 5 秒轮询把 `tasks` 整个重写 → 每张 `DownloadTaskCard`（「双层玻璃 + 取图」）全部重建；且被上层页面盖住时轮询照跑。
  - **逐条实测，两条是错的**：① **「取图」不成立** —— 卡片里没有任何图片加载，全文只有 3 个 `Image(systemName:)`（SF Symbols）；② **「双层玻璃」数字错** —— 实际 3 层（整卡 `liquidGlassCard` + 暂停键 + 删除键 `liquidGlassCapsule`）。③ **「被 push 盖住」在本页内不可达** —— 本页内部零 `navigationDestination`，它是 `navigationDestination(isPresented:)` 呈现族。⚠️ 但这条只对「页内 push」成立：**全局路由仍可能盖到它**，且 macOS 上被盖页的 `.task` 不会取消（未测全局路由那条，别当已证）。
  - **关键：④「每次都整表重建」不成立（这条我一开始测错过，见下）**。按真实形状复现（`@State [Row]` + `ForEach` + 卡片闭包**捕获 row**、每次 body 都是新闭包），用真 `NSHostingView` 挂窗口数 body 求值：**等值数组写入 → root 与卡片都不重算**（`root 1→1`、`card 2→2`）；**真变更写入 → 两者都重算**（`root 1→2`、`card 2→4`）。SwiftUI 在 `@State` 写入时做了相等性去重，所以「5 秒一次整表重建」这个浪费不存在。
  - **⚠️ 一条被我自己推翻的错误结论（过程留着防重犯）**：初版探针只数了**叶子子视图**的 body（其唯一输入是 `Int`，自然不变），据此得出「无一重算」；独立审查指出该结构不符真实形状，改成上面的真实形状后结论仍然成立、但依据换了。**教训：测「某个状态变化会不会导致重算」，必须数触发源所在的那个 body，并且让被测视图的输入包含变化的那个值。**
  - **⚠️ 另一条彻底错的，也留在这里**：初版写「`scenePhase` 在 macOS 上永不进 `.background`、⌘H 隐藏时完全不变」。**错。** 重测（从 `active` 起）实测：**隐藏 → `NSApplication.didHide` + `scenePhase active → background`**；最小化 → `active → inactive`；恢复 → `active`。初版之所以「没变化」，是因为按 ⌘H 时 app **已经处于最小化后的 `inactive`**，不是从 active 隐藏 —— 测量前提就不对。
  - **由 ④/⑤ 的更正带出一条真实的小浪费（新记 `P2-40`）**：轮询循环只看 `Task.isCancelled`，**不管 app 是否在前台**。macOS 隐藏 / 最小化、iOS 进后台时，只要进程还在跑就每 5 秒发一次请求（iOS 后台会被系统挂起，macOS 不会）。**`scenePhase == .background` 就是正确的门控点** —— 实测可靠。量级很小（挂机 720 次/小时的无用请求），不紧急，但真实存在。
  - **处置**：`P1-04` 主体推翻（进 `REJ-07`），残留的真实项单立 **`P2-40`**。`P1-04` 编号保留以防重复排查。审查清单：`P1` 17 → **16**、`P2` 39 → **40**、合计仍 **92**。
  - **顺手**：`CLAUDE.md`（本地文件、不进仓库）4 处过期事实已按实测改正 —— 工作区基准 `0399500` → `d4018b7`、Xcode 26.3/Swift 6.2.4 → **27.1/6.4**、包 scheme「10 个」→ **11 个**（漏 MetadataKit）、`swift test` 包清单补上 `MetadataKit`。

- **动画标题解析的 40 条正则提成静态量：单次 `parse` 省 74%，一次自动匹配的主线程阻塞从 ~262 ms 降到 ~70 ms**（性能审查清单 `P1-07`）。
  - **现象**：`AnimeTitleParser.parse` 每次调用**现场编译** 40 条 `NSRegularExpression`（`cleanBaseString` 的 24 条剥离表 + `replaceRomanNumerals` 的 12 条 ASCII 罗马数字 + 季数识别 5 条 + Part/Cour 2 条）。而打分器对**每个候选**都调两次 `parse`（`nameCN` + `name`），一次自动匹配最多 **360 次**，全在 `@MainActor` 上一口气做完。触发点是「进任何未关联条目的详情页 / 切到未关联的季」。
  - **实测归因**（本机 Debug，5 轮取均值）：一条 `NSRegularExpression` **编译 61.5 µs**、**匹配只要 0.53 µs** —— 差两个数量级。「每次调用重新编译常量 pattern」是纯粹的浪费。
  - **修法**：全部提成 `static let`，连编译助手也沿用本仓既有约定（`DanmakuKit/DanmakuFilenameParser` 早就这么做，注释理由同构：「全集搜索可返回数百分集——现场编译正则就是主线程秒级卡顿」）。顺带把每次调用都重新分配的字面量数组也静态化（`chineseDigits` 40 对、`unicodeRomans` 10 对、`asciiRomanReplacements` 12 对、`arcKeywords`、`finalPatterns`）。ASCII 罗马数字的**替换模板**与 pattern 配对静态化 —— 只静态化 pattern 会让模板留在循环体字面量里，等于白拆一半。
  - **收益**（本机 Debug，同口径）：

    | 指标 | 改前 | 改后 | 降幅 |
    |---|---|---|---|
    | 单次 `parse` | **0.812 ms** | **0.208 ms** | **−74%** |
    | `pickBestCandidate`（90 候选 × 2 遍） | **262.3 ms** | **69.7 ms** | **−73%** |

  - **三条刻意的边界（都写进了代码注释）**：
    ① **`finalPatterns` 那 3 条继续走 `String.range(of:)`，不换。** 穷举实测证明两套 API **不等价**：36816 条语料（含 BMP `0x20–0x2FFF` 逐码点包裹）上出现 **2300 处分歧**，例如 `"Final Season\u{300}"`（末尾组合附加符号）—— `range(of:)` 判**不**匹配、`NSRegularExpression` 判匹配。这比 `REJ-02` 记的 `\d` 口径差异**更广**：连 `\s` 与大小写折叠都不同。那 3 条对每次 `parse` 只花 **13.7 µs**，不值得为这点钱冒语义漂移的险。
    ② **编译失败仍静默跳过**（`compactMap`），不改成 `preconditionFailure`。改前是 `if let regex = try? ...`，语义必须逐字保持；有 golden 语料兜底，不需要在运行时炸用户。
    ③ **季数链的 `usedSeasonRegex` 标志必须保留**：原实现里某条正则**完整绑定成功**后，后续 `else if` 全被跳过 —— 哪怕 `Int()` 返回 `nil`（`NSRegularExpression` 的 `\d` 等于 `\p{Nd}`，「第٣季」会命中而 `Int("٣")` 是 nil）。写成「命中就拿值、否则走兜底」是**行为变更**，不是重构。
  - **等价性怎么保证**：golden 语料在**改动实现之前**用原实现 dump 出来（独立一个 commit），39 条覆盖每一条 pattern 家族 + 空白/极短标题 + `explicitSeasonName` 分支 + 三个公开字符串变换。改后 **4/4 全绿、逐字节一致**。
  - **顺带更正一个我自己算错的数**：原计划把「3 条 `range(of:)` 每次多花 184 µs」当成本底，实测**只有 13.7 µs** —— 61.5 µs 是 `NSRegularExpression` 的**构造**成本，不是 `range(of:)` 的调用成本。改后剩 208 µs 里正则只占 **36.5 µs**，其余 **171.5 µs 全是字符串处理**（`normalizeFullWidth` 逐 scalar 重建、62 趟整串替换、末尾逐字符过滤）。**要继续压得往字符串处理去，别再琢磨正则。**
  - **验证**：macOS `OcPlayerTests` **607 条 / 589 通过 / 18 跳过 / 0 失败**（基线 603/585 + 新增 4 条 golden）；`BangumiKit` 55 条不变（本批不动该包）。

### 构建 / 发布

- **发版产物重新带上 dSYM（否则崩溃日志永远查不出东西）**（性能审查清单 `CORR-01`）。
  - **现象**：`package-macos.sh` 与 `package-ios.sh` 都在 `xcodebuild` 命令行覆盖了工程设置 `DEBUG_INFORMATION_FORMAT=dwarf`，而工程 Release 配置本来就是 `dwarf-with-dsym`（`project.pbxproj` 的 `1A0000000000000000000006` 块）—— 覆盖把符号从发版产物里抹掉了。**而且光删覆盖还不够**：两个脚本从头到尾没有任何收集 `.dSYM` 的动作，符号只留在 `DerivedData` 里，`dist/` 拿不到，`release.yml` 又只上传 `dist/*`，所以发布资产里根本没有符号。
  - **修法**：① 删掉两处命令行覆盖，并在原位置留注释说明「不要再传这个设置」；② 把 `.dSYM` 打成独立资产（`$ARTIFACT_BASE.dSYM.zip`）放进 `dist/` —— 普通用户下载体积不变，需要符号的人多下一个文件；③ 加**硬断言**：`APP_PATH` 存在但 `.dSYM` 缺失就 `exit 1`。这一条是有意为之 —— 缺符号时构建一切正常、包也能发，**没有任何报错**，不钉死就会再次静默退化。`release.yml` 不需要改（`gh release upload dist/*` 会把新资产自动带上）。
  - **实测**（本机 Release 打包，`v0.0.0-dsymtest`）：UUID 逐字符一致 `FDAF2C22-0EA3-387F-A6DC-F418E0B34A9F`（app ↔ dSYM）；dSYM zip 35 MB、内含 138 MB 未压缩 DWARF，`DW_AT_linkage_name` **194 200 条**、编译单元带源码路径与语句表；`atos` 能把真实地址解成 `main (in OcPlayer) (OcPlayerApp.swift:0)` 与 `partial apply for closure #4 in DanmakuSelectionSheet.body.getter`；`shasum -a 256 -c` 三项全 OK。
  - **一条必须说清的边界（比原判更精确）**：发版 `.app` 本体**并未被 strip**（`LC_SYMTAB` 有 652 580 条符号），所以**函数名**本来就能从公开的 app 二进制里解出来；真正缺的是 **DWARF** —— 发版二进制 `otool -l` 里 **0 个 debug 节**，`dwarfdump --lookup` 直读为空。也就是说：**行号、内联帧与源码位置此前完全拿不到**，而这正是定位崩溃的关键；而且唯一可用的符号来源是随包公开的二进制，一旦将来对 `.app` 做 strip（`COPY_PHASE_STRIP=YES`）就彻底归零。dSYM 是标准且与 UUID 绑定，补上它才算真正可查。
  - **验证入口**：`bash -n Scripts/package-macos.sh Scripts/package-ios.sh`；`SKIP_ERIKA_FETCH=1 Scripts/package-macos.sh v0.0.0-dsymtest` 后 `ls dist/*.dSYM.zip` + `dwarfdump --uuid` 比对 + `shasum -a 256 -c SHA256SUMS.txt`。

- **CI 缓存 key 去掉 `github.sha`，并给两个 workflow 各自加前缀**（性能审查清单 `BLD-04`）。
  - **现象**：`test.yml` 与 `release.yml` 的 `actions/cache` 主键都是 `spm-<os>-<Package.resolved 哈希>-<github.sha>`。带 sha 意味着**只有同一次 run 重跑才命中**，每个 PR 都 miss（靠 `restore-keys` 前缀回退拿到上一版快照），但 `Post Cache` 每次照样 save 一条新条目（实测每 run 白花 67–110 s 上传）。
  - **实测额度**（`gh api .../actions/caches`）：仓库缓存已占 **8.56 GiB / 10 GB**，其中 **3 条 2.61 GiB 的僵尸 SPM 条目**只差 sha 尾缀（`Package.resolved` 哈希完全相同 `9dfe529d…`），内核 `erika-macOS-ARM64-v0.2.1` 0.736 GiB。改前每个 workflow 的条目几乎从不复用、且随时可能把内核缓存挤出去。
  - **修法**：主键去掉 `-${{ github.sha }}`，改为 `spm-test-v1-…` / `spm-release-v1-…`。**前缀是必需的而不是美化**：两个块缓存的是**不同路径**（`ci-test` vs `ci-release-test`），去掉 sha 后 key 会逐字相同、互相顶掉。`-v1-` 是留给将来的手动失效旋钮。内核那块本来就不带 sha、每次都命中，**不动**。
  - **取舍**：主键稳定 ⇒ 条目只在首次写入、之后不刷新，缓存会随提交变旧（未改动的依赖模块仍复用，收益从「冷构建」变成「增量构建」）。不选 `run_id` 滚动 key，是因为那会回到每次写一条 2.6 GiB、把额度打爆的老路。
  - **⚠️ 落地后的实测更正（2026-10-17 晚，两个 PR 的 CI 数据）**：上面「条目回到每个 workflow 一条」这句话**在 PR 阶段并不成立** —— `actions/cache` 的条目**按 ref 作用域隔离**，PR 运行的 ref 是 `refs/pull/<n>/merge`，读不到别的 PR 写的条目。实测：
    | 运行 | `Cache`（恢复） | `Post Cache`（保存） | 结果 |
    |---|---|---|---|
    | PR #28 首次 | 2 s（miss） | 76 s | 建出 `spm-test-v1-…` @ `refs/pull/28/merge` |
    | PR #29 首次 | 1 s（miss） | 86 s | 又建一条**同 key** @ `refs/pull/29/merge` |
    | 缓存现状 | — | — | 同 key 两条（2.603 + 2.602 GiB）+ 内核 0.736 = **5.94 GiB** |
    准确的说法是：**同一 PR 内多次 push 会复用同一条**（改前每次 push 都新写一条，这才是主要收益），而**跨 PR 的复用要靠默认分支** —— 等 `main` 上跑出一次 `refs/heads/main` 的条目后，后续 PR 才能命中它并不再重复写。也就是说稳态「一条 + 内核」要**等一次 main 的 push 运行之后**才成立。
  - **本步不做 `BLD-02`**（把 iOS DerivedData 也加进缓存路径）：额度算术不允许 —— 本步改完后约 5.9 GiB 有余量，若同时加两个 iOS 根，两档各涨到 4–5 GiB、合计约 9.2 GiB，又会把内核挤出去。留待单独评估（更稳的做法是给它单开一个可独立淘汰的条目）→ **已由下一批单独落地**，见下方「iOS 测试的 DerivedData 单独进缓存」条。

- **iOS 测试的 DerivedData 单独进 CI 缓存**（性能审查清单 `BLD-02`）。
  - **现象**：`test.yml` 缓存的是 `.local-build/ci-test` + `Packages/*/.build`，而 iOS 那步用的是**另一个根** `.local-build/ci-test-ios` —— 于是 job 里最慢的一步恰好是唯一没有缓存的一步。实测（2026-10-17 的两个 run）：iOS 步 **462 s ↔ 627 s**，同一次运行里命中缓存的 macOS 步只要 **100 s**；它的耗时构成是解析 **57 s** + 编译 **403 s** + 用例 **110 s** + 收尾 48 s，前两项正是 DerivedData 里的东西。而且它的波动（±165 s）比缓存能省下的还大 —— 冷编译受 runner 负载影响最狠。
  - **修法**：**单开一条** `ios-dd-v1-<os>-<Package.resolved 哈希>`，`path` 只放 `.local-build/ci-test-ios`。不并进 `spm-test-` 那条：它只服务 iOS 这一步，胖了 / 坏了可以**单独删掉**，不必连 macOS 与包构建的缓存一起丢（并入后两档各涨到 4–5 GiB，一旦把内核 0.736 GiB 挤出去，每次运行白下 306 MB）。主键同样只由 `Package.resolved` 决定 ⇒ 依赖没变的 PR 精确命中、且**命中的运行不会再写一条新的**。**不进 `release.yml`**：tag 运行的条目按 tag 隔离、写不进默认分支，单独改它只是白占额度，归 `BLD-03`（从默认分支播种）一起做。
  - **本地实测**（同一个 `-derivedDataPath`，`-scheme OcPlayer-iOS -destination 'platform=iOS Simulator,name=iPhone 17 Pro' build-for-testing`）：**冷建 116 s → 增量 14 s**（改 `PlaybackController.swift` + `StorageMaintenance.swift` 两个真源文件，日志里确有这两条 `SwiftCompile`）；只把 mtime 摸一下则是 15 s（Xcode 用**内容签名**判定增量，不是 mtime —— 所以 CI 每次全新 checkout 也不会因此全量重编）。缓存体积 **1.9 GB** = `Build` 1.0 G + `SourcePackages` 556 M + `ModuleCache`/`Index` 275 M。
  - **额度算术**：先删掉两条僵尸条目（见上一条的 ref 作用域说明；`refs/pull/28/merge` 与 `refs/pull/29/merge` 各 2.6 GiB，key 与 `refs/heads/main` 那条逐字相同）→ **8.54 GiB → 3.34 GiB**；新条目 +1.9 GB ⇒ **5.24 GiB / 10 GB**。稳态就是「main 的 SPM 条目 + main 的 iOS 条目 + 内核」= 5.24 GiB（PR 从默认分支恢复、精确命中不再新写）。
  - **预期收益**：iOS 步 627 s → 约 330 s（省掉解析 57 s + 编译 403 s，换回恢复 ~60 s + 增量编译 ~50 s，按 runner 与增量比 3.4× 折算）。判据是「重跑同一次运行拿到同机同码 A/B」，未到即为空口。
  - **✅ 同码 A/B 实测**（PR #30 的**四次**运行：att 1 冷缓存、att 2/3/4 均命中；同一 commit、同一 runner）：
    | 阶段（iOS 步内部） | att1（miss） | att2（命中） | att3（命中） | att4（命中） |
    |---|---|---|---|---|
    | 解析 Package Graph | 7 s | 6 s | 4 s | 7 s |
    | **编译**（resolve → `builtin-validationUtility`） | **211 s** | **81 s** | **78 s** | **91 s** |
    | **模拟器启动 + 装机**（→ 首条 App 日志） | 185 s | 162 s | **331 s** | 181 s |
    | 用例（`All tests`） | 106 s | 114 s | 109 s | 109 s |
    | iOS 步总计 | 511 s | 377 s | 534 s | 388 s |
    **结论要分开说，别混在一起：**
    - **编译阶段稳定省 ~125 s**（211 s → 78–91 s，三次命中分别是 81 / 78 / 91 s）。这是本条的**真实收益**，与「依赖模块完全复用」互相印证（冷缓存时 `JellyfinAPI` 29 个 / `GRDB` 7 个 / `swift-nio` 系若干文件重编，命中后只剩 41 个 App 侧文件）。
    - **步总 / job 总不能用这些数算** —— 中间那段「模拟器启动 + 装机」在 **162 / 181 / 331 s** 之间跳，att3 的 331 s 是离群点（**±170 s**），比缓存收益还大。att3 命中缓存却比冷启动还慢（534 s vs 511 s）就是被它拖的。**这正是审查清单原文说的「iOS 步 462 s ↔ 627 s 的波动比缓存收益还大」，现在查清了机制：波动不在编译，在模拟器启动。**
    - 准确口径：**每 job 稳定省 ~125 s**（编译），步总仍会在 ~380–540 s 之间跳，取决于当次 runner 的模拟器冷启速度。
  - **由这条带出的新条目（`BLD-08`，未修）**：模拟器启动/装机那 162–331 s **既没缓存也没有预算**，是 iOS 步波动的主因，也是下一刀要切的地方（候选：`xcrun simctl boot` + `simctl bootstatus -b` 预热、或用 `-destination 'platform=iOS Simulator,id=…'` 跳过机型解析）。本轮**不做**：与缓存无关，属另一条线。
  - **⚠️ 一条被自己推翻的错误结论（如实记）**：第一版把「iOS 步 511 → 377 s」当成了缓存收益、还写进了 PR 评论。第三次运行（同样命中，却 534 s）推翻了它。把 iOS 步按四段切开才看清：**收益在编译、噪声在模拟器启动**。教训是**同码 A/B 至少要两次命中运行**才能把噪声和收益分开，只看一次会得出反的答案。PR 里已发更正评论。
  - **一条没做到位的地方（如实记）**：命中后仍有 **41 个文件的 `SwiftCompile`**（冷缓存是 120 个），编译没有全量命中。本机同根实测的增量只要 14 s，说明 CI 侧还有别的东西在让 fingerprint 失效（**未定位**）。再往下压编译得先查这个，属下一轮的活。
  - **验证入口**：`ruby -ryaml -e 'YAML.load_file(".github/workflows/test.yml")'`（并确认 `gh api .../actions/workflows` 里 Test 仍是 `active` —— YAML 写坏会变 `disabled_invalid`）；A/B 见上表。

- **测试夹具的等待改成显式失败**（性能审查清单 `CORR-08`）。
  - **现象**：`AppTests/SkipPreferenceTests.swift` 的 `makeController` 用 3 秒轮询等「playing + 片长 + 位置」三件套落地，**超时后既不 `XCTFail` 也不重试就直接返回**。于是「夹具没等到」被伪装成一条**完全看不懂的断言失败**：`main` 的 `597a8d6` 就是这么红的 —— `testSkipForwardClampsToTailMargin` 报 `("10.0") is not equal to ("1197.0")`，而 `10.0` 正是「位置还停在 0 时 `skip(by: 10)`」的落点，跟「尾部边际」毫无关系。为这一条排查了半轮 26 分钟的 CI + 一次重跑，最后判定为偶发。
  - **修法**：换成同类测试里已有的 `waitUntil` 形态 —— 超时 `XCTFail`，并把**实测状态**一起打出来（`state=… duration=… position=…`）。不加新用例：这次修的是**失败的可诊断性**，现有 10 个调用点就是回归面。`PlaybackControllerOpenTests.setUp` 里那两处静默等待**不动** —— 有注释说明是故意「等不到就带残留继续」。
  - **红 → 绿（真跑过）**：临时把 `timeout` 改 0，`-only-testing:OcPlayerTests/SkipPreferenceTests` 立刻红，报 `等待超时：引擎事件落到状态机（playing + 片长 + 位置）（实测 state=idle duration=0.0 seconds position=0.0 seconds）`，**同一用例下面紧跟着就是那条 `("10.0") is not equal to ("1197.0")`** —— 根因当场坐实，不用再猜。改回默认后该套件 18/18 全绿；全量 macOS `OcPlayerTests` **600 条：582 通过 / 18 跳过 / 0 失败**。
  - **同一个坑还有第二处，本轮一并修了**：`ServerEndpointWiringTests` 自己那个 `waitUntil`（`:190-199`）**也是静默超时**。全仓 `AppTests` 里 8 个等待辅助，**7 个会 `XCTFail`，只有它不会** —— 而它恰好在本次 PR 的最后一次 CI 上炸了：`testResolvedAddressIsPersistedAndPublished` 报三条看不懂的地址断言（`http://192.0.2.10:8096 ≠ http://100.64.1.20:8096`），看起来像地址决议算错了；实际是那次 runner 被拖慢 —— 同套件上一条 `testCallbackFromReplacedSessionIsIgnored` 跑了 **35.2 s**（本机 **0.012 s**），后台探活没在 3 s 内落地，夹具静默返回。
    - 修法同上：超时 `XCTFail` + 打实测状态（`serverEndpointURL` / `profile.baseURL` / `probes.count`）。
    - **红 → 绿**：临时把 `timeout` 改成 `.zero`，报 `等待超时：后台探活/请求计数未在 0.0 seconds 内落地（实测 serverEndpointURL=http://192.0.2.10:8096 profile.baseURL=http://192.0.2.10:8096）`，**后面紧跟的那三条与 CI 上的失败逐字符一致** —— 复现 + 解释两件事一次拿到。撤掉探针后 `ServerEndpointWiringTests` 5/5 全绿。
    - 结论：这两处加起来才把「夹具静默超时」这一类清干净；只修一处就还会在别处浪费一整轮 CI。


### 修复

- **可再生的图片缓存搬出 `Application Support`，进 `Caches`**（性能审查清单 `CORR-02`）。
  - **现象**：`OcPlayerStorage.defaultRoot` 是 `Application Support/OcPlayer`（类型注释明说「iOS 上该目录不参与系统清理」——这对凭据/进度是对的），但 `ImagePipeline` 把两套**可再生**的图片缓存也放在这个根下：512 MB 的 `URLCache`（`Cache.db`）与 256 MB 的字节缓存（`Blobs/`），**上限相加 768 MB**，本机实测已到 **370 MB**。后果三条：① iOS 上进 iCloud 备份（用户备份里带上几百 MB 重下即可获得的海报字节）；② 系统存储吃紧时**不会被回收**（`Caches` 才会）；③ 与真实会话峰值 RSS 435 MB 叠加。全仓唯一设了 `isExcludedFromBackup` 的地方是**凭据文件**。
  - **修法**：不改 `defaultRoot`（它的定位是对的），而是给可再生数据开一条**并行入口** —— 新增 `OcPlayerStorage.cachesRoot`（`Caches/OcPlayer`）与 `cacheDirectory(_:in:)`，与 `directory(_:in:)` 对称，并在类型注释里把「用户数据 vs 可再生缓存」的分工写成表格。**必须沿用隔离机制**：`isIsolated` 时落到 `isolationRoot/Caches`，否则跑一次测试就会写开发机真实的 `~/Library/Caches`。落盘点只改两行（`ImagePipeline` 的 URLCache 目录与 `Blobs/` 父目录）；`ImageCacheIdentityStore` 的复原扫描跟着搬（它读的是同一份 `Cache.db`，不跟就是扫一个永不存在的目录）；删掉 `AppStorageDirectories.imageCache`（已核实声明了但**全仓零引用**）。
  - **一次性清理旧目录**：搬家后旧目录既不会被读、又继续占着备份额度，所以首次启动删掉（marker `…imageCache.cachesRootV1`，与同文件另两个迁移同形）。删除前过**四道闸门**（末段必须叫 `ImageCache` / 父目录必须是数据根 / `legacy != current` 防参数写反删掉新目录 / 目标确实存在），抽成纯函数 `shouldRemoveLegacyImageCache` 逐条正反向钉死 —— 这是一条 `removeItem`，判据错了就是删用户真正的缓存。
  - **顺带修掉一个真实事故**：这条迁移把「一次性迁移在测试进程里跑」从一个隐患变成了破坏 —— `ImageDecoderTests` 会读 `ImagePipeline.shared`（= 默认目录），于是跑一遍 `swift test --package-path Packages/AppDesignKit` 就**真的删掉了开发机 370 MB 的旧缓存**（实测发生）。新增 `shouldRunOneTimeMigrations(cacheDirectory:)`：注入目录的调用方不跑，且**测试进程一律不跑**（`RuntimeEnvironment.isRunningTests` 同时覆盖 `xcodebuild test` 与 `swift test`），并加用例把这条回护钉死。原有的两个迁移同样受这条守卫保护。
  - **实测**：`DiagnosticsKit` 69 条、`AppDesignKit` 127 条（新增 6 + 9 条）全绿；macOS Debug 构建通过；端到端跑真 App —— 造出旧目录 + 清标记后启动，**旧目录被删、新目录建出并真的缓存了 25 张图（18 MB）**，迁移标记落位为 `1`。
  - **代价（有意接受）**：升级后首次启动图片缓存**冷一次**（按需重下），与仓库既有两次缓存键迁移同一取舍；旧 `Cache.db` 被删后「从旧缓存捞回历史身份」对旧字节失去意义，但那些字节本来也一起删了。

### 改动

- **iPad 整个走 iPhone 版式：底部标签栏 + 紧凑内容**（用户口径：「iPad 可以改用 iPhone 那样的 tabview 吗？我看 iPad 的小火箭是 iPhone 样式的」；给了三个变体，选了「V2：只用 iPhone 版的样式」）。
  - **SwiftUI 没有「选底部栏」的公开 API**：`EnvironmentValues.tabBarPlacement` **只读**（只能读「栏现在在哪」）、`.tabViewStyle(.tabBarOnly)` 只管「别变成侧栏」、`UITabBarController.mode` 同样只有 automatic / tabBar / tabSidebar。能用的只有**尺寸类这个副作用** —— `TabView` 那一层的 `horizontalSizeClass` 决定标签栏形态。实拍确认：把 `compactLayout` 的 `TabView` 钉成 `.compact`，iPad 立刻变成 iPhone 形态的底部栏（图标 + 文字 + 头像）。
  - **口径收在一个纯函数里**：`ShellSizeClass.resolved(idiom:actual:)` —— **iPad 恒 compact**（竖屏 / 横屏 / 分屏都一样），iPhone 原样返回（compact 是它的常态；Pro Max 横屏的 regular 是它自己的版式，**不动**）。抽成纯函数是为了能用例钉住「哪些设备被强制、哪些不动」—— 系统怎么渲染只能靠实拍，但这条决策是我们自己的。
  - **留白必须同口径**：`contentLeading` 原本跟真实 trait 走（iPad 52pt），改成跟**外壳尺寸类**走（iPad 22pt）。不改就会出现「内容是 iPhone 版式、左右留白还是 iPad 的 52pt」这种错位。
  - **代价（认下来的）**：这是**跟平台口径对着干** —— iPadOS 18 起系统把标签栏放顶部（Liquid Glass 顶部胶囊），将来系统改行为会**静默**退回顶部胶囊：不会崩，但会白改，所以来历写在代码注释与本文件里。另外大屏密度会明显上去：实测 13″ **横屏库页 12 列**、竖屏 8 列，而常规档是 3 列大卡 —— 这是「紧凑度量铺满宽屏」的必然结果，不是缺陷（想要「少而大」的列数上限要另做，见下）。
  - **顺带解决的一件事**：顶部胶囊**只渲染文字、把图标丢掉了**，所以头像在 iPad 上原本根本看不到；底部栏有图标，头像就出来了。（此前两条「iPad 顶部 Tab 胶囊」的记录是当时的口径，现在 iPad 不再有顶部胶囊。）
  - **验证**：iPad Pro 13-inch (M5) / iPadOS 26.3 模拟器实拍（真实服务器 + 真实账号）—— 竖屏首页：底部栏 + 头像 + 紧凑内容（3 列 rail、6 张「最近添加」、22pt 留白）；横屏库页：12 列海报墙。iPhone 17 Pro 实拍：标签栏与改动前**一致**（头像、玻璃胶囊、尺寸都没变），因为 iPhone 走 `idiom != .pad` 的原样分支。用例 `ShellSizeClassTests` 新增 2 条（iPad 恒 compact：常规 / 紧凑 / nil 三种输入；iPhone 原样）。iOS 模拟器 **587 全绿**（585 → +2）、macOS scheme 全绿。
  - **未做**：宽屏下的**列数上限**（`PosterGrid` 紧凑档是 `.adaptive(minimum:)`，列数随宽度无限增长）。若 12 列看着太碎，出路是给紧凑档加「最多 N 列」—— 需要拿到可用宽度（`GeometryReader`）才能算，属独立一轮。
- **macOS 顶栏药丸的「首页」也接上头像：选中原色 / 未选中灰化**（用户口径：iOS 那格接上之后，macOS 药丸的「首页」也要接；并直接点出关键问题——「接上头像后不是选择的时候和选择的时候的差距」）。
  - **药丸的选中信号本来只有一条**：前景色亮暗（选中 `.primary` / 未选中 `.secondary`），而且药丸里**没有文字**（只有 `.help` 气泡）——图标自己不变色，那一格就彻底没有信号。iOS 那边之所以成立，是因为**系统玻璃胶囊**替它承担了选中反馈（所以「头像不变色」在那边不是缺陷）；macOS 这颗药丸**故意没有选中底**（用户此前否掉过蓝色强调底），这条口径搬不过来。
  - **按同构思路试的「压暗 / 降不透明」实测不成立**：头像亮度由**图片内容**决定，不由 App 决定。本机真实头像平均明度 **209/255**（偏亮），压在浅色玻璃上 `opacity(0.55)` 只剩 **Δ20/255**，而相邻 glyph 的 primary↔secondary 是 **Δ120/255**（深色 96）——差 6 倍；深色模式下方向还反了（变淡 = 往深底里沉 = 更像「选中」）。
  - **改走饱和度通道**：选中原色 / 未选中灰化。真机截图实测（深色外观）：头像格平均饱和度 **111/255 → 0.7/255**、峰值 **196 → 5**，而**明度几乎不动**（信号确实不在亮暗通道，不与相邻 glyph 的语言打架）。四种状态都可区分：彩色无底 = 当前页；彩色有底 = 当前页且鼠标在这；灰色有底 = 鼠标在这但不是当前页；灰色无底 = 都不是。**刻意没走**「给所有 segment 补一个中性选中底」那条路：它会和 hover 底撞车——悬停在非当前页上会和「当前页」长得一模一样。
  - **尺寸 18pt 是量出来的**：把真实头像按 13 / 16 / 18 / 20pt 渲染出来逐个看 —— 13pt（SF Symbol 那一档）只剩一团粉、**认不出人**，16pt 勉强，**18pt 起才看得出脸**；正好落在品牌 logo 已有的 18 / 20pt 档里，槽位（28×24）与胶囊高度（36pt）都不用动。
  - **用 `.grayscale` 而不是 `.saturation(0)`**：两者观感等价，但实测 `ImageRenderer` **不认 `.saturation()`** —— 纯色矩形与位图加与不加**逐值相同**（0.897 vs 0.897、0.762 vs 0.762），认 `.grayscale(1)`（0.762 → 0.000）。这一格的选中信号只有这一条，必须能被渲染用例钉住，所以取 `.grayscale`。
  - **验证**：macOS 真机实拍 A/B（真实服务器 + 真实账号，深色外观）——首页为当前页时头像原色、其余三个 glyph 变暗；当前页切到设置后头像灰化、齿轮变亮，两条信号并存不打架。用例 `SectionAvatarIconTests` 新增 4 条（选中保饱和度 / 未选中饱和度≈0 / 两种状态都是圆、四角透明 / 尺寸 18pt），用 `ImageRenderer` 真渲染量像素（与 `AppAccentTests` 同一套手法）。iOS 模拟器 **585 全绿**（581 → +4）、macOS scheme 全绿。
- **首页 Tab 的图标改成「服务端上这个账号的头像」**（用户口径：照对照产品 Rex 的「发现」栏位那样，用服务器上用户的头像）。**没有头像的账号完全保持原样**——服务端上头像本来就是可选的，没有时仍是系统 `house.fill`，逐像素同款。链路是新的：登录响应里的 `User.PrimaryImageTag` → `ServerProfile` → `MediaServer.currentUserAvatarTag()`（`/Users/Me` 校准）+ `userImageURL(tag:)` → 装载成位图 → `AppModel.userAvatarImage` → `AppShellView` 首页 Tab。
  - **用户头像的路由与条目图不同形**（最容易踩的一处）：钉住的 `jellyfin-sdk-swift 3.3.0`（Jellyfin 12.x OpenAPI）里，用户图只有独立端点 `GET /UserImage?userId=&tag=&format=` 一条，**没有** `/Users/{userId}/Images/{type}` —— 条目图是 `/Items/{id}/Images/{type}`、人物是 `/Persons/{name}/Images/{type}`，用户图是全仓唯一不遵循 `{id}/Images/{type}` 形状的那条。Emby 侧走老式 `/Users/{userId}/Images/Primary`（与 `/Users/{id}/Views` 同批旧路由）。两条形状都钉成黄金值用例。
  - **tag 从登录响应白拿**：登录响应的 `User` 本来就是 `UserDto`，`PrimaryImageTag` 直接落进档案（`decodeIfPresent`，老档案解出来是「这个账号没头像」这个**正常**状态），冷启动第一帧就能出图、不必等网络。会话激活后再用 `/Users/Me` 校准一次——换过头像则 tag 变、URL 变、图片缓存自然不命中（不需要手工失效任何缓存）。
  - **`nil` 也必须能写进档案**：`ServerStore` 新增 `setPrimaryImageTag(_:for:)`，走 `mutate` 而**不是** `save`。因为 `save` 会过 `ServerProfile.merged`，那里「新档案没带 tag 就沿用旧的」的规则会把 `nil` 挡回来 —— 于是「用户在服务端把头像删了」永远落不了盘，下次冷启动又拿旧 tag 出图。两条规则（合并时保留旧的 / 校准口能清成 nil）各自有用例钉住。
  - **标签栏那三条硬约束全是实拍量出来的**（iPhone 17 Pro / iOS 26.3 模拟器，非推理）。任何一条不满足，那一格就画不对：
    1. **label 里不能有 `if/else`**：条件视图会让标签栏画出约 **84pt 的纯黑圆角块**，图标与「首页」文字全被盖住（A/B 实拍：换成单一 `Image` 立刻恢复）。→ 条件提到 **Tab 这一层**，两个分支各放一个裸 `Image`；两个分支的 `value` 都是 `.home`，选中分区与内容栈不受影响。
    2. **位图必须 `alwaysOriginal`，而且要在 `UIImage` 上设**：否则标签栏把它当模板图渲染，整张头像变成一坨纯色（浅色模式下就是上面那块黑）。SwiftUI 的 `.renderingMode(.original)` 在这里**不起作用**。
    3. **位图要按点尺寸栅格化**：标签栏按图片的**自然尺寸**画，`.frame` / `.resizable()` / `.clipShape()` 全被忽略 —— 84px 的位图会被画成 **84pt**（比邻居胖三倍）且方角。所以裁圆、等比填满、渲染模式三件事都在装载时烤进 `AppModel.tabIcon(from:)`（28pt @屏幕 scale）。
  - **`/UserImage` 要算进图片缓存键的规范化**：`ImageCacheKey.isMediaServerImage` 原先只认路径含 `/Images/`，而 `/UserImage` 不含 —— 漏了它，头像的键会保留 host，局域网 ↔ Tailscale 各存一份、换地址重下一遍，正是这条规范化要修的病。
  - **验证**（全部是实拍 / 实请求，非推理）：
    - **真服务器**：拿本机 macOS App 里那份真实档案，对 `192.168.100.107:8096`（Jellyfin 12.1.0）直接发请求 —— `/Users/Me` 返回 `PrimaryImageTag = 59d647b9…`（**这个账号确实有头像**），`/UserImage?userId=&tag=` **200 / 542KB / image/jpeg**（2048×2048 的原图，正好说明本地 `maxPixelSize` 下采样是必需的）；不带 `tag` 请求返回的字节与带 `tag` **逐字节相同**（服务端忽略该参数 —— 它的作用纯粹是客户端的缓存失效信号，与实现口径一致）。顺带记一笔：老式 `/Users/{id}/Images/Primary` 在这台 12.1.0 上**也**返回 200（只是不在钉住的 SDK 生成的 OpenAPI 里），所以走 SDK 那条 `/UserImage` 是保守且正确的选择。
    - **模拟器实拍**：先写了一个假 Jellyfin 服务器（`/System/Info/Public` + `/Users/Me` + `/UserImage` 吐图）做隔离实验，再换成**真实服务器 + 真实账号**（iPhone 17 Pro / iOS 26.3，干净重装后启动）逐张实拍：有头像时首页 Tab 是**彩色圆形头像**、尺寸与相邻图标同槽、选中态不变色（选中反馈由系统那枚玻璃胶囊承担，与 Rex 口径一致）；无头像时与改动前逐像素同款（`house.fill` + 胶囊）；非方图（120×240）按等比填满裁切、不变形。
    - **为什么必须干净重装**：这台模拟器里留着开发者自己账号的 76MB 图片缓存，不擦掉时「标签栏那张脸是我喂的假图还是缓存里的真头像」根本说不清——第一版实验就被它骗过一次（把缓存里的真头像当成了自己喂的图，据此得出「彩色已经渲染成功」的错误结论）。
  - **用例**：`AppModelAvatarTests` 新增 7 条（落进模型的是标签栏版本 28pt + `alwaysOriginal` / 无 tag 不发取图请求 / 换 tag 落盘并按新 tag 重取 / 服务端删头像要同时清内存与档案 / 校准失败保留旧图 / 会话边界清空 / `tabIcon` 的裁圆 + 尺寸 + 渲染模式），`JellyfinKit` 新增 11 条（登录响应带 tag、空串与类型不对当没有、`/Users/Me` 读 tag、`/UserImage` 与 Emby 旧路由的 URL 形状、档案往返、合并保留 / 校准口清 nil），`AppDesignKit` 新增 2 条（`/UserImage` 跨地址共键、Emby 头像端点）。iOS 模拟器 **581 全绿**（574 → +7）、macOS scheme 全绿、`JellyfinKit` **210** / `AppDesignKit` **118** / `MetadataKit` **53** 全绿。

- **全 App 的强调色统一成「中性」：不再用色相表达强调 / 选中，改用前景色亮暗**（用户口径：Tab 修好了，但还有一堆按钮是蓝的；要求先统计、再定方向。选定「统一成中性 primary/secondary」，范围含 macOS、播放器 HUD 与弹幕 sheet）。落地点**只有一行**——`RootView` 根节点钉 `.tint(Color.primary)`；`Color.accentColor` 与 `.foregroundStyle(.tint)` 本来就跟着环境 tint 走，于是 40 处显式 `Color.accentColor`、13 处 `.foregroundStyle(.tint)`、98 个未指定样式（默认吃 tint）的 `Button`、15 个 `Toggle`、21 个 `Picker`、4 个 `Stepper`、2 个 `Slider`、47 个 `ProgressView`、15 个 `.bordered` / 12 个 `.borderless`、11 个 `Menu`、12 个 `confirmationDialog`、约 20 个工具栏按钮、iOS 标签栏选中色**全部自动跟着变**，不必逐个改。macOS 原先没有任何 pin、跟随用户的系统强调色（可能是粉 / 石墨），一并统一。
  - **先统计再动手，统计口径落成表**（用户要求「你先统计一下」）。按「是否吃环境 tint」把全仓控件分了类：吃 tint 的走一行根 tint；不吃 tint 的只有三类——字面色（`Color.blue` / `.orange` 这类语义色）、自绘调色板（`PlayerHUDPalette`）、品牌橙（`LoginWallStyle.accent`）。域语义色（Bangumi 收藏状态 / 条目类型、评分橙、MoviePilot 任务状态点、警告橙、破坏性红）**刻意保留**：它们表达的是数据含义，不是 App 强调色。
  - **关键发现（模拟器 A/B 实测，非推理）：`Color.accentColor` 跟随环境 tint**。用一个最小 SwiftUI 探针（A = 不设 tint，B = `.tint(.blue)`，其余控件树完全相同，同机型同等待）逐像素比，1.273% 像素有差异，正好落在 4 条带上：工具栏按钮（label→蓝）、`Toggle`（**绿 systemGreen → 蓝**）、菜单式 `Picker` 取值（**灰 secondary → 蓝**）、`.bordered` 底（中性→蓝）；第二页只有圆形不定 `ProgressView`（灰→蓝，0.038%）。也就是说上一版为「把强调色钉回去」加的 `.tabContentAccent()`（钉 `Color.blue`）**并不等于「没设 tint」**，它顺带改了五类控件的颜色——而上一版 CHANGELOG 里「内容侧逐像素完全相同」只验了详情页，详情页恰好没有开关 / 取值 / 转圈。
  - **两处必须显式修的坑（系统不会自动处理）**：tint 变 `.primary` 之后，`.buttonStyle(.borderedProminent)` 与自绘 `.fill(Color.accentColor)` 的**实底会变白而标签还是白**——模拟器实测整颗按钮糊成一颗看不见文字的白色胶囊。所以新增 `AppDesignKit.AppAccent`（`solid` = `.primary`，`onSolid` = 其反色：深色取 `systemBackground` / `windowBackgroundColor`，浅色反之）与 `View.neutralProminentButton()`，替掉 7 处裸的 `.borderedProminent`；详情页播放键、每日放送 / Bangumi 搜索的选中 chip、剧集卡「已看」角标、HUD 迷你开关也一并改成「实底 + 反色字 / 反色点」。反色不是猜的：`AppAccentTests`（新增 3 条，`ImageRenderer` 真渲染）在深 / 浅外观下量文字与底的对比度、要求 ≥ 4.5:1，**把 `onSolid` 改回白色实测失败**（深色下 1.43:1），证明这条用例真的拦得住。
  - **顺带删掉上一版那套「钉回去」机制**：`TabContentAccent` / `.tabContentAccent()` 及其「新增 Tab 必须记得补一句」的约束全部撤除；`compactTabs` 与 `compactLayout` 的 `TabView` 也不再各自钉 tint。根节点钉一次之后，标签栏与内容侧是同一个来源，不存在「污染后再钉回来」。**为什么不能把 tint 还原成「未设置」**：`\.tint` 在 SDK 里是 `package` 保护级，`.environment(\.tint, nil)` 编译不过（实测报 `'tint' is inaccessible due to 'package' protection level`），所以只能换成一个明确的值。
  - **开关（`Toggle`）必须单独配一个轨道色，`primary` 对它是不可用的值**（用户实机验收时发现：「开的时候变成全白了」）。开关的圆点在两种外观下都是白的，而 `.tint(.primary)` 让**开态轨道也是白的**——模拟器逐行取样实测：深色模式下**开态与关态都是 `rgb(255,255,255)`**，即整颗开关糊成一颗纯白胶囊，圆点与开关状态一起消失（比"圆点会融进轨道"更严重，是两态都读不出来）。修法：新增 `AppAccent.switchTrack = Color.primary.opacity(0.30)` 与 `View.neutralSwitch()`，给全仓 **15 处 `Toggle`** 逐个挂上（这些开关没有共用的行组件，只能落在调用点——`neutralSwitch()` 的文档注释里写明了"新增开关别忘"）。**0.30 是量出来的折中**：拿 5 个候选（`.primary` / `primary@0.30` / `@0.45` / `@0.60` / `.gray`）在深、浅两种外观下逐行取样，圆点恒为白——`.primary` 差值 **0**（不可用）、`@0.60` 深色下只剩 66（圆点发糊）、`@0.45` 深色下 91、`@0.30` 深色 115 / 浅色 117（两态最均衡），`.gray` 与它数值几乎相同但取值不跟随前景色。落地后复测：深色轨道 `rgb(149,149,156)` lum149 vs 圆点 255（差 **106**），浅色轨道 `rgb(130,128,128)` lum128 vs 圆点 255（差 **127**）。
    - **两个平台都挂这一句**。本仓的 `Toggle` 全部落在 `NavigationStack + Form` 里（设置 10 个子页 + MoviePilot 订阅 sheet），**macOS 在这个上下文下渲染的是开关而不是复选框**（macOS 真实「设置 → 播放」页实拍确认：灰轨道 + 白圆点）；而**裸 `Form` 的探针会渲染成复选框**——那是探针上下文与 App 不同，第一版据此加了「仅 iOS」守卫，是错的，已撤。macOS 侧另有 `toggleStyle(.switch)` 的对照探针：`.tint(.primary)` 下是浅色近白轨道，`primary@0.30` 是灰轨道 + 白圆点，与 iOS 结论一致。
  - **验证**：iPhone 17 Pro / iOS 26.3 模拟器逐屏实拍核对（深 / 浅两种外观都拍）——详情页播放键填充 `rgb(0,145,255)` → `rgb(255,255,255)`、其上文字 `rgb(255,255,255)` → `rgb(0,0,0)`（两者像素数完全对得上：14947 / 3736，是同一颗按钮的纯反色）；设置播放页 `Picker` 取值文本与 `Toggle` 轨道上的系统蓝（`rgb(0,145,255)`）清零、开关圆点重新可见；首页工具栏「打开 / 刷新」由蓝变中性；每日放送选中日 chip 变成白底黑字、未选中仍是灰底；MoviePilot 未配置页的「去设置」白底黑字可读。`Packages/AppDesignKit` **116**（113 → +3）全绿、iOS 模拟器 **574 全绿**（0 失败 0 跳过，与改动前同数）、macOS scheme 编译通过。

- **iPhone / iPad 的 Tab 选中色不再是系统蓝，改成与 macOS 顶栏药丸同一套「中性选中」**（用户口径：默认蓝色太丑，要跟 macOS 选中时一样；附了一张效果参考图）。macOS 那套选中态从一开始就只靠**前景色亮暗**区分（选中 `.primary` / 未选中 `.secondary`，不画强调色底，见 `AppShellSectionGroup.segmentBackground`），而 iOS 的 `TabView` 选中项吃环境 tint，本 App 没有 AccentColor 资源，解出来就是系统蓝。现在给 `TabView` 钉 `.tint(Color.primary)`：选中项变白（深色）/ 近黑（浅色），**系统自带的玻璃选中底保留**——iOS 26 悬浮玻璃标签栏那个高亮胶囊才是「选中」的指示，色相不再承担这个职责。
  - **真正的坑：`.tint` 是环境值，而且 `Color.accentColor` 也跟着它走**。第一版只加了 `.tint(Color.primary)`，结果详情页那颗 `compactPlayButton`（`.fill(Color.accentColor)`）整颗渲染成白色、`.foregroundStyle(.tint)` 的「展开全文」同样变白——**全 App 的强调色被一起洗掉了**。逐像素 A/B（同机型、同深链、同等待时间）量到：`.fill(Color.accentColor)` 从 `rgb(0,145,255)` 变成 `rgb(255,255,255)`。
  - **修法：每个 Tab 根页把强调色钉回去，但必须是具体色值**。`.tint(Color.accentColor)` 在这里是**自我指涉**——求值发生在 TabView 内部，拿到的正是被污染后的 `.primary`，等于没钉（第一版就是这么写的，白改一轮）。改用 `Color.blue`：资源目录里没有 AccentColor，改动前 `.tint` / `Color.accentColor` 解出来的就是系统默认强调色（systemBlue），与 `Color.blue` 逐值相同。修饰符挂在 `NavigationStack` **外面**，连导航栏 chrome 与 push 进来的路由页一起覆盖。
  - **试过并否掉的一条路**：`UITabBar.appearance().tintColor = .label`（早于 iOS 26 的标准做法）。实测 iOS 26 的玻璃标签栏不认 appearance 代理——选中项依旧是系统蓝（A/B 逐像素相同），所以没走 UIKit。
  - **新增 Tab 时必须补 `.tabContentAccent()`**：`compactTabs` 的文档注释里写明了。漏了不会编译报错，只会让那个 Tab 里的强调色元素悄悄变白/黑。
  - **验证**（Debug 构建 + 模拟器实拍，非推理）：iPhone 17 Pro / iOS 26.3 深色，选中「首页」的图标 `rgb(37,174,251)` → `rgb(249,239,239)`，未选中三项逐像素不变；iPad Pro 13-inch (M5) / iOS 26.3 浅色，选中「首页」文字 `rgb(0,107,240)` → `rgb(18,20,39)`。**回溯性检验**：详情页整图 A/B 与改动前逐像素比对，差异只落在「被选中的那一个 Tab 项」与状态栏时钟（`0.22%` 像素），内容侧**完全相同**——播放键 `rgb(0,145,255)`、「展开全文」`rgb(98,145,255)` 一字不差。搜索 Tab（`role: .search`）选中时展开成搜索框的那一态也是中性的。iOS 模拟器 **574 全绿**（= `OcPlayerTests-iOS` 声明数，未增减用例），macOS scheme 编译通过。
  - **未做**：自定义 Tab 栏。参考图里那套「胶囊 + 玻璃高亮」就是 iOS 26 原生标签栏本来的样子，差别只在选中色，没有必要自己画一个（自绘会丢掉系统的最小化、搜索框展开、iPad 尺寸类适配与无障碍）。

- **登录页换成「海报墙 + 毛玻璃卡片」**（用户口径：拿默认工作区里那个 `poster-wall-login` 演示改我们的登录界面）。演示（Cineframe）是一面**静态**番剧海报墙 + 居中毛玻璃登录卡，鼠标移动时整面墙 3D 倾斜；本仓只搬它的**视觉语言**，**流程一个字没动**——服务器地址、HTTP/HTTPS 协议选择、「可以不打前缀」提示、Quick Connect 配对码三态、账号密码兜底、已保存服务器列表（含「需重新登录」与「已固定」两种副标题）、「先不登录，直接用播放器」、错误行，全部照旧，字段 / 按钮 / 状态 / 动作逐条对齐。
  - **墙上的图 = 你自己的媒体库海报，且完全离线**。条目身份取自元数据缓存（`MetadataStore.posterCandidates`：电影 / 剧集且有 `primaryImageTag`），字节取自本机图片缓存；两条路径都**不需要会话、不发网络请求**，所以登录页在断网、服务器不可达时照样是完整一面墙。
  - **为什么不能「扫缓存目录挑竖版文件」**（第一版就是这么做的，实测推翻）：图片缓存里同时存着**演员头像**（`/Items/{personId}/Images/Primary`）与条目海报，两者都是 2:3 竖图，按宽高比根本分不开——本机 429 张竖图里最大的两档尺寸 **342×513（101 张）与 240×360（65 张）几乎全是演员头像**，扫出来的墙是「一墙陌生人的脸」。也试过按饱和度区分：分布是连续谱（0.048…0.773，四分位 0.191 / 0.269 / 0.383），没有可用阈值。结论是**摆哪些图必须由条目身份决定**，不能由图片外观决定。
  - **没有 token 也能命中缓存键**（这是本改动的关键难点）。图片缓存键里含一个由 `DeviceId + Token` 派生的身份哈希（`ImageCacheKey.authIdentity`），而登录页出现的时机恰恰是「刚退出登录」或「token 刚过期」——这两条路径**都会把 token 删掉**（`ServerStore.signOut(id:)` → `tokens.delete`）。所以会话还在时（`AppModel.activate`，唯一的会话落地点）把那个哈希记进新的 `ImageCacheIdentityStore`，登录页接着用：**登出不会让磁盘上的字节消失**，只是需要有人记得它们的键长什么样。存的是不可逆的 12 位哈希，而它本来就是磁盘缓存文件名的一部分，没有引入新的敏感信息。为让「按认证头写、按身份读」指向同一个键，`ImagePipeline.requestKey` 收敛成**一份**实现（`_auth` 查询项与键中段共用同一个身份）；`ServerProfile.imageURL` 与 `EmbySession` 共用新提取的 `ServerURLBuilder`，避免两处拼接漂移后墙静默变空。
  - **倾斜**：macOS 用 `NSTrackingArea`（`hitTest` 返回 nil，不挡登录卡的点击）驱动 `rotation3DEffect` 双轴 + 整体位移/缩放；**iOS 刻意不做**——没有指针，加一条只在晃动手机时才看得见的动效，收益远小于传感器订阅与耗电，所以 iOS 上墙是静态的。`accessibilityReduceMotion` 打开时墙完全静止（有像素级用例钉住）。**列级视差本轮删掉了**（原实现让每一列各自偏移，读出来是景深）：它是整页最贵的一样东西，实测单它一项就占指针移动时 CPU 的 **26 个百分点**，而墙改成「一张合成图」之后列级偏移在结构上也不再可能——景深交给整墙的 3D 倾斜表达。
  - **性能：墙是「一张合成图 + 一次变换」，指针移动时 43.7% → 9～11% 的一个核**（空闲 0.0%）。改前指针一动就要把一百多个 tile 视图的 display list 整个重新生成、再把整窗重新合成一遍——`sample` 里近四分之一的主线程时间花在 `-[RBLayer display]` → `RootTexture::make_texture` → `SurfacePool::wait_image_queue` 的 `usleep` 上（产帧快过显示器，在等 surface）。三处结构问题，逐个用同一套悬停基准量过（`top` 取 9 秒 CPU 时间差，同一窗口、同一扫动轨迹、同一 8 秒 hover）：
    - **① 指针状态原本挂在登录页上**——`pointer` 是 `OnboardingView` 的 `@State`，于是鼠标每动一次**整页**都重新求值，包括右边那张卡片、以及卡片里那个 `NSViewRepresentable` 的 HTTP/HTTPS 分段控件（`sample` 里能直接看到 `updateNSView` 与 `_layoutSubtreeWithOldSize:` 各占一截）。挪进只包住墙的 `LoginWallBackdrop` 之后，指针的作废范围就只到墙为止。**这条是第一轮**（只做了它，43.7% → 45%，几乎没动）。
    - **② 列级视差独占 26 个百分点**（43.7% → 17.4%，单独关掉它）——每列各带一个跟着指针走的 `.offset`，而它在**布局层**改变，于是 9 列每帧都要重新布局重画；给列内容套 `drawingGroup()` 反而**更糟**（32.3%），因为偏移变化会把那张纹理也带着逐帧重画。删掉。
    - **③ 一百多个 tile 各自成层**——每个 tile 都有自己的圆角、描边、阴影，未命中真海报时还多三团径向渐变加一个 `plusLighter` 混合。改成**合成成一张位图**：新增 `LoginWallRasterizer`，把整面墙 `ImageRenderer` 成**一张**图（底色烘进去所以不透明；长边按 4096px 预算封顶），每帧要动的只剩这张图的 `rotation3DEffect` + `offset` + `scaleEffect`。**最终 9.2% / 11.2%**（同一基准跑两遍；逐秒读数 8–20%，空闲 0.0%）——这个基准本身有 ±2 个百分点左右的噪声，所以下面每条 A/B 只认量级差别。
    - 顺带把**加载**也变成一次：原来每个 tile 各自去取图、各自解码（同一张海报在大窗口里合法地出现多次，就解码多次），现在先按 `poster.id` 去重、只解墙上真正用到的那几十张。`LoginWallImageStore` 的解码也从继承主 actor 的 `Task` 改成 `Task.detached`——`decodeCachedFile` 里那次 `Data(contentsOf:)` 是**同步读盘**，落在主线程上正好卡首帧。
    - **A/B 的另一半（都留着）**：`.ultraThinMaterial`（43.9%）与胶片颗粒（44.3%）在基准噪声内**不花钱**；把指针上报合并到显示器刷新率也拿不到收益（11.4% vs 10.9%，反而略差），所以**没做**——少一层延迟。
    - 墙本身仍然**没有任何东西跑在时钟上**：没有 `TimelineView`、没有 `repeatForever`、没有跑马灯。窗口拖拽会连续改变视口，所以合成图在视口稳定 120ms 后才重画，这期间显示上一张被拉到新尺寸。演示里的两团氛围色晕与卡片光晕用 `CABasicAnimation` 缓慢漂移（理由与本仓既有判例一致：SwiftUI 的 `repeatForever` 会让整个窗口每帧重新 diff），但**本轮改成静态渐变合成**：漂移幅度只有 ±26pt、周期 23 秒，压过遮罩后几乎看不出来，而代价是一整套 AppKit / UIKit 分叉（`wantsLayer`、`layer` 的可选性、`alphaComponent`、`layout()` vs `layoutSubviews()`）。静态合成在两个平台上都完全不花 CPU，视觉差别可以忽略。
  - **遮罩档位是看着真海报调的**，不是照抄演示值：演示的强度是配它自己那批封面的，直接套在本机媒体库海报上会把墙压成一片黑。实测对照后定成**夜间 0.72 / 日间 0.32**（日间是白纱，同强度会洗成灰雾）。两种外观都保留，没有强制夜间。
  - **「一个 token 一个缓存」——缓存身份改用账号，不再用凭证**（本轮实测发现并修掉；与上面的改版无关，是既有缺陷）。
    - **症状**：登录页上 47 张海报全变成程序化封面，而 `MetadataStore.posterCandidates` 照样给出 47 个候选。逐字节复算缓存键（`FNV1a` 文件名）后确认——**当前身份命中 0/47，历史身份命中 47/47**，字节一张没少地躺在磁盘上。
    - **根因**：缓存身份由 `DeviceId + Token` 派生（`ImageCacheKey.authIdentity`），而 `Token` **不是账号**——服务端每次重新登录都会发一个新 token（同一账号、同一份可见范围）。于是每登录一次：全部缓存键跟着变 → 墙整面变空 → 同一批图片被重新下载、另存一份。本机 URL 缓存里翻出过 **7 个**身份（`b484f14daf8d` 1264 条、`ceb97745c31d` 212、`fb0a472edd66` 104、`77ed78fcc9c0` 76、`65467bb5cd08` 4 …），512MB 的图片缓存被切成七份、每份都更早被淘汰。
    - **反证**：正常启动（带凭据、恢复会话、进首页）前后逐字段比对 `credentials.json` 与身份历史，**一个字节都没变**；登录页那 2 个新身份是本轮反复「无凭据启动 → 走登录流程」测出来的。也就是说 token 只在**真正重新登录**时才换，而这个动作本身完全正常——不该拿它当缓存身份。
    - **修法（根因）**：身份改成 `DeviceId + UserId`。`UserId` 才是账号的稳定标识：换账号会变（正确——那是另一份可见范围），重新登录 / token 轮换**不再**变，升级版本与换地址一如既往不影响。账号随认证头走——`ClientIdentity.authorizationHeader` 多一个 `UserId="…"` 字段（服务端按键取值、不认识就忽略），于是**所有发头的地方自动带上它**，读写两条路径不可能各算一个键（这一点是刻意的：早先 `requestKey` 收敛成一份实现，正是为了防这种分裂）。老的头没有 `UserId`，所以退化路径**逐字保留**改动前的算法，改动前写下的键仍能原样算出来。
    - **修法（历史）**：身份改成记**一串**（最近在前、去重、上限 8），复原键时逐个试；首次运行**只读地扫一遍 `URLCache`** 把历史身份捞回来——那个库的键就是带 `_auth=<身份>` 的规范化 URL（见 `ImageCacheKey.canonicalURL`），是「这批字节当初是用哪个身份写进去的」唯一的现存证据。扫的是文件字节而不是用 SQLite 打开它（`Cache.db` 正被系统 URLCache 持有、schema 是私有格式），读不出来就当没扫到：它是**提示**不是依赖。登录页因此仍然认得出全部旧字节。
    - **代价（如实说明）**：`UserId` 是新身份，而 App 自身的图片加载路径不查身份历史，所以**升级后第一次浏览会把图片重新下一遍**（一次性）。登录页那面墙不受影响（它走身份历史）。旧命名空间里的字节留在磁盘上等 LRU 淘汰，想立刻腾地方可以在设置里清一次图片缓存。
  - **验证**：`Packages/AppDesignKit` **112**（81 → +31）、`Packages/JellyfinKit` **199**（193 → +6）、`Packages/MetadataKit` **212**（159 XCTest + 53 swift-testing，205 → +7）、macOS scheme **551 通过 + 17 跳过 / 0 失败**（568 条）、iOS 模拟器（iPhone 17 Pro / iOS 26.3）**574 全绿**（含 `LoginWallCatalogLoaderTests` **17** 条）。其中三条是**像素级**的，用 `ImageRenderer` 真渲染后量：墙有可见明暗结构（亮度极差 > 40）、指针移动后 **>10%** 像素变化（倾斜真的生效）、关掉动效后两个指针位置**逐像素相同**。另有三条钉**合成图那条路径本身**（整面墙能出一张不空的位图、尺寸等于墙画布 × scale、长边受 4096px 预算约束、空库返回 nil 不画空图）。另有 8 条把两条算键入口对起来（按认证头写入、按缓存身份读出必须指到同一个文件），以及「换身份 / 换 `maxPixelSize` / 换 `maxWidth` / 换 `tag` 都查不到」——这几条正是墙会**静默变空**的那些路径。真海报路径另用本机缓存端到端复核过：47 个有主图的条目**全部**复原出缓存文件（`maxWidth=400 / maxPixelSize=400` 一档覆盖 45 个）。
  - **未做**：演示里的「记住我 / 忘记密码 / 通过 Apple 继续 / 立即注册」是虚构功能的占位，本仓没有对应能力，没有搬；墙上的标题与年份只进了无障碍标签与程序化封面（真海报不显示文字），因为缓存文件名是键的哈希、反推不回条目名。

- **拼写统一：用户可见的「TMDb」改成官方的「TMDB」**。TMDb 的官方品牌拼写是 **TMDB**（全大写），而本仓的界面文案、日志与文档一直写作「TMDb」——只有 2026-10-13 新加的 TMDb 署名用的是官方原文（`This product uses the TMDB API…`），于是同一个页面上两种拼法并存。本轮把**用户能看见的两类位置**统一到官方拼写：
  - **① 界面文案与运行时字符串**（错误提示、设置项标题、开关说明、备份摘要、日志文本与日志 `category`）。日志 `category` 一并改是因为它会出现在用户导出的诊断日志里（`diagnostics-*.jsonl` 的 `category` 字段），界面说 TMDB、日志说 TMDb 会很怪；已确认它**不参与文件路径**（`fileURL` 由会话文件名决定），也没有任何测试或脚本按它过滤。
  - **② 注释与文档**（`Docs/DEVELOPMENT.md`、`README.md`）。
  - **刻意不动的两类**：**Swift 标识符**（`TMDbClient` / `TMDbCoordinator` / `preferTMDb` / `TMDbEntityKey` … 共 42 个类型名、650 处引用、12 个文件名，含 `MetadataKit` 的 public API）——用户永远看不到，改动换来 846 处 churn + 文件重命名 + 破坏性公共 API 变更，收益接近零，要改应当单开一个纯重构 PR；以及 **CHANGELOG 的历史条目**（那是当时的记录，不该被追溯修改）。
  - **实施口径**：只替换**独立词** `(?<![A-Za-z0-9_])TMDb(?![A-Za-z0-9_])`，且**只在字符串字面量与注释区域内**替换——这是这个改动最容易翻车的地方：`preferTMDb` / `refreshTMDb` / `hasTMDb` / `targetTMDb` 这类 **camelCase 标识符是以 TMDb 结尾的**，用朴素的 `TMDb` → `TMDB` 全局替换会把它们改成 `preferTMDB`，直接编译不过（第一版的正则只检查了「后面不是标识符字符」，漏了「前面也不能是」，实测因此把 99 处代码位置误判成可改）。改完逐个核对 24 个标识符的出现次数与 HEAD 完全一致（见下）。
  - **验证**（rebase 到含设置页改动的最新 `main` 之后）：macOS scheme **533 通过 + 17 跳过**、iOS 模拟器 **557** 全绿（= `AppTests` 声明数）、`Packages/MetadataKit` **159**、`Packages/AppDesignKit` **81** 全绿。**用例声明数逐个相符**（`AppTests` 557 → 557、`MetadataKit` 205、`AppDesignKit` 81、`JellyfinKit` 193）——纯文本改动不该增减用例，这条正是用来证明没有误删；**24 个标识符出现次数逐个相等**（脚本核对，含 `preferTMDb` 80 / `TMDbLink` 87 / `TMDbCoordinator` 71 / `refreshTMDb` 11 / `hasTMDb` 5 / `targetTMDb` 18），证明没有把 camelCase 标识符改坏。
  - **rebase 时补改的 21 处**：设置页那个 PR 先合入 `main`，它**新增的文件**（`SettingsHub` / `SettingsView` 的页脚署名 / 两个新测试文件 / `SettingsRow` 与 `SettingsMetrics` 的注释）里有 21 处 prose 用的还是「TMDb」——这些文件在本分支创建时还不存在，所以 rebase 后才扫得到（同一套脚本按同一口径补改，标识符同样未受影响）。两处合并冲突（`CHANGELOG.md` 与 `SettingsPagesTMDb.swift`）按「**取 `main` 的结构 + 本 PR 的拼写**」解：那一轮把 `Text(` 重构成 `SettingsNote(`、把 `Section("x")` 拆成 `header/footer`，与本 PR 改同一行的字符串重叠，但无语义冲突。
  - **未做**：标识符层面的重命名（见上，建议单独 PR）；`CHANGELOG` 历史条目；`.zcode/plans/` 下的本地草稿（已被 `.gitignore` 忽略，不入库）。

- **设置界面「向 Rex 靠」：分段卡 + 呼吸感行高 + 单色图标**（用户拿对照产品 Rex 的设置页截图给的口径是「我们的就显得很粗糙」）。**先把两张截图逐像素量了一遍再动手**（Rex 602×1308 按 401pt 逻辑宽折算 1.5 px/pt、我们 359×782 按 402pt 折算 0.893 px/pt，两边另用「占屏宽百分比」交叉核对过），量出来的差异只有四处——**而字号 / 文字 leading / 图标-文字间距 / 分隔线对齐这四项本来就一致**，所以问题不在排版塌了：
  - **① 主因是「根本没有卡」**。`settingsRowBackground()` 把行底设成 `Color.clear`（当时的理由是 material / glassEffect 自带模式色纱、跟 `.home` 遮罩叠出来是死白），于是行直接压在模糊氛围图上、分段只剩空气；而 Rex 的卡实测是页面 lum 49.7 → 卡内 71.6（Δ≈22，反解 `白 ≈10%`）。改成**半透明纯色叠加**（`SettingsCardFill`，纯色没有那层纱，于是「有卡片边界」与「氛围图仍透出来」同时成立），入口改名 `settingsCard()`。**保持 `Form` + `Section` 结构不动**：`insetGrouped` 的段背景本来就是连续的，逐行铺同一个半透明色就是一张整卡，圆角与首尾行形状由系统给——iOS 26 的段圆角比上一代更大，自绘只会跟它打架。
    - **亮色档从 0.75 降到 0.30（装到真机后的第二轮反馈）**。用户看到实机后给的口径是「夜间模式的效果可以，白天模式的时候跟 bangumi 那边的透明度差距有点大，设置页的已经变成白底实心了。人家 rex 也是做成的玻璃状态的」。量化确认：把**同一块**合成氛围底在**同一采样区**「盖卡 / 不盖卡」两次渲染相除（不能拿卡外当分母——氛围底是斜向渐变，那样会把「那个位置的底色本来就不饱和」误算成「卡底洗掉了颜色」，第一版就是这么得到 >1 的假读数的），亮色 0.75 只让 **26%** 的彩色透过来（用户说的「白底实心」就是它），而用户认可的暗色 0.10 是 **90%**。降到 0.30 后是 **70%**，与暗色同档。**关键事实：亮色下「加白换边界」极不划算**——亮色页面底色已被 `.home` 遮罩压到接近白（实测 lum 212/255），把 0.75 降到 0.30，**边缘阶跃只从 +15 掉到 +13（几乎无损），透出度却从 0.26 涨到 0.70**。所以边界交给系统那套段结构表达就够了。
    - **为什么不用 material / glassEffect**（这一轮把数据补齐了）：两者都**降低**透出度——亮色下 `ultraThinMaterial` / `thinMaterial` 只有 0.50、`regularMaterial` 与 `glassEffect(.regular)` 只有 0.37，**比「白 0.30」的 0.70 更不透明**（本仓早先记过这笔：material 自带一层模式色纱）。而它们唯一能提供的**模糊**在这里是多余的：衬底的氛围图**本身已被 `BackdropAmbienceView` 模糊过**（radius 14–20 + scale 1.12），再糊一层肉眼看不出差别，只剩那层纱的代价。Rex 的「玻璃感」也是纯半透明叠加、没有模糊——观感来自**透**，不是来自糊。
  - **② 行距 49.8 → 58pt**（Rex 实测 57.8pt）。**这里踩了一个坑、又补了一个真缺陷，值得记下来**。第一版把 58 直接当 `.frame(minHeight:)` 用，渲染出来是 **88pt**（一屏只剩五行）；用探针把关系量清楚——`.insetGrouped` 的行高 = **内容高 + 系统自带 30pt 内边距**（不设 frame 时内容自然高 22.3 → 行距 52.3；minHeight 58 → 88.0；minHeight 28 → 58.0）。于是第二版取「内容高 28 + 系统内边距 30 = 58」，**行高对了，但独立复核实测出一个真问题：多出来的 30pt 是系统的行内边距、不属于按钮，热区只有 28pt**——「看着 58pt 高、只有中间 28pt 点得着」，而当时那条用例却拿**行距**去断言「满足 44pt 最小点击区」，premise 是错的。**终版**：内容自己占满 **44pt**（HIG 最小点击区，`Button` 的 frame 即热区），同时**由我们自己声明行内边距**（`rowVerticalInset` 7×2）把它压回 58pt 总行距——**44 + 14 = 58 = 28 + 30，行距分毫未动、只是把「系统的内边距」换成了「内容的热区」**。横向照抄系统那档（`rowLeadingInset` 16pt），因为声明 `listRowInsets` 会把横向一起替换（实测照抄后横向逐像素一致）。
  - **③ 图标从系统强调色改成单色**。改前用 `Label(_, systemImage:)`，图标吃的是强调色蓝（截图像素实测 B−R > 40）；Rex 的 glyph 是白色单色**直接坐在卡上、没有色块 tile**（实测：无字形那一列的 lum 77.3 ≈ 卡底 79.0）。所以**不引入彩色圆角 tile**（那是 Apple 自家设置的语言，不是对照对象的），只把色阶固定成 `.primary`，同时给图标一个固定宽列——SF Symbol 宽度随符号差很多（`server.rack` 18pt 下就有 23.5pt 宽），交给 `Label` 自动排版时文字 leading 会跟着漂。
  - **④ 分段从四段改成三段**（服务 / 播放与界面 / 应用）：改前最后一段**没有标题**，只靠留白与前一段分隔，读起来是「两张卡而非一个分组」。TMDb 与网络并进「服务」（前者是第三方服务集成、后者服务整条服务端链路；对照产品的「反向代理」同样在「服务」下），原「网络与元数据」段本来只为两行存在、段标题比内容还长。**分组表落成数据**（新 `SettingsHub.groups`）：改前是四个手写 `Section {}`，「新增子页忘了挂 hub」没有任何东西拦得住——而 hub 是**唯一入口**，漏挂等于那个子页从产品里消失（子页自己不会报错、氛围契约也照样绿）。`SettingsSubpage` 新增 `symbolName`（与写进脚本的 `routeKey` 刻意分开：一个是给人看的呈现，一个是自动化通道的稳定键）。
  - **⑤ 行图标改用品牌 SVG、Jellyfin 改名「媒体服务器」、页脚补 TMDb 署名**（用户第三轮口径：「设置页的 jellyfin 改成媒体服务器、bangumi 的图标改成和 tabview 一样用 SVG、moviepilot 也一样用 SVG。tmdb 也是。设置最底部加上给你的这张图这个」）。
    - **图标来源抽成 `SettingsRowIconSource`**（`.symbol(name)` / `.brand(name:aspect:)`）：有品牌资产的走品牌图，其余仍是 SF Symbol。Bangumi / MoviePilot **复用 Tab 栏那两份资产**（`bangumi-logo` / `moviepilot-logo`），所以 hub 行与 Tab、以及 macOS 顶栏药丸上看到的是同一张图；TMDb 只有官方彩色字标（`tmdb-logo`）。三个品牌图的**宽高比差 2.7 倍**（0.94 / 0.86 / **2.33**），所以新增纯函数 `SettingsRowIcon.fittedSize(aspect:in:)` 按更紧的一维约束——填错方向的后果是**字标溢出图标列把标题挤走**（TMDb 的 wordmark 若按高约束会算出 42pt 宽，比列宽宽近一倍）。这条有单测（含 0.1…10 的极端比例与非法值）。
    - **「Jellyfin」→「媒体服务器」**：本 App 同时支持 Jellyfin 与 Emby，拿其中一家的名字当整类功能的入口名对 Emby 用户是误导。**`routeKey` 保持 `jellyfin` 不动**（自动化通道与 `verify-ambience.sh` 的 PAGES 表依赖它），有用例同时钉住「显示名改了」与「键没改」。
    - **页脚 TMDb 署名**（`TMDbAttributionFooter`）：官方字标 + 官方那句英文原文 `This product uses the TMDB API but is not endorsed or certified by TMDB.`。**没有直接贴那张截图**——那是 Rex 的截图，紫色背景是它自己的界面底色、被一起烤进了 JPEG，贴到我们的氛围背景上会是一块突兀的方片；所以按它的**内容**重建。字标走 `.renderingMode(.original)` **保持品牌配色**（与详情页「在 TMDB 打开」同一条口径：官方渐变改色等于改品牌标识）；放在**卡片之外**（`listRowBackground(Color.clear)` + 无分隔线），署名是页脚级法务信息，不该长得像一行可点的设置项。用英文原文而非仓里已有的中文译句：条款给的是这一句固定表述，署名以原文最稳妥（那两处中文译句职责不同、保留不动）。
    - **行图标统一单色（用户第四轮口径）**：「把 tmdb 元数据补充的那个 logo 改成和 bangumi、moviepilot 的一样的颜色」。Bangumi / MoviePilot 的 imageset 自带 `template-rendering-intent`，**TMDb 那份没有**（它是官方彩色渐变字标，资产层要保持原样给详情页与页脚署名用）——所以只在 `SettingsRowIcon` 的 `.brand` 分支显式写 `.renderingMode(.template)`，把「行图标必须单色」这条规则收在代码一处，而不是散在三个 `Contents.json` 里（加第四个品牌图时谁也不会记得去改 JSON）。**顺带一个 Swift 细节**：`.renderingMode` 是 `Image` 自己的方法，必须**紧跟 `Image`**——放到 `.resizable()` / `.scaledToFit()` 之后类型已擦成 `some View`，会报 `value of type 'some View' has no member 'renderingMode'`。品牌配色仍保留在它该在的地方：详情页「在 TMDB 打开」与设置页页脚署名走 `.original`。
    - **验证**：新增 `SettingsRowIcon` 的 `fittedSize` 单测（10 条包用例）、`SettingsHubGroupingTests` 扩到 8 条（图标唯一性改为按 `.brand`/`.symbol` 归一比较、三个品牌图比例逐个钉住、「恰好三个品牌图」、显示名与 `routeKey` 的分离）、`SettingsLayoutTests` 新增 `testTMDbAttributionRendersAtPageBottom` 与 `testBrandRowIconsAreMonochrome`（后者用受控 `List` + 中性灰底量**图标框内的通道极差**：真 hub 的卡是半透明的、氛围底色会干扰判定；底固定成中性灰后，框内任何明显色偏都只可能来自图标本身）（拉长到 1400pt 渲染整页，从页脚区间的**最大色度**判断字标在不在——深灰底上「有彩色」就是它，这条同时能抓「被 `.renderingMode(.template)` 洗成单色」）。**反向验证**：摘掉页脚 → 色度 0.0 红；把 `.original` 改成 `.template` → 同样红；把 Bangumi 从品牌图改回 SF Symbol → 比例用例红；**去掉 `.brand` 分支的 `.renderingMode(.template)` → 单色用例红，报出「TMDb 元数据补全」色偏 226**（正是用户指出的那一行）。
  - **顺带把「说明文字」的归属定下来**：`SettingsNote`（解释**某一个**控件，紧贴该控件、不切分隔线、leading 内缩到文字列）vs `Section(footer:)`（解释**整段**，卡片下方的留白里）。改前两者都是裸 `Text` 独立成行，加卡之后会变成「一行说明独占一格、上下都被分隔线切开」的碎感。本轮迁移 20 处到 `SettingsNote`、5 处到段脚（TMDb 3 段、字幕外观 1 段，另一处在「剧集占位」），其余 23 处 `.font(.caption)` 是**行内状态标签 / 复合行内的副标题 / 带图标的 notice**，刻意保留。
  - **未做**：Liquid Glass 卡片（本仓规格要求「用户明确要求才上」）、设置页搜索、图标 tile。**外部调研**（Apple HIG / iOS 26 采纳指南 / 同心圆角 / 多篇实测）落在 `Docs/settings-screen-design-research.md`——那份报告是**实施前**写的，其中「行高用 `.frame(minHeight: 54)`」等三条已被实测推翻，报告开头补了 `⚠️ Correction after implementation` 表，别照抄 §4/§6 的常量。
  - **验证**（逐像素，不是断言常量）：`Packages/AppDesignKit/Tests/.../SettingsRhythmTests` **9 条**（含 `testCardFillStaysTranslucent`——把「卡底必须是玻璃不是实心」钉住；改前那套只断言「亮度差 ≥8」，而白 0.75 的亮度差高达 +48 **轻松通过**，牺牲的恰恰是透明度，这正是它漏掉用户这轮反馈的原因）（令牌与算式 + `ImageRenderer` 量图标列/标题排版 + **图标单色性** + 卡底边界不得成死白）；`AppTests/SettingsLayoutTests` **7 条**把**真 hub** 挂进离屏 `UIWindow`、过一帧 runloop 再 `layer.render`，从像素量：行距 **58±2pt**（实测 58.0）、卡缘距屏缘 **16±2pt**（实测 15.7 / 16.3）、卡内外亮度差 ≥8（深色与**浅色各一条**）、**分隔线起点 69±3pt**（= 卡缘 16 + 行内缩 16 + 图标列 22 + 间距 15，按分量算出来而不是写死），外加 iOS 档位令牌（44 / 7 / 16 / 58）的绝对值；`AppTests/SettingsHubGroupingTests` 6 条（每页在分段表里**恰好一次**、段标题非空且唯一、段序稳定、无空段、图标名非空且互不重复、图标名不撞自动化键——这条当场抓出 `network` 与 `network` 撞名）。
  - **反向验证**（本仓硬规矩，逐条改回缺陷版确认变红再还原）：`settingsCard()` 改回 `Color.clear` → 2 条红（且是**硬失败不是 skip**）；分段表删掉 `.network` → 分组用例红；iOS 内容高改成 0 → iOS 行距用例红；图标改成 `.yellow` → 单色用例红（通道极差 255 ≫ 24）；去掉 `alignmentGuide` → **不红**（实测去掉后分隔线仍在 69pt，iOS 16 起系统本就按首个文字对齐）——所以把那条注释从「关键一行」改成如实说明「导轨与系统默认落点相同、它是把意图写成代码而非当下生效的修复」，并补一条钉**结果**的用例。
  - **独立对抗式复核抓出并已修的四处**（都由我在同一轮内改掉、并各自补了反向验证）：① **假通过**——卡消失时用例抛的是 `XCTSkip`，CI 报 `TEST SUCCEEDED`，改成 `XCTUnwrap` 硬失败；② **热区只有 28pt** 而用例拿行距断言 44pt（见上，已改成 44 + 自声明内边距）；③ **恒真断言**——`separatorLeading == iconColumnWidth + iconLabelSpacing` 是它的定义本身，永不会红（注释却声称「任一分量被改会亮」），改成钉绝对值 37 且两个分量各自钉住；④ **`#if os(iOS)` 的断言在 CI 里从不执行**——包测试只跑在 macOS 上，把 iOS 档位改成 0 时 78 条包用例全绿；现已把 iOS 真值抽成 `iOS*` 常量、断言它们（改坏当场在 macOS 上红），iOS 构建确实用到这几个常量则由模拟器上的 `SettingsLayoutTests` 验。另外补了**亮色模式**的真 `Form` 渲染用例（此前 `.light` 从没传进 `renderHub`，那段 `-light.png` 分支不可达）——它立刻抓出一个**测试脚手架的缺陷**：底图写死深色，亮色下量到的 145 亮度差是脚手架造出来的，底图已改成随外观取。
  - **实跑**：`Packages/AppDesignKit` **81** 用例；macOS scheme **534 通过 + 17 跳过**（8 条既有 iOS 专有版式 + 7 条 `SettingsLayoutTests`，均按 `XCTSkip`）；iOS 模拟器（iPhone 17 Pro）**557** 全绿。（**勘误**：本条初版的 iOS 数写的是 615，那是我把日志里的 `Test Suite` 行也数进去了——`Test Case` 行才是用例数，感谢独立复核指出。）
  - **氛围验收台回归**（这一轮最要紧的闸门——卡底是叠在氛围图上的，必须证明图还透得出来）：iOS（**卡底真正生效的那一端**）连跑 3 轮、`ios.settings` 与 `ios.settings.playback` 每轮都判 `image:2`，**3/3 全绿**，浅色与深色各验过。**macOS 侧要如实说明**：`settingsCard()` / `settingsSectionSpacing()` / `settingsRowInsets()` 在 macOS 上全是 `self`（**卡片改动对 macOS 是 no-op**，原生分组玻璃本就是正确观感），所以 macOS 的读数不构成本次改动的证据；而本机跑 macOS 验收台有一个**既有的时序抖动**——同一份二进制时好时坏（`mac.settings` 4 次里 2 次判 `flat`），失败时截图是**纯白 255,255,255、方差 0.00、63KB**（正常页 1.26MB），即窗口还没画完就截了图；**决定性对照：我完全没碰过的 `mac.home` 同样抖（3 次里 2 次判 `flat`，签名一模一样）**，所以这是验收台/环境的抖动，不是这次 UI 改动带来的回归。报告中「缺背景」的那几次均为未重跑的首次截图，重跑即 `image:2`。
  - **观感与几何另在真机截图上复核**（`Scripts/verify-ambience.sh` 产出的截图，非合成）：行距 58.0、卡缘距屏缘 15.7 / 16.3、分隔线 69.0、图标 B−R 从改前的 >40 降到 6。

- **氛围背景图铺满双端全部界面——把"每页各自垫底"收敛成一个挂载点**。用户问「检查一下现在项目的背景图，是否全部界面都有」——答案是**不是，缺口全在 iOS**：macOS 靠 `AppShellView` 根节点一份常驻整窗层（导航栈宿主透明），任何没画底的页面**自动**就有背景；iOS 的 UIKit 宿主不透明（`WindowAmbience.reachesScreen == false`，栈后垫层到不了屏幕），**每个页面必须自己垫**，而全仓只垫了 7 处。**逐页取证**（新增验收台，见下）：iOS 上搜索 Tab 根页、媒体库网格页、Bangumi 个人页 / 收藏列表 / 条目详情 / 每日放送、设置 10 个子页、管理服务器、开源许可证**一律是系统纯色白底**——截图里最刺眼的一处是媒体库页：整页白底，而底部 Tab 栏玻璃底下**能透出氛围图**（图就在栈根下面，页面自己没画）。**修法不是"再补 11 个调用点"，而是把挂载点从 N 个页面收敛到一个路由出口**——否则下次新增页面照样漏：
  - **① 氛围池所有权上移**（新增 `AppModel+Ambience.swift`，`AmbientBackdropCarousel` 退化为纯渲染）。池子原先住在首页那个视图的 `@State` 里、而该视图只挂在首页 Tab 内，于是**冷启动直奔别的 Tab / 进设置子页时池子从未装载**，`homeAmbience` 恒 nil，那些页面整个会话都停在纯色底——`fb36f14` 记的是同族病（会话内不再重试），这次修的是更根本的一层：**池子不该属于某一个页面**。现在由 `AppShellView` 根节点的 `.task(id: app.ambienceTrigger)` 单点驱动，与"当前停在哪个分区"解耦。六条既有语义逐条保留并加了用例：拉失败**不记账**（否则触发键稳定下来、这个会话再也不会重试，这正是那条回归的命门）、同代次同地址不重拉、端点多变重拉、首图预热完成才让池子可见、`reduceMotion` 只留静态首图、会话边界连池子一起清（池里 URL 带着旧服务器的 authHeader）。
  - **② 统一入口 `pageAmbience(_:)`**（新增 `DesignSystem/PageAmbience.swift`）。**平台分叉只允许存在于这一个文件里**：macOS 上自带主体图的页面（`ownsArt`）声明整窗层、其余 no-op；iOS 上一律自垫 + 兜底纯色。两条历史判例写进实现约束：必须走 `.background {}`（布局隔离——`fill` 溢出参与布局会把根布局撑大，macOS 侧栏时代实测两回）、iOS 层**不许** `.drawingGroup()`（它把 `ignoresSafeArea` 截断，图到不了 iPad 侧栏玻璃底下，`987f3bc`）。详情页的三处特有语义（底图未就绪先画池子那张、两档淡入、未就绪时声明 nil）**作为参数**走同一入口，不复制渲染代码。
  - **③ 补挂载点**。`appRouteView` 一处加 `.routeAmbience(route)` → 覆盖六类 push 页面（媒体库 / Bangumi 四页 / 10 个设置子页），**新增 `Route` case 自动继承**；搜索 Tab 根页与四个 Tab 根页统一迁到 `pageAmbience`；四个呈现式页（管理服务器 / 开源许可证 / 下载管理 / 资源搜索）各自挂上；`ServersView` / `OpenSourceLicensesView` 补 `.scrollContentBackground(.hidden)` + 逐 Section `settingsRowBackground()`（iOS 的 grouped 行底是系统不透明白，会把氛围图挡死）。**详情页在路由出口显式让路**：它自己的整窗声明在底图未就绪时发的是 nil（"本页暂无氛围"），外层再声明一次会把它盖掉、背景消失。
- **Debug 深链通道 `OCPLAYER_START_ROUTE`：进场即到某个 push 页 / 设置子页 / 呈现式叶子页**（新增 `LaunchRoute.swift` + `AppModel+LaunchRoute.swift`）。本机模拟器只能无头跑（没有 `Simulator.app`，点按导航不可用），而"push 进来的页面"恰恰是这次缺口最集中的地方——没有进场通道就只能靠手点截图，逐页回归每次都付一遍这个成本。语法 `library` / `detail` / `bangumi.profile|calendar|subject.<id>` / `settings.<子页键>[.servers|.licenses]` / `search`（解析是纯函数，非法值返回 nil 而不是静默乱跳）。落地挂在 `AppShellView` 的 `.task` 上（那时布局已定型、`isCompact` 已设定，`push()` 才分派到正确的栈）；呈现式叶子页走"宿主页消费一次性标记"，与手动点击同一条 `pushPresented`。整块在 `#if OCPLAYER_SELFTEST` 内（Release 不编译、不读环境变量），Release 分支保持与现状逐字相同的空实现 API。
- **氛围背景验收台**（新增 `Scripts/verify-ambience.sh` + `Scripts/ambience-probe.swift` + `Docs/AMBIENCE.md`）。这套东西的存在理由是：**"某页有没有背景图"此前只能靠人眼看截图，既不可复现也没法进回归**。判据是"氛围图是彩色照片、纯色页面底是中性色"：取内容左右留白，算**色度中位数** + **亮度方差** + **平均梯度**。三次迭代都是被实跑教育出来的：①**色度单独不够**——浅色模式下被白雾压过的淡氛围图色度只有 4–5，与纯色底分不开；②**方差不够**——模糊图（`lum_std` 2.8–8.4）与文字/控件（45–72）都非零，第一版把前者误判成"区域被内容占据"、报告显示"判不了"；**梯度把它们分开了**（0.26–0.28 vs 7.2–7.9，差一个量级），阈值 1.0 落在空档正中；③**只算横向梯度不够**——灵动岛黑块横向上完全均匀（0.01），改成双向扫描才接住。另有两条**环境陷阱**的处理，都是"环境坏了伪装成被测对象坏了"：**锁屏后 `screencapture` 只给黑图**（实测跑出过"9 页全判缺背景"的假结论，代码一行没改），现在跑前查 `CGSSessionScreenIsLocked` 直接拒绝、截图后再抽检全黑；**固定 `sleep` 截图会截到启动骨架屏**（慢轮次超过等待时长），改成等"会话就绪 + 深链落地标记"出现再截，深链超时记为失败**不判定**（那时截到的大概率是首页，而首页有背景——照判会得到假通过）。覆盖契约（`--list`）是页面 × 平台 × 门控 × 期望的唯一事实源，`Docs/AMBIENCE.md` 是同一份清单的说明版。
  - **验证（三端全绿，逐页可复现）**：macOS **8/8 required 有背景**（含深链进来的媒体库 / 设置子页 / 每日放送 / 详情页）、iPhone 17 Pro **11/11**、iPad Pro 13"（M5）**11/11**；改前基线同一套判据：iOS **6 页判缺背景 + 1 页判不了**（媒体库 / 搜索 / Bangumi 个人 / 设置子页 / 管理服务器 / 开源许可证），macOS 0 缺（与静态分析一致）。**反向验证**：临时短路 `routeAmbience` 的挂载点 → 那三页立刻判**缺背景（exit 1）**，还原后复跑 **有背景（exit 0）**——证明判据不是恒真。测试：macOS scheme **527 用例（519 通过 + 8 条既有 skip）**、iOS 模拟器 **533 用例全绿**；新增 `AmbiencePoolTests` 13 条（失败不记账 / 冷启动抢跑 / 回退源 / 预热先于可见 / 同键不重拉 / 换会话与换址重拉 / reduceMotion / 空池不空转 / 声明不被空池清掉）、`LaunchRouteTests` 8 条（全部语法 + 非法值 + 叶子页挂错宿主判非法 + 子页键稳定唯一且与 `title` 解耦）。**未做**：Emby 服务器侧未逐页复核（判据与平台无关，但会话只连了 Jellyfin）；深色模式只跑了一轮（`iOS 深色` 需要 `simctl ui appearance dark`，本次未纳入）。


- **返回首页不再比进入详情页慢半拍：删掉 pop 侧白等的 0.45s**。两段式换页里 `back()` / `popPresented(_:)` 在落地后一直多睡一拍 `Motion.exitSeconds` 才复位 `routeExiting`，原注释写的是「等系统弹栈过渡走完、离场页真正移除」——实测没有这个过渡，这 0.45s 只把落点页的淡入整体推后半拍。量法两条：①**最小复刻**（`NavigationStack` + `RouteExitFader` + `coveredPageHidden` + `beginRouteExit` 逐行同源，覆盖 push/pop 与呈现式两条链）录屏逐帧取探针区帧均色（2560×1440、~40–60fps）：push 淡出 0.45s → 空窗 0.20s → 淡入 0.45s（≈1.0s），pop 线上 0.45s → **空窗 0.60s** → 0.45s（≈1.5s），把多等的那拍去掉后 pop 空窗回到 0.20s（≈1.1s）且全程无离场页残影；②**生命周期探针**量「离场页什么时候真没了」：弹栈落地 → 离场页 `onDisappear` 仅差 **9ms**、呈现式关闭仅差 **19ms**——落地本身是硬切（与 `7fd9e06` 起 CHANGELOG 记的「等 0.45s 再硬关」一致），没有任何东西需要遮。修法：`back()` / `popPresented(_:)` 去掉 `restoreDelay`，`beginRouteExit` 随之删掉这个已无调用方的参数；现在两个方向同拍：淡出 0.45s → 落地 → 0.05s 前置帧 → 淡入 0.45s，回到 `7fd9e06` 设计口径的「空底谷 ~0.95s」。验证：macOS Debug 与 iOS（模拟器，无签名）构建均通过，macOS scheme 全量 **481** 用例（473 通过 + 8 条 iOS 专有版式按 `XCTSkip`）全绿。
- **详情页向 Senplay / Rex 的「秒开」看齐：列表请求带全字段 + 点击预取 + item∥季并行 + 快照 TTL**（用户问「为什么他们点开详情页这么流畅，我们的却要重新加载」——答案是三样我们都没有：列表字段给得太少、点击前无预取、在线时永远重发。四块改动各自独立、互为保险）：
  - **列表接口带全字段**（`JellyfinKit` 两端）。首页四条 rail（latest / favorite / resume / nextUp）与库页 `itemsPage`（合集成员走它）的 `fields` 从只有 `PrimaryImageAspectRatio`（itemsPage 加 `ProviderIds`）扩成统一常量 `MediaListFields.items` = `Overview,Genres,CommunityRating,OfficialRating,PrimaryImageAspectRatio,ProviderIds`——此前列表条目只有标题和图 tag，点进详情页首屏全靠 `/Items/{id}` 二次请求。**实现上有个 SDK 缺口**：Jellyfin 官方 SDK 的 `ItemFields` 枚举没有 `CommunityRating` / `OfficialRating` 两个 case（官方 openapi 生成漏了），而 `GetItemsQuery.fields` 是 `[ItemFields]?` 塞不进字符串，所以这五处改走「SDK 类型化参数照旧、`fields: nil` 让 SDK 不生成该 key、再往 `Request.query`（public var）手动 append 全量字段串」——既有 `item(id:)` 手拼 fields 的先例证明这条路稳。**刻意不带 `People`**：演员表是列表 payload 大头（每条十几人），而演员区不是首屏关键，由预取在点击瞬间拉完整详情补上，晚一两百毫秒无感；`ProviderIds` 只是小字典且库级批量 TMDb 补全靠它。映射层**零改动**（`ServerItemFields` → `MediaItem` 的槽位早就在，纯加 fields 即生效）；不引入 Taglines / Studios（域模型没槽位，详情页也没用）。Emby 侧同口径（过 `embySafeFields`，新字段名两家都认）。验证：`JellyfinServerTests` 在 latest / favorite / resume / 合集成员四条既有用例里补 `query["fields"] == MediaListFields.items` 断言（此前**没有任何**列表 fields 断言）、`EmbyServerTests` 补两条，`Packages/JellyfinKit` **192 用例全绿**。
  - **点击预取**（新增 `AppModel+DetailPrefetch.swift`）。全部详情入口（首页三条 rail、搜索、库页、合集成员、相似推荐、`openSeriesDetail` 的三个内部出口）都收敛在 `openDetail(_:)` 一处——预取钩子放这里，一处全覆盖：push 转场动画开始的同时发请求（比进页早约一个转场的时长），item 与季**并行**、随后按共享的默认季逻辑（见下）拉该季分集，落地写进 `detailSnapshots`。合集带第一页成员、电影只发 item 一发。in-flight 按条目 id 去重（连点不重发）；失败与取消一律静默——预取只是加速，永远不能变成新的失败源，进页 `load()` 的正常路径兜底重试；会话清空（`clearDetailSnapshots`）一并取消在途任务。图片预热同链同参：`imageTarget(.backdrop, 800)` + 512 解码调 `ImagePipeline.load`，与进页后 `prewarmAmbience` 的服务端一路完全同参（同 URL 直接短路），TMDb 回落那一路留给进页后补。`load()` 开头会等在途预取落地再读快照（通常点击到进页不足一秒），省掉与预取并发的一轮重复请求；预取没赶上时多付一次幂等 GET，无正确性问题。
  - **快照 TTL 短路**（`AppModel.DetailSnapshot` 新增 `fetchedAt`，`detailSnapshotTTL` = 5 分钟）。原先的 SWR 快照只兜「离线 / 刷新失败」——在线时 item/季/推荐**每次进页照发**，第二次进同一部剧并不比第一次快。现在 `load()` 对 TTL 内的内存快照**整页原位渲染、零请求直接返回**（TMDb overlay 照读本地缓存，refresh 有自己的过期策略）；过 TTL 走既有 SWR 刷新，语义不变。**磁盘快照不参与 TTL**（`loadFromDisk` 构造时 `fetchedAt` 置 `.distantPast`）：它是「上一次会话写穿的」，写穿时刻可能几秒前也可能几天前，而 TTL 的收益只在本会话内——为那点收益放过磁盘旧数据不值，磁盘来源一律 SWR 网络确认（这条语义由 `MetadataCacheIntegrationTests.testDetailPrefersNetworkOverCache` 钉住；首轮实现曾让磁盘快照带 SQLite 写入时间，全量跑暴露 5 条集成用例红——磁盘数据刚写穿即被 TTL 短路——才改成现在的口径）。本地写回（播放返回的 `applyPlayState` / `reloadAfterPlayback`）会重新 storeSnapshot、刷新时间戳，即续期 TTL。验证：新增 `DetailSnapshotTTLTests` 3 条（TTL 内零网络且快照状态整页恢复 / 过 TTL 照常网络刷新 / 本地写回续期时间戳）。
  - **`load()` 串行砍半**。原先 item 回来 → 确认 `kind == .series` → 发季 → 落地才有 `selectedSeasonID` → 发集，**三跳串行**；现在季请求只依赖 seriesID，`shown.kind`（列表条目 / SWR 快照都带着 kind）预判为 series 时 `async let` 与 item 并行，预判失误（极罕见）在详情落地后按详情 kind 补拉兜底。季失败**不连累详情**：详情先上屏、季区空着、错误并入 failure（与原串行版 catch 语义一致）；取消穿透沿用 `JellyfinError.isCancellation` 统一判据（内部转抛 `CancellationError` 交给外层既有的取消 catch，不误报失败）。
  - **默认季/集逻辑上提**（新增 `AppModel+DetailPrefs.swift`）。`preferredSeasonID` / `preferredEpisodeHint` / `isSpecialsSeason` / `preferredEpisodeID` 从 `DetailViewModel` 的 private 上提到 `AppModel` extension（行为逐字不变，VM 改调共享版）：它们只依赖 `home.resume/nextUp` 与入参，而**预取必须用与进页同一套「会停在哪个季」的判断**——否则预取拉 A 季、进页选 B 季，集列表照样空窗。验证：新增 `DetailPrefetchTests` 5 条（series 一轮拉齐 item+季+集且快照整页就位 / in-flight 去重 / TTL 内快照免预取 / 电影只发 item / 合集带成员页且 `parentID` 正确）。**反向验证**：`detailSnapshotTTL` 改成 0 → `testFreshSnapshotSkipsNetwork` 红（TTL 短路被砍立刻退回全量网络）；摘掉 `openDetail` 里的预取钩子 → 预取 4 条红（免预取那条仍绿，正确——它测的恰是「不发请求」）；均恢复后复跑全绿。实跑：macOS scheme **481 用例**（473 通过 + 8 条 iOS 专有版式按 `XCTSkip`）、`Packages/JellyfinKit` 192 用例全绿。

### 改动

- **多端同步配置：导出成一个文件，经 iCloud 云盘 / 隔空投送搬到另一台设备**（用户的原话是「Mac 上已经设好了 TMDb 的 key，如果能多端同步，我就不用再在 iPad 和 iPhone 上添加了」）。**先定路线再写码**：拿原生 iCloud API（`NSUbiquitousKeyValueStore` / CloudKit / iCloud 文档容器）做「无感后台同步」在本项目**不可行**——那条路要求付费开发者账号 + 正式签名 + 后台注册 iCloud 容器，而本项目发行包统一 ad-hoc 签名、iOS 侧是用户自己重签的未签名 ipa（README「下载」），苹果服务端不会认这个 Team 的容器。所以取「**导出普通文件 → 交给系统文件选择器**」这一侧：用户自己就能存进 iCloud 云盘、或直接隔空投送给手机，零账号门槛、数据始终在用户手里，且双端与侧载安装都成立。**导出内容与三条不导出/不写回的取舍**：①**只搬「用户可搬走」的偏好**——TMDb Key 与语言策略、播放偏好（跳过片头片尾 / 保留秒数 / 字幕语言 / 画质增强 / 预读与回退预算 / 字幕外观）、弹幕偏好（不透明度 / 显示区域 / 屏蔽项 / 字号 / 自动装载）、常规开关（Bangumi / MoviePilot / 首页栏目 / 选集排序）与弹弹play **自定义**网关；②**服务器地址、账号密码、会话 token 一律不进备份**（它们跟着服务器走而不是跟着用户，且泄露面太大），**备份里没有 Key 时导入也不清除目标设备已有的 Key**——「备份里没凭据」不等于「用户想登出」；③**弹弹play 的 API Key 刻意不搬**：`DandanplaySettingsStore.apiKey` 的 getter 在未设置时会回落**内置公共 Key**，于是「读出来再写回去」会把一个内置常量变成用户显式设置（将来换内置 Key 时那台设备就再也跟不上），而 `updateGateway` 是整体赋值，备份里没有 Key 时会把目标设备上用户自有的 Key 抹掉——所以只写自定义网关、不碰 Key。**三个「不会编译报错、只会静默失效」的坑是这块的主要风险，逐个钉住**：①字幕颜色在 `UserDefaults` 里是 **UInt32 整数**（`PlaybackPreferences.storedColor` 按 `integer(forKey:)` 读），按字符串存取不会有任何报错，只会让颜色搬不过去；②字幕外观那一组（对齐 / 边距 / 颜色 / 描边 / 加粗）与 `subtitleBold` 都是**三态**，「没设过」必须保持 nil 且导入时**不写**（写成 0 或默认值等于替用户改了字幕、顶掉 ASS 特效字体）；③导出时的默认值必须与 App 真实默认逐项一致，否则会把「没设过」变成「设成了默认值」——其中 `danmakuDisplayArea` 真实默认是 **0.75**（不是 0.5）、字幕语言 rawValue 是 **`zh-Hans`**（不是 `chi`）、TMDb `cacheDays` 默认 **90**（不写死，直接引用 `TMDbPreferences.defaultCacheDays`）；能引事实源的默认值一律引用（`PlaybackPreferences.outroRetentionOptionsSeconds` / `danmakuBaseFontSize`、`SubtitleLanguagePreference` 与 `PlaybackUpscalerMode` 的 rawValue），导入端先校验枚举档位再写。**接口刻意的窄**：协调器不持有 `AppModel`、也不依赖 `DanmakuModel`——导出只要一个网关字符串，写回只要一个 `DandanplaySettingsStore`（它自己就能注入 `UserDefaults`），于是整条链路都能用独立 suite 测（`.standard` 在测试宿主里是**真实的用户域**；而构造 `DanmakuModel` 会真的在 Application Support 下建出弹幕目录）。**文件格式**：`.json`（prettyPrinted + sortedKeys，可读、可手改、崩溃后能一眼看出导了什么），带 `formatVersion`，读的时候 `> 1` 直接拒绝（宁可不导入，也不按旧语义误解新字段），非本 App 的文件 / 被截断 / 明文文本一律拦在覆盖之前。**iOS 上必须 `startAccessingSecurityScopedResource()`**：`fileImporter` 给回来的是沙盒外 URL，不申请授权读会直接失败（「选得到文件但导入报错」的典型成因）。入口在设置 → 维护 →「配置备份与多端同步」（导出 / 从文件恢复，恢复前弹确认框列出文件里有什么、Key 只回显尾 4 位），TMDb 设置页在已配置时给一句指路文案。验证：新增 `ConfigBackupTests` **15 条**——TMDb 全字段导出→JSON 往返→另一台设备恢复（含 `isConfigured` 翻转）、无 Key 不清除既有 Key、局部备份不碰其它设置、颜色按整数往返、三态 nil 不覆盖目标设备既有值（且「明确关掉 ≠ 没设过」）、枚举用 rawValue 且坏档位不写、弹幕默认值逐项对齐 App 真实默认、未自定义网关不导出内置默认网关、损坏 JSON / 空文件 / 明文 / 未来版本号四种拒绝、缺失文件给可读话术、摘要只回显尾 4 位、`FileDocument` 承载 JSON 且同配置逐字节稳定。实跑：macOS scheme **499 用例（491 通过 + 8 条 iOS 专有版式按 `XCTSkip`）全绿**、iOS 模拟器（iPhone 17 Pro）**505 用例全绿**。**反向验证**（逐条改回缺陷版，确认对应用例变红，再还原）：`subtitlePrimaryColor` 改回「按整数读不出来」→ `testSubtitleColorsSurviveRoundTripAsIntegers` 红；`displayArea` 默认改回 0.5 → `testDanmakuDefaultsMatchAppDefaults` 红；`subtitleLanguage` 默认改回 `chi` → `testEnumPreferencesUseRawValues` 红；三态字段 nil 也无条件写入 → `testUnsetSubtitleStyleStaysUnsetAfterImport` 红；四轮各只红对应用例（无连带污染），协调器还原后与改前逐字节一致。**未做**：GUI 里的点击走查（导出面板里选 iCloud 云盘 / 隔空投送、手机上选文件恢复）需要真机手点，本次只验到「双端构建 + 数据链路全绿」。

### 改动

- **首页「向 Rex 靠」的三件事：去掉顶栏大标题、栏位之间收紧、最近添加改成 16:9 小卡**（用户拿两张对照截图给的口径：图一是 Rex 的首页、图二是我们的，逐条点名三处——「首页二字去掉」「每个栏位之间间距没那么大」「他们的最近添加比例较小」）。先把两张 602×1308 的截图逐像素量了一遍（栏位标题 ink 位置、卡片框边界、栏位之间的白缝），再按量到的数字改 token，**不是凭观感调参**：
  - **`首页` 大标题去掉（iOS）**。它已经写在底部 Tab 上，顶栏再挂一遍只白占约 52pt——对照截图里 Rex 的第一个栏位标题紧贴状态栏下方，我们的在 194pt 处。去掉后顶部只留右上角两个按钮（打开 / 刷新），与 Rex 的顶栏形态一致。`navigationBarTitleDisplayMode(.inline)` + `toolbar(removing: .title)` 双保险（大标题与栏内标题都不出）。**macOS 不动**：那边是窗口标题栏 + `navigationSubtitle`（服务器名），本来就没有大标题可去；搜索入口是底部放大镜 Tab，不经导航栏，不受影响。**同口径推广到另外三个 Tab 根页（iOS）**：Bangumi（登录页与主页两处）/ MoviePilot / 设置同款双保险——理由同一条：页名已写在底部 Tab 上，顶部不再挂一遍；设置子页是 push 页、标题统一在 `AppShell.settingsSubpageView` 给定，不受影响；macOS 三页全部保留原样（MoviePilot / Bangumi 工具栏还有 subtitle，设置页保留工具栏标题）。这三页没有逐像素量过（首页量过的口径直接平移），双平台构建通过。
  - **栏位之间的留白收紧 22pt**。那段白缝由三个 token 决定：`railHoverPadding` **28 → 16**、Rail 顶部内边距 **24 → 18**（新 `Metrics.railTopInset`）、标题与内容之间 **14 → 10**（新 `Metrics.railHeaderSpacing`）。实测：栏位间距（上一栏文案底 → 下一栏标题 ink 顶）**60.5pt → 42.5 / 42.0pt**，与对照产品 Rex 的 ≈42pt 基本重合；栏位内部「标题 → 封面」**45pt → 28.5pt**（Rex ≈17pt，我们刻意松一档：卡片悬停放大 1.055，贴太紧会打架，16 给了一倍余量）。**骨架屏必须一起改**：`SkeletonRail` 原先把 `spacing: 14` / `.padding(.top, 24)` 抄成字面量与 Rail 各写一份，改一边漏一边就会在骨架撤掉的瞬间错开几 pt——现在两边读同一组 token，并加了「骨架高 == 真实 Rail 高」的用例钉住。
  - **「最近添加」从 2:3 海报卡换成 16:9 横版小卡**（新 `LatestCard` + `Rail.Kind.latest` + `Metrics.compactLatestWidth` 165 / `latestWidth` 230）。Rex 那一栏的卡宽是屏宽的 ≈41%（176pt），同屏「继续观看」的剧照卡是 59%（251pt）——它的口径就是「最近添加比剧照卡小一档」；我们原先这一栏是 120 宽 / 180 高的海报卡，**面积是 Rex 那张的两倍多**。新卡走 `homeStillImageChoice`（Thumb → Backdrop → Primary，与「继续观看」同一条链，有横版图不会被裁），文案两行「标题 / 年份 · 首类型」（Rex 是 `2024 · 喜剧`），没有年份与类型时第二行整行不画。真实首页实测：最新栏 165×93（16:9）、其余两栏仍是 240×135。
  - **验证**：`Packages/AppDesignKit` 新增 `RailRhythmTests` 5 条 + `AppDesignKitTests` 扩 2 条（65 → 71 用例全绿），`AppTests/HomeLayoutTests` 新增 4 条（真 `HomeView` + 真 `AppModel` + 替身服务器，挂进离屏 `UIWindow` 渲染成位图后**从像素上量**：三条栏位的卡宽 / 画幅、两段栏位间距、三段标题到封面间距）。**反向验证**（改回旧 token 逐条确认会红）：`railHoverPadding`/`railTopInset`/`railHeaderSpacing` 三个一起改回 28/24/14 → `RailRhythmTests` 2 条红（45pt / 55pt 超界）、`HomeLayoutTests` 3 条红（60.5pt / 60.0pt 栏位间距、44.5pt 标题间距）；只把 `SkeletonRail` 改回字面量 → 骨架用例 3 处红（差 10pt）。恢复后复跑全绿。实跑：`Packages/AppDesignKit` **71** 用例、macOS scheme 全绿、iOS 模拟器（iPhone 17 Pro）**474** 用例全绿。
- **海报墙「向 Rex 靠」的两件事：手机上 3 列、卡片边框贴着图片**（用户三轮截图反馈串起来的一条线：「我们的在手机上显得太大」→「所有剧集的都被裁切了一部分」→「上下空出一截，是你边框设计的问题」；后两轮用户补了 Rex 的竖版与横版截图作参照）。**三个问题同一个根：我一直在拿一个拍脑袋定的比例去套服务端的图片**。先把事实量全（本机 Jellyfin 12.1.0 真实数据 + 两张 359×782 截图的逐像素测量）：
  - **列数**：Rex 媒体库 3 列 × ≈118pt（列距 ≈10pt、行距 ≈16pt），我们 2 列 × 178pt。而且那 178 是**写死的**——紧凑网格传 `width: nil` 本意「跟随列宽」，`PosterCard` 却回落到 178，比列宽（172pt）还宽 6pt，卡片两侧各溢出 3pt。现在紧凑端 3 列 × 112.7pt；列 / 行距 / 卡宽三件统一收进 `PosterGrid`（媒体库网格、全局搜索结果、合集成员此前各写一遍同样的三元表达式，注释里还写着「与库页同款」）。用 `.adaptive(minimum:)` 而非写死三个 `.flexible()`：紧凑宽度不止手机，iPad 分屏窄到 320pt 时退回 2 列。
  - **不裁切**：26 部剧集里 **22 部是 400×570（0.7013）**、2 部 0.75、3 部 0.6667——按 2:3 铺，0.70 的左右各裁 2.5%、0.75 的各裁 5.6%。**只有那 3 部 2:3 的毫发无伤**。
  - **不留边**：光改「不裁」会在上下露灰条，因为**框还是写死的 2:3**。正确做法是**框跟着图走**：框高＝列宽 ÷ 这张图自己的比例。比例三级来源——服务端 `PrimaryImageAspectRatio` → 位图实测（`RemoteImage` 解码完回报真实尺寸）→ 画幅兜底。**顺带把参考对象的做法也量了**：Rex 是**固定框 + 裁切**（逐卡量到恒为 106×154＝0.688，把 0.75 那张海报左右切掉），所以这不是「抄 Rex」能解决的；我们取「不裁」这一侧，代价是同行的卡高随各自比例略有不同（`GridItem` 因此补了 `alignment: .top`——不给它，`LazyVGrid` 会把矮的卡在行内居中，三张卡顶边参差成 110/118/129，**这条是用例先报出来的**）。
  - **横版必须与竖版分开处理**（用户第三轮：「横着的那些有问题」）。`Shape` 的 `heightRatio` 拆成 `budgetHeightRatio`（解码预算锚点）与 `nominalRatio`（兜底框比例）——两者混用正是横版被挤变形的直接原因；新增 `followsImageRatio`：**只有海报跟随图片比例，剧照不跟随**，两个理由都是实测的——剧照资产统一 16:9，而 rail 高度是常量，跟随只会让异形封面把卡片撑高、标题被裁；更关键的是**剧照卡显示的是 Thumb/Backdrop，而 `PrimaryImageAspectRatio` 描述的是 Primary 那张图**（实测「年会不能停！2」primary＝0.667、thumb 却是 16:9），拿它当剧照比例本身就是错的。兜底比例改为**可按调用点覆盖**：Jellyfin 海报墙用多数派 0.70（骨架卡同步），TMDb / bgm.tv 的海报惯例是 2:3，那 6 处显式传 `2.0/3.0`。
  - **数据层**：`MediaItem` 新增 `primaryImageAspectRatio`；Jellyfin（`ItemFields.primaryImageAspectRatio`）与 Emby 两侧的**列表接口都要显式要**——实测 `/Items` 不带 fields 时 0/12 带比例，而首页两条 rail、媒体库、收藏、详情共 6 个端点全部补上。
  - **解码尺寸不再写死**：`PosterCard` 原先固定 `maxPixelSize: 400`，而 3x 屏上 113pt 的卡要 508px——每张都被放大 27%、白糊一档。现在按 **盒宽 × 画幅 × `displayScale`** 算（`ArtworkMetrics.pixelBudget`，纯函数、有单测），网格自适应宽先经 `onGeometryChange` 量到列宽再起图（量到之前铺一块与加载态同色的中性灰），解码只做一次。调用点里 7 处写死的预算（400/720/500/360/300/240）一并去掉——它们全是「猜一个够大的数」，正是「图糊」与「白下大图」的共同来源。
  - **验证**：新增 `PosterGridLayoutTests`（3 条，把列策略交给 SwiftUI 真排一遍再从位图里数：402pt → 3 列 × 112.7pt、320pt → 2 列 × 133pt、常规宽 1280pt → 6 列且单卡 ≥178pt）；`ArtworkScalingTests` **10 条**——三种真实海报比例逐个断言「四边贴死 + 不裁 + 不留边」，横版剧照 / 库卡 / 海报卡三条，兜底比例一条，外加**反向验证**（比例闸门改回 1.6 + 剧照也跟随实测比例＝线上那个构建 → 断言报出 **21px 灰带**）；`LibraryGridLayoutTests` / `LibraryArtworkScalingTests` **10 条**走真 `LibraryView` + 真 `AppModel` + 真 `ImagePipeline`（离屏 `UIWindow` + 真 runloop）：402pt 3 列、标题两行居中、骨架同位、同一行混排三种比例逐列量、横版剧照与库卡「图区上沿＝图片上沿」。**方法上补了一课**：最早那版用例只量图片外接矩形，而**留边根本量不出来**（图片永远保持自己的比例，被挤变形的是框）——缺陷正是从这儿溜过去的；现在包内垫**绿底**（露绿＝留边，排除圆角那一圈）、App 层比较图区上沿与图片上沿，两处都拦得住。实跑：`Packages/AppDesignKit` **65** 用例、macOS scheme **464**（460 通过 + 4 条 iOS 专有版式按 `XCTSkip`）、iOS 模拟器（iPhone 17 Pro）**470** 全绿；真机（iPhone 17 / iOS 27.2）装 Release `0.2.1 (533)` 验证用户报的两个现场均修复。

- **详情页选集条开始「提前占位」：库里还没有的集也会画出来，标「未播出」或「未入库」**（向 Rex 那类播放器学的一处）。此前选集条的数据只有一个来源——`server.episodes(seriesID:seasonID:)`，所以库里缺的集**直接从轨道上消失**：一部只收了 S3E25 的番，用户看不到「这一季其实有 12 集、后面 11 集还没入库」。而两份「整季」数据其实早就在手上：TMDb 季叠加层一次请求就带回每集的 `episodeNumber / name / overview / stillPath / airDate / runtime`（`airDate` 此前在 App 侧**零引用**），Bangumi 区块也已经在读全量章节（还带「未播」语义）。现在轨道渲染的是派生值 `episodeSlots`（`MetadataKit.EpisodeSlotBuilder`，纯函数、`now` 注入）：**TMDb 季数据优先，编号对不上或没有 TMDb 数据时用 Bangumi 章节兜底**。四条决定这块的设计：①**占位不进 `episodes`**——那个数组会流进播放、已看标记、连播、详情快照与磁盘缓存，混进假条目等于每一处都要再加一道「这是不是真的」判断，所以占位是 `.local` / `.placeholder` 联合类型，`EpisodePlaceholderCard` **刻意不是 Button**（占位没有可播条目，做成按钮就会出现「点了没反应」或「点了进播放器再失败」），无障碍上也不带 `.isButton`；②**编号要锚点**——库内已有集号时，来源必须与它至少有一集同号，否则整个来源作废。实测两种编号口径都存在（Jellyfin 的 `IndexNumber` 有时是季内相对号、有时是绝对号），**错号的占位比没有占位更坏**（用户会按它去找片）；③**数量要有界**——占位只覆盖 `库内最小集号 … 库内最大集号 + 24`（`forwardWindow`，约一个标准季），另加 `maxPlaceholders = 60` 的安全网。下界不可省：一部只有第 1000 集的库会把 1…999 全算成空洞、把有用的库尾挤出上限之外（写测试时才发现，原方案是「任何缺失且 ≤ 上界」，已改）；④**「未播出」= 有播出日期且晚于现在**，日期未知算「未入库」（Bangumi 上未定档就是空 airdate，当成未播出会让十年前的老集标成「未播出」）。季号 0（特典）与季号缺失一律不补：TMDb 的 season 0 与 Jellyfin 从文件名派生的 SP 编号不同源，硬补只会造一批错号假卡片。占位卡的**图**：TMDb 的 `still_path` 优先，没有时用**剧集自己的横版图**（`MediaItem.homeStillImageTarget`，与首页「继续观看」同一条链：剧的 Thumb → Backdrop → Primary）——占位本来就没有自己的剧照，用剧的图把格子填上比留一块灰底有用得多（用户实测口径）。日期不放在标题下方而是**画在图里**（左下角 + 底部渐隐），因为横向 ScrollView 里 `LazyHStack` 的高度是按**已实现的子视图**算的：两种卡高度不一时，矮的那张会定下整条轨道的高度、高出的部分被直接裁掉（实测日期行被裁成半行）。现在两种卡严格同构，标题统一 `lineLimit(2, reservesSpace: true)` 恒占两行，卡高恒定、布局不可能再错。**这一整块不发任何新网络请求**：TMDb 季数据本来就在拉、Bangumi 章节本来就在读本地库，两份缓存都在同一个 `Media.sqlite` 里，所以**离线也能出占位**。Bangumi 侧让**区块**把章节递上来（`onCandidatesLoaded`）而不是 VM 自己再读一次库：区块今天已经在读全量章节，且自带「启用开关 / 登录态 / 建库就绪」三道闸门，VM 复刻它们只会多一处漂移点，VM 因此也不必 import BangumiKit。开关在设置 → TMDb →「剧集占位」（`TMDbPreferences.showPlaceholders`，默认开；刻意放在 `isConfigured` 闸门之外，只有 Bangumi 兜底的用户也找得到）。顺带把 `BangumiEpisodeDTO.aired` 拆成 `airDateValue`（三态：日期 / 未知）+ `aired`（`airDateValue.map { $0 <= Date() } ?? false`，**语义逐字不变**），并让 `TMDbAirDate` 与它同口径（本地时区当日零点）——两边差一天会让同一集在两个来源下判成不同状态。验证：`EpisodeSlotTests` 新增 26 条（空洞补位与顺序 / 未播出与未入库 / 今天零点算已播 / 窗口上界锚在库内最大集号、下界锚在最小集号 / 长番被窗口截住 / 上限安全网 / 空库从第 1 集补 / 编号无交集则作废 / 库内无集号则不可信 / 来源优先级与兜底救场 / 特典不补 / 去重与 id 不相撞 / 集号 ≤ 0 丢弃 / 标题回落与 `episodeLabel` / 季叠加层映射（坏日期 → nil、分钟 → 秒、剧集级叠加层无候选）/ 偏好默认值），`BangumiKit` 新增 2 条（`airDateValue` 三态、`aired` 语义不变），`EpisodePlaceholderTests` 新增 6 条（只收本篇 / 小数 `sort` 丢弃 / `sort < 1` 丢弃 / 中文标题优先 / 空 airdate → nil / 不凭空造剧照与时长），`MetadataCacheIntegrationTests` 新增 5 条接线用例（多一条钉住取图链：没有 TMDb 剧照时落到剧的 Thumb 且带服务端凭证、有剧照时走 TMDb CDN 且不带凭证）（真 AppModel + 真 SQLite + `StubMediaServer`：TMDb 季数据补出 26…36 且 `episodes` 与选中集一个都不多、关开关后不出占位、没配 TMDb 时 Bangumi 候选兜底且编号对不上就忽略、换季清掉旧季候选）。**反向验证**（临时改实现，逐条确认会红）：去掉锚点检查 → `testMismatchedNumberingSuppressesPlaceholders` + `testFallbackRescuesAMismatchedPrimary` 失败；窗口改成无上限 → `testLongRunningSeriesIsBoundedByForwardWindow` + `testWindowIsAnchoredOnTheLocalSpan` + `testEmptyLocalSeasonFillsFromTheStart` 失败；反转来源优先级 → `testPrimaryWinsOverFallback` 失败；日期未知当未播出 → `testUnknownAirDateIsNotInLibraryNotNotAired` 失败；均还原后复跑全绿。实跑：`Packages/MetadataKit` **144** 用例、`Packages/BangumiKit` **48** 用例（swift-testing）、macOS scheme **419** 用例、iOS 模拟器（iPhone 17 Pro）**419** 用例全绿（新增用例全部离线，集成用例刻意把 TMDb 对应 + 剧集实体 + 季数据三份都预置成未过期，否则 `performRefresh` 会真打 TMDb——第一版就踩了，用例从 0.02 s 变成 3.3 s）。
- **修「iPad 上播完一集既不连播也不退出，只剩内核报错」**。根因是**内核在片尾把「读到文件末尾」间歇性报成致命错误**，而 App 只在状态 `.stopped` 时才算「播完」：`PlaybackReportingCoordinator` 心跳分支此前写死 `snapshot.state == .stopped && 位置 ≥ 片长 − 2s`，内核落 `.error` 时算出 `reachedEnd=false`，`AppModel` 终态回调里的 `if event.reachedEnd` 不成立 → 既不播下一集也不 `dismissPlayer()`，用户只能手动关。**现场**（iPad mini 5 / iPadOS 26.6.2 / OcPlayer 0.2.1 / Erika v0.2.1；日志从配对设备用 `xcrun devicectl device copy from --domain-type appDataContainer --domain-identifier dev.jumusu.OcPlayer` 直接拉回，不用碰设备）：`我的朋友很少 S1E5`（1472 s）播到 **1471.512 s** 时内核 stderr 落 `playback_fatal: demux worker error: ffmpeg error in av_read_frame: Input/output error (-5)` → `内核错误事件 code=3` → `PlayerState -> error`；**此后 18 秒内日志里唯一的动作是用户手动 `closePlayer`**。同一份日志 23:05 的两次（`无职转生 S3E14`，1422 s，位置 1421.587 s）同签名，三次全部落在片尾前 0.4–0.5 秒。**关键对照**把分水岭指到「读边界是否跨过 EOF」：2026-10-07 那次收尾里内核最后一次 HTTP range 恰好读到文件末尾（`start=919287807 + length=81988 = 文件长度 919369795`）→ `decoder_eof_drain stage=complete` → `.stopped` → 连播/退出照常；失败那次的最后一次成功读取停在**距文件尾 3966 字节**处（1100816527 / 1100820493），下一次跨过 EOF 的读直接给 EIO，内核 HTTP trace 里没有任何 4xx/5xx（27 次 `http_range` 全是 206）。修法收在 `PlaybackReportingCoordinator.isEndOfStream`：`.stopped` **或** `.error` 且位置在片长 − 2 s 以内即算播到文件尾，**只接进心跳分支**——`stop()` 那条路径由宿主主动进入（关播放器 / 换控制器 / 退后台），把片尾 `.error` 也当播完会在用户正拆台时反过来触发连播（`AppModel.playback` 的 didSet 里 `stop()` 甚至跑在 `clearPlaybackSessionState()` 之前），故 `isNaturalEnd` 保持只认 `.stopped`，两条路径的差异与原因都写进注释。**未修根因**：内核侧「跨 EOF 的读返回短读/EOF 而不是 EIO」仍需上游 Erika 修 + 升 `Config/Erika.version`，本条只是让症状不再落到用户身上。验证：`PlaybackReportingCoordinatorTests` 新增 3 条（片尾 error → `reachedEnd=true` 且只报一次 Stopped / 片中 error（100 s 片源的第 31 s）仍 `reachedEnd=false`，错误徽章 +「重试」那条路不变 / 宿主主动 `stop()` 时片尾 error 不触发终态），macOS scheme **409** 用例、iOS 模拟器（iPhone 17 Pro）**409** 用例全绿；**反向验证**：把心跳那行还原成旧表达式 → 新增的第 1 条失败（终态回调 1 秒内不来），恢复后复跑全绿。
- **字幕外观可调：设置 → 播放新增「字幕外观」组**（位置 / 上下边距 / 字幕颜色 / 描边颜色 / 描边粗细 / 加粗）。此前 App 对字幕**只有一个旋钮**——整体缩放（HUD 的「字体大小 +/-」），而内核（Erika）的 `erika_presenter_set_subtitle_style` 从 v0.1.9 起就带着 21 个字段 + 8 位 `override_mask`，在 ErikaKit 与 App 两侧**都是零引用、连封装都没有**。于是「字幕贴边」「亮场景字幕看不清」这类真实抱怨完全没有出口。**两个语义决定这块的全部设计**：①**每一项都是三态**——「不设置」是独立状态，不是默认值。内核这个接口在不覆盖时是**填空缺**（片源自带的 ASS 排版、特效字体全部保留），所以用户没动过的项必须以 nil / 0 哨兵带出去；带上一个「看起来合理」的默认值，就等于一进设置页替全片改了字幕。为此存储层刻意不用 `storedDouble` 的钳制语义：描边宽度被改坏成 999 若钳到上限 32，会变成一个用户没要过的**有效设置**，所以非法值一律当「没设」（位置 / 边距用 `storedInt` 的区间校验，描边宽度单独读取，有边界用例钉住 32 合法、32.1 非法）。②**「覆盖自带样式」默认关**，`override_mask` 因此默认是 0——打开才把用户改过的项对应位置位（位是逐位对齐内核宏的，**不能按位序对齐**：宏编号是 2/3/4/5/6/7/8/11，跳号）。文案把区别写清楚：关着只填空缺，打开会顶掉字幕自带的排版（含 ASS 特效字体）。字体族 / 内存字体刻意不在本次范围（那是另一件需要字体选择器的事），所以 `FONT_NAME` 位永远不置位、`font_family` 恒为 NULL——有用例专门断言 `all` 掩码**不含**字体名 / 字号字段 / 模糊这三位，防以后手滑把它们一起打开。颜色用 `0xRRGGBBAA`（与内核同口径），UI 侧走 `ColorPicker`；双端取分量的 API 不同（`NSColor.redComponent` vs `UIColor.getRed`），就地各写一支、`getRed` 失败时兜白色而不是写进一个无意义的 0。验证：`ErikaSubtitleStyleMappingTests` 新增 8 条（没设的项必须是内核默认值而不是 0——字号 0 会被钳成最小 8、对齐 0 非法 / 设过的项原样带上 / 默认 `override_mask == 0` / 五个覆盖位逐个对齐内核宏 / `all` 恰好等于本仓库涉及的位且不含字体名、字号字段、模糊 / 组合位按位或 / `covering` 能识别改过哪几类 / 空样式自检），`SubtitleAppearancePreferenceTests` 新增 11 条（什么都没设 → 空样式不下发 / 只设颜色只带颜色 / 加粗三态含「还原后键真的消失」/ 数值 0 = 不设置 / 非法值回落不设置 / 描边宽度边界 32 合法 32.1 非法 / 覆盖开关 → 掩码 / 颜色往返不丢精度 / 占位色不会被写回 / 十六进制文案 / 位置选项都在九宫格 1…9 内），`ErikaRenderTests` 新增真内核用例（非覆盖、覆盖、空样式三条路下发都不报错，无字幕轨时也安全）。反向验证：把覆盖位改成按位序对齐 + 未设字号传 0 → 映射用例 5 处失败；把「没设过」的位置填成默认值 2 → 偏好用例 4 条失败；均恢复后复跑全绿。实跑：`Packages/ErikaKit` 72 用例（XCTest 16 + swift-testing 64）、`Packages/PlaybackKit` 59 用例、macOS scheme **406** 用例、iOS 模拟器（iPhone 17 Pro）**406** 用例全绿。

### 改动

- **画质增强（ArtCNN 亮度上采样）可用：设置 → 播放 → 播放内核新增「画质增强」四档**（关 / F16 / F32 / F16 去噪）。内核早就带着这个能力：`erika_presenter_create_with_config` 的 `luma_upscaler` 字段、运行期的 `set_upscaler`、以及 `ErikaUpscalerStatus`（请求档位 / 实际后端 / 回退次数 / 已上采样帧）。链路其实**已经铺到 App 门口**——`ErikaPresenter.init` 与 `ErikaEngine.init` 都有 `upscaler` 参数——但**断在装配点**：`PlaybackEngineAssembly` 只传了 `edrHeadroom`，于是 `luma_upscaler` 恒为 Off，`set_upscaler` / `get_upscaler_status` 在整个仓库零调用。为什么一直没接上，根因是类型：那两个参数用的是 `ErikaLumaUpscalerMode`（CErika 的 C 枚举），而 `CErika` 是 ErikaKit 的内部 target、`App/` 看不见它，所以装配点根本没法给这个参数命名。现在按本仓库既有的分层把它解决掉：PlaybackKit 新增中立的 `PlaybackUpscalerMode` / `PlaybackUpscalerState`，ErikaKit 里逐个显式映射到 C 枚举（**不用 rawValue 互转**——两份枚举各自演进，靠数值对齐等于把它们绑死），`ErikaEngine.init` 的 `upscaler:` 换成中立类型（全仓无人传这个参数，改动无外溢）。装配点的工厂闭包在**每次播放重建引擎**时读偏好，所以设置改完「下一次播放生效」，不打断当前播放去重建内核；open 收尾的参数重放块里再补一次 `setLumaUpscaler`，盖住「引擎已建好、open 还没收尾」这个窗口。**「设了到底有没有生效」是这块最容易骗人的地方**，所以两件事都做了：①`PlaybackUpscalerState.isFallingBackNatively`（请求开着、后端报 `inactive`）会驱动设置页一条明确提示「后端不支持，已回落原生采样」；②这道提示带了「已出过帧」闸门——实测发现 `inactive` 有**两个**来源：后端不支持，以及画面管线还没跑起来（未 attach surface / 首帧之前读回来也是 `inactive`）。少了这道闸，用户一进设置页就会看到假警告。**本机实测**（macOS / Apple Silicon / Metal）：挂上 surface 并 tick 之后，F16 / F32 / F16 去噪三档全部跑在 `simdgroupMatrix` 上且 `upscaled_frames` 在涨（各档 26 / 49 / 88 帧，回退计数 0）；未挂 surface 时同一档位读回来是 `inactive`——这正是上面那道闸的事实依据。验证：`ErikaUpscalerMappingTests` 新增 7 条（四档双向映射 / 不认识的档位码回落 off / 每档都有可显示名字且数量为 4 / 后端状态 0…4 逐个对齐 + 未知回落 / 字段原样映射 / 「请求开着且 inactive 才算回落」的四种组合 / 中性值），`UpscalerPreferenceTests` 新增 4 条（键不存在回落关闭 / 坏值回落关闭 / 四档存取往返 / 存的是 rawValue 而不是显示文案），`ErikaRenderTests` 新增真内核用例（挂画布跑热后逐档切换：请求档位必须读得回，且**报了计算后端就必须真有帧被上采样**，避免「设了没效果」与「后端不支持」在 App 侧分不开）。反向验证：把 `artCnnC4F16Ds` 映射写成 F32 → 映射用例失败；把坏值兜底改成 `.artCnnC4F16` → 偏好用例失败；均恢复后复跑全绿。实跑：`Packages/ErikaKit` 71 用例（XCTest 16 + swift-testing 55）、`Packages/PlaybackKit` 59 用例、macOS scheme **395** 用例、iOS 模拟器（iPhone 17 Pro）**395** 用例全绿。

- **字幕与渲染按「这一帧要显示的时刻」采样：接入内核的 `render_tick_with_timing`**。v0.2.1 的内核新增了这个 C API，本仓库此前只升级了 vendored 二进制与 `erika.h`、App 侧仍走无 timing 的 `render_tick`（0.2.1 的 CHANGELOG 与 `Docs/DEVELOPMENT.md` 都记着这笔欠账）。现在 `RenderLoop` 每次显示回调同时给出「到显示目标的延迟」（`CADisplayLink.targetTimestamp - CACurrentMediaTime()`），`ErikaEngine` 把它交给内核：视频、字幕与渲染上下文于是按**同一个显示目标时刻**采样播放快照，而不是各自采各自的时间点——渲染繁忙时字幕与画面的错位正是这么来的。延迟先过一道**客户端夹取**：内核只接受有限值且落在 ±0.25 s 内（`erika.h` 的硬约束，超界直接判错而不是忽略），所以非有限或超界一律传 nil、退回无 timing 的 `render_tick`；这道夹取不是形式主义——`CADisplayLink` 尚未进 runloop、系统休眠唤醒时 `targetTimestamp` 可能离现在很远，不夹就会变成「画面卡住 + 满屏 render_tick 失败」。**关于「旧内核缺这个符号要可选解析」**：本项目用 `dlsym` 探测没有意义——符号是静态链接、编译期绑定，钉点低于 v0.2.1 时构建会**响亮失败**（fail-closed），而不是静默降级；这正是 `fetch-erika.sh` 与 `Config/Erika.version` 想要的行为，所以代码里不写运行时探测。后台仅音频档不受影响（那条路没有显示目标）。验证：`RenderTickTimingTests` 新增 5 条（正常范围原样通过 / 边界 ±0.25 有效 / 超界返回 nil / 非有限一律拒绝 / 约束常量与 `erika.h` 声明一致），`ErikaRenderTests` 新增真内核用例（带 timing 的重载与无 timing 的 tick 一样能出画、不报错，同时证明新符号在钉点二进制里确实可用）。反向验证：去掉 ±0.25 边界判断 → 边界用例失败；恢复后复跑全绿。实跑：`Packages/ErikaKit` 63 用例（XCTest 16 + swift-testing 47）全绿；macOS / iOS scheme 各 **391** 用例全绿。

- **内核一直在报的「HDR 为什么没出」「刚才那一下为什么卡」现在终于能看到**——三块此前被丢掉的诊断信息接上了。①**输出细节**：`get_output_status` 的 13 个字段里，App 从始至终只读了 `active_encoding` 一个——面格式（8bit / 10bit / 16bit 浮点）、**回退原因**（显示器不支持 HDR / 缺 16 位浮点面格式 / scRGB 数据空间校验失败…，内核承诺只追加不重编号 0…8）、回退次数、有效 headroom、是否走在扩展线性通路上，全部零读取。现在它们经 PlaybackKit 的中立类型 `PlaybackOutputSnapshot` 一路到信息面板新增的「输出」行（`Apple EDR · 10bit` / `SDR · 8bit · 回退 显示器不支持 HDR`）与诊断日志字段；内核报了一个本版本不认识的回退码时**照实说「回退（原因未识别）」**，而不是猜一个最像的原因（猜错会把排查带偏，比不显示更坏）。「输出」行在什么都没拿到时整行隐藏，不会在 SDR 屏上凭空多一行假数据。日志侧每 5s 与内存采样搭同一趟车采一次输出状态，**只在语义量变化时记**——`headroom_updates` 这类累计计数刻意不参与比较，否则「变化才记」会退化成逐次刷屏（有专门的用例钉住这张清单）。②**原始计数器**：`ErikaPresenterStats` 的 34 个字段里只有 8 个进了中立层，其余 26 个（`video_frame_backpressure_drops` 背压丢帧、`cpu_video_frame_fallbacks` 回退软解、`audio_clock_underflow_frames` 音频时钟欠载、`shared_handle`/`direct_zero_copy` 帧路径构成、`hdr10_metadata_*`、`last_render_micros`…）**从没有任何读取点**，连 `latestErikaStats` 这个逃生舱都没人用。现在 `kernelDiagnosticsFields()` 把全部字段导出，会话收尾（`stopPlayback`）落一条「内核统计快照」——**必须在 `engine.stop()` 之前**，因为内核自 v0.2.1 起在 stop 时释放 HTTP 缓存与队列，落在之后等于记录一个已经被清过的现场（用例钉住调用顺序）。③**解码后端切换事件**：`VideoDecoderChanged` 一路映射到中立事件，然后到 `PlayerState` 就是一个 `break`——硬解掉软解时画面照常、只表现为「突然变卡」，用户不会报「内核换了解码器」，于是排障永远拿不到第一现场。现在落一条 `decoder.changed` 事件行，带毫秒位置。**刻意不动的一处**：`AudioOutputChanged` 与 `audio_recovery_*` 那套音频自恢复状态机**只在 Windows WASAPI / Android AAudio / OHOS OHAudio 后端实现，Apple 后端恒 stable/0、事件永不触发**（0.2.1 的记账），所以在 `PlayerState` 里保持 `break` 并就地写明原因——它是「不适用」，不是遗漏，别当成缺陷来修。顺带更正两处与内核契约相反的注释：`ErikaPresenter` 与 `PlaybackEngine` 都写着截图含弹幕，而内核明确「video + subtitle, **no danmaku**」。验证：`ErikaOutputSnapshotTests` 新增 10 条（回退码 0…8 逐个对齐 / 不认识的码回落 unknown 而不猜 / 面格式三档 / headroom 只在内核说 known 时才算数 / 全 0 结构不产生假回退 / 日志用稳定 rawValue / 「累计计数不触发记录」+「每个语义量变化都能触发」+「完全相同不重复记录」），`PlaybackEventTests` 新增 2 条（事件名逐个钉住 + 反向断言没有事件漏出清单 / `decoder.changed` 带毫秒位置），`ErikaRenderTests` 新增真内核用例（诊断字段逐个点名，防「少写一行映射」），`KernelDiagnosticsSnapshotTests` 新增 2 条（快照必须先于 stop / 空字段不阻断收尾），`PlayerVideoColorLabelTests` 新增 5 条（编码+面格式组合、回退原因必须显示、不认识的码不许藏、全空时整行隐藏、只有编码也要出内容）。反向验证：把 `headroom_updates` 算进变化比较 → 降噪用例失败；把快照调用挪到 `stop()` 之后 → 顺序用例失败；两处均恢复后复跑全绿。实跑：`Packages/PlaybackKit` 59 用例、`Packages/ErikaKit` 57 用例（XCTest 16 + swift-testing 41）、macOS scheme **391** 用例、iOS 模拟器（iPhone 17 Pro）**391** 用例全绿。

- **外挂字幕可以删了**（内嵌轨不行）。此前字幕菜单只有「关闭字幕」和逐轨勾选——`erika_presenter_remove_subtitle_track` 这个内核入口在 ErikaKit 里**从未被封装**（全仓零引用），所以手动导入选错文件、或 Jellyfin 侧车字幕批量挂上来几条错的时候，用户唯一能做的就是「关掉它」或者换片，**没有任何办法把那条轨撤销**。现在字幕轨那一行尾随一个删除按钮，点了就从内核轨道列表里消失。三处设计取舍：①**闸门用内核自报的 `can_remove`，不在宿主侧用 `source == .external` 猜**——`ErikaTrackInfo.can_remove` 此前在映射时就被丢掉了（`TrackInfo` 根本没这个字段），现在一路透传到 UI：内嵌轨的删除入口**不渲染**，而不是渲染出来再让内核拒绝（那是一条「点了没反应」的菜单项）；②**删掉当前正在显示的那条时，清掉「用户自己拨过」闸门**，让既有的默认字幕偏好校正（见上一条）接着挑一条或关闭——闸门是为「别覆盖用户的选择」而设的，而那条轨已经不存在了，继续拦着只会让用户停在「字幕没了也不自动选」的状态里；③**顺手清 `externalSubtitleNames` 里按轨道 id 记的显示名**：不清就会串到内核复用的新轨 id 上，而 Jellyfin 侧车的「简体 / 繁体」判定读的正是它。**不删磁盘上的导入副本**：同一文件可能被多条轨引用，且目录已由 `ManagedDirectoryPruner` 按 100 文件 / 512 MB 有界修剪，孤儿不构成泄漏。UI 上刻意**不复用 `PlayerHUDCheckRow`**（它本身就是一个 Button）——删除按钮并排成独立 Button，避免 Button 嵌 Button 导致的点击范围与手势判定不确定（macOS 误触 / iOS 外层吞内层）。协议侧 `removeSubtitleTrack` 带默认空实现（不支持的引擎不会有反应，而 UI 的闸门已经把它们挡住了），`TrackInfo` 新增的 `canRemove` 带默认值 `false`，源兼容。验证：`ErikaTrackTests` 新增真内核用例（外挂 srt 挂上 → `canRemove` 为 true → 删除后从 `tracks()` 消失；同素材内嵌轨 `canRemove` 必须为 false——`TestMedia` 造不出内嵌字幕轨，用内嵌视频/音轨覆盖同一段映射），`AppTests/SubtitleRemovalTests` 新增 4 条接线用例（闸门拦住内嵌轨连引擎都不碰、删旁轨不动选择、删选中轨后按偏好重新收敛、移除失败保留闸门并弹错误）。反向验证：把 `removeSubtitleTrack` 改成空操作 → 真内核用例失败；把 `canRemove` 硬编码 true → 内嵌轨断言失败；去掉控制器闸门 → 接线用例失败；删选中轨不清闸门 → 收敛用例失败；四处均恢复后复跑全绿。实跑：`Packages/PlaybackKit` 57 用例、`Packages/ErikaKit` 46 用例（XCTest 16 + swift-testing 30）、macOS scheme **384** 用例、iOS 模拟器（iPhone 17 Pro）**384** 用例全绿。

- **首页栏目「关闭」不再等于删除：关掉的栏目只在首页不渲染，设置页永远保留条目、位置也不丢**。此前存储串只记「显示中的栏目」（`HomeSectionPreference`），关掉 = 从串里删掉 = 设置页那行跟着消失，**没有任何入口能再打开**（用户实测反馈）；顺带两个同源问题：①**「全关」存不住**——全关编码成空串，空串又被当成「未配置」回默认全开，四个开关自己亮回来；②**顺序随关闭一起丢**——重开只能追加到末尾。现在串的语义改成「**全部栏目的顺序 + 关掉了哪些**」（token = `rawValue` 显示 / `-rawValue` 已关闭，仍是单一 `@AppStorage` 键 `dev.jumusu.ocplayer.home.sections`，缺省串字面不变）：设置页 `ForEach(layout.order)` 永远列全部栏目，开关只切 `hidden`、**不挪位置**（关掉再打开回到原位），关掉的行照样能上下移且**不影响首页可见顺序**（排序作用于全序）；首页只用 `visible` 渲染。旧数据迁移**不写代码、不加版本号、不新增存储键**——**缺项 = 已关闭**（正是旧格式的语义）并按 `allCases` 顺序归位，所以升级后首页渲染的栏目与顺序与升级前完全一致（被重排过的旧串也保住已列项的相对顺序；全关的空串读成「全关」而不是「未配置」）。全关时首页给明确空态（「首页栏目都已关闭」+「去设置」），不再错报「媒体库暂无可展示内容」、也不停在骨架屏；设置 hub 的值预览改成「显示 M/N 栏」，关掉的行在设置页压暗。顺带定下一条口径：**将来新增 `HomeSection` case 对老用户默认是关闭的**（串里没有它），要用户自己在设置页打开——不让新栏目悄悄冒出来。验证：`HomeSectionPreferenceTests` 重写为 18 条（默认串字面 / 旧格式迁移 / 去重与空格容错 / 开关保位 / 排序边界 / 归一化 / 「串长什么样设置页都列全部栏目」），macOS `OcPlayerTests` 全绿、macOS Debug 构建通过。

- **默认字幕改为「中文优先·简体优先」**。此前开片看到哪条字幕轨由内核（Erika）按 **probe 顺序取第一条字幕轨**（上游 `playback.rs` 的 `find(|t| t.kind == Subtitle)`，不看 disposition、也不认语言偏好）——片源里第一条是英字 / 日字时，中文用户每次开片都要手动切一次；原来的 `autoSelectSubtitleIfNone` 只在「Jellyfin 侧车字幕全部下载完」那一刻兜一次，**内封字幕完全没管**，而内封恰恰是绝大多数片源的字幕形态。现在设置 → 播放新增「默认字幕语言」四档：**中文优先（简体，默认档）/ 中文优先（繁体）/ 跟随文件默认 / 默认关闭**，判定收在 `PlaybackKit` 的纯函数 `SubtitleTrackSelector`（新增 `SubtitleSelection.swift`），轨道列表每次刷新后由 `PlaybackController.applySubtitlePreferenceIfNeeded()` 落动作。规则要点：①**「中文」的识别三处一起看**——内核给的语言标签（`zh` / `chi` / `zho` / `cmn` / `zh-Hans` / `Chinese (Simplified)`…）、轨道名（`简体中文` / `CHS&JPN` / `繁體` / `sc` / `Big5`…）与 App 层记录的外挂字幕显示名（Jellyfin 侧车字幕的「简体」）：内封轨的语言标签经常是空的、语言信息只写在轨名里，只认语言码会漏掉一半片源；②简繁分三档——明确标了偏好那一档 > 没标简繁的中文 > 明确标了另一档（「中文」比「繁體」更该被选中，但要排在「简体」之后）；③**一条中文字幕都没有时保持内核的选择**，绝不退回「第一条」——用户抱怨的是「默认用第一个」，不是「没有中文也要乱切」；只有**全是外挂字幕**（内核对外挂轨完全不碰、一条都不选）才兜第一条，避免「有字幕却一条不显示」，这条兜底对「跟随文件默认」档也生效（它正是加偏好之前的既有行为）；④**同档等价候选保留当前选择**（内核挑中的第一条常常正好是简体轨，不为等价项来回切）；⑤用户在菜单里手动选过（含「关闭字幕」、含手动导入字幕文件）之后**本片内不再自动改**——外挂字幕是一条条挂上来的、轨道刷新是持续事件，不加这道闸就会出现「刚切到日文字幕，两秒后被切回中文」，换片 / 重建引擎复位。自动选轨每次刷新都重算（后到的简体侧车字幕能顶掉先前的繁体），动作判为 `keep` 时**不碰引擎、不刷列表**，避免「选轨 → 事件 → 再选」自激（有用例钉住幂等）。接线走 `PlayerState.onTracksRefreshed` 回调：轨道何时齐全是事件流说了算（open 后内封轨道就绪、侧车字幕逐条挂上），控制器自己拿不到「这次刷新之后列表已最新」这个点。**重入闸门是必需的**：动作下发后方法末尾那次 `refreshTracks` 会**同步**再触发回调，而内核选轨是**异步生效**的（`ErikaTrackTests` 里用真内核验证：`selectSubtitleTrack` 之后不能立刻在 `tracks()` 读到新的 `selected`——选轨命令是投给内核 worker 异步生效的）——同一次调用里回读仍是旧选择，没有闸门就会「判定 → 选轨 → 刷新 → 判定」一路同步递归下栈（真机上是栈溢出崩溃），这条有专门的回归用例（替身内核刻意做成异步生效模型）。复核（独立子代理对上游内核 v0.2.1 源码逐条比对）另揪出四处并已修：①**「中日双语 / 中英双语 / 简日双语」这类内封 ASS 轨名全部漏判**（词表只有「中文 / 简体 / 繁体」，而这些轨的 `language` 往往是空的）——补齐双语词表；②**同一个短 token 在不同字段里含义不同**：语言字段里的 `sc`/`sg`/`mo` 是撒丁语 / 桑戈语 / 摩尔多瓦语，轨名里的 `SC`/`TC` 才是发布组的简繁标注，App 层显示名的兜底又可能是 `codec.uppercased()`（外部输入）——三段分开按可信度判定；③**轨名与语言码互相矛盾时**（muxer 常把整条轨语言码继承第一条）原先语言码压过轨名，会把名字写着「繁體」的轨选给偏好简体的用户——现在矛盾即降级为「未标注」，让结论明确的那条胜出；④**侧车字幕逐条挂载会在开播头几秒连续切两次轨**（繁體先下完、简体后下完，每次切换都是内核级轨切换、会停/重启音频输出）——新增批次闸门，整批只在结束时校正一次。同时修掉两个自己引入的缺陷：**用户手动导入坏字幕文件也会永久关掉自动校正**（闸门原先在加载前就置位，现在只在真正生效后置位）、以及复核发现的**重入递归**。验证：`PlaybackKit` 新增 18 条规则用例（`SubtitleSelectionTests`：语言 / 轨名 / 外显名识别、简繁排序、未标注中文的优先级、同档保留、全外挂兜底、内封「不选」保持、两档不干预、幂等重算），`AppTests` 新增 13 条接线用例（`SubtitlePreferenceTests`：默认档、轨道刷新切中文、幂等不重复下发、用户选过后不覆盖、关字幕不复活、换源复位、无中文保持源默认、后到侧车字幕顶替、两档不干预、同轮刷新不重入、坏字幕文件不关校正、侧车整批只切一次）。实跑：`Packages/PlaybackKit` 57 用例全绿；`Packages/ErikaKit` 真内核轨道用例（含新增的「选轨后 `tracks()` 必须报 selected」断言，这条正是重入闸门的事实依据）全绿；macOS scheme **367** 用例全绿、iOS 模拟器（iPhone 17 Pro）scheme **367** 用例全绿。两条新回归用例已在「临时还原旧实现」的对照下确认会失败（不是恒真断言）。

- **iOS 切后台不再报错，且后台真的继续出声（用上内核内建的仅音频档，取代原先「进后台暂停 + 回前台重建整个内核」）**。上一版（见下方 0.2.1 那条）把「切后台回来报 `avcodec_send_packet: Unknown error occurred (-1313558101)`、只能点重试」当成「挂起往返必然弄坏解码会话」来兜——兜法是内核已经坏了再重建。这次查到两个可根治的前置事实，把它降级为纯保险：**①前提是错的**。`PlaybackNowPlayingCenter` 里写着「内核（Erika）自己在 Rust 侧配置音频输出」，据此谁都不碰 `AVAudioSession`——但 iOS 切片 `nm -u liberika_capi.a` 里**查不到任何 AVFoundation 符号**、全库 `grep -ci audiosession` 为 **0**，内核只引用 6 个 AudioToolbox 的 `AudioQueue*` C 函数。**音频会话必须宿主配**，两边都没配 → 默认类别（`.soloAmbient`）下退后台 / 锁屏时系统把会话连同 AudioQueue 一起收走，回前台第一包数据自然是 AVERROR_UNKNOWN。**②内核本来就有正确通路**：`erika_presenter_audio_only_tick` 首次调用即 `set_video_decode_suspended(true)` + 丢弃待解码帧（上游 `crates/erika/src/presenter.rs`），切回 `render_tick` 时走 `try_resume_video_decode` → `flush 解码器 + 回关键帧重定位`，并用 `audio_seek_floor` 避免已入队 PCM 被重发——挂起/恢复是内核内建的，宿主只需换帧驱动。可它在 App 层**从未被调用过**（只有测试用），`PlaybackEngine` 协议注释还把它写成「刻意不放进协议」。落地四块：①`Config/Info.plist` 加 `UIBackgroundModes: audio`（经 `Config/App.xcconfig` 的 `INFOPLIST_FILE` 两平台共用，macOS 忽略该 key）；②新增 `ErikaAudioSession`——`.playback` + `.moviePlayback` + `setActive(true)`，在**每次 `play()` 之前**执行（照上游 Flutter iOS 插件的做法；失败只记日志不打断播放）；③`ErikaEngine` 新增后台档位 `setBackgroundAudioOnly`——进档先停 `RenderLoop`（等渲染线程真正退出）再起 16ms 定时器走 `audioOnlyTick()`，退档反向切回 `CADisplayLink`；`step()` 加**档位闸门**，丢弃跨线程迟到的 tick（否则迟到的定时器回调会把内核刚解开的视频解码又挂起，或后台档里的 `render_tick` 把刚挂起的解码立刻解开）；④`PlaybackController` 用 `suspensionMode` 记住这次往返走哪条策略，**没有后台档的内核退回原来的「挂起前暂停」**，行为不回归。顺带补 `PlaybackAudioInterruptions`：来电 / Siri 的 `AVAudioSession.interruptionNotification`（`.began` 暂停、`.ended` + `.shouldResume` 续播，用户自己在中断期间按过暂停则不自动恢复）。**两条记账**：`audio_recovery_*` / `AudioOutputChanged` 那套音频自恢复状态机只在 Windows WASAPI / Android AAudio / OHOS OHAudio 实现，**Apple 后端零实现、恒为 stable/0、事件永不触发**，别拿它做 iOS 的恢复逻辑；v0.2.1 内核**已导出** `erika_presenter_audio_only_tick`，本改动不需要换内核。自审另揪出一处真 bug 并加了回归用例：档位退出原先被挡在 `guard resumePlaying` 之后——用户在后台把播放停掉、回前台时决策表给 `.none`，渲染线程就再也不会启动，回来是一片永远不动的黑屏；现在档位退出与「要不要接着播」解耦。验证：iOS 模拟器 `OcPlayerTests` **354 用例全绿**、macOS scheme 全绿；`AppBackgroundPlaybackTests` 8 条（回前台决策表全组合、能力分流、暂停失败回退重建、档位退出解耦、无控制器/未在播时空转）；新增 `ErikaEngineCapabilityTests` 守住 `supportsBackgroundAudio` 不被误改回 false（改回去 = 症状复发）；9 个 SPM 包 + ErikaKit（按 CI 的 skip 清单）全过。**真机已验**：iPhone 17（iOS 27.2）与 iPad mini 5（iPadOS 26.6.2）装 Release `0.2.1 (518)`，切后台继续出声、回前台自动续播无错误徽章，用户确认可用。

### 修复

- **修「Bangumi 刷新后进度条已是 2 / 12，下面的章节格子还停在 02 未看」**（用户 2026-10-15 截图指认 + 本机库与线上接口双向实证）。**根因是刷新只对齐条目级数据、从不重拉单集状态**：`refreshAllCollections` 做两件事——收藏接口回读条目级 `epStatus`（进度条上的「2 / 12」）、`fetchSubjectIDsMissingEpisodes` 补章节——而后者只挑「本地本篇章节条数 < `eps`」的条目。**章节一条不缺、但单集已看状态是旧的**条目因此永远等不到重拉：在别的设备 / 网页上标了一集之后，进度条是新值、格子还是旧的。**现场实证**（本机 `Bangumi.sqlite` + 真实 token 直连 `next.bgm.tv`）：`subject=554779`（学生会也有洞！）服务端 `epStatus=2`、ep2 的 `collection={"status":2,"updatedAt":1791743282}`，而本地 `collected_at=1791743282`（10-12）却 `episodes_synced_at=1791385383`（10-07）、ep2 的 `status=0`；同库另有 3 条同病条目（`17883` 服务端 6 / 本地 4、`607915` 19 / 18、`622288` 计数相同但记录更新——即「挪了一集」）。**修法两层**：①**新增判据** `fetchSubjectIDsWithStaleEpisodeProgress` —— 只看「在看」里的动画 / 三次元、且本地已有章节的条目（一条章节都没有的仍归补齐那条路），命中任一即重拉：**(a)** `collected_at > episodes_synced_at`（服务端收藏记录比上次章节同步新；bgm.tv 在单集进度变化时**同时**推进它——实测 554779 的 `updated_at` 与 ep2 的 `collection.updatedAt` 逐秒相同——所以这条能覆盖「已看总数没变、只是挪了一集」这种计数看不见的情况，且**自清**：重拉后 `episodes_synced_at` 就晚于它了）；**(b)** 服务端已看数 ≠ 本地标为看过的本篇数（本地确实落后 / 超前，用 60s 冷却挡「刚拉完还是对不上」的重复请求）。`backfillMissingEpisodes` 随之改名 `reconcileEpisodes`（补齐 + 对齐两件事，保序去重，`episodeSyncTargets` 抽成纯函数便于钉住）。②**顺带修同族的反向病**：章节接口对**没看过**的集**不给 `collection` 字段**（线上实测：看过的集带 `{"status":2,…}`、没看过的是 `null`），而落库的 `update` 只在「有 collection」时写状态——于是在别处**取消**看过永远撤不掉（本地旧 `status` 被保留）。现在 `saveEpisodes` 新增 `authoritativeCollection`：整份替换 + **已登录**时把「没有 collection」当「没看过」归零；默认 **false**（未登录时整个响应都没有该字段，按 nil 归零会把本地已看状态清空）。验证：`Packages/BangumiKit` **55 用例全绿**（新增 7 条：服务端已看数领先 → 冷却归零后入选 / 冷却期内不重复拉 / 收藏记录更新即入选（计数相同也抓得住）/ 对得上且同步在后一条不拉 / 没有本地章节的不归它管 / 只看在看动画三次元 / 权威与非权威两种落库口径 + `episodeSyncTargets` 保序去重）。**反向验证**：把脱节查询改成恒空、`authoritativeCollection` 分支删掉 → **3 处断言红**（正是本条的两个机制），还原后复跑全绿。**另用真实库副本跑了一遍新查询**：本机 7 条在看动画里精确命中该重拉的 4 条（含报障的 554779）、另外 3 条一致的不动。

- **修「跳到接近片尾时播放器直接进错误态」：seek 落点距片尾的安全边际从 0.5s 提到 3s**。原先所有「跳到接近片尾」的落点（续播定位 / `skip(by:)` / 章节与 MediaSegments 跳过 / 保底跳过片尾）统一钳到「片长 − 0.5s」，而 0.5s 会让内核在文件**末尾那几 KB** 上做同步读取；那次读空 / 断时 Erika v0.2.1 把「文件结束」报成 `av_read_frame: Input/output error (-5)` 的 fatal，播放器直接进 `.error`（2026-10-12 实测复现、逐字一致；同形态问题在 2026-10-09 的 iPad 片尾也出现过）。3s 在常见码率下约 1.5–4 MiB，被默认 2 MiB 预读窗口覆盖——尾读在播到片尾前就完成，不再有「临门一脚」的同步读。**修法是把四散的口径收成一处**：新增 `PlaybackController.endOfFileMarginSeconds`（唯一事实源）与 `clampedBeforeEnd(_:duration:)`（唯一钳法），四处调用点全部改走它；片长未知（0）时不钳。**「保底跳过片尾」的保留档位 0 / 5 秒随之被兜到 3s**（设置文案同步改成「不保留也会停在片尾前 3 秒」）——贴片尾的落点正是这条 fatal 的触发条件，不能让一个设置档位绕过防线；档位本身保留（用户仍可表达「不保留」的意图），只是实际落点受边际约束。顺带把保底跳过片尾那条日志从 `PlaybackLog.append` 收成 `PlaybackLog.info`，并在落点**被边际钳制**时多记一行——钳制是静默的，不记就无从归因。验证：`SkipPreferenceTests` 新增 4 条（0 档钳到边际 / 片长未知时不钳 / `performSkipMark` 的落点被钳 / 落点在文件内时不受影响），macOS 534 用例、iOS 540 用例全绿。
- **修「集列表加载失败」挂出 `Error Domain=NSURLErrorDomain Code=-999 已取消` 裸 dump，且那次访问永远不自愈**（用户截图指认 + 诊断日志实锤）。进剧集详情页后集列表请求被页面层取消（macOS 26 上 `.task` 被取消且不重启——与 `DetailViewModel` 既有注释「实测那个 task 只在页面初现时跑了一次」、以及「被盖页不发 onDisappear」是同族现象），URLSession 抛的是 `URLError`（NSURLErrorDomain, -999），与 `CancellationError` **无子型关系**——`catch is CancellationError` 接不住它，落进兜底 catch 把裸 NSError 全文写进 `episodeLoadError`；而成功路径不清错误、task 又不重启，错误条驻留到重进页面。日志佐证：13:49:08 进详情页 `/Items`、`/Similar`、`/Seasons` 全部成功（47–187ms，网络无任何问题），`/Episodes` **一条日志都没有**（Jellyfin 路径的取消被刻意不记日志，这正是「被取消」的特征签名），之后 13 分半零请求，14:02 重进才恢复。修四层：①**判据统一**——`loadEpisodes` / `loadMembers` / `load()` 三处 catch 换 `catch where JellyfinError.isCancellation(error)`（包内现成判据，同时覆盖 `CancellationError` 与 `URLError.cancelled`），取消一律静默，不再误报「加载失败」/「正在展示缓存」；②**成功自愈**——集列表加载成功后清 `episodeLoadError`，盖掉「旧取消 attempt 的 catch 落在新 attempt 清空之后」的竞态窗口；③**取消补拉**——取消且季未变、数据未到时排一次 500ms 静默补拉（同轮访问上限 2 次，成功 / 换季 / 重进页复位；视图 `onDisappear` 撤掉待补拉，而被盖页不发 onDisappear，被盖场景补拉照跑——正是要救的场景），集列表不再因取消空转；④**取消留痕**——Jellyfin 路径的 `send()` 此前对取消「照抛不记日志」（排查时无从归因的直接原因），Emby 路径反而把取消记成 `.error` 级「请求失败」，两处统一为 info 级「请求被取消（任务取消，非故障）」。验证：新增 `DetailLoadCancellationTests` 5 条（取消静默 + 补拉就位 → 补拉成功后集列表就位且计数复位 / 陈旧错误被成功洗掉 / 补拉上限 2 次 / 首拉取消不写整页错误、不误报 staleNotice / 成员取消静默），**未打补丁时 4 条红**（陈旧错误一条旧代码已绿，保留作行为钉），打补丁后全绿；macOS scheme 全量测试通过、`Packages/JellyfinKit` 192 用例全绿（其中顺手同步 747f923 漏改的两条 `item()` fields 断言——`PrimaryImageAspectRatio` 加进 fields 时没更新测试，属存量红、与本次无关，单独提交）。

- **修「打开媒体库时顶栏整条变白 ~0.3s、空态鬼影与新网格叠化」**（用户录屏 + 截图指认）。把录屏逐帧抽出定位：三次 push 落地（电视剧 1.15–1.45s、电影 ~5.2s、合集 ~9.05s）顶栏换项瞬间整条纯白、~0.3s 后才动画回透玻璃；两次 pop 落地工具栏项同样切换却**从不白**——把病灶钉在「落地页 body 由什么承载」上，而不是换页本身。两个病同窗、两个根：①**裸 `EmptyState`（`ContentUnavailableView`，理想尺寸恒 400×400）把尺寸链连着氛围背景层一起塌掉**——顶栏玻璃底下没图，露出系统不透明白底。这正是 `PageFillingState` 文档与 CHANGELOG 三条判例（Bangumi 合集列表 / 每日放送 / 首页错误态）修过的同一类病，**本页是最后一个漏网的根级裸用方**（六种 frame 撑法实测全救不回来，只有 ScrollView 载体有效）；②**落地首帧先于 `.task`**，body 落到空态分支，「这里还没有内容」出一帧后被 `.motion` 拉成 0.2s 交叉淡变、与新网格叠化。修法两处都在 `LibraryView`：**两个空态分支包进 `PageFillingState`**——此后 body 四态（骨架 / 失败 / 空态 / 网格）全部由滚动容器承载，尺寸链不再塌，连「筛选出 0 条」「加载失败」「空库」这类**稳态**顶栏发白一并消掉；**落地首帧直接渲染骨架**——复用 `lastLibraryID == nil`（`.task` 首跑前恒 nil）作「还没开始加载」信号，不新增状态。刻意不用 `isLoading = true` 初值：`loadMoreFooter.onAppear` 的 `!isLoading` 闸门与 `.task` 同帧竞争，会把缓存页复访的第 2 页自动预取吞掉（LazyVStack 的 onAppear 不会重触发）。**修完用户复测仍报「加载时顶栏一大块白」**——第二层根因：骨架屏的 ScrollView 挂着 `.scrollDisabled(true)`，布局上撑得住尺寸链、材质判定却不认它（在 `load()` 里人工加 2.5s 延迟拉长骨架期录屏实锤：落地 ~0.6s 后顶栏翻白，与用户描述吻合；此前本地服务器骨架期只有 ~0.2s，录屏恰好没赶上翻白）。修法对齐 `PageFillingState` 的做法：骨架内容高度 `containerRelativeFrame(.vertical)` 锁到视口——ScrollView 是活的、内容不溢出 → 没有滚动条可闪（系统常显滚动条下 `scrollIndicators(.hidden)` 实测压不住，弃用），自然也不需要 `scrollDisabled`；折页以下的骨架卡本来就看不见。**没挂** `toolbarBackground(.hidden, for: .windowToolbar)`——DetailView 那行是氛围化设计的动机，这里用仓库正统修法即可。两段式换页的「空底谷」（内容整体淡出→淡入 ~0.95s，`7fd9e06`）是设计行为，本次不动。验证：macOS scheme 全量测试通过；换 /Applications Debug 构建连真服务器，CGEvent 合成点击 + `screencapture -v` 录屏逐帧对照修前基线——**换项瞬间（修前纯白的精确时刻）顶栏已是透玻璃**、人工延迟的 2.5s 长骨架期顶栏全程透玻璃且无滚动条（修前同条件 ~0.6s 即翻白）、pop 前后无白条、骨架→网格交叉段无空态鬼影。

- **修上一批合集改动里我自己引入的三处缺陷（自查发现）**。①**「确定没有」与「请求失败」被混成一个 `false`**：`TMDbEnricher.refreshCollection` 返回 `Bool`，于是「TMDb 上确实没有这个合集」（确定结论）与「断网 / 401 / 429」（可重试）在调用方看来完全一样，而 App 层一律当成确定结论记账 —— 症状是**一次网络抖动就让合集卡此后永久空白，只能重启 App**。现在返回现成的 `RefreshOutcome`（`.skipped / .fetched / .noMatch / .failed`，提为 `public` 并新增 `isConclusive`），定位阶段也拆出 `CollectionResolution` 三态（`.found / .noMatch / .failed`）：**拿到过响应但都没归集合 = 确定没有；一个响应都没拿到、全是失败 = 网络问题**。特别地，旧写法 `try? await client.movie(...)` 把网络错误整个吞掉，正是混淆的来源。②**库卡封面把成员请求失败吞成「这个合集没海报」**：`(try? await server.collectionMembers(...))?.items ?? []` 之后无条件记账，同一类症状的第二个版本。现在标记 `memberLookupFailed`：**拼出图就存下并记账**（画面已可用），**一张都没拼出且没有失败**才记账（确定没有），**一张都没有且有失败**则不记账、下次进入可视区再试。③**一致性**：我在 `MediaServer.collectionMembers` 写了「三条约束收成唯一一份，别再各写一份」，却**漏改了播放路径**——`resolvePlayableMember` 仍用裸 `itemsPage` 加自己的一份常量。现在三处调用点（播放挑选 / 详情页分页 / 库卡拼图）全部走同一个封装，`collectionMembers(of:startIndex:limit:)` 补上 `startIndex` 以覆盖分页场景，两份重复常量（`collectionMembersLimit` / `membersPageSize`）删除。验证：`TMDbCollectionTests` 由 7 条增至 11 条（新增：全部成员详情请求失败 → `.failed` 且**不落库**且不去拉合集详情 / 详情成功但都没归属 → `.noMatch` 且 `isConclusive` / 个别成员 404 不影响另一个成员定位成功 / 缓存命中 → `.skipped`），既有 5 条断言从 `XCTAssertFalse(didFetch)` 升级为精确的结局断言；`CollectionDetailTests` 由 23 条增至 25 条（成员请求失败且无海报 → 不记账 / 部分合集失败但拼出图 → 存下并记账）。**反向验证**：把 `resolveCollection` 的失败分支改回 `.noMatch` → MetadataKit **3 条红**；恢复后复跑全绿。实跑：`Packages/MetadataKit` 11 条（全包 155 + swift-testing 50）、macOS scheme **457** 用例全绿。**覆盖缺口已在紧随其后的一批里关闭**（起初如实记为缺口：App 层「按 `outcome.isConclusive` 决定记不记账」那几行**没有直接测试**——`TMDbCoordinator` 的客户端硬编码、换不掉 TMDb 的网络，造不出「请求失败」的场景；当时把该判断改回无条件记账，用例**照样全绿**）。修法是给协调器开注入点：`TMDbCoordinator.init(defaults:sessionConfiguration:)` 接受一个会话配置（nil = 生产用的独立会话，行为逐字不变），测试传 `MockURLProtocol` 的配置即可替换 TMDb 网络。新增 3 条 `CollectionDetailTests`：**TMDb 请求失败时不记账**（即该缺陷的回归用例）/ **TMDb 明确没有对应时记账**（成对，把两种结局钉死在 App 层）/ **断网失败 → 恢复后重试成功**（收益闭环）。关闭判据是**反向验证**：把判断改回无条件记账 → 这次 **2 条红**（此前同一次注入是全绿的）。
- **合集页面去掉 Bangumi 章节区，背景图改由 TMDb 合集补上**（接上一条合集修复，用户实测反馈的两点）。①**Bangumi 章节区对合集是纯噪声**：那一栏列的是「按集数组织的作品」的章节，而合集是「多部电影的容器」，两者不是一回事。实测 EVA 合集页上它自动匹配到了**同名剧集**、列出「新世纪福音战士」TV 的 01…26 集「未看」格子——26 个格子没有一个能点进合集里那两部电影，还占掉整屏。现在 `DetailView` 对 `.boxSet` 整块不渲染（连带它的自动匹配 / 远端补齐也不会跑）。②**背景图走 TMDb 合集**（原本页面是一片纯色底）。合集自己在服务端**没有可用的 TMDb 入口**：实测手工建的合集 `ProviderIds` 是空 Map，按名字搜又撞上名字不一致（Jellyfin「新世纪福音战士新剧场版（系列）」vs TMDb「福音战士新剧场版（系列）」）。真正权威的线索在**成员**身上——电影详情的 `belongs_to_collection` 直接写着归属，实测同一合集的两个成员给出**同一个** id（EVA → 210303、中二病 → 1192656）。于是新增 `TMDbEntityKey.collection` / `TMDbMediaType.collection` / `TMDbClient.collection(id:)`（`/collection/{id}`，实测带我们那套 `append_to_response` 也返回 200）与 `TMDbEnricher.refreshCollection(item:members:tenant:)`：逐个成员的 `ProviderIds["Tmdb"]` 查 `/movie/{id}` 取 `belongs_to_collection.id`（**刻意不用 `fetchAndStore`**——那会覆盖该电影的缓存载荷，而这里只是借一步查归属），拿到后落库 + 拉合集详情。**三条刻意的边界**：a)**不做名字搜索兜底**——那种场景（TMDb 知道合集、但成员的 `belongs_to_collection` 缺失）下名字搜索每次打开合集页要多打 1 次搜索 + 最多 3 次详情且失败不落库（下次还会再试），而猜错的代价是整页背景/海报/简介都来自**另一个合集**；实测的兜底改为**零成本**的「用第一个带背景图的成员」（`collectionBackdropFallback`，jellyfin-web 对合集卡也是拿子项图顶上），且只在合集上生效。b)**不用合集条目自己的 `ProviderIds["Tmdb"]`**：Jellyfin 的 TMDb 合集 provider 理论上会写它，但本机是空的、**没有样本可验证**它写的是不是合集 id，拿没验证过的语义去请求，错了就是错误的背景图。c)**成员没有 TMDb id 时一个请求都不发**（剧集成员同样跳过——TMDb 的 collection 只装电影）。命中缓存（link + 未过期 payload）时**零请求**早退，这是成本闸门：合集页每次打开都会调它，实测第二次打开不发任何请求。③**标题用服务端名、不给 TMDb 顶替**：合集名是用户在 Jellyfin 里起的**标签**（不是作品正式标题），顶替会让页面标题与合集库/侧栏对不上；简介仍按既有策略由 TMDb 补缺（实测合集服务端 `Overview` 为空，TMDb 有「再构建作品…」）。④顺带修一处**同源的隐性不一致**：详情页的氛围层原本用 `shown.imageTarget`（只看服务端 tag）而 `isAmbientActive` 也只看服务端 tag，两者恰好一致所以看不出问题；一旦图片可能来自 TMDb / 成员兜底，就会「走了氛围布局却画不出图」。现在统一走 VM 的 `backdropTarget` + 新增的 `hasBackdrop`（服务端 tag → TMDb → 成员兜底，与取图同一条判定）。**未覆盖**：合集库网格里的合集卡仍是服务端图（网格没有 overlay 数据，仍显示「一叠海报」占位图标）；TMDb 没对应时没有背景图就用成员图，两者都没有才回纯色底。验证：`TMDbCollectionTests` 新增 7 条（成员路线定位到 `.collection(210303)` 且**不搜名字** / 第一个成员无归属时落到下一个成员 / **命中缓存零请求** / 成员无 TMDb id 时零请求且不落库 / TMDb 无对应时不落库 / 剧集成员不参与定位 / 脏 ProviderIds 忽略），`TMDbClientTests` 新增 4 条（`belongs_to_collection` 解码、没有该键时为 nil 而不是 0、`/collection/{id}` 路径与 `name`→`title` 解码、合集键形状），`TMDbOverlayTests` 的实体键往返用例纳入 `.collection` 并加了拒绝 `collection/abc` 这类脏串，`CollectionDetailTests` 新增 7 条 App 层接线用例（真 AppModel + 真 SQLite：合集保留服务端标题 + 简介由 TMDb 补 / 剧集仍 TMDb 优先 / 成员背景兜底取第一个**有图**的成员 / 一个成员都没图时无背景 / 非合集不许借成员图 / 服务端图优先 / 没配 key 或没成员时整条路静默无操作）；`CollectionDetailTests` 里显式 `app.tmdb.attach(store:)`——补全服务在 `bootstrap()` 里装配而测试宿主整段跳过 bootstrap，不补这一步 `enricher` 恒为 nil、overlay 永远读不到，用例会「碰巧通过」。**反向验证**：把合集标题的 preferTMDb 改回统一策略 → 标题用例红；把 `hasBackdrop` 短路成只看服务端 tag → 成员兜底用例红；把命中缓存的早退禁用 → MetadataKit 的零请求用例红（2 处断言）；三处恢复后复跑全绿。实跑：`Packages/MetadataKit` **155 用例（+swift-testing 50）**、macOS scheme **446 用例**、iOS 模拟器（iPhone 17 Pro）**446 用例**全绿。
- **合集（Jellyfin / Emby 的 Collection / BoxSet）之前只是一个「空壳条目」：详情页没有成员列表、主按钮必然播失败、封面每次渲染都打一次 404**。三件事同一个根：**服务端的合集能力一条都没接**。①**没有成员列表**——`MediaItem.Kind.boxSet` 早就在映射表里，但详情页只有 `kind == .series` 才去拉子项（`DetailView` 的季/集分支），全仓库**没有任何一处**用 `itemsPage(parentID: <合集id>)`；现场佐证：`Media.sqlite` 里两条 boxSet 行的 `childCount` 只有详情接口才返回，写入时间是 2026-10-06 22:10:22 / 22:10:25——紧跟在合集库分页（22:10:22）之后 3 秒，即用户把两个合集都点开过，看到的就是一个标题 + 一个播放键。②**主按钮必失败**：`resolvePlayableItem` 只特判 `.series`，合集把自己原样送进协商；实测（本机 Jellyfin 12.1.0，只读 GET）`/Items/{合集id}/PlaybackInfo` → **400**、`/Videos/{合集id}/stream` → **400**、`/Items?ids={合集id}&fields=MediaSources` 的 `MediaSources` 为空、`/Items/{合集id}/Similar` 也是空。失败路径还特别隐蔽：PlaybackInfo 400 后走「回退直连」分支，而 `streamURL` 只拼字符串不抛错，于是**播放器照样弹出来**、内核再去开那个 400 的地址 → 用户看到「点播放 → 播放器闪一下 → 报错」，全程没有一句解释。③**封面 404**：`imageTarget` / `LibraryCard.coverTarget` 不管 tag 是否存在都拼 URL，而服务端返回的 `ImageTags` 正是「有没有这张图」的事实来源（实测合集库 `/UserViews` 是 `ImageTags: {}`、两个合集条目同样是空 Map、Jellyfin 手工建的合集默认不带图），`RemoteImage` 拿到 404 后显示的占位与「url == nil」分支**完全一样**——纯亏一次请求；诊断日志里 `图片请求返回非 200` 累计 18 条，其中跨 4 个会话反复出现的就是合集库那条 `/Items/e7bfe656…/Images/Primary`。**修法**：①合集详情页新增「合集内容」网格——`DetailViewModel.loadMembers` 走 `itemsPage(parentID: 合集id, recursive: false)`（**recursive 必须是 false**：合集里可以放剧集，递归会把季与集一并拉出来；**排序显式给年份升序**：不传 sort 时服务端对合集子项的顺序不稳定，实测同一合集 `recursive=false` 与 `true` 两次顺序不同，而合集自己的 `DisplayOrder`（PremiereDate）不在 `MediaItemsSortField` 值域里），成员可点进各自详情，带加载 / 空 / 失败三态与「加载更多」（一页 200，`totalRecordCount` 大于已加载数才出按钮，**不自动预取**：合集通常一页装得下）；成员进 `DetailSnapshot`，再次进入先出快照再被网络原位覆盖，与季/集同一套 SWR。②`resolvePlayableItem` 对 `.boxSet` 解析成**第一个没看过的成员**（全看过则第一个；成员里只有剧集时回到剧集自己的解析规则，复用 nextUp/resume 与「第一个未看常规集」），解析不出内容时按类型给文案（`noPlayableContentMessage`：合集说「这个合集里还没有可播放的内容」而不是「该剧没有可播放的剧集」）。③`MediaItem.imageTarget` 与 `LibraryCard` 在**没有 tag 时不发请求**，`RemoteImage` / `MediaArtwork` 新增 `emptyIcon`（默认 `photo`）供合集换成「一叠海报」图标（`rectangle.stack.fill`），合集库卡片与合集条目卡片都不再是一张破图。**刻意没动的一处**：合集库网格的 `itemKinds` 仍是 nil（不传 `includeItemTypes`）——Jellyfin 有已知 bug（[#16454](https://github.com/jellyfin/jellyfin/issues/16454)，10.11.6 上 `parentId` 遇上 `includeItemTypes=BoxSet` 会被忽略并返回库而不是合集），显式加类型过滤在 12.1.0 实测无害、在旧版本会踩坑，所以维持现状并就地写明原因。**未覆盖**：Emby 的 `GroupItemsIntoCollections`（文档语：*hide items behind their boxsets*，官方客户端靠它在电影库里用合集替换成员；Jellyfin 12 的 SDK 已无此参数），以及演员头像（`castImageTarget` 直接拼 URL，`MediaItem.Person` 不携带 tag，本次不动）。验证：`CollectionPlaybackTests` 新增 7 条（第一个未看过成员 / 全看过取第一个 / **入参形态**钉住 `recursive == false` + `parentID` + `kinds == nil` + 不做服务端观看过滤 / 空合集解析为 nil / 成员只有剧集时递归到剧集规则 / 查询失败往上抛而不是静默返回合集自身 / 文案按类型），`CardImageTargetTests` 新增 5 条（Primary/Thumb/Backdrop/Logo 无 tag 一律不出 URL、有 tag 时 URL 里必须带条目 id 与 tag、无 server 时双 nil、首页横版图链不受影响），`StubMediaServer` 新增 `itemsPageResult` 与 `lastItemsPageQuery`（替身的 `imageURL` 补上 `tag` query，与真实实现同形，否则「tag 进 URL」这条断言没有意义）；`MetadataCacheIntegrationTests.testPlaceholderThumbPrefersTMDbStillThenFallsBackToSeriesImage` 的断言随替身一起拆成「路径 + tag」两段（原先是整串字面量，钉的是同一个语义、但会被取图参数的无害调整弄红）。**反向验证**：临时把 `.boxSet` 分支与「无 tag 不发请求」两道判断各自短路，合集用例 **5 条红**（含「空合集应为 nil」——它会退回把合集自身当可播条目）、取图用例 **2 条红**；恢复后完整套件 **432 用例全绿**（macOS）。
- **修「多设备同账号下 Bangumi 已看数据倒退」：标一集「看过」会把条目强制打回「在看」，v0.1.5 起全部版本中招**。根因是**读「我在这个条目的收藏状态」的接口根本不存在**：`BangumiCollectionService.getSubjectCollection` 请求 `GET /v0/users/-/collections/{id}`，而 Bangumi 只把 `-`（当前用户）注册在 **PATCH/POST** `/v0/users/-/collections/{id}` 上（`bangumi/server` 的 `web/routes.go`），这个 GET 会落进公共路由 `/users/:username/collections/:subject_id`，`username = "-"` → 查无此人 → **恒定 404**。实测（2026-10-07，本机）：`curl https://api.bgm.tv/v0/users/-/collections/17883` → `404 {"description":"user doesn't exist or has been removed"}`；而正确路由 `GET /v0/users/868609/collections/17883` → `200`。客户端把 404 一律当成「用户没收藏」返回 `nil`，`targetWatchingState(for: nil)` 于是恒返回 `.doing`，**每次标「看过」前都先 POST `{"type":3}`**（手动点章节与播放结束自动标记是同一个入口）——已看 → 在看，即为用户报的「已看数据倒退」；读接口恒假，还让「全部本篇看完 → 自动转看过」永不触发、条目详情页永远拿不到服务端收藏态。**现场实证**（`~/Library/Logs/OcPlayer`，本地 23:02–23:05）：`请求失败 path=/v0/users/-/collections/554779 error=status(404)` → `播放联动：条目推进为在看 subject=554779`，而 554779 在本机库里 22:58 还是「想看」（`ctype=1`），事后服务端已是 `type=3` / `updated_at=2026-10-07T23:03:01+08:00`；同一时段 568244 的 `updated_at` 也被顶到 `23:04:53`。引入点 `186b756`（错 URL，08-23）与 `128f083`（强制推进，08-29）同属 **v0.1.5**（08-30 发布），故影响窗口为 v0.1.5–v0.2.1。**修法三层**：①读取改走真实存在的公共路由 `GET /v0/users/{username}/collections/{subject_id}`（username 取 `BangumiProfile.username`，缺则退回数字 id，`/` 做 path 转义）；②返回值从「`nil` 兼表两义」换成三态 `BangumiCollectionLookup`（`.collected(_)` / `.notCollected` / `.unknown(reason)`），并**按 404 响应体区分两种 404**——只有含 `subject is not collected by user` 才算没收藏，`user doesn't exist or has been removed` 与空 body 一律 `.unknown`；③**所有写服务端的决策都拒绝消费 `.unknown`**（`targetWatchingState` 对 `.unknown` 返回 `nil` 即不写，`reconcileSubject` / 详情页只在 `.collected` 时覆盖本地）。顺带修掉同一函数里两个从未被执行过（因为请求恒 404）的缺陷：`updated_at` 在 wire 上是 **ISO8601 字符串**而不是 unix 秒，旧代码用**本地 `Date()` 冒充服务端时间**填 `interest.updatedAt`——它落成 `collectedAt`（进度页/收藏列表的排序键），一旦请求通了会把每次回读的条目顶到列表最前，现在改为解析 ISO8601（含小数秒兜底），解析不出来按 `.unknown` 处理、不拿本地时钟顶替。**另修两处同主题的「数据倒退」**：①**本地已看数会改小**——`updateEpisodeCollection` 标记后无条件用「本地章节表里已看的本篇数」覆盖 `epStatus`，而「看过」条目**永远不做章节补齐**（`fetchSubjectIDsMissingEpisodes` 只挑「在看」），本地表天然落后：本机库里 255209 / 638497 服务端 `ep_status = 13`、本地只数得出 12，用户在进度页点一集反而把已看写回 12。现在规则改为**标「看过」只允许往上推，只有明确的「取消 / 改其它状态」才允许下调**（服务端权威值仍由收藏同步与回读全量覆盖，单调性只约束本地推导这一条路径）；②**增量同步水位线没有重叠**——`since` 取「同步开始秒」且服务端按 `updated_at > since` 过滤，同一秒内的变更（以及设备时钟偏快时整个偏差窗口）会被永久跳过，多设备下被放大；查询改为回看 `since - 300s`，写入仍用「同步开始」（失败不推进水位不变），重叠区间重复拉到的条目 upsert 幂等。（附一条**没能实证**的记账：`since` 的边界语义无法离线验证——它只声明在需要鉴权的 `/p1/collections/subjects` 上，公开的 `/p1/users/{username}/collections/subjects` 直接忽略该参数，实测 since 传任何值都返回全部 528 条；此项按稳健性加固处理，不是本次的主修复。）验证：`Packages/BangumiKit` **46 用例全绿**（新增 5 条：`subjectCollectionURLUsesUsernameRoute` 钉住路径必须是 `/v0/users/{username}/collections/{id}` 且**不含** `/users/-/collections/`、`collectionLookupClassifies404ByBody` 钉住「用户不存在」的 404 必须解成 `.unknown`、`collectionLookupDecodesRealResponseAndTimestamp` 用真实回包钉住 ISO8601 → unix 秒、`localProgressNeverRegressesOnMark` 钉住标看过不改小 / 取消可下调、`targetWatchingStateOnlyAdvancesConfirmedStates` 覆盖 `.unknown → nil`），并按惯例做了**反向验证**：临时把 URL 还原成错路由、404 一律当未收藏、`updatedAt` 还原成本地 `Date()`、进度还原成无条件覆盖，**4 条新用例全部报错**（共 8 处断言失败，含 `epStatus` 被写成 12 的现场复现），还原后复跑全绿——不是恒真断言。**注意**：旧用例 `targetWatchingStateOnlyAdvancesNonDoing` 里那句 `#expect(targetWatchingState(for: nil) == .doing)` 正是把本 bug 当契约钉住了，已重写。受影响账号的**服务端数据无法自动还原**（本地库没有条目历史，判断不出被打回之前的原始状态），需要在 bgm.tv 时间线按 2026-08-23 之后的区间人工核对。

- **修复首页「最近添加」整条消失（静默丢栏）**。`JellyfinServer.latestItems` 此前打 `/Items/Latest` 并带 `includeItemTypes=Movie,Series`，而 **Jellyfin 12.1.0** 上该端点**一带这个参数就恒返回空数组（HTTP 200）**——空数组是「成功值」（不是失败），于是 `home.latest = []`、Rail 的 `if !isEmpty` 不成立 → 整条 rail 不渲染，**连 `首页 rail 加载失败` 都不打**（用户侧表现就是「最近添加突然不显示了」，且没有任何错误提示）。实测（2026-10-07，本机 `100.64.1.96:8096` / ServerId `7fbb1313…` / Version **12.1.0**，用 App 自己的凭据与请求头）：`/Items/Latest?userId=…&includeItemTypes=Movie,Series&limit=24` → `[]`；同一个请求**去掉** `includeItemTypes` → 10 条（且混着 Episode/Season）；换成 `Movie` / `Series` / 小写合并写法一律空；服务器自带 OpenAPI（`/api-docs/openapi.json`）**仍声明**该参数、也没标 deprecated，所以这是服务端行为回归、不是接口移除。诊断日志佐证（`~/Library/Logs/OcPlayer`，10-04 起 7 次启动完全一致）：`请求成功 path=/Items/Latest` 从无失败、`首页 rail 加载失败` **0 条**、`Jellyfin 请求失败` **0 条**，而启动行 `首页用磁盘缓存预热` 恒为 `latest=0`（nextUp 6 / resume 4）。**修法是换端点，不是补参数**：`groupItems=false` 能让该端点出内容，但同一次实测只给 15 条、且**漏掉真正刚入库的条目**——`/Items` 的 43 条里「药屋少女的呢喃」「FX战士久留美」「一个部门的诞生」一条都不在，用户会看到「最近添加不全 / 顺序不对」，所以它只是把「全空」换成「看起来对但缺项」的次生故障。改用 `/Items` + `isRecursive: true`（默认 false 只返回顶层项）+ `sortBy: [.dateCreated]` + `sortOrder: [.descending]` + `includeItemTypes: [.movie, .series]` + `enableImageTypes`——与本文件 `favoriteItems`、库页「排序 = 最近添加」（`MediaItemsSortField.dateAdded` → `DateCreated`）**同一个已在用、10.x 起就稳定**的口径；注意返回的是信封 `BaseItemDtoQueryResult`，不再是 Latest 的裸数组。协议 `MediaServer.latestItems(limit:)` **签名不变** → `EmbyServer`（仍是老式 `/Users/{id}/Items/Latest` + 裸数组，无此参数问题）/ `CachedMediaServer` / App 层 / 测试替身零改动。**顺带纠正一条此前写死的错误结论**：`HomePresentationTests` 与 `MetadataCacheIntegrationTests` 的注释把「本机 latest 恒为空」当成「这台服务器没有最近添加」的固有形态——那其实就是本 bug 的症状；那些用例守的是「latest 为空时三态判定不能错」（合法且常见的服务器形态），**语义与断言都不变，只改注释**。验证：`JellyfinKit` 新增回归用例 `testLatestMediaUsesItemsSortedByDateCreatedInsteadOfLatestEndpoint`（一次钉住三件互相关联的事——**端点**必须 `/Items` 而非 `/Items/Latest`、**排序口径**为入库时间倒序、**信封格式**），`Packages/JellyfinKit` **191 用例全绿**；该用例在**临时还原旧实现**的对照下报 **6 处断言失败**（不是恒真断言），改回后复跑全绿。macOS Debug 构建通过后真会话实跑（`OCPLAYER_START_SECTION=home`）：网络日志只剩 `path=/Items`、`/Items/Latest` 彻底消失，无 `rail 加载失败`，rail 缓存 `latest` 由 **0 → 24**，第二次启动的预热行读出 `latest=24`（磁盘缓存已真的存下内容）；首页「最近添加」栏海报卡出现、按入库时间倒序（最新在最前），**上述三条曾被 `groupItems=false` 漏掉的条目都在图上**。

## [0.2.1] · 2026-10-06 · 设置页重构为 hub 首屏 + 子页、TMDb 元数据补全、内核换装官方 v0.2.1

### 改动

- **播放内核升级到上游 `v0.2.1`**（fork/上游 commit `70f12bf`）。上游 release 见「AimesSoft/Erika」v0.2.1，与本 App 相关的变化：
  - **资源回收**：关闭、切换媒体和 seek 时取消旧的网络读取；销毁播放器时等待后台 worker 退出、释放连接与线程；`stop()` 释放 HTTP 缓存与队列占用（保留从头重播能力）。
  - **预读窗口**：修复预取跨越条带边界后继续读取的问题，预读窗口按配置生效（`v0.1.9+dolby.streaming.fix` 里「预取窗口无界」那条线的延续）。
  - **解码**：恢复硬件解码不可用时的软件回退（WMV/WMA、8/10-bit AV1）；修正 P010 插值，保留完整信号精度。
  - **iOS 弹幕/字幕同步**：内核新增 `erika_presenter_render_tick_with_timing` C API——传入「到显示目标时间的延迟」（如 `CADisplayLink.targetTimestamp - CACurrentMediaTime()`），弹幕、字幕与渲染上下文按同一显示目标采样播放快照，渲染繁忙时同步更稳。**本版本仅升级 vendored 二进制与 `erika.h`，App 侧当时仍走 `render_tick`；后续已在 `[Unreleased]` 里接入**（延迟按内核 ±0.25 s 硬约束夹取，超界退回无 timing 路径）。
  - **C ABI 纯新增**：`erika.h` diff 仅有新枚举值 `LinuxExtendedLinearScRgb`、新函数 `render_tick_with_timing` 与 Linux 专用的 `copy_flutter_frame_rgba`；`ErikaOpenOptions` / `ErikaPresenterConfig` 布局未动，App 侧零适配。
  - 钉点：`Config/Erika.version` → v0.2.1，新增 `Scripts/erika-v0.2.1.sha256`（两包哈希与 release 自带 `SHA256SUMS` 一致）。
  - 验证：`Packages/ErikaKit` 全量 30 测试（离屏渲染 / C ABI 冒烟 / 真文件打开 / HTTP 直连 / 播放生命周期 / 内存快照 / 预读行为，CI 因无 GPU skip 的套件本地全跑）全绿；macOS App 测试全绿；iOS 模拟器 **349** 测试全绿；其余 SPM 包全绿。
- **弹幕字号改为百分比调整（±10% 步进）**。HUD 弹幕菜单的「字号」原为 4 档单选（小 / 标准 / 大 / 特大），现改为与字幕「字体大小」一致的**减小 / 重置 / 加大**，根行直接显示百分比（22pt = 100%）；步进取基准的 10%（2.2pt，连加时百分比始终落在整数档），范围放宽到 **50%–200%**（11–44pt，边界正好落在整档位上）。存储键与格式不变（原始像素 Double），旧档位值无需迁移。
- **设置页重构为「hub 首屏 + 子页」**。原先单页 11 组约 65 行（iPhone 要滚 5~6 屏），TMDb / MoviePilot 配置得越全越长；现在一级页收成 4 组 11 行导航行，每行带**当前值预览**（Jellyfin 服务器名 / Bangumi 账号 / MoviePilot 登录态、播放内核、弹幕加载方式、首页栏目数、TMDb 启用态、版本号），不进子页就能看到现在什么状态；说明文字全部随功能进各自子页。
  - **子页**：播放（含内核）/ 首页栏目 / 弹幕 / 网络 / Jellyfin / Bangumi / MoviePilot / TMDb 元数据补全 / 维护 / 关于。`@AppStorage` 状态随功能迁移到子页（互相不再牵连失效）；更新检查随行进关于页、MoviePilot profile 刷新随行进子页。
  - **hub 子页路由走 `Route.settingsSubpage`（path 驱动）**而不是 `navigationDestination(isPresented:)`：子页还会再推叶子页（Jellyfin 页推「管理服务器」、关于页推「开源许可证」），isPresented 页面不在 path 上，祖先要 `coveredByPresented` **逐层登记**才不会透过半透页面漏底；path 驱动的页面由 `appRouteView` 统一挂 `coveredPageHidden / routeExitFade / pageEntrance`，整条链自动处理。叶子页（不再下推别的页面）保留原 isPresented 模式。
  - **破坏性操作全部补确认**（原先全部点了立即执行）：退出 Jellyfin / Bangumi / MoviePilot、清空图片缓存、清空媒体元数据缓存、清除 TMDb 补全数据、清空日志。
  - **iPhone 调优**：首页栏目上下移按钮热区 44×44（原先挤在 2pt 间距里误触率高）；TMDb Key 输入改纵排（行内 SecureField + 按钮会被键盘顶住）；`.roundedBorder` 仅 macOS 生效（iOS grouped 行内原生样式是无框）；值预览统一 `.lineLimit(1)` 中间截断。首页栏目排序沿用按钮方案（grouped Form 的 onMove 在 macOS 无入口，双端一致的刻意选择，未改）。
  - 验证：macOS（`Scripts/build-macos.sh`）与 iOS（`OcPlayer-iOS` scheme）编译通过，`OcPlayerTests` 全绿；iPhone 模拟器装 Debug 构建、真实会话下 `OCPLAYER_START_SECTION=settings` 截图确认 hub 一屏放下、值预览正确、氛围图透明行底保留。
- **TMDb 元数据补全（`Packages/MetadataKit/TMDb`）**。用户自填 API Key 后，详情页可用第三方元数据补充**简介、评分、类型、演员与海报/背景图**；未配置 key 时整个功能禁用、不发任何请求、不影响现有行为。
  - **匹配优先级**：服务端 `ProviderIds["Tmdb"]` 直连（置信度 1.0，不搜索）→ 标题+年份搜索兜底。搜索按六档打分，只有 **≥0.85**（标题精确 + 年份相符）才自动落库——**错误的匹配比没有匹配更糟**：用户看到的是别人的剧情简介和海报，而且显示得像真的一样。低置信度的候选只留给手动匹配面板（Phase 3）。
  - **实测查清一个陷阱**（本机 Jellyfin 12.1.0，`Fields=ProviderIds` 才返回）：剧级 `Tmdb=153217` 是**剧集 id**；季级**只有 Tvdb、没有 Tmdb**；集级 `Tmdb=3384539` 是**单集 id**。所以**集与季绝不能拿自己的 `tmdbID` 去查 `/tv/{id}`**——那是单集 id，会拉到另一部剧或 404。二者一律从**父剧**的对应推导为 `tv/{剧id}/season/{季号}`，判断收在 `TMDbEntityKey` 的唯一入口里，并有用例钉住（断言「绝不能拿单集 id 当剧集 id 用」）。父剧对应不存在时（用户直接从「继续观看」点进某一集）会先建起来。
  - **语言逐字段回退**：TMDb 不做回退——`language=zh-CN` 时没有中文翻译的字段返回**空串**（不是 nil）。所以判定用「非空」而非 `??`（用 `??` 会把空串当有效值，英文永远补不上），且**只补缺、不整包替换**（否则中文标题会被英文顶掉）。字段齐全时不多打那一次请求。
  - **季一次拿全**：`/tv/{id}/season/{n}` 一次返回整季全部集，不是每集一个请求——这是控制配额的关键。
  - **v3/v4 密钥都收**：`eyJ…`（v4 Read Access Token）走 `Authorization: Bearer`，32 位 hex（v3 API Key）走 `api_key` 查询参数。用户从 TMDb 设置页复制哪个都行，不该要求他先分清 v3/v4。v4 路径下 URL 里不含 `api_key`（有用例断言）。
  - **主动限流**：actor 令牌桶（并发 ≤4 + 最小间隔 120ms）。官方口径是「约 50 req/s 且必须尊重 429」，而批量补全一整个库很容易瞬间打出几百个请求——主动限流而不是等被拒再退避。429 尊重 `Retry-After`。
  - **两张表分开**（`tmdb_entity` / `tmdb_link`），因为生命周期不同：实体数据是**全局的**（同一部电影对谁都一样，故不带 `tenant_id`，两个服务器档案共用一份、省一次请求；只有**语言**让它分叉，故语言进主键）；对应关系是**每台服务器各自的**（条目 id 是服务端生成的）。分开的另一个好处：解绑/重匹配只动 link，不必丢掉已拉下来的实体数据。迁移是 v2 **纯加表**，v1 的老缓存全部有效（有用例断言）。
  - **叠加层不改写 `MediaItem`**（`TMDbOverlay`）：服务端数据是「当前事实」，TMDb 是可选增强。若混进同一个结构，「关掉 TMDb」就得把改过的字段改回去——而那时已不知道原值是什么。独立结构让「关掉」=「不再叠加」，天然可逆。
  - **文本与图片策略分开**：文本可以整份换语言；图片是否顶替已有图另有开关（**两者默认都是「TMDb 优先」**，见下面那条改默认值的说明）。分开的理由是「谁的图更好」没有客观答案——用户用刮削器精修过的海报被 TMDb 顶掉是**单向损失**，必须留一个关掉的出口。TMDb 图免鉴权，故取到 TMDb URL 时**不带**服务端认证头（给 CDN 发 Jellyfin 凭证既无意义、也多送一处）。
  - **失败不删旧数据**（404 例外）：旧数据比没有强，这正是缓存优先的价值。404 那个 id 在 TMDb 不存在，留着只会每次白查一遍。
  - **缓存期硬夹在 6 个月内**（默认 90 天）：TMDb 条款禁止缓存超过 6 个月，那是 ToS 约束不是工程取舍，所以不留给调用方自行放宽。
  - **合规**：设置页与 `OpenSourceLicensesView`「社区数据与服务」分组各有一份署名（`本产品使用 TMDb API，但未获得 TMDb 认可或认证。`），后者附条款链接。
  - **季与分集的补全**（用户实测反馈「分集可以用每集的标题和描述」「切季后描述没更新」）：分集/季虽然没有自己的详情页，但 TMDb 数据在**剧集页**上有三处展示面——分集卡片标题、分集简介（悬停提示）、以及**选中某季时的页面简介**。现在都会用上：
    - **分集标题优先 TMDb**。服务端对没有元数据的分集常给「第 9 集」这种占位名（实测库里就有），而 TMDb 有真标题（如「离别之时」）。占位名**无论文本开关如何都会被顶掉**——那不是用户的元数据，是服务端没数据的表现。
    - **切季更新简介**：选中某季时优先显示该季简介，**取不到回落剧集简介**（不少季在 TMDb 上没有简介，直接替换会让整段文字凭空消失）。
    - 季数据靠「父剧的对应 + 季号」定位（季没有自己的 TMDb id），入口收在 `seasonOverlay(seriesLink:seasonNumber:)` / `refreshSeason(...)`；未过期不重复回源（切季是高频操作）。
  - **图片策略默认改为「TMDb 优先」**（用户口径：「填了 key 就是想要完整补全，能用 TMDb 就用」）：海报 / 背景 / **分集剧照**三处都优先用 TMDb 的图，服务端已有的会被顶掉。仍保留一个开关——「谁的图更好」没有客观答案，用户用刮削器精修过的海报被顶掉是单向损失，必须留一个关掉的出口。
    - **分集剧照**接上了 TMDb 的 `still_path`（此前取到但没用）：服务端缺剧照时能补，默认策略下即便服务端有也以 TMDb 为准。
    - 踩到一个「同一个概念两个默认值」的坑：`TMDbImagePolicy.init` 的默认与 `TMDbPreferences.replaceExistingImages` 的默认一度不一致（前者 false、后者 true），于是「生产路径 TMDb 优先、测试里默认只补缺」，用例直接失败。已对齐并在注释里写明。
    - 验证：`Packages/MetadataKit` 98 用例全绿；**实机**确认 TMDb 图缓存 21 → 35（新增 13 张 w500，正好是 13 集剧照）。
  - **两个踩过的坑**（都写进注释与文档）：
    1. 季数据**不能**在 `.task(id: selectedSeasonID)` 里取——那个 task 在页面初现时就跑一次，而那一刻 `seasons` 还是空的（诊断日志：与 `/Seasons` 请求同一秒、`selectedSeason` 为 nil），之后 id 变化**并没有再触发它**。改为由 `load()` 末尾确定性地触发（那时 seasons 与父剧对应都已就位），视图 task 只负责用户切季。
    2. 占位集名判定**不要用 `\d`**——实测 ICU 的 `\d` 会匹配中文数字（「九」被判为 true），于是「第九集」这种真实标题会被误判成占位名、被 TMDb 顶掉。改用 `[0-9]`，且中日文形态只锚**结尾**（服务端还有「我的朋友很少 - S01E00 - 第 0 集」这种文件名派生形态）。
  - **提交前 review 又抓出 7 处问题**（用户要求先 review 再提交）：
    1. **设置页「已补全条目」恒显示 0**：`refreshTMDbLinkCount()` 定义了却**没有任何地方调它**——看着像功能没生效。已在区块出现时取一次（实机确认显示 4，与库里 4 条对应一致）。
    2. **坏 key / 连不上完全静默**：用户填了 key、翻了几页、什么都没发生，只会以为功能坏了。现在补全服务记录最近一次失败，设置页把它翻成可读原因（「API Key 无效或已被 TMDb 拒绝」/「连不上 TMDb（检查网络或代理）」…）。`notFound` 刻意不提示——那是服务端 `ProviderIds` 脏数据，用户无法处理。
    3. **权威来源没被用上**：`TMDbLinkSource.isAuthoritative` 定义了却没人读。现在「当初靠标题搜索猜的对应」在服务端后来补上 `ProviderIds["Tmdb"]` 时会改用权威 id——否则会永远抱着一个猜出来的 id（实测库里确实有「先入库无 id、后补元数据」的条目）。权威对应本身仍不会被自动匹配顶掉。
    4. **`year(fromTitle:)` 定义了却没用**：现在接到搜索兜底——服务端没给 `year` 字段但标题里带年份（「某片 (2019)」）时会带上年份过滤，避免同名作品混在一起打分。
    5–7. **三处死代码**：`refreshEpisodeOrSeason`（已被 `refreshSeason` 取代，App 层不可达）、`refreshSeason(tvID:seasonNumber:)`、`TMDbImageSize.poster/.still`、`TMDbOverlay.hasText` —— 全部删除。它们都有同一个毛病：**看起来接好了、其实没人调**。
    - 顺带发现并修掉**我自己造成的重复定义**（`seasonOverlay`/`refreshSeason`/`refresh` 在 `TMDbEnricher` 里各存两份）——python 脚本改文件时重复应用了。已做一次全量同名声明自查确认无残留。
    - 验证：`Packages/MetadataKit` **118 用例**（+7）；`OcPlayerTests` 340 全绿；其余包全绿；macOS + iOS 构建通过；实机确认设置页计数与两个开关默认值正确。

### 库级批量补全与手动匹配

  - **库级批量补全**（设置页「补全整个媒体库」）：逐条匹配并拉取，剧集**连同各季一起补**（季数据决定分集标题/剧照/切季简介，只拉剧集本身的话那些展示面在没访问过的剧集上仍是空的）。带进度条与四类分类计数（新补 / 跳过 / 匹配不上 / 失败）——混成一个「成功 N 条」的话，用户不知道剩下那些该怎么办：「匹配不上」要他去手动匹配，「失败」要去看网络。可随时取消。
    - **天然可续**：已有对应且未过期的条目直接跳过，所以「取消 / 退出 App 之后再点一次」不会重复打请求，也不会丢进度——**进度状态就是数据库本身**，不需要额外的断点记录。
    - **单条失败不中断**：整库补全里有一条网络抖动就整体中断，会让用户以为「补全失败了」而重跑一遍全部。
  - **手动匹配面板**（详情页头部 TMDb 图标旁的循环箭头）：自动匹配刻意只在置信度 ≥ 0.85 时落库（错误的匹配比没有更糟），代价是总有条目匹配不上——冷门番、译名差异大、服务端没有 `ProviderIds` 又搜不到。面板打开即用条目标题搜一次，选中即绑定（`source: .manual`，**不会被自动匹配覆盖**）并立刻拉数据；也能**解除匹配**（匹配错了必须能取消，否则一个错误的自动匹配会永远顶在那儿，还会阻止重新自动匹配）。
  - **顺手修掉一个「列表接口不返回 ProviderIds」的坑**（Phase 3 实测发现）：`/Items` 列表接口**默认不返回** `ProviderIds`（实测本机 Jellyfin 12.1.0：不带 fields 时 0/5 个条目有，而 `/Items/{id}` 默认就有）。而 `MediaServer.items` 走的正是列表接口——不修的话库级补全会**全部退化成标题搜索**（匹配率与请求数都明显变差）。已在 Jellyfin 与 Emby 两侧的 `itemsPage` 显式加 `ProviderIds`。**实测**：批量补全后 42 条对应**全部是 `providerID` 来源**。
  - 顺带清掉两处「同一个读取有两个入口、其中一个没人用」的死代码（`TMDbCoordinator.link(for:tenant:store:)` 要求调用方自己递 `MetadataStore`；`TMDbCoordinator.link(itemID:tenant:)` 与 `TMDbEnricher.link(for:tenant:)` 才是统一入口），以及面板里一个设了从不读的 `didBind`。
  - **实机验证**：批量补全 42 条对应 / 91 个实体（含 **50 个季**）/ 0 匹配不上 / 0 失败，约 20 秒跑完；抽查「凡人修仙传」第一季 **206 集**全带中文标题（该剧从未打开过）；面板显示当前匹配与来源、候选海报、勾选态正确；手动绑定（`providerID` → `manual`）与解除（对应删除、**实体保留**）均实测通过，测试后已恢复为 `providerID`。
  - 测试：`MetadataKit` **118 用例**（+13：批量流程、可续性、失败隔离、非视频类型跳过、空列表、取消保留已做、剧集连季、手动绑定/不被自动匹配覆盖/解除/搜索、未配置 key 空操作）；`OcPlayerTests` **349 用例**（+7：批量状态、外部链接跟随已建立的对应）。

  - **两条「知道但不修」的取舍**（都写了实测依据与将来的修法，避免被反复重新讨论）：
    1. **分集剧照是两段式的**：首次渲染用服务端的图，TMDb 数据到位后替换（实测探针：第一次渲染 `overlayEps=-1`、第二次 `13`）。保留的理由：另一种做法（等 TMDb 就绪再渲染选集）会让**选集整条晚出现**，而闪换只是一帧；且离线时服务端图仍是有效兜底。要消掉它得让季数据先于分集卡片就绪（预取或让卡片在 overlay 未就绪时显示占位），代价都比收益大。
    2. **脏 `ProviderIds` 会每次重试、且永不补全**：若服务端给的 Tmdb id 在 TMDb 不存在（404），该条目每次打开详情页会白打一次请求，而且因为权威对应不会被自动匹配顶掉，它也永远不会退回标题搜索。**不加退避是因为实测本机库没有这种条目**：**全量** 41 个带 Tmdb id 的电影/剧全部有效（0 个 404，也没有类型不符）。修它需要 v3 迁移 + 失败重试策略，收益是「避免一个没有发生的请求」。将来若真出现，正确做法是在 `tmdb_link` 上记失败时间、N 天内跳过，并在权威 id 失效时退回标题搜索（见 `TMDbEnricher` 里那段注释）。
  - **一个被否掉的判断**：我一度认为「季/集没有展示面」并据此删掉了 App 层的季分支——那是只查了「有没有分集详情页」就下的结论。用户指出分集卡片标题、季切换、描述区都是现成展示面。教训：判断「有没有展示面」要看**渲染路径**，不是看有没有独立页面。
  - **修一个自己引入的缺陷**（首次实机运行靠日志发现）：演员头像原先一律由「服务端条目 id」拼 URL，而 TMDb 补的演员 id 在服务端根本不存在——实测服务端返回 **400**（日志实证 `/Items/tmdb-1254052/Images/Primary` → 400），于是每个演员一张破图 + 一次白打的请求（一页最多 20 个）。现在叠加层能由 `Person.id` 反查 TMDb 头像路径（`profilePath(forPersonID:)`），取图优先走 TMDb CDN（免鉴权）。演员 id 也加了 `tmdb-` 前缀作为**两套编号的隔离带**——服务端与 TMDb 的演员 id 可能撞号，撞了就会「拿服务端 id 问服务端、拿到另一个人的头像」这种静默错图。实机复验：400 消失，11 张 TMDb 头像已入缓存。
  - 验证：`Packages/MetadataKit` **105 用例**（新增 55：匹配优先级·脏 ProviderIds·**集/季陷阱**·置信度六档·原名回退搜索·候选排序·标题归一化（含「不剥数字差异」——不能把「阿松 2」归一成「阿松」）·叠加文本/图片策略·实体键往返与垃圾输入·落库往返·**跨租户共享与隔离**·v2 迁移保留 v1 数据·幂等重开·过期淘汰边界·清除时保留他人引用·端到端匹配→拉取→落库·并发合并·未配置全禁用）+ **17 用例**（客户端层：解码·语言逐字段回退·v3/v4·401 vs 429·限流并发与最小间隔·图片档位映射）；`OcPlayerTests` **339 用例**（新增 `TMDbCoordinatorTests` 15 项：留空即禁用·设置持久化与空白剥离·掩码回显·默认值·天数夹取·换语言重置计数·清除连带孤儿实体·AppModel 用注入域而非 `.standard`）。macOS Debug 与 iOS 构建通过；设置页**实机目视验证**过未配置与已配置两态（掩码、语言选择器、两个开关默认值、清除按钮、署名文案均正确）。

- **媒体元数据落 SQLite（`Packages/MetadataKit`），冷启动与离线不再空白**。此前首页/详情/库页的元数据**只活在内存里**，进程一退就全丢，唯一的幸存者是 3 bit 的骨架条数掩码；而 JSON API 连 HTTP 层缓存都没有（会话是裸 `URLSessionConfiguration.default`，`URLCache` 只服务图片）。于是断网冷启就是一张空白错误页，正常冷启则每次都要等一轮网络。现在新增 `Media.sqlite`（GRDB，与 Bangumi 库同目录同款 `DatabasePool`），把**首页三条 rail / 库列表 / 条目详情 / 季与集 / 翻过的库页 / 媒体技术信息**落盘，冷启动先读磁盘（首屏立刻有内容）、网络结果回来原位覆盖。
  - **装饰器只写不读**（本设计最重要的一条约束）：`CachedMediaServer` 对 `MediaServer` 的 30 条要求逐一转发，**返回值与错误与内层完全一致**，只多做一件事——把响应写盘。朴素做法「网络失败时返回缓存」会让调用方分不清手上是新数据还是旧数据，「离线」在 UI 层就没法表达；而吞错误还会把既有调好的错误路径弄浑（首页 `RailResult` 的逐条成败、详情页 SWR 的静默失败）。职责因此切成三块：写穿（装饰器）、离线读（`MetadataHydrator`）、UI 决策（页面）。选装饰器而非在各调用点加缓存，是因为协议将来新增方法会**编译不过**，而散点写法一定是漏一条就静默不缓存。
  - **离线提示分两档，不谎报**：新组件 `StaleContentBanner` 在首页与详情页各摆**一行小字**（不挡内容、不加按钮）。文案按失败原因分岔——`noNetwork` / `serverUnreachable` 才说「离线 · 数据更新于 X 前」，5xx / 401 只说「内容可能不是最新 · 刷新失败」，免得把人引去查网络而问题在服务端；时间用相对表述（几分钟前 / 昨天 / N 天前）。**有内容才提示**：没有任何内容时走的是既有整页错误态，不再叠一条自相矛盾的提示。
  - **进度永不作写权威**：缓存里的播放进度只读，服务端响应一律覆盖（`markPlayed` / `markUnplayed` 直接写回服务端返回的权威值）；进度与元数据**两个独立时间戳**（进度 15 分钟 / 元数据 7 天），因为「进度是 5 分钟前的、简介是 3 天前的」必须在 UI 上可区分。淘汰两条上限**互相独立**（3 万条 / 200 MB，都挂在每日存储维护上）：体积超限时按「当前条数的 10%」删最旧的一批——这里踩过一次，原写法是「删到条数上限的 90%」，而实测每条约 1 KB、3 万条折合才 ≈30 MB，**条数上限永远先于 200 MB 触发**，于是体积那一道在条数未超限时恒为空操作、上限形同虚设；现在与条数解耦，并有用例把体积上限压到 1 字节验证它真会删。设置页「维护」新增一行可见体积与「清空媒体元数据缓存」的出口（与图片缓存**分两行**：清图片只是重下图，清元数据会让下次冷启回到等网络的状态，合成一项用户不知道自己在放弃什么）。
  - **路径收口 + 修一个既有缺口**：新增 `OcPlayerStorage`（DiagnosticsKit）作为 `Application Support/OcPlayer/*` 的**唯一事实源**。此前这条路径在 6 处各自手拼，而维护清单只看 `AppStorageDirectories` —— `Bangumi.sqlite` 就是这么漏掉的：自引入起从未被清理、被统计、被设上限，体积在 App 内完全查不到。现在两者都登记进维护（只上报体积，不进删除路径），数据库体积上报含 `-wal` / `-shm`（WAL 会随写入增长，不算它长期少报一大截）。
  - **健壮性**：库损坏 / 迁移失败**删库重建**（缓存可重建，重建代价只是下次多拉一遍；半坏的库会让每条读路径各自出错），重建仍失败才抛错（那说明是磁盘满/权限，不能让调用方以为缓存正常）。payload 用**宽容解码**（缺字段取默认值），于是以后给 `MediaItem` 加字段**不需要迁移**；`payload_version` 只在语义不兼容时作废整条缓存。
  - 验证：`Packages/MetadataKit` **50 用例**全绿（建库/损坏自愈、round-trip、旧 payload 宽容解码、未知版本当未命中、**租户隔离**、页键与 `LibraryPageKey` 同构、淘汰最旧优先、装饰器 30 条转发不漏·返回值逐字段一致·错误原样抛·失败不留半份缓存、离线读「没缓存」与「缓存为空」的区分）；`OcPlayerTests` **314 用例**全绿（新增 `StaleContentNoticeTests` 12 项、`MetadataCacheIntegrationTests` 9 项、`MetadataCoordinatorTests` 11 项，后两者用临时目录真库端到端钉住「读缓存不发请求」「断网进详情仍有内容且标离线」「换服务器不读上一台缓存」「服务端出错不谎称离线」）；macOS Debug 与 iOS 构建通过。
- **图片缓存不再按服务器地址分家：同一台服务器换入口（局域网 ↔ Tailscale ↔ 反代）不再重下所有海报**。此前 `URLCache` 拿**完整 URL** 当键，而图片 URL 里含服务器地址：
  ```
  http://192.168.100.107:8096/Items/{id}/Images/Thumb?maxWidth=720&tag=…   ← 局域网
  http://100.64.1.96:8096/Items/{id}/Images/Thumb?maxWidth=720&tag=…  ← Tailscale
  ```
  同一张图存成两份，**换地址后全部海报重新下载一遍**——而「一台服务器多条地址、自动择优、换了无缝续用」正是这个 App 明确支持的能力（见 `ServerEndpointDirectory`）。实测用户库 110 MB 图片缓存里相当一部分是这种重复（缓存里同时躺着两个 host 的同一 item）。现在新增 `CanonicalImageURLCache`：键里把 scheme+host 换成占位符 `ocplayer.invalid`、只保留路径与查询，属主身份改由**认证头的跨进程稳定哈希**（`FNV1a`，非 `hashValue`——后者每进程随机播种会让缓存每次启动全失效）承担，于是「同一台服务器 + 同一账号的不同地址」共用一份缓存，而「不同服务器 / 不同账号」仍然隔离。
  - 只规范化路径含 `/Images/` 的媒体服务器图片；`image.tmdb.org` / `lain.bgm.tv` 等图床只有一条地址，不动（避免不同图床路径相同的理论撞键）。
  - 键一变旧键就永远命不中，故加**一次性清理**（UserDefaults 标记，只做一次）：把死数据删掉、磁盘还给用户。新键本来就要重下，这次清理**不额外增加任何下载**。实测生效：旧 110 MB → 6.5 MB，19 条新键全部形如 `http://ocplayer.invalid/Items/…`，含具体 IP 的键 **0 条**。
  - **但仅靠 `URLCache` 不足以离线出图**（用户实测报「重启后图片全是占位符」）：实测它**跨实例读不回来**——索引库里条目明明在（`storage_policy = 0`、服务器发的是 `Cache-Control: public, max-age=31536000, immutable`），同一个实例内能命中，**换个实例（= 重启 App）就一律 miss**，且直接调 `cachedResponse(for:)` 是读得到的、只有走 `URLSession` 才暴露。这个行为无法回归、也无从解释。而「断网重启后海报还在」是用户可见功能，不该建在看不清的机制上，故新增 `ImageBlobStore`：**图片字节自存**（文件名 = 稳定键的 FNV1a 哈希），读/写/淘汰全部自己控制，网络失败时由 `ImagePipeline` 回落到它。
  - **另一个真实缺陷**：认证头里含 App 版本（`Version="0.2.0 (506)"`，构建号 = git 提交数），整头哈希当缓存键就等于**每次发版把用户全部图片缓存作废**（实测 Build 505 与 506 的哈希确实不同）。现在 `authIdentity` 只取 `DeviceId` + `Token`：换地址、升级版本都不再影响缓存，换账号 / token 轮换才失效（正确）。
  - 验证：`Packages/AppDesignKit` **46 用例**全绿（`ImageCacheKeyTests` 17 项：跨地址共键·不同条目/尺寸/tag 不共键·不同账号隔离·图床不改键·**版本变化不换键**·token/设备变化换键·哈希跨进程稳定·真 `URLCache` 存取命中·清空后失效·旧键清理只跑一次；`ImageBlobStoreTests` 7 项：存取 round-trip·**新实例仍读得到**（模拟重启）·文件名稳定·空数据不写·清空·超限按最旧淘汰·体积统计）。
  - 端到端实测（真机 + 真服务器）：联网预热后把服务器指向不可路由地址（等价离线）重启 App —— **首页图片全部正常显示**（媒体库封面、继续观看剧照、接下来看海报），仅预热时没访问过的那个库封面为占位符（符合预期）。
  - **磁盘优先**（用户追问「为什么离线加载缓存图片要这么久」后修）：兜底原先写在 `catch` 里（网络失败再读磁盘），于是断网时**每张图都要先等网络超时**——实测每次 `-1005 连接中断` 约 7 秒，首页十几张图就是十几秒起步。现在改成**网络之前先查磁盘**，命中即返回，并在后台按需回源刷新。顺带把图片会话超时从系统默认 60 秒收到 15 秒（图片是可替代资源，宁可早点显示占位符）。
    - 后台刷新三道闸门防「几百张海报同时回源」：**新鲜度阈值 7 天**（用 `creationDate` = 下载时间，不是 mtime——后者读取时会被刷成「刚刚」，那样永远不刷）、**同键去重**、**并发上限 4**。超限就跳过这次（下次还有机会），不在用户翻页时突然打出上百个请求。
    - 因为 URL 通常带 `tag`（服务端换图 → URL 变 → 键变），阈值可以取得较长；它只为兜住**没有 tag 的 URL**，压住「永远不更新」。
    - 同时修一个**我自己引入的 bug**：`imageFromBlobStore` 用 `try?` 把「解码被取消」和「字节真解不出」收敛成同一个 `nil`，于是**取消（快速滚动时的常态）会被当成坏数据、把完好的缓存删掉**，缓存越用越少（实机日志里就出现了「磁盘图片解码失败，已丢弃」）。现在取消原样上抛、只有真 `nil` 才丢弃。
    - 验证：`Packages/AppDesignKit` **51 用例**全绿（新增 `ImagePipelineDiskFirstTests` 5 项）。其中「缓存命中不等网络」用**永不返回的 URLProtocol** 当网络——只要加载能返回就证明它没等网络。**回归有效性已实测**：把代码临时回退回「网络优先」，该用例报 **15.05 秒**失败；修好后 < 1 秒通过。真机复验：离线启动日志无任何网络等待、无「解码失败」，截图确认媒体库封面与继续观看剧照全部正常显示。
  - 排查记录（两条 Foundation 实测，都已写进代码注释）：`removeCachedResponse(for:)` 单条删除在本机 Foundation 上对磁盘缓存**不可靠**（同一个 `URLRequest` 存完再删仍然命中），故不再拿它当断言；`removeAllCachedResponses()` 是**异步**的（清空后立刻查仍命中、约 1 秒后才失效），用例改成轮询等待而非死等，避免慢机器偶发失败。用户可见的「清空图片缓存」走的是后者，实测有效。

  - 排查记录：期间测试宿主连续崩溃（用例 0.000 秒失败 + xcodebuild 反复重启宿主，单轮从 11 秒涨到 162 秒），崩溃报告是 `doesNotRecognizeSelector` 打在 `Dictionary.subscript.modify`——**我自己给测试替身加的调用计数器被三条并发 rail 同时改写**（`loadHome` 用 `async let`），把 Dictionary 结构写坏了。加锁后消失（已在新计数器上写明这段）。同批修掉另一处测试隔离问题：`xcodebuild` 默认并行多进程跑用例，而新用例与 `HomeRailLoadingTests` 共用 `.standard` 里的骨架条数键会互相污染，故给 `AppModel` 加了 `preferences:` 注入点（与 `ServerStore(defaults:)` 同款）。

- **详情页头部补上「去原站看看」的两个品牌图标：Bangumi 与 TMDB**。此前详情页看不到这部作品在外部站点是哪一条：Bangumi 只能在页内区块里点进 App 自己的条目页，TMDB 则连入口都没有（条目上的 `ProviderIds` 早就带着 Tmdb id，只是没地方用）。现在头部元信息行右侧给两个图标（窄屏放在类型行右侧，避免挤压已经排满的评分 / 分级 / 年份 / 季数 / 时长那一行），点开即用系统默认浏览器打开 `bgm.tv/subject/{id}` 与 `themoviedb.org/movie|tv/{id}`。
  - **只显示拼得出确定地址的那些**。电影 → `/movie/{id}`、剧集 → `/tv/{id}`（条目自身的 ProviderIds 就是该粒度的 id）；**季与分集一律不给链接**——它们要的是 `/tv/{id}/season/{n}` 里的**剧集级** id，而分集条目 ProviderIds 里的是集级 id（`TheIntroDB` 那边踩过同一个坑，见 `AppModel.seriesTmdbID`），硬拼会指到别的作品。宁可少一个图标，也不摆一个点进去是别人家片子的地址（`ExternalMetadataLinksTests` 钉住这条）。ProviderIds 是插件写的字符串，空串 / 非数字 / 0 / 前后空白都按「没有」处理（trim 后可用则照用）。
  - **Bangumi 图标与页内区块同一条门槛**：设置里停用 Bangumi 或未登录时整块不出现，不会出现「区块说没登录、头部却挂着 Bangumi 图标」；条目未关联时也不出现（没有可去的地方）。页内第一次自动匹配 / 手动关联成功时，图标**当场**出现——关联的唯一写入口 `BangumiMatcher.setLinkedSubjectID` 发一条 `OcPlayer.bangumiLinkDidChange` 广播，将来新增写点自动带上。
  - **品牌图标按各自规则渲染**：两个都用**官方彩色图**，与同为品牌标识的 TMDB 并排风格统一。TMDB 用官网 logos-attribution 页提供的官方 SVG（`blue_square_1` 方形变体，2.2 KB）；Bangumi 用**官方 glyph + 官方渐变色**——仓库原有那份是同一个 TV 标记的单色线稿（与官方 favicon 逐像素比对确认同形状），新增一份 `bangumi-logo-color`（保留矢量与透明通道，填官方 App 图标采样到的渐变：顶部 `#F70098` 洋红 → 底部 `#FF69A3` 品牌粉）。**顶栏药丸与 iOS Tab 不动**：那里图标要与标签文字一起随选中态变亮变暗、并与同为单色模板图的 MoviePilot 并排，仍用原 `bangumi-logo`；两份资产共用同一 glyph，不存在形状漂移。
  - **没走官方横版字标的理由**：Bangumi 官方彩色资源（`logo_riff.png` / `logo.png` / `logo_rc1.png` / `ico_ios.png`）除了 16×16 favicon 外全是宽高比 2.9–4.0 的横版字标，而详情页此行图标只有 12–15pt 高 —— 实测缩到该尺寸后「番组计划」副标题完全糊掉、字标不可辨认；`ico_ios.png` 虽 256×256 且彩色，但是 RGB 无 alpha（iOS 图标白底烘死），不能作行内图标。官方方形彩色标记只有 16×16，放大即糊。故取「官方 glyph + 官方渐变」的矢量组合，任意尺寸清晰。
  - 尺寸宽高都钉死（Bangumi 15×15 正方形标记 / TMDB 28×12 宽扁字标）——交给 `.frame(height:)` 推宽度会让排布依赖父级提案，钉死后图标不随可压缩的兄弟视图变形。
  - **解析任务挂在条件之外**：`.task` 若挂在「有链接才画」的 `if` 里会自锁——首帧 `links` 为空（Bangumi 关联还没解出来）→ 图标行不存在 → 任务从未运行 → 永远解不出来。故包一层恒在的 `Group`。
  - **顺带收敛一处重复**：详情页的「选中的季 → 剧集 → 条目自身」Bangumi 关联解析链原来内联在页内区块的 `load()` 里，头部图标是第二个读点，收敛成 `BangumiMatcher.linkedSubjectID(for:selectedSeason:)`（行为逐字不变，第 1 季 / 单季才回落到剧集，其它季不回落以免串季）；`DetailView` 里「当前选中的季」也抽成一个属性，给头部图标与 Bangumi 区块共用。**播放结束的自动标记那条链没动**：它取分集条目自己的 `seasonID`、也没有「第 1 季才回落」这一档，语义不同。
  - 验证：`OcPlayerTests` 新增 `DetailExternalLinksTests` 5 个用例（电影/剧集的地址、季与分集不给链接、脏 ProviderIds 六态、Bangumi 地址三态、组合顺序与图标渲染属性）；macOS Debug 构建通过。

- **一台服务器可以有多条地址（局域网 / Tailscale / 反代域名），App 自动挑最快可达的那条**。此前 `ServerProfile` 只存得下**一个** `baseURL`，于是「在家走局域网、出门走 Tailscale」这件事只能靠**同一个服务器登两遍**——而档案 id 是 `serverID:userID`，两次登录指向同一个 id，第二次会把第一次的地址**覆盖**掉：出门前存好的局域网地址、回家后存好的 Tailscale 地址，永远只剩最后那个，且换地址必须重新输账号密码。现在档案拆成「一组地址 + 当前生效地址 + 可选固定项」，服务器身份（`/System/Info/Public` 的 `Id`）是合并判据。
  - **落盘**：`ServerProfile` 新增 `addresses`（备选地址，落盘就是地址字符串数组）/ `pinnedURL`（用户固定项）/ `serverID`（显式服务器 Id，老档案从 id 前缀恢复，且拒绝把 host 兜底值当服务器 Id 用）。三个字段都是 `decodeIfPresent`，0.2.0 及更早的档案解出来是「只有一条地址、自动择优」的正常状态，无需迁移。已在档案里的老 `baseURL` 永远是候选之一。
  - **合并**：`ServerStore.save` 同 id 不再整体替换，改走 `ServerProfile.merged` —— 新登录地址成为当前、旧 `baseURL` 与旧备选退成候选（归一化去重，尾斜杠 / 大小写 / 默认端口视为同一入口），固定项沿用用户的选择。于是「用 Tailscale 地址再登一次」只是给这台服务器**补了一个入口**，不会再冒出一个服务器条目。
  - **择优**：新增 `ServerEndpointDirectory`（每档案一个，由 `ServerStore` 托管并在会话重建之间复用）+ `ServerProbe`（`/System/Info/Public` 探活，匿名可用、响应里带服务器 `Id`）+ `ServerAddress`（地址模型与分类：`100.64.0.0/10` 与 `*.ts.net` 认 Tailscale、私网 IPv4 与 `.local`/单标签主机名认局域网）。规则是**按实测延迟择优而不是按类别**（Tailscale 直连有时比绕一圈的局域网更快），并且三条约束：①**粘性**——当前地址可达时只有新地址明显更快（< 当前 × 0.7 − 20ms）才切，避免两个入口延迟接近时来回抖；②**软过期后台重探**——缓存 300s 到期后台重探、不阻塞请求，只有首启 / 网络变化 / 从没探过时才等一次探活（2s 超时）；③**失败开放**——一个地址都探不通时保持原地址不动，绝不把「探活本身失败」变成「连不上服务器」（并把下一次重探推后 5s，免得服务器整个下线时每个请求都先等一轮）。
  - **换址**：`JellyfinServer.send` 与 `EmbySession.data` 在传输层失败时重新探活，换到别的地址就在新地址上**立刻重试一次**（不打退避）；失败触发的重决议有 3s 冷却，一串并发失败不会打成探活风暴。HTTP 状态码（4xx/5xx）不算「地址不通」——服务器已经答了话，换地址只会把同一个错误再撞一遍。换址判断刻意排在**重试闸门之前**：`.serverUnreachable` 里「名字解析不了」（`-1003/-1006`）那一类是不可重试的，而主机名候选（`nas.local` / MagicDNS 名 / 反代域名）换网络后报的恰恰是它 —— 排在后面会被 `break` 一起吃掉，等于「出门自动换址」在最典型的一类地址上静默失效。
  - **探活的严格性**：`/System/Info/Public` 解不出媒体服务器那四个字段就判**不可达**（此前 `try?` 吞掉解码失败、`Id` 校验又因拿不到 `Id` 而跳过，于是反代 SPA fallback / NAS 管理页这种「200 + HTML」的地址会被判可达：它通常比真服务器更快，会被选为当前地址，而探活永远成功、粘性不切走，API 却全部解不出来，卡住只能用户手动处理）。服务器没报 `Id` 时仍算可达 —— 那只是失去「是不是同一台」的校验能力，不该把可用地址判死。
  - **服务器 Id 的形状校验**：老档案没有显式 `serverID` 时从档案 id 前缀恢复，但前缀必须是「≥16 位十六进制」才认。老版本在服务器没报 `Id` 时会拿 host（`nas`）甚至整个地址串（`http`）拼档案 id,把它们当服务器 Id 用会让每条地址的探活校验都对不上：添加地址误报「另一台服务器」、启动换址静默失效（`firstReachable` 全 nil 后回落到 baseURL，连报错都没有）。
  - **触发点**：登录 / 启动恢复 / 切换服务器挂上决议器并立即预热一次；新增 `ServerEndpointMonitor`（`NWPathMonitor`，500ms 去抖）在 Wi-Fi ↔ 蜂窝、插拔网线、Tailscale 起停时作废地址结论；iOS 回前台同样作废。决议选中的地址由 `AppModel.serverEndpointChanged` **在主线程**写回档案（`ServerStore` 的写路径必须留主线程：后台线程写 `UserDefaults` 会与主线程读构成 ABBA 互等，MoviePilotStore 上实测过），并驱动 `serverEndpointURL` 让图片 / 播放流地址跟着换。两处容易漏的细节各有回归测试：①`invalidate()` 会**作废在飞的决议**（只置标志的话，在飞任务回来仍会把旧结论标回「新鲜」，网络变化被丢掉、最长再等 300s）；②`NWPathMonitor` 启动时那一次投递是「当前路径」而不是「路径变了」，跳过它免得刚预热好的结论当场被作废、首屏白等一轮探活。
  - **UI**：「管理服务器」每台服务器可展开管理地址——列出全部入口（分类图标 + 延迟 / 使用中 / 已固定 / 不可达）、添加地址（带服务器 Id 校验：能连上但报的是**另一台**服务器时明确拒绝并入，并提示改用「连接其它服务器」；此刻连不上也可以「仍然添加」，典型场景是在没有 Tailscale 的网络里先把家里那条存好。Emby 档案的候选会自动补 `/emby` 前缀 —— 手工入口是登录流程之外唯一会产生候选的地方，漏了前缀会在被选中后全链路 404）、删除地址（二次确认，最后一条不给删）、固定 / 恢复自动择优（固定后不再自动切换，文案写明代价）、「重新检测」。设置页地址行显示当前生效地址并说明共几个入口；登录页的已保存服务器行标出地址条数。首页氛围轮播的装载触发键并入当前生效地址：换址后池子里的图片 URL 已作废，必须按新地址重拉一次。
  - **验证**：`swift test --package-path Packages/JellyfinKit` 190 用例全绿（新增 4 个测试文件：地址分类 / 归一化 / 落盘格式、决议器的择优·粘性·固定·冷却·失效·在飞作废·空候选、真实探活的路径·Id 校验·非媒体服务器拒绝、两实现在 IP 与主机名两类失败下的换址重试；另在 `ServerStoreTests` 补 14 个用例覆盖合并、地址增删、固定、老档案解码与服务器 Id 形状校验）。`OcPlayerTests`（macOS 与 iOS 模拟器）269 用例全绿，含新增 `ServerEndpointWiringTests`：换址结论落档案 + 发布到界面、不换址时不写档案（以「探活确实发生过」为前置，不用固定 sleep）、固定项优先、旧会话迟到回调被忽略、Emby 候选补 `/emby` 前缀。macOS / iOS 构建通过。另做了一轮对抗性审查（并发 / 锁、合并去重、老数据兼容、请求放大、Emby 前缀、UI 状态一致性、测试假通过），上列换址闸门顺序、探活严格性、Id 形状校验、在飞作废、Emby 前缀、氛围图重拉六项即该轮发现并修掉的问题。


- **jellyfin-sdk-swift 3.0.0 → 3.3.0，Jellyfin 12 兼容**。Jellyfin 12.0 起版本号脱离 10.x 系（10.11 直接跳 12.0），带三项客户端可见的破坏性变更，逐项核对全不沾：①旧式鉴权默认禁用（`X-Emby-Token` 头 / `api_key` 查询参数）——我们全链路只用现代 `Authorization: MediaBrowser …` 头，token 不进 URL；②移除 `/emby/*`、`/mediabrowser/*` 路径别名与 `GET /QuickConnect/Initiate`（只留 POST）——`/emby` 前缀只拼给 Emby 档案，Quick Connect 走 SDK 的 POST；③GetItems 带 `includeItemTypes` 时递归过滤语义变化——我们的查询（`Movie,Series` / `Episode` + `recursive=true`）正是此形态，是本次升级的实际动机。3.3.0 按 Jellyfin 12.1 的 OpenAPI 重新生成，`from: "3.0.0"` 收紧为 `from: "3.3.0"`；封装层（JellyfinKit）零改动编译通过，133 个包测试全绿（请求形状断言不变，说明 SDK 层消费的路由与参数未漂移）。遗留提醒：跳过片头读的 `/MediaSegments` 依赖服务器端 intro-skipper 插件，10.11 时代的插件在 12.0 上不加载，需等插件发 12.0 适配版（服务器侧，非播放器问题）。验证：`swift test --package-path Packages/JellyfinKit` 133 用例全绿；macOS Debug 构建通过（App 层不直接 import SDK，仅消费 JellyfinKit 封装）。真实 12 服务器上的媒体库/剧集列表回归待有环境时补。

### 修复

- **修「播放完返回详情页背景丢失」——被盖住的库页透过透明详情页漏出**（用户截图现场：详情页内容间散落着媒体库网格的卡片）。探针 + 实机复现证实氛围声明与整窗背景层全程完好（c9f728c 的栈根修复无回归），真正漏的是**被盖住的路由页**：macOS 26 的 NavigationStack push 时**不给被盖页发 `onDisappear`**（探针证实整个进出播放流程零生命周期事件），`pageEntrance` 的「被覆盖即复位」从未生效——被盖页一直 opacity 1，只是系统平时不合成它；播放器开合翻转窗口工具栏可见性、乃至**改一次窗口尺寸**（与播放无关，实测可复现），都会触发整窗重合成让它重新参与合成。修法与栈根同一哲学：`CoveredPageHider`（AppShell）在 onAppear（落地即栈顶）记下自己的栈深度，`opacity = (depth == app.path.count)`，**path 驱动、与生命周期解耦**；仅 macOS 生效（紧凑布局的导航栈宿主不合成被盖页、`app.path` 恒空，保持直通）。验证：实机「播放开合」与「改窗口尺寸」两场景修复前后对照截图；`OcPlayerTests`（macOS）263 用例全绿。

- **修呈现式页面（`navigationDestination(isPresented:)`）同族两洞**。①**宿主漏出**：这类页面不在 `path` 上，`CoveredPageHider` 的深度比较看不见这层覆盖，宿主在呈现落地后依旧「是栈顶」——而呈现族全是透显设计（资源搜索页声明整窗氛围、下载管理 / 管理服务器 / 开源许可证走系统 List·Form 半透底），宿主内容会透过它们漏出（触发条件同上：整窗重合成）。修法：新增 `coveredByPresented(_:)` 绑定驱动宿主显隐，四个宿主登记——设置页（服务器 / 许可证两开关）、MoviePilot 首页（下载管理 / 资源搜索）、详情页（资源搜索，落地开关 `isResourcePresented` 从 `MoviePilotResourceSection` 上提由 `DetailView` 持有）、资源搜索页（下载管理）；只动 opacity 不摘视图，宿主的氛围声明保持活着供被盖期间整窗层继续渲染。②**声明被覆盖丢失**：详情页（声明 D）呈现资源搜索页（声明 R）后返回，`WindowAmbienceSetter.onDisappear` 把单值声明清成 nil，而 D 已被覆盖、详情页不会再补发——返回详情页背景照样丢。修法：声明改**栈**（`windowAmbienceStack`，条目带 setter 实例 id）：出现压入、存续期间原位更新、离屏按 id 摘除、栈顶即生效值（nil 条目表示「声明无氛围」照样占层，onDisappear 晚于新页 onAppear 的乱序天然安全）；`resetBrowseState` 相应改为清整个栈。验证：macOS Debug 构建通过；`OcPlayerTests`（macOS）263 用例全绿；实机验证设置 → 管理服务器、媒体库 → 详情两条链在改窗口尺寸重合成后无漏出、详情页氛围完好、连续返回首页后轮播氛围正确恢复。

- **设置页补上「退出 Bangumi」**。此前 Bangumi 的退出登录**只有一个出口**——Bangumi 分区「我的」页顶栏那颗门图标；设置页里只有账号行与「登录入口在顶栏的 Bangumi 分区」一句提示，想退出得先切到那个分区、再进个人页，与 Jellyfin / MoviePilot 的出口位置（都摆在「设置 → 服务」各自区块里）也不一致。现在设置页 Bangumi 区块在已登录时给出「退出 Bangumi」按钮（`role: .destructive`，同一个 `rectangle.portrait.and.arrow.right` 图标，调 `BangumiCoordinator.signOut()`），未登录时仍显示原来的登录指引——两块互斥，不会同时出现。顺带修同区块一处会互相打架的显示：账号行原先直接读 `bangumi.profile?.nickname`，而**已登录但资料还没拉回来**（profile 为 nil）时会显示「未登录」，旁边却摆着「退出 Bangumi」——抽成 `bangumiAccountText`，以 `isAuthenticated`（登录的唯一门控信号）为准，profile 缺失时退化显示「已登录」而不是「未登录」。验证：macOS Debug 构建通过；`OcPlayerTests`（macOS scheme）全绿；实机注入登录态逐项复核——账号行显示昵称 + 「退出 Bangumi」在位（注入 profile 缺失时显示「已登录」，不再自相矛盾）、点击后按钮消失且 `isAuthenticated` 归 false、`credentials.json` 里的 `bangumi.auth` 被清掉。

- **修「Bangumi 未登录时顶栏与氛围背景显示错误」（截图现场：整窗氛围图在，唯独顶栏是一条死灰横条，玻璃完全没吃到图）**。与上一条 MoviePilot 同源同坑，只是**同一坑里漏掉的那批根级状态视图**：`PageFillingState` 当时只落到了 MoviePilot 与首页，Bangumi 未登录态的门面 `BangumiLoginView` 仍是抱紧内容的 `VStack` + `.frame(maxWidth:.infinity,maxHeight:.infinity)`——理想尺寸与窗口无关，整条尺寸链（根视图 → 导航栈 → 外壳 → `.background`）跟着塌，顶栏底下没了内容，系统改画不透明的窗口底色。**同一份构建上的 A/B 是判决性的**（1384×869，深度色，取样：顶栏条带 y=8pt 亮度 sd 与「顶栏 vs 下方内容带」亮度差 |t−c|）：Bangumi 未登录页 sd **3.28** / |t−c| **42.6**（一条 52pt 死灰平条），而同窗口已修好的 MoviePilot 门控页 sd **29.11** / |t−c| **17.5**（玻璃透过氛围图）、首页 sd 30.57 / 9.2、设置页 sd 34.72 / 17.8 全过——即这不是「登录态不同」或氛围图没出来，而是这一页没包载体。另写最小复现 App（只保留「窗口 `.background` 氛围层 + 导航栈 + 工具栏」这一形状）逐项二分，把「载体」钉死：**`frame` 系全救不回来**——`.frame(maxWidth:.infinity,maxHeight:.infinity)`、`minWidth/maxWidth/minHeight/maxHeight` 组合、`GeometryReader`、`ZStack{Color.clear; content}`、整链级 `containerRelativeFrame([.horizontal,.vertical])` 六种写法顶栏一律不透明（|t−c|≈79.8），**只有 ScrollView 载体过**（|t−c|≈1.6），与 `PageFillingState` 的选择逐字吻合；且**push 页同病**（栈根已换成铺满的 ScrollView 之后，push 进来的裸状态页依旧不透明，|t−c|≈79.6），载体要落在「谁的状态视图谁包」上。落地范围（全部改走 `PageFillingState`）：`BangumiLoginView` 整页门面；`BangumiHomeView` 的建库失败态（原 `frame(maxWidth:maxHeight:)` 已证无效，去掉）与进度页失败 / 空态两个根级分支、搜索态失败 / 无结果两个分支（后两个原来同样是 `frame` 版）；`BangumiCalendarView`（push 页）的加载失败 / 无数据两态；`BangumiCollectionListView`（push 页）的加载中（两处）与失败态。`BangumiLinkPicker`（sheet，自带固定 minHeight）与 `BangumiSubjectDetailView` / `BangumiProfileView`（根已是 ScrollView）本就安全，未动。验证：macOS Debug 构建通过；`OcPlayerTests`（macOS scheme）**263 用例全绿**；实机逐页取样（每次先用窗口标题断言确实落在该页，1384×869，五次连续切换）——首页 sd 32.47 / |t−c| 14.9、Bangumi 未登录 sd **11.54** / |t−c| **1.6**、MoviePilot 未登录 sd 11.54 / 1.6、设置 sd 11.54 / 5.1、Bangumi 二次进入复测 sd 23.02 / 14.1，全部 sd>10（玻璃顶栏，修复前该页为 3.28 判 FAIL），顶栏行为与首页 / 设置页 / MoviePilot 门控页一致。

- **修「MoviePilot 分区整页只有中间一块有氛围背景」（未登录 / 未配置门控页，用户报的「整个画面都错误」）**。根因不在登录态，而在**尺寸链**：AppShell 把氛围底图挂在根节点的 `.background` 上，而 `.background` 拿到的尺寸就是宿主的尺寸、**不会反过来把宿主撑大**；分区的根视图一旦是「理想尺寸固定」的状态视图，整条链（根视图 → 导航栈 → 外壳 → 背景）就一路塌成内容那一小块。实机实测（1100×700）：`ContentUnavailableView` 的理想尺寸是 **400×400**（`MoviePilotHomeView.gate`），同一页在 1384×869 与 1100×700 两个窗口下，有图的那块都恰好是 400×400 居中——即它不随窗口变化。像素对照同窗口的 Bangumi 页：顶栏玻璃采样到的是氛围图 (159,127,99)，而 MoviePilot 页顶栏与四周一律 (41,43,43)（= `windowBackgroundColor`），八个取样点全同色，确认是背景层塌了而非遮罩所盖（截图里那块方形边界也正是它）。修法：新增共享原语 `PageFillingState`（`AppDesignKit/Layout/`）——用 ScrollView 承载状态视图，ScrollView 不吃理想尺寸、会铺满被给到的空间，尺寸链从它开始一路撑满窗口，`.background` 自然拿到整窗尺寸；`containerRelativeFrame(.vertical)` 负责把内容在可视区垂直居中。**给状态视图自己加 `.frame(maxWidth:.infinity,maxHeight:.infinity)`（哪怕连带 `.ignoresSafeArea()`）不管用**，实测仍然塌——这正是本坑的迷惑之处。落地范围：`MoviePilotHomeView` 的三态门控（`gate`）与搜索态的三个根级分支（加载中 / 失败 / 无结果，搜索态下本页没有结果列表的 ScrollView 兜底）全部包上；`HomeView` 里同款私有实现（`SearchEmptyState` 与 `errorState` 内联各一份）收敛到该原语，AppDesignKit 新增文件成为这条约定唯一的落点与解释处。验证：macOS Debug 构建通过；`swift test --package-path Packages/AppDesignKit` 24 用例、`Packages/MoviePilotKit` 60 用例全绿；实机逐项复核——修复后同一页八个取样点**互不相同**（左上 (12,2,2) / 右上 (107,57,19) / 左中 (17,5,5) / 右中 (61,21,11) / 左下 (24,18,18) / 右下 (24,19,18) / 顶栏玻璃 (108,54,23)），顶栏玻璃与 Bangumi、设置页行为一致；两种窗口尺寸（1384×869 与 1100×700）下均满窗；首页（共用同一原语）截图确认无回归。
- **修「MoviePilot 只是没登录，分区首页却报『未配置 MoviePilot』」（截图现场：登出 / 令牌失效后整页空态 + 一个「去设置」按钮，而地址与用户名其实一直好着）**。根因是首页门控用了 `MoviePilotStore.isConfigured` 当「配没配」的判据：这个属性同时要求**地址 + 用户名 + （密码或令牌）**——它的语义是「现在能不能拿这份凭据直接发请求」，而不是「这台服务器配过账号」。于是凭据被正常交还的两种情形（用户点「退出 MoviePilot」、令牌 8 天过期后没记住密码、静默重登也失败）全都落进 `false`，首页把「未登录」说成「未配置」，还把人赶去设置页；而设置页状态行对同一状态显示的是另一个词（`.isConfigured ? "未登录" : "凭据不全"`），两处文案互相打架，且默认档（不保存密码）下**每次重启后令牌一过期就必现**。本机实测当前配置正是这一态：`serverURL=192.168.100.107:30000`、`username=jumusu`、`rememberPassword=1`，而凭据文件里 `moviepilot.token` 与 `moviepilot.password` 都不存在——旧判据算出「未配置」，与截图逐字吻合。修法：把「配过账号」与「凭据可用」拆成两个语义，新增 `MoviePilotStore.hasAccount`（仅地址有效 + 用户名非空）与三态枚举 `IntegrationState`（`.unconfigured` 没配过 / `.loggedOut` 账号在但没令牌 / `.ready` 有令牌），并让**分区首页与设置页状态行共用同一判据**（`MoviePilotCoordinator.integrationState` 转发）——首页 `.unconfigured` 才给「去设置」，`.loggedOut` 给「重新登录」+「去设置」（登录窗预填地址与用户名，用户只补密码），设置页三态文案随之收敛，同一状态在两处不可能再显示成两个词。`isConfigured` 保留原语义（供「能不能直接发请求」使用，其既有测试不动）。验证：`swift test --package-path Packages/MoviePilotKit` 60 用例全绿，新增三个状态机用例——`testSignOutReadsAsLoggedOutNotUnconfigured`（登出后 `isConfigured == false` 但 `hasAccount == true`、态为 `.loggedOut`）、`testExpiredTokenWithoutRememberedPasswordReadsAsLoggedOut`（跨重启、401 清令牌后仍是 `.loggedOut`）、`testIntegrationStateIsUnconfiguredWithoutUsableAddressAndUsername`（缺用户名 / 地址非 http(s) origin / 只有孤儿令牌都必须是 `.unconfigured`，否则会把人送进一个没有「改地址」出口的页面）；macOS Debug 构建通过；本机真实配置代入新判据得到 `.loggedOut`，与修复目标一致。
- **修「设置 → 退出 MoviePilot 每次必卡死（App 未响应，只能强制退出）」**。根因是 `MoviePilotStore` 在**后台线程**上写 `UserDefaults` 造成的 ABBA 互等：`UserDefaults` 每次写入都会同步发变更通知，SwiftUI 给 `@AppStorage` 挂的 `UserDefaultObserver` 就在**发通知的那个线程**上响应它，响应体里要 `Update.begin()`——申请 SwiftUI 的 UI 更新锁（`MovableLock`）；而主线程此刻正持着那把锁在渲染设置页，同一时刻要读 `store.serverURLString`、等 `MoviePilotStore.lock`。于是后台线程「持 store lock 等 UI 锁」、主线程「持 UI 锁等 store lock」，两边互等，永不恢复（不是慢，不会自己好）。`sample` 实录（0.2.0 482）：主线程停在 `SettingsView.body` 读 `serverURLString` 的 `NSLock` 上，后台 `MoviePilotAPIClient.signOut()` 的 actor 线程停在 `clearSession()` 里 `defaults.removeObject` 触发的 `Update.begin()` 上。三个旁证全部对上：**两端都复现**（共享代码）、**永久卡死**（真互等）、**只有 MoviePilot 卡**（`BangumiContext` 是 `@MainActor`、Jellyfin 登出在主线程，两者的 store 写入天然在主线程）。另有一处更隐蔽的地方让它是无条件必现：`removeObject` 删一个**不存在**的键同样发通知（现场两个 legacy 键都早已不在）。修法：`MoviePilotStore` 的所有 `UserDefaults` 写入收进唯一落点 `mutateDefaults(_:)`——在主线程就直接写，在后台就投到主线程补做（补做时照常持锁），既不阻塞也不丢弃；真值（地址 / 用户名 / 密码 / 开关）的调用点全在主线程，能从 actor 上走到的只有「历史残留键清理」这类没有时效要求的写入。**推迟删除带来一个新窗口，同轮一并堵掉**：旧令牌键的删除被推迟的那几毫秒里，凭据文件已空而旧键还在，迁移分支会把刚作废的旧令牌搬回去——等于登出静默失败。为此加一把会话内的一次性闩 `legacyTokenRevoked`（清令牌统一走 `clearTokenUnlocked()`），此后读路径一律不认旧键；顺带把 `accessToken` 读写路径里重复的一份迁移逻辑收敛成一个 `accessTokenUnlocked()`。验证：新增两个回归用例——`testClearSessionFromBackgroundThreadKeepsDefaultsWritesOnMain`（从 `Task.detached` 调 `clearSession`，断言变更通知不落在后台线程、残留键仍被清掉）、`testClearedTokenIsNotResurrectedFromLegacyKeyWhileRemovalIsDeferred`（主线程故意占住，把「推迟删除」的窗口做成确定性可见），并**两个都做了反向验证**：临时退回直写，前者立刻报「2 次后台写入」（与 sample 现场逐条吻合）；临时摘掉闩，后者读回 `stale-legacy-token`。`swift test --package-path Packages/MoviePilotKit` 57 用例全绿。顺带记录同形状的隐患（**未改逻辑**）：`BangumiStore` 的 `auth` setter / 迁移读也会持锁写 `UserDefaults`，且 `BangumiAPIClient` 是 actor（`store.auth = …` 在后台线程）——目前够不着那条环，只因为没有任何视图在 body 求值里读该 store（`BangumiContext` 把 UI 要用的都存成了 @Observable 存储属性），已在类型注释里写明「别在 body 里读 `store.*`」以及届时的改法。
- **修「iOS 切后台回来播放器直接报错，只能点重试」（`playback error: ffmpeg error … avcodec_send_packet: Unknown error occurred (-1313558101)`）**。根因是挂起往返本身：App 没有后台音频能力（`Info.plist` 无 `UIBackgroundModes: audio`，App 层也不配 `AVAudioSession`），进程进后台几百毫秒就被系统冻住，而内核的音频出口（iOS 上是 AudioQueue）与 VideoToolbox 解码会话醒不过来——回前台第一包数据喂进 `avcodec_send_packet` 就是 AVERROR_UNKNOWN，播放器被钉死在错误态；原来的前后台钩子只做进度上报，既不拦也不恢复，只能靠用户手动重试（重建内核）。修法三段：①**进后台先停**——`PlaybackController.beginSystemSuspension()` 在进程被挂起前主动暂停在播会话（`.playing` / `.ready` 都算「用户离开时正在看」；open 在飞或本来就暂停时不动引擎），并带回「回前台接着播」的意图；②**回前台接回去**——`AppModel.playbackDidEnterForeground()` 按意图 + 当前状态决策（纯函数 `foregroundResumeAction`）：内核算健康就解开那次暂停；内核没撑过挂起（`.error` / `setupError` / `play()` 都没调成）就走与「重试」相同的重建路径静默重建——Jellyfin 条目重走完整 `play()`，本地文件 / 直连以**同一个 request id + 当前内核位置**重开（刻意不走 `retryPlayback()` 的「≥30s 才算续播点」启发式：那是给用户手动重试防片头误判的，系统往返里位置退到 0 重来才是 bug）；③**恢复后补 3 秒观察窗**（250ms 一拍）——解码器坏掉的第一现场未必在 `play()` 当场落地，而是恢复后第一包数据上，窗口内落进错误态就做一次静默重建，仍失败则按普通错误交给错误徽章，不循环重试。自动动作只发生在「离开前确实在播」的这一次往返里，播放中用户自己按的暂停不受影响；macOS 不挂起进程，这条路径整个空转。顺带修同族的一处误判：open 看门狗按墙钟算 60s，切后台期间进程被冻住而墙钟照走，「点完播放就切走再回来」会被判「连接媒体服务器超时」——现在挂起时长从 open 的账上扣掉（`openElapsedMilliseconds`），看门狗没到点只补睡差额。验证：iOS 模拟器 `OcPlayerTests` 全绿（含新增 `AppBackgroundPlaybackTests`：回前台决策表全组合 + 无控制器 / 未在播时钩子必须空转）；macOS 构建与测试通过。真机续播效果待设备回归（挂 `playbackDidEnterBackground/Foreground` 与「后台往返后自动重建播放」诊断行，日志可查）。
- **修「呈现式页面的返回键点了没反应」（下载管理 / 资源搜索 / 管理服务器 / 开源许可证）**。常规布局（macOS / iPad 常规宽度）的顶栏返回键是自绘的 `AppShellBackButton`，它只会调 `AppModel.back()`；而 `back()` 的落地是 `path.removeLast()`，并有 `guard !path.isEmpty else { return }` 守卫。`navigationDestination(isPresented:)` 呈现的页面（下载管理、资源搜索、管理服务器、开源许可证）**根本不在 `path` 上**——`isPresented` 是另一套呈现机制，栈里看不到它，于是守卫直接把这次点击吞掉：淡出都不发生，按钮像没绑事件。修法：新增 `AppModel.popPresented(_:)` 作为 `pushPresented(_:)` 的对称出口（同样走两段式，`restoreDelay` 与 `back()` 取同一档），并给自绘返回键补一个可选的 `presented: Binding<Bool>`——非空时走 `popPresented` 关掉页面自己的落地开关，为空时维持 `back()` 弹栈。六个调用点全部接上（`appShellBackChrome(title:presented:)` 新重载）：MoviePilot 首页的下载管理与资源搜索、详情页 MoviePilot 区块的资源搜索、资源搜索页的「添加下载成功后跳下载管理」、设置页的管理服务器与开源许可证——后两个是同源同病的既有 bug，一并修掉。顺带两处一致性：①呈现式页面此前没有任何离场过渡（不在路由出口 `appRouteView` 上，没人替它挂 `routeExitFade`），返回是「等 0.45s 再硬关」，现在由 `appShellBackChrome(title:presented:)` 按 `presented` 非空补挂，与路由页同一个 `Motion.exit`；②资源搜索页自动跳转的下载管理此前裸用系统返回键（与其它入口的顶栏不一致），现统一为 `appShellBackChrome(title: "下载管理")`。验证：macOS Debug / iOS（模拟器）构建均通过；`OcPlayerTests` macOS 套件 244 用例全绿，含新增回归用例 `testPopPresentedDismissesWhileBackIsNoOpOnEmptyStack`（钉住「空栈上 `back()` 是空操作、`popPresented` 必须真的关掉开关」这一形状）；macOS 实机点按确认下载管理页返回键恢复。

- **修测试宿主被「stderr → os_log → stderr」自激循环拖死（iOS 测试步骤在 CI 上从未绿过的根因）**。`KernelStderrPump`（GUI 启动时劫持 fd 2 接内核 stderr 进诊断管线）在测试宿主里也照常启动，而 iOS 模拟器的测试宿主会把进程 os_log 回声到 stderr（Xcode 控制台显示 os_log 就靠这条通路）——`record()` 把读到的行写进 os_log，回声落回 fd 2 被泵再读、再写 os_log：无限自激，每圈包一层时间戳前缀（此前测试日志里看到的嵌套行就是它）。后果：①CI 的 iOS 模拟器测试步骤自 9/22 加入起一次都没跑完过——宿主启动后零输出，挂满作业超时被取消；②本机表现为测试跑到一半宿主被静默带走，xcodebuild 假报 TEST SUCCEEDED（实际只执行了 102/229、129/229 等）；③logd 被灌爆的时段系统守护进程连环崩（与「每次测试都弹」的 WidgetRenderer/chronod 崩溃弹窗时间强相关）。修法：测试宿主（`XCTestConfigurationFilePath` 判定，与日志目录改写同款）不装泵——测试要的是解码器本身（`KernelLoggingTests` 直接喂 `KernelStderrDecoder`），不需要劫持 fd 2。修后 iOS 套件 229 用例一次跑完全绿、回声嵌套归零；macOS 套件 228 用例全绿不受影响。

## [0.2.0] · 2026-09-29 · 双端导航外壳重做与氛围背景贯通、弹幕匹配精准度、内核换装官方 v0.2.0

### 改动

- **氛围页卡片统一改半透明；iOS 设置页分组底清空（与 macOS 观感对齐）**。macOS 靠整窗氛围层垫底，页面透明处透出轮播图；但页面自己的卡片用 `.background.secondary` 实心底把图挡死（Bangumi 进度卡 / 搜索行 / 日历骨架、条目详情五处卡片），iOS 设置页更是一片死白——`Form` 的 grouped 行底是系统不透明白，`scrollContentBackground(.hidden)` 只管列表底、管不到行底。改动：①Bangumi 各处卡片与 `HoverRowHighlight`（搜索结果行 / 日历行）底改 `.ultraThinMaterial` 磨砂，透出氛围图；②iOS 设置页逐 Section 清空行底（新增 `settingsRowBackground()`，`#if os(iOS)` 限定），分组结构交给 Section 标题与分隔线表达，行直接浮在氛围图上（同 macOS 分组观感）。**踩坑记录**：`.listRowBackground` 挂在 `Form` 上在 iOS 完全不生效（行底是逐行的 trait，`Form` 自己是容器，写在它外面的值传不到行）——期间试过整档材质 / `glassEffect` / 按外观调透明度，因为修饰符没生效，观感差异全部来自轮播换片的错觉，最后用「行底涂红」实验才定位；且材质与 `glassEffect` 浅色下本身偏白（`.home` 遮罩浅色档本就盖 55%–66% 白雾），叠加仍是死白，故最终取全透。验证：iPad Pro 13″ 模拟器（iPad-repro）深浅色截图，与 macOS 设置页并排对比一致；OcPlayerTests iOS 全绿（229 用例）；macOS 构建通过。

- **自动化：启动直落分区（`OCPLAYER_START_SECTION` / `OCPLAYER_SECTION_SWITCH_SECONDS`）**。本机 Xcode 无 `Simulator.app`（模拟器只能无头跑），点按导航不可用，截图验收需要「进场即到目标页」的通道。`LaunchOptions` 增两个环境变量：`OCPLAYER_START_SECTION=home|bangumi|moviepilot|settings` 直落分区；配合 `OCPLAYER_SECTION_SWITCH_SECONDS=<秒>` 先留首页跑轮播（`homeAmbience` 要轮播加载后才非 nil）再切过去，避免冷启直奔某 Tab 时看到纯色底、误判背景没生效。`simctl launch` 传参需加 `SIMCTL_CHILD_` 前缀。

- **iOS 端 Bangumi / MoviePilot / 设置三个 Tab 补上氛围背景图**。macOS 靠整窗层把首页轮播垫在所有页面后面，这三个页自身透明所以都有背景；iOS 的 Tab 宿主不透明、轮播又只挂在首页 Tab 里，其余 Tab 一直是纯色底。改为三个 Tab 的根页面统一从 `AppModel.homeAmbience` 取轮播当前那张垫底（`BackdropAmbienceView` + `.home` 遮罩，与首页同参）——跨 Tab 背景连续、轮播换片时同步渐变，也不多拉一次图（图本就在内存缓存里）。设置页是 `Form`，其 `scrollContentBackground(.hidden)` 已在此前 macOS 轮就加好，分组底透明、氛围图直接透出。注意：TabView 未访问的 Tab 不会实例化，冷启直奔某 Tab 时 `homeAmbience` 还是 nil、该 Tab 暂为纯色底，回首页轮播跑起来后即恢复。验证：iPad Pro 13″ 模拟器逐 Tab 截图（Bangumi / MoviePilot / 设置三页背景在位）；OcPlayerTests iOS 全绿（229 用例）；macOS 构建通过。

- **iPad 推入页恢复显示顶部 Tab 胶囊（撤销 push 页收起胶囊）**。此前为避免「胶囊 + 返回键/标题」两行顶栏，在 push 页挂 `.toolbar(.hidden, for: .tabBar)`；实测（iPad mini，iPadOS 26.6）胶囊的收起发生在**推入动画结束之后**且不带过渡——推入过程中胶囊还在、返回键与标题被压在它下面，结束才消失 → 标题「从下一点的位置闪回顶部」。先后试过挂在路由页与挂在导航栈（按栈的 path 驱动）两种挂法，真机上时机都改变不了；iOS 27 模拟器则是推入首帧即收起（两版行为差异在系统版本）。系统 TabView 内无法根治，故撤销隐藏，回到系统标准形态：推入页顶部 = 胶囊 + 返回键/标题两行，全程稳定无闪烁（录屏逐帧确认：推入中与落定后胶囊、标题位置一致）。`hidesTabBarWhenRegular` 一并移除；若日后要「只有一个顶栏」，出路是 iPad 弃用系统 Tab 栏改用 macOS 同款外壳（见上一轮评估）。**并按需求去掉推入页的标题**（iPad 常规宽度）：`.navigationBarTitleDisplayMode(.inline)` + `.toolbar(removing: .title)`——页面头部自己有名字（详情页 Logo / 库页网格），顶栏只留胶囊 + 返回键。验证：iPad Pro 13″ 模拟器录屏 + 截图（推入页顶栏 = 胶囊 + 返回键，无标题）；OcPlayerTests iOS 全绿（229 用例）；macOS 构建通过。

- **iPad 进详情页不再「先黑一下」：入场动画收成 macOS 专用 + 背景从首页延续进来**。两处根因，都在 iOS 上被实测确认（iPad Pro 13″ 模拟器录屏逐帧量，30fps 亮度均值 0–255）：①`pageEntrance`（首帧 opacity 0 → 0.2s 淡入）是为 macOS 写的——macOS 系统 push 会被同帧的整窗氛围声明 / 工具栏重建吞掉，页面得自带过渡；iOS 的系统 push 本来就有滑动，再叠这层等于在滑动中多出几帧「整页透明」，露出底层黑底（实测亮度直落 **17**，落地页稳定态 34）。守卫放在 `PageEntranceModifier` 内部（`#if os(macOS)`），全仓 7 处调用一处覆盖。②更主要的那层黑：详情页背景是 backdrop@800，冷启必走一次网络；iOS 的导航栈宿主不透明（**栈后面垫一层到不了屏幕**，用醒目测试色实测确认，所以 macOS 那套「整窗层垫在栈后」在 iOS 复制不了），页面只能自己画底色，而暗色下 `Color.pageBackground` 就是黑。改为：**页面内做背景延续**——底图未就绪时先画首页轮播当前那张（`AppModel.homeAmbience`，由 `AmbientBackdropCarousel` 声明；与首页同 URL、同档解码，内存缓存命中，瞬时可画），自己的底图到位后由 `RemoteImage` 的 preserveCurrentImageOnReload 原位缓慢淡入替换。为此 `BackdropAmbienceView` 加 `fade` 参数：兜底那张用短淡入（默认的 1.6s 在推页那 0.35s 里只走到 ~25% 不透明度，观感等于没兜住），换成自己那张时仍走 `Motion.ambient` 缓慢渐变。实测转场：黑窗从「直到自己的底图到位（~1.5s）」缩到 ~0.3s，且背景与首页连续（抽帧确认：推入 → 首页那张 → 自己的底图）。**残留 ~0.3s 已根治**：兜底图虽是内存缓存命中，但 `RemoteImage` 也要异步加载再淡入，推页那零点几秒里背景仍是页面底色（夜间闪黑、日间闪白）。改为 `RemoteImage` 初始化时对内存缓存**同步**出图（命中即以位图初始化 `image` 与 `loadedKey`，加载任务直接跳过），推入页第一帧背景就是首页那张。实测推入逐帧亮度：100→91→84→77→71→66→70，全程平滑、最低 66 不低于落地页（70），黑/白闪消失。此改动在共享组件 `RemoteImage` 上、全仓生效：任何命中内存缓存的图首帧即出（此前一律异步 + 淡入）。验证：录屏逐帧对比 + 抽帧；OcPlayerTests iOS 全绿（229 用例）；macOS 构建通过（该平台走整窗层，未动）。

- **修「搜索 Tab 切走再切回后输入框消失」**。iOS 26/27 的导航栏搜索框默认「随滚动收起」，而搜索页正文不是 ScrollView（空态 `SearchEmptyState`）就是可滚动列表（`HomeSearchContent` 的结果）——正文里只要存在 ScrollView，**切到别的 Tab 再切回搜索 Tab，输入框会被系统收掉且不再恢复**（表现为搜索页只剩标题 + 空态，没有任何输入入口；首次进入搜索 Tab 是正常的）。二分实测（模拟器真机点击驱动 DeviceHub 镜像）逐项排除：外壳（TabView / 选中绑定 / path 绑定 / `appRoutes()` / Bangumi、MoviePilot 两个条件 Tab）都无关——把搜索页正文换成纯文本，切回来字段照样在；正文换成 `SearchEmptyState`、只加 `.scrollDisabled(true)`、换成内容超高的可滚动列表，三者都会丢字段。修法：搜索页 `.searchable` 改 `placement: .navigationBarDrawer(displayMode: .always)`（iOS 15+ 的「字段常驻、不随滚动收起」，非 iOS 26 新 API），字段位置与观感不变、结果列表滚动时也不再收起。验证：iPhone 17 模拟器两次「首页 / MoviePilot → 搜索」往返输入框均在位；OcPlayerTests iOS 全绿（229 用例）；macOS 构建通过（该 placement 仅 iOS，`#else` 分支保持原 `.searchable`）。

- **macOS 搜索入口修复 + 搜索实现两端共用**。上一条把搜索整体搬到 iOS 搜索 Tab 时，macOS 的搜索框（原挂 `HomeView.searchable`，窗口工具栏里那个）失去消费方，一并消失——本次补回：搜索结果区抽成两端共用的 `HomeSearchContent(query:)`（词由外部 `.searchable` 经 binding 传入，防抖与「词变了作废在途请求」改由 `.task(id:)` 承担，少一层手工 debounce 状态），iOS `HomeSearchView`（搜索 Tab）与 macOS `HomeView`（`#if os(macOS)` 的工具栏搜索框）各自提供入口与未输入提示，空态载体提为文件级 `SearchEmptyState`。两个平台各自实测：macOS 导航栏搜索框输入「朋友」命中并渲染海报墙（氛围背景正常）；iOS 测试全绿。结论同时明确：**Tab 化导航与搜索 Tab 都是 iOS 形态**——macOS 的分区入口是窗口工具栏玻璃药丸（Safari 式），`Tab(role: .search)` 在 macOS 上无对应呈现，继续保持两套外壳、共用业务实现。

- **修 iPhone 搜索点 X 收起后被系统重新展开（循环关不掉）**。上一条给首页补的 `.searchToolbarBehavior(.minimize)` 触发系统宿主互扰：iOS 27 模拟器逐帧复现——点 X 收起 0.4s 后搜索框自动弹回（文字保留）；二分实验（去掉 `.toolbar` 按钮组 → 不再重开；按钮组合/分拆无关）确认触发条件是「导航栏里存在任何 primaryAction 工具栏项 + minimize 搜索」，属导航栏搜索的宿主行为，应用侧绕不开。改用 Apple 规范化做法 **`Tab(role: .search)` 搜索 Tab**：搜索词 / 结果 / 分页状态整体从 `HomeView` 迁到新 `HomeSearchView`（同文件），`AppModel` 增 `Section.search` 与 `navPaths.search`，`compactLayout` 的 TabView 迁到 `Tab` API（`Tab(role:)` 要求全量 Tab 语法，不能与 `.tabItem` 混用）。搜索页 `navigationBarTitleDisplayMode(.inline)` 让字段常驻（大标题模式下 iPhone 会藏进下拉）。验证：模拟器驱动完整路径——搜索 Tab 进入 → 输入 → 点 ⊗ 清除（字段保持）→ 点 X 收起（0.5s/1.2s/2.5s 三帧均保持收起）→ 切回首页正常；搜索请求与空态渲染正常；OcPlayerTests iOS 全绿；macOS 构建通过（常规布局的搜索入口未动）。

- **iPhone 首页补常驻搜索钮**。`.searchable` 在 iPhone 上默认收进下拉，顶部工具组里没有放大镜（iPad 常规宽度本就渲染成搜索钮）；`.searchToolbarBehavior(.minimize)` 后两端一致——顶部玻璃组 = 打开 / 刷新 / 搜索。验证：iOS 27 双端模拟器截图确认。

- **iOS 撤掉底部「媒体库」Tab**。首页「媒体库」栏（`1112b78` 新增）已经是媒体库的唯一入口，Tab 是重复出口；`Section.libraries`、`navPaths.libraries` 与 `MediaLibraryListView` 一并摘除（`Route.library` 保留，首页栏仍走它 push 单库页），`AppModelLifecycleTests` 的清栈断言改指 `navPaths.bangumi`。验证：iOS 27 iPad Pro 13″ / iPhone 17 Pro 模拟器截图确认 Tab 只剩 首页 / Bangumi / MoviePilot / 设置、首页媒体库栏照常进库；OcPlayerTests iOS 全绿；macOS 构建通过。

- **iPad 撤顶栏药丸，分区切换改用 iPhone 同款 Tab；顺带修 iOS 首页氛围背景不显示**。顶栏药丸方案在 iPad 上从未真机验证过（当时仅编译验证），实测两处都坏：iOS 导航栏自带白底玻璃条，`.principal` 里的自绘玻璃组既不是悬浮药丸也不是 Mac 观感；氛围轮播垫在导航栈外的 AppShell 根节点 `.background` 里，被 iOS 不透明的 UIKit 宿主挡住整层到不了屏幕（iPhone 首页同病——`dd15527` 把轮播上移出页面时在 iOS 上就已不可见，`WindowAmbience.reachesScreen == false` 的判据早就写明 iOS 宿主不透明）。修法：①`AppShellView.layout` 收敛为 macOS 走顶栏药丸（`splitLayout`）、iOS 一律走 `compactLayout`（TabView）——iPad 分区切换、返回键、详情页顶栏全部回归 iPhone 同款系统行为，内容列宽仍按常规宽度取值；②AppShell 根节点的整窗氛围层改为 macOS 独占，iOS 首页轮播垫回首页 Tab 栈内页面 `.background`（布局隔离挂载——做成 ZStack 兄弟节点会复现 macOS 侧栏时代「ignoresSafeArea 撑大根布局、内容列顶出屏幕」的坑，本次实测复现后改 `.background` 消除）。AppShellChrome 的 iOS 顶栏分支随之不再可达，暂留待方案稳定后清理。验证：iOS 27 iPad Pro 13″ / iPhone 17 Pro 模拟器截图——iPad 顶部悬浮玻璃 Tab 胶囊 + 氛围背景满窗透出（含 Tab 栏玻璃下）、首页内容列边距恢复，iPhone 首页背景回归；macOS 构建通过（顶栏药丸路径未动）。

- **换页两段式转场 + pop 返回补过渡（`pageEntrance` / `routeExiting` / `routeReturning`）**。此前 macOS 上系统 push / pop 均被同帧的整窗氛围声明 / 工具栏重建吞掉（实测 1 帧硬切），只有详情页有自绘入场，其余 push 页面进出全是硬切，顶栏分区切换的交叉淡入也不可见。现统一为：①AppDesignKit 新增 `.pageEntrance()`（纯淡入，reduceMotion 经 `.motion` 直切），挂 `appRouteView` 路由出口覆盖全部路由页。②新增 `Motion.exit`（0.45s）退场 token：点击后当前页先整体淡出（`RouteExitFader` 读 `app.routeExiting`，挂在栈根与每个路由页上，从哪层发起哪层淡出），淡出完成才落地 push（`AppModel.beginRouteExit` 统一延迟落地，转场期间忽略新点击防连点）。③**pop 返回与 push 对称（自绘返回键）**：系统返回键的 pop 点击即系统级滑出，不经 binding 拦不住——常规布局把返回键自绘（`AppShellBackButton`，同位玻璃胶囊，`navigationBarBackButtonHidden` 换掉系统键），点击走 `AppModel.back()` 与 push 完全相同的两段式（淡出 0.45s → 禁动画 transaction 弹栈 → 落点页淡入）；compact（iPhone）保留系统返回键与侧滑返回。④**分区切换**同样走两段式：顶栏药丸改 `AppModel.switchSection`，当前页淡出后换分区（`selectedSection` didSet 清栈照旧），落点经同一淡出层淡入；compact（iPhone Tab）与 reduceMotion 直切。为此把 7 处 `NavigationLink(value:)`（媒体库列表、Bangumi 首页搜索行 / 进度卡、收藏列表、个人页、日历、章节区）换成 Button 走统一 `open*` 入口；设置「管理服务器…」「开源许可证」与 MoviePilot 顶栏「下载管理」、订阅卡 / 右键菜单 / 搜索结果「查资源」/ 详情页 MoviePilot 区块的资源入口改 `pushPresented` + 页级 `isPresented` + 目标页 `pageEntrance`。详情页私有入场实现撤除改共用版；落地恢复加前置拍（`Motion.restoreDelay` 0.05s）：新页先以隐藏态提交一帧、`pageEntrance` 首帧锚定后再翻 `appeared`——否则新视图与复位同帧出生（透明度无 from-state）+ onAppear 与首帧渲染合并，入场被吞成硬切。**修播放后背景丢失 / 首页透过详情页漏出**：播放器开合会翻转窗口工具栏可见性（`RootView` 的 `.toolbar(.hidden, for: .windowToolbar)`），重放 shell 生命周期——栈根 `pageEntrance` 重挂载即 `appeared=true`，首页透过透明详情页漏出、详情页氛围声明被清成「背景丢失」。栈根显隐改 **path 驱动**（`app.path.isEmpty`，栈里有页面即隐藏），与生命周期解耦；`pageEntrance(initiallyVisible:)` 参数随之移除。顶部工具栏按钮不参与过渡：分区药丸、自绘返回键、自绘标题与右侧系统工具项（打开 / 刷新 / 排序 / 添加订阅 / 下载管理 / 更多）统一走 NSToolbar 原生换项行为（与系统按钮一致，即换即现，无自定义淡出）——`routeExitFade` 只挂在页面内容上，导航条不挂。淡出层挂玻璃**外**（胶囊整颗一起淡，不是只淡内容）；顶栏标题文字系统渲染无过渡钩子，**push 页**常规布局改自绘（`appShellBackChrome(title:)`，`toolbar(removing: .title)` 隐藏系统文字，标题与返回键同一工具栏项保证顺序）参与淡入淡出，无同步名称的页面（如异步加载的 Bangumi 条目）保持系统标题；**根页面保持系统标题**——首页有 `.searchable` 搜索框与副标题都是系统渲染、无过渡钩子，自绘标题会把工具栏布局挤歪且只能淡一半，观感更差。右侧工具项（打开 / 刷新 / 排序 / 添加订阅 / 下载管理 / 更多）**保持系统按钮不参与过渡**（试过隐藏系统共享底 + 自绘胶囊让整颗淡入淡出，观感代价大于收益，回退）——系统共享玻璃底不随内容淡出会留幽灵胶囊，所以这些项不做淡出，随 NSToolbar 换项原样进出；搜索框为纯系统渲染，保持原样（无钩子，系统限制）。compact（iPhone）系统 push / present / pop 动画本来就在，直切不等待；MoviePilot 下载页的自动跳转（添加下载成功后）不属于点击导航，保持即时。遗留：切分区时顶栏按钮组整体换入换出是 NSToolbar 层重建，SwiftUI 无过渡钩子（按钮高亮随 0.45s 淡出后切换）；订阅 sheet 内与开源许可证内的深层子页仍是系统 push。验证：`OcPlayer-macOS` 与 `OcPlayer-iOS`（无签名）Debug 构建均通过；转场节奏待实机复核。

- **修详情页入场闪跳（背景图「闪一下变大再恢复」+ 进页无过渡动画）**。逐帧录屏定位到三个叠加问题，一并修掉：①**氛围背景随位图加载可见地缩放沉降**——`RemoteImage` 的位图以 `scaledToFill` 直接当 ZStack 子层画、参与布局：位图到位瞬间容器理想尺寸从「无比例」跳到「图片覆盖尺寸」，这个几何变化被氛围层挂着的 1.6s `Motion.ambient` 动画播成一段可见的缩放（裁剪窗口从紧到松，逐帧可见背景先「大」再沉降回正常）；图走网络必现、命中缓存发生在最初几帧所以「有时候」才看见，首页轮播 12s 换片同病。修法：位图一律画进 `.overlay`——overlay 不影响宿主尺寸，图到位只剩纯淡入。②**点击进详情页 1 帧硬切、无过渡动画**——系统 push 被同帧的整窗氛围声明 / 工具栏重建吞掉（录屏实测 5.83→5.90s 直接换页）；且 `isLoading` 把整页压到 0.86 透明度、数据落地再提亮，本身就是一次亮度脉冲。修法：去掉全页透明度脉冲，页面自带入场动画（内容淡入 + 12pt 上移落位，`reduceMotion` 自动直切），无论系统 push 是否被吞都有一段可见统一的过渡。③**氛围层灰占位淡入**——氛围声明改为底图预热完成后才发出（与氛围层完全同参预热：800 宽 URL + 512 解码，`DetailViewModel.prewarmAmbience`），淡入时图已就绪；取图失败保持不声明，回退纯色底。另给 banner↔ambient 头部布局切换（从续播 / 接下来看点进、占位条目无 backdrop tag 时触发）加交叉淡入，不再硬切跳变。已知遗留：进详情后顶栏右侧搜索框等首页工具栏项残留约 1s 才消失（NSToolbar 重建滞后），待观察是否与 push 被吞同源。验证：macOS Debug 构建通过、OcPlayerTests 全绿；实机复核入场过渡与背景稳定性通过。

- **常规布局撤掉侧栏，导航改顶栏玻璃图标组 + 独立「媒体库」按钮**。macOS / iPad 原来靠 `NavigationSplitView` 侧栏承载分区入口（首页 / MoviePilot / Bangumi）、媒体库列表与底部「设置」行；现在侧栏整列让给内容：分区收进顶栏**一组纯图标按钮**（共用一个液态玻璃圆角容器，当前分区带强调色底，版式对着 macOS 26 Safari 工具栏那组做——图标化后整组宽度只有原来文字版的三分之一，标题与搜索框不用再抢位置），媒体库**单独一颗同款按钮**（带小箭头，与 Safari 的「历史记录」按钮同一处理），点开弹出各库列表、当前库打勾，库拉取失败时在面板里给原因与重试——这段原本住在侧栏里，撤栏后必须跟着搬，否则「媒体库拉取失败」在常规布局下就彻底没有出口。已经在某个库里时按钮换成该库的类型图标 + 强调色底，一眼能看出身处哪个库。iPhone 底部 Tab 不变；两个集成的启用开关照旧门控对应按钮的显隐（停用瞬间选中回落首页）。

  **顶栏挂载点分两端**：macOS 挂**窗口工具栏**（`AppShellView` 根）——工具栏属于窗口而不属于某个栈，push 进详情页后这组按钮照样在，换页不必先返回；iPad 挂每个导航栈的根内容（导航栏由栈自己提供，`.principal` 居中）。`AppModel.Section` / `appRoutes()` / `RootView` 的播放覆盖层都没动。

  实现上踩到并记录两处：①**玻璃 tint 会晕开**——给选中段上 `.glassEffect(.regular.tint(...))`，颜色会顺着 `GlassEffectContainer` 的取样区域扩散，`.red` 全不透明时整条工具栏被染成粉红；而 0.55 的强调色 tint 又淡到与未选中段肉眼无差（两次实测截图对比）。选中 / hover 底最终改为**圆角矩形内的半透明填充**，落在内容层，清晰、不晕、深浅色模式下都稳。②**系统不给自定义工具栏视图提供玻璃**——把 `.glassEffect` 摘掉后按钮完全没有底（不是「双层玻璃」，HomeView 注释里那条警告只针对系统已上玻璃的标准控件）。另同步文案：设置页三处「侧栏」改「顶栏」，首页空态文案改指顶栏的「媒体库」按钮。

  验证：macOS Debug 构建通过；实机截图确认首页顶栏渲染（图标组 + 媒体库按钮）、经 AXPress 打开媒体库面板列出电视剧 / 电影 / 合集、切到「设置」后选中底与窗口标题同步跟随。**iPad 端只有编译验证**（`OcPlayer-iOS` scheme，无签名构建），未在真机 / 模拟器上跑过。

- **修 AppTests 的崩溃型 flaky（内核 stderr 解码压实回归测试）**。`KernelLoggingTests.testDecoderDoesNotRetainConsumedBytes` 有两处独立缺陷：①**进程崩溃**——`Self.mallocInUseBytes() - before` 是两个 `UInt64` 相减，而 `malloc_zone_statistics` 量的是进程级活内存、循环里既分配也释放，`after < before` 时下溢、当场 SIGTRAP（`Swift runtime failure: arithmetic overflow`）。表象极具误导性：**0.000 秒「失败」、无任何断言文案**，实为测试宿主进程被打崩；实测 5 轮崩 2 轮，崩溃报告 `OcPlayer-*.ips` 从 17:16 起共 8 份全是这一个测试。改用有符号差值。②**阈值假失败**：崩溃一直在掩盖断言抖动——2 MiB 阈值对进程级统计太紧，实测同代码 grown 跨四个数量级（272 B / 1.0 KB / 1.4 KB / 2.6 KB / 2.8 KB / 6.4 KB / 176 KB，另 4 轮为负；两轮顶到 2.23 MB），约 11% 假失败。阈值提到 8 MiB：真正的回归是「留住整条流」≈ 12 MB（生产实测 60 MB+），仍接得住。**试过并否决的替代方案**：把迭代数从 20 万提到 100 万以放大信号——实测噪声与分配次数近似成正比，100 万次下噪声跟着涨到 14.2 MB（n=6：2.2 KB / 7.4 KB / 11.9 KB / 2.9 MB / 2.9 MB / 14.2 MB），信噪比没有改善，故维持 20 万次。修后完整套件 222 用例全绿、崩溃报告 0 新增。

- **修 iOS 套件的时序 flaky（PlaybackControllerOpenTests）**。`testPauseIntentDuringInFlightOpenAppliesPauseAfterSuccess` 在 iOS 模拟器上偶发「前置：open 应处于在飞」等不到：open 的完成回调要经主线程 Task 才把**进程级**在飞计数 `activeOpenAttempts` 减回去，而测试方法返回时这些回调可能还没落地——前一个用例（`testOpenWorkersHaveABoundedCapacity`，恰好把 2 个在飞槽占满）刚一结束，下一个用例的 open 就撞上「后台媒体打开任务已满」直接走失败分支（引擎零调用、`openingRequestID` 从未赋值，与现场断言逐条吻合；macOS 上时序快，从未暴露）。修法：`PlaybackController` 加 DEBUG 观察口 `activeOpenAttemptsForTesting`，测试类 `setUp` 改 async、开跑前先把计数排到 0（最多等 3 秒，等不到就让该失败的用例自己失败）。

- **修「库内搜索后切走再回来只剩搜索结果」**。分页缓存的键只有 `libraryID`，而库内搜索是把结果**原地**写进该库那一格：搜「败犬女主」→ 点进详情 → 回首页 → 再点该库，`LibraryView.searchText` 是 `@State`、视图重建后已空，缓存里却还是那几条 → **搜索框空着、网格只剩当初搜出来的几个**，且没有任何入口能切回浏览页（只能重新搜一次再清空）。给缓存键加上搜索词维度（`AppModel.LibraryPageKey`：库 + 词，空词 = 浏览页），浏览页与各搜索词各占一格，切走再回来各自还原。配套三处：请求发出时快照当时生效的词并用它写回对应格子（否则 await 期间改词会把第一个词的结果落进第二个词的格子）；`onChange` 同步切键，消掉防抖窗口里「框里是新词、内容还是上一个词」的中间态；旧搜索词的格子随新词作废丢弃（搜索框一次只装一个词、切库还会清空，旧格子再也读不到），浏览页与上限兜底逻辑保持不变。新增 2 个回归用例。**另修掉本次改动引入的打字闪动**：切键那一拍新格必然是空的，而 `isLoading` 还是 `false`，body 会落到 `items.isEmpty` 分支、满屏渲染「没有匹配」，每敲一个字闪一次空结果页（350 ms 防抖 + 网络往返的整段窗口）；改为切键时同步进入加载态，同一窗口渲染骨架屏。清空搜索框时也不再作废浏览页缓存重拉（那是「切走再回来」的落脚点，本就是有效的），避免「内容 → 空 → 内容」的白闪。

- **「海报氛围背景」开关移除，氛围图改为常开**。设置页「通用」分组的开关与 `SettingsKeys.ambientBackdrop` 一并删除：详情页与首页轮播不再有开关维度，条目有 backdrop 图即铺氛围底，没图仍回退清晰横幅（这条判断本就与开关独立，见 `DetailView.isAmbientActive`）。**老用户无迁移成本**：该键删掉后全仓库不再有任何读取点，盘上残留的 `false` 是死键——升级后氛围图照常出，不会出现「以前关了、升级后还锁在关」的状态。残留键刻意不主动清理：无读取点即无影响，为它加启动期清理反而多一条要维护的路径（已 grep 确认 App / Packages / AppTests 三棵树除本注释外无引用）。顺带修掉「删除只做了一半」导致的 **App target 编译失败**——`AmbientBackdropCarousel` 仍在读已删的 key（包测试全绿，错误只在 App target，所以此前没暴露）；并同步 README、详情页注释、`SettingsKeys` 头注释、设置页类注释里的过时描述。

- **自定义 User-Agent（播放器白名单服放行）**。设置 → **网络**新增「自定义 User-Agent（可选）」输入框：部分 Emby/Jellyfin 服开了播放器白名单，表现为能登录浏览、一拉流即被拒——把 UA 填成白名单内的播放器（如 SenPlayer）即可通过。**全局生效**（不按服务器档案分，所以 UI 在顶层「网络」分组而不是某台服务器的分组里）。三条请求发送口**逐请求**读取偏好（`ClientIdentity.customUserAgent`），设置改完即时生效、无需重连：Emby 裸传输层 `EmbySession.data` 与 Jellyfin SDK 出口 `JellyfinServer.send` 各按当时值加 `User-Agent` 头（登录 / 探活会话另在 `URLSessionConfiguration.httpAdditionalHeaders` 带会话创建时刻的值，**合并**已有头而不是整体赋值，避免吃掉调用方自带的额外头），播放拉流 `PlaybackController.openPreparedRequest` 把它随 `Authorization` 一起传给内核 `open_with_headers`。取值时剔除控制字符：`URLRequest.setValue` 遇到带换行的值会把**整条头**静默丢掉（不报错），用户会以为白名单 UA 生效了、实际发的是系统默认；粘贴 UA 常带尾随换行，所以是剔除而不是整值作废（作废同样会静默退回默认）。留空 = 系统默认，行为不变。测试：两端传输层各一条「自定义 UA 逐请求携带」用例 + 两条取值净化用例；UA 用例改为存旧值还原，不再无条件清 key。

- **媒体库站内搜索**。库海报墙页顶部新增搜索框（`.searchable`，输入防抖 350ms 后发服务端查询）：`MediaServer.itemsPage` 协议新增 `searchTerm` 参数，Emby 走 `/Items?searchTerm=`、Jellyfin 走 SDK `searchTerm`，搜索结果与排序 / 观看状态筛选 / 分页缓存（`AppModel.libraryPages`）全链路复用——搜索也是一种筛选，不另起结果页。切库自动清空搜索词（只在**真的换库**时清：`.task(id:)` 每次 appear 都重跑，比对 id 才不会把「搜到结果 → 进详情 → 返回」的搜索词和滚动位置一起清掉）；无结果时给专属空态文案。**检索粒度到剧集为止**：剧集库只按剧集条目名匹配，单集标题不参与检索（分集搜索刻意不做——服务端 `searchTerm` 对单集命中率低，且「搜到某一集」的落点应是剧集详情而不是直接播放）。防抖重载走可取消路径（`await load`），慢速连续输入不会并发堆请求；`load` 被取消时不再把加载态落下去——缓存已清空，「非加载态 + 空 items」会闪一帧空态。测试：两端「searchTerm 落 query」用例。

- **首页全库搜索**。首页顶部新增搜索框（`.searchable`，防抖 350ms 后发服务端查询），搜的是**所有媒体库**——`itemsPage` 不带 `parentId` 即全库检索（电影 + 剧集，与首页卡片粒度一致）；各库页的搜索框不变，仍只搜各自的库。结果以库页同款海报墙就地替换 rails，支持滚动翻页与失败重试（footer 的自动预取靠 `onAppear`，必须待在 lazy 容器里——非 lazy 的 ScrollView 内容只在加入视图树时触发一次，第 3 页起就不会再自动预取）；结果是瞬态数据，只住视图 `@State`，不进 `AppModel.libraryPages` 分页缓存（回首页就该回到 rails）。氛围背景修复：`.background` 的背景尺寸跟随被包内容，搜索的空态/错误态是抱紧内容的小块——打字瞬间背景塌成内容小块、出结果再撑开，肉眼可见地闪；顶栏玻璃底下没图还会变纯白（实测像素 (249,249,249)）。现搜索空态/错误态（连带首页加载失败态）改用 ScrollView 承载（`containerRelativeFrame` 垂直居中）——只有 ScrollView 的 frame 会自然铺到工具栏/侧栏玻璃底下，裸 EmptyState 连 `frame` 撑满 + `ignoresSafeArea` 都救不回来；背景全程满窗。`searchLanded` 落地门只用来区分「还在搜」和「搜完了」：本词结论落地前搜索区显示骨架屏，不抢跑闪一帧错误的「没有匹配」；但**不能**拿它把整个搜索态挡回 rails——那样手上还有旧结果时每改一个字都会整页弹回首页再跳回来（有旧结果就继续显示旧结果，新结果回来原地替换，改词全程不闪）。搜索失败文案走 `localizedDescription`：`JellyfinError` 是 `LocalizedError` 不是 `CustomStringConvertible`，插值会把 `JellyfinError(kind: …)` 反射串直接摆给用户。搜索在途时切服务器会清空搜索词回 rails，旧服务器的结果不落进新会话。（中途试过把轮播挪成 ZStack 兄弟节点：背景的 `ignoresSafeArea` 会把根布局撑到全窗宽，内容列铺进侧栏底下、换片闪屏，弃。）另按服务端实测在单字无结果时给引导文案：Jellyfin/Emby 的 `searchTerm` 分词对单字不匹配，两字以上的子串才命中。检索粒度同样到剧集为止（电影 + 剧集条目名，单集标题不参与），空态副文案里写明，免得用户以为搜坏了。搜索速度依赖服务端自己的索引（Jellyfin/Emby 的 `searchTerm` 查询本就打在服务端 SQLite 索引上），客户端不另建本地索引。

- **内核换装上游官方 `v0.2.0`，fork 阶段收尾**。Erika 上游把 fork 上先行的改动全部合入：v0.2.0 带入杜比视界 RPU 映射 / HDR tone-mapping / 感知色域映射管线（#136）、headless GIF 导出 `erika_export_gif`（#138，App 暂未接入）、HTTP(S) 持久流式预取（#139）。实测新 release 的 `erika.h` 与上一版 fork 内核（`v0.1.9+dolby.streaming.fix.dev`）**逐字节相同**——C ABI 无变化，App 侧零适配，持久流预取 / 预取窗口封顶 / 回退预算（`http_back_buffer_bytes`）语义与 0.1.9 记账一致，0.1.8 的慢源 A/B 口径（开播 13.2 秒、78.3 秒零卡顿）沿用。钉点切回官方：`Scripts/build-macos.sh` / `package-macos.sh` / `package-ios.sh` / `release.yml` / `test.yml` 删除 `ERIKA_REPO=fork` 默认值（`fetch-erika.sh` 默认上游即生效），`ERIKA_VERSION` 默认 `v0.2.0`，新增 `Scripts/erika-v0.2.0.sha256`（哈希取自 release 自带 `SHA256SUMS`，下载实校通过）。回归：ErikaKit 30 用例全绿（含真跑内核的离屏渲染与预读行为套件）。README 内核说明与 `PlaybackPreferences` / 预读行为测试的版本注释同步更新。

- **弹幕匹配精准度：规范名合成 + 集号 token 打分 + 类型硬门槛 + 手动搜索别名合并**。四件事都有生产/实测背书（对生产网关与官方 schema 逐条核对过）。①**合成文件名**：Jellyfin 源文件名是裸数字（`01.mkv`）时，旧实现合成 `番剧名 第N季 E05 01.mkv`——实测这种「E 标记与尾巴数字冲突」的形态会让弹弹play 的模糊匹配锁到「第1话」；现在统一走 `DanmakuFilenameParser.canonicalMatchName`（原名含番剧名就原样保留、只剥扩展名，否则合成规范名且不拼回原名），standalone 同修；缓存身份改用**原始**文件名，以后调合成规则不再让已记住的映射失效。②**集号 token 与特典**：弹弹play 把特典/OP-ED 放在同一作品下的 `S`/`C`/`O` 命名空间（实测 `episode=S2` 返回「S2 …」特典），旧实现的宽松兜底会把 `S5 聖地巡礼` 当成第 5 话——新增 `DanmakuEpisodeToken`（正片数字 / 特典命名空间+序号），season-0 条目按文件名关键词判定命名空间，特典候选对正片目标不再以集数命中；**特典目标不再拿 Jellyfin 序号发 `episode=S<n>`**（实测与弹弹play 的 S 序号不同源，序号 29 会唯一命中同 IP 剧场版的 S29），改走全集搜索让打分器选。③**类型硬门槛**：剧场版与剧集是不同作品，类型不匹配直接出局——用户实报的错匹配（中二病 S00E29 特典被同 IP 剧场版的 S29 抢走；旧打分在模糊与检索两条路径分别命中无关日剧第29话 1548 / 综艺第29话 1550）实测修复为 noMatch 手动选。④**手动搜索别名合并**：弹弹play 搜索认不得「另一个中文译名」（实测搜「虽然我是不完美恶女～雏宫蝶鼠替换传～」返回的全是无关作品），手动选弹幕时并发用 Bangumi 的 nameCN 换库内标题再搜一次、按 animeId 去重合并（Bangumi 首条实测即正确标题；解析结果永久缓存、负缓存 7 天，失败静默）。自动路径的 tier-1 文件名模糊对这类译名本来就有效（实测 rank 0 命中，新旧打分同分 2898）。**特典自动匹配的边界**：hash 未命中且本地元数据无身份信息（如「第 29 集」这种泛化名）时落 noMatch 手动选——元数据里没有的信息不该靠猜。测试：DanmakuKit 156 用例、AppTests 全绿；打分器用生产真实候选集离线复验（错匹配三路径全灭、正确 case 保持命中）。

- **Bangumi 登录改走 OcPlay 网关，客户端不再持有 OAuth 应用密钥**。授权地址由 `GET /v1/bangumi/oauth/authorize?state=` 拼（`client_id` / `redirect_uri` 在网关侧），换 token 与刷新走 `POST /v1/bangumi/oauth/token` / `/refresh`，业务 API（收藏、章节、搜索）仍直连 `api.bgm.tv`。`Secrets.xcconfig` / `Info.plist` 里的 `BANGUMI_APP_ID` / `BANGUMI_APP_SECRET` 随之删除——旧 secret 已进过构建产物，应在 bgm.tv 轮换。登录前置条件变成「网关地址 + 带 `bgm:oauth` 权限的 API Key」，与弹幕共用同一份设置（`AppModel.bootstrap` 与网关设置变更时推给 BangumiKit）；未配置时登录页给引导文案，网关错误码映射为对应提示（`SCOPE_REQUIRED` / `GATEWAY_NOT_CONFIGURED` / `OCPLAY_USER_AGENT_REQUIRED`，`BANGUMI_OAUTH_REJECTED` 清凭证回未登录）。`refresh_token` 仅在 Bangumi 轮换时返回，响应缺该字段时沿用旧值；`expires_in` 缺省时按一周兜底。BangumiKit 新增 5 用例（state 每次授权轮换且与请求一致、state 不匹配不发网络请求、换 token 只带 code 且请求带 `X-API-Key` + `OcPlay/` UA、网关 403 各错误码各自文案、refresh 未轮换时沿用旧 refresh_token），用按 host 分派的 mock URLProtocol 离线跑。对生产网关做过一轮真网络冒烟（跑完即删）：authorize 返回真 bgm.tv 地址、错误 code 与错误 refresh_token 都被 Bangumi 拒绝并正确落到「重新登录」。

- **修 `BangumiAPIClient` 的 403 分支丢掉响应体**（真网关冒烟测出来的）：403 曾直接抛 `notice("请求被拒绝，请检查权限")`，body 被丢弃，于是网关的 `SCOPE_REQUIRED` / `OCPLAY_USER_AGENT_REQUIRED` / `GATEWAY_NOT_CONFIGURED` 全都退化成同一句笼统文案。现在 403 走标准映射（`.forbidden(body)`，面向用户的文案与旧行为逐字相同），网关错误码才解析得出来。


### 修复

- **弹幕偶发「弹幕服务暂时不可用」**（先定因后修）。真实根因在生产网关：OcPlay Worker 偶发抛未捕获异常，CF 把它包成 HTTP 500 返回——CF 调用统计的 `scriptThrewException` 与 App 侧 500 逐分钟吻合，而网关自己的 D1 请求日志对此记的是 200（遥测在响应投递前落库，所以网关日志里永远看不到这次失败），此前按 502/503/504 口径接的重试因此全部漏接。叠加第二个成因：本机到网关的链路有 TLS 握手被重置的抖动（实测约 12%，直连甚至会整段黑洞），客户端对这类连接错误同样一次即弃。客户端修复：`DandanplayError.isRetryable` 把 500 与 `.cannotConnect` / `.secureConnectionFailed` 纳入重试集——匹配/搜索/正文全是幂等只读，实测同一请求秒级重试即成功（08:17 / 08:57 / 13:47 三次失败均由几十秒内的同一请求成功验证）；取消（-999）仍不重试，500 进集后编排层「网关故障短路剩余降级层」语义不变、重试耗尽才短路。GatewayClientTests 新增瞬态 500 与 TLS/连接类错误重试用例，编排层「500 一次即抛」用例断言翻转为耗尽 3 次尝试。网关侧的异常原文仍待取（CF dashboard → Workers Logs 或 `wrangler tail --status error`），拿到后再治根。

- **播放越久内存越涨、关掉也不回落：内核 stderr 解码缓冲无限增长**（真机实测定位）。`KernelStderrDecoder.ingest` 用 `remainder = remainder[idx...]` 切片分帧——`Data` 切片共享底层存储，已消费的行前缀一直留在存储里，下次 `append` 沿偏移 realloc 时把它们一并保住，于是缓冲把进程一生流经的内核 stderr 全部字节都留住。详细日志开启时内核把 playback/demux trace 写文件**且**回声到 stderr（高流量），把这缓冲喂得飞快：实测一条播放会话残留 60MB+，24 分钟播放进程内存涨 200–400MB。它可达（解码器持有），所以 `leaks` 扫不出；又在 xzone 的 4 MiB 段里涨，于是进程内存以 4 MiB 步长爬升——这正是「内存随播放增长、停播不回」的真因，**与内核无关**（内核单独无头实测跨集播放零泄漏、`in_use` 每轮稳定、IOSurface 归零）。修复：消费完把残行 `Data(remainder)` 拷到全新右尺寸存储，让旧存储随切片离开被释放；残行 ≤ `maxLineBytes`，拷贝开销可忽略。真机实测（自检模式真实渲染路径）：修复前 24 分钟 footprint 持续上涨，修复后升到 ~128MB 工作集即拉平、4 分钟零增长。AppTests 补 `testDecoderDoesNotRetainConsumedBytes` 回归用例（喂 20 万行断言活内存不涨）。

- **iPad 详情页氛围背景落黑底**：详情页在常规布局下靠 AppShell 垫在整块 `NavigationSplitView` 后面的整窗层出氛围图——macOS 的 split view 是透明的，垫在后面能透出来；iOS 的 `UISplitViewController` 自带不透明底，垫在后面的层到不了屏幕，而页面自身又不垫任何底，于是整页落在 split view 的底上（深色外观下与纯黑无异：实测正文、顶栏条带、左缘全为 `(0,0,0)`）。新增 `WindowAmbience.reachesScreen` 判据（macOS true / iOS false），详情页与 MoviePilot 资源页按它分叉：够不着屏幕时常规布局也自己垫 `BackdropAmbienceView`，并补 `Color.pageBackground` 兜底（详情页原有兜底的条件同步放宽）；`windowAmbience(_:)` 声明仍只在够得着屏幕的平台发——iOS 上没人消费它，省掉一次窗口大小的离屏渲染。修复后实测正文 `(85,77,67)`、顶栏 `(153,140,102)` 都有图；macOS 上 `reachesScreen` 为 true、`drawsOwnAmbience` 退化成原来的 `horizontalSizeClass == .compact`，行为不变。

- **MoviePilot 资源页侧栏玻璃底下没有氛围图**（iPad；macOS 正常）：该页的氛围图多挂了一句 `.drawingGroup()`，它把子树栅格化进离屏纹理、纹理边界取扩展前的 frame，于是把链尾的 `.ignoresSafeArea()` 截断——图出不了内容区。iPadOS 上详情列本身跨满整窗、侧栏宽度是它的左安全区，全靠那一步 `ignoresSafeArea` 才铺到侧栏玻璃底下（详情页没有这句，所以它的背景能铺满整窗、侧栏能透出来，实测左缘 `(79,20,14)`）。去掉它与 `.allowsHitTesting(false)`（`.background` 本就在内容之下，不吃点击），和详情页写法对齐；顺带补上「没海报时兜底 `Color.pageBackground`」。修复前侧栏内部 `(21,21,20)` 中性灰、左缘 `(0,0,0)` 纯黑；修复后 `(31,35,30)` / `(27,47,41)`，与内容列 `(64,68,49)` 同族、侧栏右缘横切平滑过渡，内容列像素不变。注意 `drawingGroup()` 当初是为「资源搜索页掉帧」加的，但那批同时删掉了 300 多行实时玻璃着色器；滚动资源列表若有掉帧再单独议。

### 待跟进（内核侧，上游 Erika）

- **开播 HEAD 探测约 3.8 秒**：0.1.8 记账的待跟进项①。内核 open 先发 HEAD 探测、失败再回退一字节 range；部分源站对 HEAD 恒回 403（如三重跳转的 strm 源），这段探测纯属浪费。修复在内核（上游 Erika），本仓只记账；核心里能省掉「HEAD 失败再 range」的往返即可。v0.2.0 的 release 说明与 CHANGELOG 均未见此修复，继续记账。

## [0.1.9] · 2026-09-22 · 内核换装 v0.1.9+dolby.streaming.fix.dev——预取窗口封顶，播放期间内存不再随窗口增长

### 改动

- **内核换装 `v0.1.9+dolby.streaming.fix.dev`：持久流预取的窗口不再无界**。这是 0.1.8 里记的待跟进项②——上一版内核下播放期间进程内存会随预取窗口增长（1.6 GB 片源实测峰值 RSS 1415 MB，而 App 传的预读 / 回退各 32 MiB，疑似开放式 GET 的前向窗口没起封顶作用；macOS 无碍，iOS / tvOS 上有 jetsam 风险）。内核侧根因（fork commit 85a9738）：worker 原先只从 reader 的 `paused` 标志得知「窗口满了」，而 reader 在包队列满时就不再刷新该标志——快源上这个背压信号因此失效，整个资源被预取完（927 MB 片源实测缓存到 659 MB）；现在每个 worker 按自己的生产偏移对绝对边界自我节流，不再依赖 reader 的刷新节奏。**C ABI 无变化**：`erika.h` 与上一版逐字节相同，`ErikaOpenOptions` 布局未动，App 侧零适配。钉点同步换到 `Scripts/build-macos.sh` / `package-macos.sh` / `package-ios.sh` / `release.yml` / `test.yml`，并新增 `Scripts/erika-v0.1.9+dolby.streaming.fix.dev.sha256`（哈希与 release 自带的 `SHA256SUMS` 逐字节核对一致）。杜比视界 RPU 映射与持久流预取本体未动，0.1.8 的慢源 A/B 口径（开播 13.2 秒、78.3 秒零卡顿）仍然成立。

### 文档

- **README 的构建与测试口径对齐现状**：`--disable-swift-testing` 只对纯 XCTest 包安全——BangumiKit 与 ErikaKit 用的是 swift-testing，照旧文案加这个开关会把它们的套件静默跳过（ErikaKit 那 30 个用例全在里面，它另有 4 个 XCTest 文件，两套并存）；末尾那行「0 tests in 0 suites」只是 swift-testing runner 空跑，不代表 XCTest 没跑。CI 的实际范围也写明：macOS scheme 的 `OcPlayerTests` 加 8 个 SPM 包，AppDesignKit 未纳入循环，ErikaKit 只跑不依赖 GPU 的套件。另修 DanmakuRenderKit 的描述（`DanmakuViewAdapter` 已在 bffe2b7 删除，现为异步绘制图层）与 `SKIP_ERIKA_FETCH` 的脚本清单（补 `package-ios.sh`）。

## [0.1.8] · 2026-09-21 · Emby 全链路加固、公网慢源播放修复与详情页媒体信息

### 重构

- **Emby 与 Jellyfin 在解码契约上分家：Emby 改走裸 HTTP + 宽松 DTO，Jellyfin 保留官方 SDK 强类型；200 行 `EmbySanitizer` 整层删除**。起因是 Emby 的问题反复落在同一个根因上——`jellyfin-sdk-swift` 的强类型枚举值域就是 Jellyfin 的值域，而 Emby 作为前身产品值域更宽：`VideoRange` 会报 `"DolbyVision"`、`MediaStreams[].Type` 会报 `"Attachment"`（MKV 内嵌字体）、`LockedFields` 会报 `"SortName"`、`Type` 会报 `"CollectionFolder"`。这些值让 SDK 解码**整包炸**，于是历史实现养了一层 JSON 重写：`JellyfinServer.send` 不走 SDK 的 `client.send`，而是 `client.data(for:)` 拿裸 Data、全量 JSON 重解析 + 递归深拷贝洗一遍、再用 SDK 的 decoder 二次解码。代价有两处：**Jellyfin 的每个响应都被迫改道**（为 Emby 的问题付费），而且这层洗白**并不全覆盖**（`reportPlayback*` / `downloadSubtitle` / 登录响应都绕过它），规则本身还带「同名不同义不能互相污染」这类误伤风险（`Type` 在顶层是 `BaseItemKind`、在 `MediaSources[]` 是 `MediaSourceType`、在 `MediaStreams[]` 才是 `MediaStreamType`，历史上误伤顶层 `Type` 打挂过章节列表）。分家后的形状：① 新增 `MediaServer` 协议作为两家的唯一契约（25 条方法 + `profile` + `authorizationHeader`），`JellyfinServer` 与新增的 `EmbyServer` 各自实现；② **Emby 侧不建任何 Swift 枚举**——`EmbyDTOs` 把 `Type` / `CollectionType` / `VideoRange` / `MediaStreams[].Type` / `LockedFields` 一律收成 `String?`，脏值在映射层落到 `.unknown` / `.other`，或者干脆不匹配任何分支被自然过滤（`"Attachment"` 不再需要被改写成 `"Data"`，它只是不等于 `"Video"`/`"Audio"`/`"Subtitle"`）。**九条洗白规则全部变得不必要**，`LooseItems.swift`（`EmbySanitizer` + `LooseDecoding`，253 行）整个删除，`JellyfinServer.send` 回到 `client.send(request).value` 一行。③ 映射逻辑不重复：`ServerItemFields` 作为「服务端条目 DTO → `MediaItem`」的中间表示，SDK 的 `BaseItemDto` 与 Emby 的宽松 DTO 各填一份，季/集号语义、父级图回退规则、缺 id 时的确定性派生只存在一处（这避开了「两边都降成无类型」路线的重复代价）。④ 按 `kind` 分叉只剩**一处**：`MediaServerFactory`（造会话）与 `MediaServerLogin`（探活 + 登录，探活也改走裸传输，于是 Emby 的整条登录链路不碰 SDK）。App 层 27 处 `JellyfinServer` 全部改成 `any MediaServer`，只有 3 个调用点因协议不能带默认参数而补全了实参。⑤ 上报协议窄化：`PlaybackReporting`（3 条方法）下沉到包内、`MediaServer` 继承它，App 的播放上报协调器只依赖这 3 条——测试替身不必实现另外 20 多条。测试同步重组为 `JellyfinServerTests`（纯 Jellyfin）/ `MediaServerLoginTests`（登录与探活，两家共用）/ `EmbyServerTests`（Emby 路由与宽松值域），旧的洗白用例改写成「响应仍能解出域模型且真值没丢」。净变化：删除 1795 行、新增约 1500 行。

- **清掉三处零引用死代码，净删 747 行**：全项目过度设计审查后落地，纯删除、无行为变更——`DanmakuRenderKit` 的 Gif 弹幕子系统（`DanmakuGifCell` / `DanmakuGifCellModel` / `GifAnimator`，480 行）包内外零引用；`DanmakuViewAdapter`（SwiftUI 适配器，143 行）同样零引用，App 直接实例化 `DanmakuView`；`DanmakuViewDelegate` 体系（协议 + 默认实现扩展 + delegate 属性 + 12 处调用点，约 120 行）全仓无人 conform、无人 set delegate。另删 `ChapterSkippingEvaluator` 协议（单实现，实际跳过源在 `ChapterSession` 上游合并）与 `PlayerState.clearError()`（唯一调用方是它自己的单测）。`PlaybackReporting` / `PlaybackReportingStateSource` 经核实均有测试替身（`TestPlaybackReporter` / `TestPlaybackStateSource`），属合格测试缝，保留。

### 新增

- **Emby 的片头 / 片尾识别：从章节 marker 翻译出与 Jellyfin 同形的 segment**。Emby 没有 `/MediaSegments` 接口（那是 Jellyfin 插件生态提供的），历史实现直接返回空、回退到章节名启发式——而 Emby 其实把片头 / 片尾标成了章节 marker（`MarkerType: IntroStart / IntroEnd / CreditsStart`），这是在白扔服务端已经算好的真值。现在 `EmbyServer.mediaSegments` 读 `fields=Chapters` 并翻译：`MarkerType` 兼容枚举名与**数字下标**两种形态（下标顺序即 Emby 枚举声明顺序，不能改）；很多集只有起始 marker 没有结束 marker，取**下一个章节的起点**顶替（那正是片头交接给正片的位置），后面没有章节的保持无界不猜长度；片尾没有结束 marker 则一直跑到条目 `RunTimeTicks`。

- **Emby 4.10 的「接下来看」逐剧扫描兜底**。Emby 4.10 对**不带 series 范围**的 Next Up 恒返回空数组，而同一查询限定到某部剧时返回正确的那一集——表现是首页「接下来看」整行空着。现在空结果会触发兜底：取最近看过的 25 部剧（按 `DatePlayed` 倒序、按剧去重，连看一整季不会刷出几十条重复），逐部问 scoped NextUp 取第一条，5 条并发。**顺序必须稳定**——并发回来的顺序不保证，所以按剧 id 收进字典、最后按「最近看过」的原顺序还原（这条是测试发现的真 bug：初版用 `withTaskGroup` 直接收集，行序会随调度抖动）。非空结果不触发扫描，省掉最多 25 次额外请求；扫描自身出任何问题都保留原答案，不让整行报错。

- **详情页新增「媒体信息」区块：按当前选中集展示该集文件的媒体参数**（剧集跟随横向选集，电影显示自身；目录/合集等无文件条目整块不出现）。展示四组：视频（分辨率 + 宽高比、编码 + profile、码率、帧率、动态范围、色彩、位深、隔行）、音频（逐轨：语言 · 编码 · 声道布局 + 声道数 · 采样率 · 码率 · 默认标记）、字幕（逐轨：语言 · 编码 · 外挂/强制/默认）、文件（容器、大小、时长、文件名）。**数据源刻意用 `GET /Items?ids=&fields=MediaSources` 而不是 `POST PlaybackInfo`**：后者是开播协商端点、会建播放会话，在详情页翻看选集不该在服务端留下会话记录（与既有 `externalSubtitles` 同一条只读路由）。多版本条目（同一集挂多个文件）按**开播同款规则**选源——直连优先 → 可直推 → 第一条——该规则从 `AppModel+Playback` 的内联判断抽成 `MediaSourceSelection`，详情页与开播路径共用一份，保证「展示的文件」就是「点播放会打开的文件」；版本数 > 1 时区块头带「共 N 个版本」。其余实现要点：`MediaFileInfo` 域模型只带文件名不带完整服务器路径（浏览面不摊目录结构）；平均帧率缺失或离谱（0 / 超大脏值）时回退实时帧率；`DOVI*` 全变体统一显示「杜比视界」，与 `PlaybackSessionContext.isDolbyVision` 判定同口径；认不出的色彩/动态范围原样透传而不猜；媒体信息按条目 id 缓存在本次停留内，来回点选集不重拉、不闪 loading，且竞态守卫用「正在拉的是哪个条目」而非 Bool，避免切集时旧请求把新集的 loading 清掉。顺带把 Bangumi 作品信息用的 `EqualRowHeightGrid`（同行等高网格）从 `BangumiSubjectDetailView` 的私有实现提为 AppDesignKit 公开组件，两处共用。JellyfinKit 新增 7 用例（完整字段映射、多源选源与直推回退、无媒体源返回 nil、老服务端字段缺失、帧率回退、Emby 脏枚举端到端），App 层新增 11 用例（码率/大小/帧率/分辨率与宽高比/声道/采样率/动态范围全变体/色彩/编码容器大写/语言/时长）。

- **详情页「剧集」行新增正序 / 倒序切换**：长剧从第 1 集排起，续播的最新一集要翻几十页。行右上角加同款胶囊按钮（集数 > 1 才显示），倒序即选集条反转，选中集的自动滚动定位不受影响；排序只影响横向条展示，不动数据与选中态，偏好跨启动保留。

### 修复

- **首页三条 rail 改为各自独立成败：一条挂掉不再把整页清空**。原来 `loadHome` 用 `try await (resume, nextUp, latest)` 一个元组收口，**任何一条失败就把三条全丢**、`home.error` 一设整页白屏。起因是一台公网中转 Emby 的实测：同一会话里 Jellyfin 局域网稳定 23–56ms，而那台 Emby 中位 370ms、长尾到 22s、**13 个请求撞满 30s 上限**（超时还成组出现——16:11:22 / 16:11:58 / 16:12:01 三批，每批 5 个请求在同一毫秒一起超时，典型的服务器间歇性假死）。这种服务器上「另外两条已经拿到内容」是常态，却被一条超时全带走。现在三条并发、各自把成功或失败收进 `RailResult`（不抛），成功的覆盖、失败的**保留上一次的内容不清空**，只有三条全挂才置 `home.error`（`HomeView` 本来也只在 latest 为空时展示整页错误态，部分失败时置 error 只会白白遮住已拿到的内容）；逐条 rail 的失败各留一条 warning 日志，便于按 rail 定位是哪条接口慢。取消不算失败，避免换会话时把过期请求的取消报成错误。新增 4 用例（一条挂掉另外两条留下、三条全挂才报错、失败保留旧内容、过期 generation 不写回）。

- **Emby 的「接下来看」逐剧扫描加三层预算，不再拖住首页**。扫描是「无范围 Next Up 返回空」时的补充手段（Emby 4.10 的行为），代价是 1 + N 条额外请求（N 上限 25）。它本身在快服务器上很便宜（实测 warm 180ms/条），但在一台 warm 都要 3–9 秒、偶尔 >30s 的服务器上，逐条问一遍能把这一行拖到几分钟——而这一行在首页加载的路径上。三层收口：① 无范围那次已经慢过 1.5 秒 → **整轮跳过**（这一行拿不到内容是可接受的降级，把整页拖住不是）；② 单条请求 5 秒封顶（新增 `EmbySession` 的逐请求 `timeout` 覆盖，默认 30s 对补充请求太宽）；③ 整轮 4 秒预算，超了返回已拿到的部分。最坏情况从「几分钟」收到约 9 秒。新增 1 用例（服务器已慢时不发任何扫描请求）。

- **诊断日志的脱敏正则不再吞掉服务器 API 路径**。脱敏规则原本是 `(?i)(?:file://)?/(?:Users|home)/[^\s"'<>]+` 的泛匹配，本意是抹掉本地文件系统路径 `/Users/jumusu/Documents/...`——但 `/Users/` 同时是 Jellyfin / Emby 的 **API 路由前缀**，于是 `path=/Users/user-e/Items/Resume` 整段变成 `<user-path>`，而这正是排障时最需要的那一列（上面那次定位就因此无法区分 Views / Resume / Latest 是哪个端点慢，只能靠时间线反推）。改为锚定本机用户名（`/Users/<NSUserName()>` 与 `/home/<name>`），既只抹真正要抹的东西，也不误伤 API 路径。取舍：同机上**别的**用户的家目录路径不再被抹——App 只写自己的容器和用户显式选中的文件，这个面很小。新增 1 用例（5 条典型 API 路径逐一断言不被脱敏），原有用例改为按当前用户名构造输入，不再依赖跑测试的机器是谁。

- **Emby 认证头 scheme 从 `MediaBrowser` 改成 `Emby`**。`ClientIdentity` 原本两个产品共用 `MediaBrowser …`，现在按产品分叉（`authorizationHeader(scheme:token:)`，Jellyfin 仍 `MediaBrowser`）。这是两家唯一的分叉点，其余字段与拼接顺序完全一致，因此上层用该头哈希做缓存键的语义不受影响。

- **Emby 的 `Fields` 参数加白名单过滤**。Emby 收到不认识的 `Fields` 名字会**拒掉整个请求**（不是忽略那个字段），而 `ItemCounts` 是 Jellyfin 独有的字段名——之前没发过所以没踩到，但下一个加字段的人会踩。现在发出前摘掉，摘空则整个参数不发。

- **Emby 上 token 过期不再无声无息**。Jellyfin 侧本来就有「已登录会话收到 401 → 发通知把 UI 拉回重登流程」的兜底，Emby 侧没有——token 失效后只会让后续请求持续裸报错误。现在 `EmbySession` 在同口径下发同一条通知（`MediaServerAuthentication.authenticationRequired`，常量从 `JellyfinAuthentication` 改名，它已不只服务一家；`JellyfinServerScheme` 同理改名为 `ServerScheme`）。**关键是只有已登录会话才发**：匿名会话（探活 / 登录阶段）的 401 是密码错误，发了会把用户从登录页踢回登录页——传输层因此显式区分 `profileID` 是否为 nil，两个方向各有一条用例。

- **两处 Emby 实现自身的缺陷（由新测试发现）**：① `UserItemDataDto` 的已看标志在 wire 上是 **`Played`** 而不是 `IsPlayed`（那是 `BaseItemDto` 顶层别处的拼法）——Emby 的宽松 DTO 一开始按 `IsPlayed` 写，`PlayedPercentage` / `PlaybackPositionTicks` 全部读成 0；同时记下一个坑：`keyDecodingStrategy` 会先把 JSON 键转成小写首字母再和属性名比对，所以任何显式 `CodingKeys` 都得按转换后的形态写，这里改为直接让属性名对上。② 「标记已看 / 取消已看」的状态回读用了裸 `JSONDecoder()`，绕过了会话带键名策略的解码器，导致一次成功的写入被读成「未看」；改为统一走 `EmbySession.decode`。另：上报接口刻意**不解析响应体**——这几个端点有的回 204 无 body，去解一个空 body 会把成功的上报报成失败。

- **iPhone 横屏点开 HUD 功能面板（弹幕/字幕/音轨/章节/更多）画面被撑大再弹回（issue #5，本基线复发）**：面板是动作簇的子视图，它的高度沿 `GlassEffectContainer` → HUD 根 `ZStack` → 播放器根 `ZStack` 一路把尺寸撑大——根 `ZStack` 尺寸 = max(子视图)，而视频 surface 是贪婪子视图，frame 跟着长，内核 `resize_surface` + CoreAnimation 把旧 drawable 拉伸 = 画面被撑大/缩放。模拟器 A/B 实测（自动开合面板 + surface 尺寸日志）：基线面板开合窗口内 surface 高度 `1206→1212→1337→1384→1394→1396→1206`px 弹簧振荡（402→465pt，与此前真机实测 `rootZStack 402→465.3` 吻合），也证明模拟器能复现**布局层面**的病（`6bf6c26`「模拟器看不出差异」只对玻璃渲染成立）；修复后窗口内 surface 零变化。修复只改承载、不动观感：① 动作簇外套**固定尺寸承载框**（`.frame(width:height:alignment: .bottomTrailing)`，高度 = 按钮行 + 间距 + 卡片上限）——显式 frame 向父层报告的是给定值，面板开合与面板内部怎么测量都无法再改变簇的尺寸，传播链从结构上切断，按钮行锚定与面板展开方向不变；② 新增 `PlayerHUDPanelMetrics` 面板几何预算单一事实源，卡片高度上限改按档位取静态值（横屏 iPhone `verticalSizeClass == .compact` 按最保守 375pt 屏高推导 213pt，其余 320pt），且**把子菜单头部（返回键 + 标题 46pt）算进卡片预算**——此前只限内容不扣头部，「播放速度」这类子菜单的簇高 428pt 必然顶出 402pt 屏；③ 新增 `PlayerLayoutClamp`（GeometryReader 贪婪容器，报告恒等于提案）套在浮动跳过按钮层上——它按面板实测高度动态让位、理想高会超屏，是同一类传播路径，夹紧后层内布局与让位行为不变。`GlassEffectContainer`/`glassEffectID`/`matchedGeometry` 液态形变/按钮重排/展开动画全部保持原样（`6e82991` 回退说明要求「恢复原始展开观感」）。⚠️ 面板高度上限必须是静态档位：「实测高度回写 @State → 喂回布局」在这个视图层级会形成每帧震荡的布局反馈循环（历史教训）。

- **全屏下鼠标移到 HUD 顶栏按钮位置 HUD 立即收起、按钮点不到（issue #4）**：macOS 原生全屏时系统把工具栏条带放进独立窗口 `NSToolbarFullScreenWindow`（高 52pt，悬在主窗之上），而全屏 HUD 顶栏只留 22pt 上边距，关闭 / 退出全屏 / 音量一排控件正压在条带里——指针滑进条带落在系统窗口上，主窗口的 `NSTrackingArea` 因此收到 `mouseExited`，触发了「移出窗口立即收起 HUD」，于是「鼠标放到按钮位置」被误判成「鼠标离开了播放器」；鼠标一动 HUD 又回来，再碰再收。两层修复：`PlayerMouseTrackingView` 的 `mouseExited` 用 `NSEvent.mouseLocation` 对窗口 frame 复核，指针仍在窗口矩形内就不算移出——对全屏顶缘唤出菜单栏等一切「被别的窗口盖住但没真正离开」的场景一并免疫，真正移出窗口仍立即收起；全屏 HUD 顶栏与长按倍速徽章的顶边距从 22pt 提到 56pt，整体让到条带之下，按钮的悬停与点击不再被条带窗口截走（窗口态 58pt 避标题栏拖动区的口径不变，iOS 布局不动）。

- **Emby 上回退直连播放时进度上报全部被拒 400、续播位置丢失（issue #3 日志 87 次全 400 的根因）**：三个独立开源项目（plezy / OhMyCine / go-emby2openlist）实测交叉证实，Emby 的 `/Sessions/Playing` 与 `/Sessions/Playing/Progress` 在 body 缺 `PlaySessionId` 时必拒 400（`Value cannot be null. (Parameter 'key')`，Emby 4.9.5），`Stopped` 容忍缺失；Jellyfin 三个端点都接受缺失。而回退直连路径（`PlaybackInfo` 失败 → 裸 URL 播放）构造的会话上下文没有 `playSessionID`——在该服务器上上报 100% 失败，续播位置全部丢失。修复：只对 Emby 档案、且没有协商会话时，按 `itemId` 合成一个**确定性**会话 id（`ocplayer-<itemId>`，照 plezy 的 `_resolvePlaySessionId` 模式）——确定性保证同一片源的 start / progress / stopped 三段上报落在服务端同一会话行，而不是三条孤儿会话；有协商会话则原样透传；Jellyfin 档案行为一字不动。同时 Start / Progress 的 body 补上 `SessionId` 字段（与 `PlaySessionId` 同值，对齐 Swiftfin 的上报形状）。JellyfinKit 新增 4 用例（Emby 回退合成、Jellyfin 回退保持省略、协商会话不被覆盖、合成确定性）。

- **Emby 上杜比视界片源拿不到服务端播放会话、整个媒体库列表可能加载失败（issue #3 的枚举解码问题）**：Emby 兼容层有几个字段的值域比 jellyfin-sdk-swift 的枚举更宽，强类型解码整包炸掉。诊断日志（issue #3 附件）里共 45 次解码失败，三种值：`VideoRange` 报 "DolbyVision"（SDK 只有 Unknown/SDR/HDR，40 次）——`/Items/{id}/PlaybackInfo` 因此失败、调用方「回退直连」（日志里 7 次），杜比片源丢失 `mediaSourceID` / `playSessionID` 与服务端协商，只能裸 `?Static=true` 拉流；`MediaStreams[].Type` 报 "Attachment"（MKV 内嵌字体，SDK `MediaStreamType` 无此 case，4 次）——同样炸 PlaybackInfo，实测波及《少女终末旅行》整季；`LockedFields` 报 "SortName"（SDK `MetadataField` 无此 case，1 次）——它在 `/Items` 列表响应里，一条脏值就把**整个媒体库列表**炸成「媒体库列表加载失败」。修复都在既有的 `EmbySanitizer` 洗白层，对标准 Jellyfin 是无害透传：`VideoRange` 的未知值归一成 "HDR"（**与上游 Jellyfin 语义一致**——其 `MediaStream.GetVideoColorRange()` 对杜比视界返回的就是 `(VideoRange.HDR, VideoRangeType.DOVI*)`，Emby 只是把粗粒度字段写细了）；`MediaStreams[].Type` 的未知值归一成 SDK 已有的 "Data"（附件流保留、只修类型值）；`LockedFields` 按数组元素过滤，剔除 SDK 不认识的项（该字段 App 侧无消费方，信息损失为零）。**关键约束是只洗 `VideoRange` 而不碰 `VideoRangeType`**：App 的杜比判定（`PlaybackSessionContext.isDolbyVision`）只看后者的 DOVI 前缀，而 SDK 的 `VideoRangeType` 有完整 DOVI 系列 case、原样透传即可——洗粗粒度救解码，靠细粒度保真值域。三处规则都按 key 精确限定子树（`Type` 在顶层是 BaseItemKind、在 MediaSources[] 是 MediaSourceType、在 MediaStreams[] 才是 MediaStreamType，同名不同义不能互相污染），并保证幂等（`JellyfinServer.send` 对非 Emby 档案是「先直接解码、失败再 sanitize 重试」，同一响应被洗两次是真实路径）。JellyfinKit 新增 5 用例（三处值域各一条、标准 Jellyfin 零影响一条、幂等一条——幂等用例比对语义而非字节，因 Foundation 的 JSONSerialization 不保证键序）。

- **iPhone 播放中横屏锁整个失效（回退误撤修复后复发）**：`AppModel` 持方向切换闭包、由 App 启动时装配的写法有个隐藏前提——闭包必须装在实际存储并注入 `RootView` 的那个 `AppModel` 实例上，而 SwiftUI 会多次创建 App 值，经 `@State` 属性访问到的 appModel 与注入的不是同一实例（`ObjectIdentifier` 实测 `0x8000` vs `0xb200`）：handler 装在了将被丢弃的临时实例上，`presentedPlayer` didSet 触发时恒为 nil，`setPlayerActive` 从未被调用——`requestGeometryUpdate` 不发，手动转设备也被 `mask=portrait` 拒绝。改为无装配时序依赖的广播模式：`AppModel` 在 didSet 里发通知，`IOSApplicationDelegate` 在自身 init（App 启动最早阶段）注册观察者并执行方向切换（delegate 实例由 `@UIApplicationDelegateAdaptor` 直接创建，不存在实例替换问题）；启动即播时 scene 尚未连接，方向请求先攒下、`UIScene.didActivateNotification` 到达后补发。`setPlayerActive` 顺带补上正式诊断日志（「方向切换 playerActive=…」）。模拟器实测启动即播自动进横屏。

- **Bangumi 详情页与关联选择器在 iPhone 上横向溢出**：`BangumiLinkPicker` 写死 `minWidth: 480`，而 iPhone sheet 宽度不足 480，两侧内容被裁出可视区——最小宽度改为只约束常规宽度（`horizontalSizeClass != .compact`）。条目详情页头部同批适配紧凑宽度：海报从 130×195 缩到 100×150 给信息列留宽度；标签徽章行从 `HStack` 改走 `FlowLayout` 自动换行（不换行必横向溢出）；操作行四个元素（收藏状态 / 我的评分 / 已看进度 / MoviePilot 下载）在紧凑宽度下拆成两行，常规宽度维持原一行布局。

- **紧凑端「海报氛围背景」开关来回切时标题上下跳**：`ambientCompactHeader` 的标题原本顶边贴屏（`padding(.top, 52)`），与 `compactHeroBanner` 的标题不在同一竖直位置，于是开关切换（有图 / 无图两条头部）时标题会跳一段，正文区起点也随头部高度变。现在标题占同一个 `compactBannerHeight` 英雄带、同样底对齐 + 8pt 内边距，只是没有图片层——开关来回切标题不动，正文区起点两边一致；顺带解决顶边贴屏那版会把艺术字 Logo 压进状态栏（离灵动岛只剩几个点）的问题，底对齐后 Logo 顶边恒定落在 198pt 以下。

### 改动

- **内核换装 `v0.1.9+dolby.streaming.dev`：公网慢源上「播不动 / 卡死」的问题解决**：旧内核（`stream.prefetch.fix.dev`）的按需读取仍走每 4 MiB 一次的有界请求，**每块都要重付一次连接 + TLS + TTFB**——在一台单请求延迟 1–5 秒、且约一半请求会在传输中途挂死十几秒的公网服务器上，单次 4 MiB 读取实测 1.0–8.9 秒；而 4 MiB 在 6.5 Mbps 片源上只够 ≈5 秒画面，首块一读完补给就断。实测后果：一台三重跳转（Cloudflare → Emby strm 307 → Alist 302 → 对象存储）的服务器**开播 60 秒看门狗超时、整场播不起来**（内核自身 66.5 秒才完成 open，只比看门狗晚 6 秒）；另一台单请求延迟正常但一半请求中途挂死的服务器上，90.3 秒播放里 **41.8 秒在缓冲**（46%）、最长一次冻 37.6 秒、音频累计欠载 43.6 秒静音。新内核把预取改成**持久流 worker**：每个 worker 持有一条开放式 GET（`bytes=锚点-`），源站每个 worker 只 seek 一次、背压交给 TCP，按需读取不再逐块重付往返。同一台服务器、同一套 App 实测对比：开播 13.2 秒成功（旧版超时失败）；按需读取只剩 3 次（均为开播探测）；预取 stripe **457 条，中位 31ms / p95 75ms / 最大 900ms，0 条超 1 秒**（旧版每 4 MiB 1–10 秒），网络错误 0 条；**78.3 秒播放零卡顿——`buffered_ms: 0`、`stall_count: 0`、0 次 buffer 事件、音频欠载 0 帧**；帧延迟中位 3ms / p95 8ms / 最大 16ms。trace 事件名同步换代：`http_range_error` / `http_range_retry` 被 `http_stream_body_error` / `http_stream_open_error` / `http_stream_worker_done` 取代（排障时按新名找）。同时带入 libplacebo 风格的杜比视界 RPU 映射 / HDR tone-gamut 管线（PR #136）。**C ABI 纯增量**：`erika.h` 只 +36 行（新增 `erika_export_gif`），`ErikaOpenOptions` 布局未动，App 侧零适配。钉点同步换到 `Scripts/build-macos.sh` / `package-macos.sh` / `package-ios.sh` / `release.yml` / `test.yml`，并新增 `Scripts/erika-v0.1.9+dolby.streaming.dev.sha256`（哈希与 release 自带的 `SHA256SUMS` 逐字节核对一致）。回归：App 202 + 各 SPM 包 383 + ErikaKit 30，全通过。**两点待跟进**：① 开播仍有约 3.8 秒花在 HEAD 探测上，而这台服务器对 HEAD 恒回 403（内核先 HEAD、失败再回退一字节 range），是可再省的一段；② 该内核下播放期间进程内存会随预取窗口增长（1.6 GB 片源实测涨到约 1.3 GB，峰值 RSS 1415 MB），而 App 传的是预读 / 回退各 32 MiB，疑似开放式 GET 的前向窗口未起封顶作用——macOS 无碍，**iOS / tvOS 上需留意 jetsam**。

- **内核换装 `v0.1.9+stream.prefetch.dev`：HTTP 预读改持久流，回退预算开放可调**：fork 的预加载重做（commit 5ff79d7）——两个 worker 持有**开放式 GET**（`bytes=锚点-`），源站每个 worker 只 seek 一次，背压就是 TCP 本身，替代了 `dolby.buffering.dev` 的 4 MiB 分块链（旧方案每个 4 MiB 都付一次请求延迟，慢源上预读追不上播放）。慢源 A/B（72 Mbps、单请求 2 秒延迟）：播放速率 0.15x → 0.73x，健康时段可到 1.0x。同时带入杜比视界 RPU 映射与 #137 request-cap/resume/rewind-cache。**回退预算从内核固定 16 MiB 开放为 `ErikaOpenOptions.http_back_buffer_bytes`**（C ABI 变化：`reserved[3]` 缩为 `reserved[2]`、新字段落在偏移 24，结构体尺寸不变仍为 48 字节，read-ahead 偏移 16 不动），高码率片源按「码率 × 期望回退时长」取值（16 MiB 在 71 Mbps 下只够回退 ~1.8 秒）。App 侧适配：`PlaybackSource` 新增 `backBufferBytes` 透传内核；设置页「播放」组新增「回退缓冲」档位（默认 16 / 32 / 64 / 128 MiB，0 = 内核默认），预读说明文案随持久流语义回落；`open.start` 诊断事件补 `back_buffer_bytes` 字段。ErikaOpenOptionsLayoutTests 锁死新布局（回退预算落在偏移 24）。

- **跳过片头/片尾加入设置开关，保底片尾保留时长从 20 秒改为默认 10 秒且可选**：设置页「播放」组新增「跳过片头」「跳过片尾」两个开关（默认开，关闭后播放中不再弹对应类别的「跳过」按钮，改动即播即生效）与「片尾保留」档位（不保留 / 5 / 10 / 15 / 20 / 30 秒，默认 10——原硬编码 20s 会拖到黑屏、错过自动连播窗口）。保留时长只作用于「末 90 秒保底跳过片尾」的落点（片长 − 保留秒数，不往回跳；不保留时钳在片长 − 0.5s 防内核 EOF 错误风暴）；服务端 MediaSegments / 章节启发式给出的片尾标记有精确区间终点，仍按终点跳。App 层新增 11 用例（门控、落点钳制、默认值与非法存量回落、控制器 seek 实测）。

- **关于页开源许可证新增「社区数据与服务」组**：App 设置 → 关于 → 开源许可证按 catalog 顺序分四组（主要依赖 → 社区数据与服务 → SwiftPM 依赖 → Erika 内置组件），新增组列出 Jellyfin / Emby（媒体服务器）、弹弹play（弹幕数据）、AniSkip / AniList（片头标注与 ID 映射）、Bangumi、MoviePilot；服务类条目没有随包文本，详情页只列主页与数据来源说明。打包脚本的许可证拷贝走自己的清单（SwiftPM checkouts + Erika licenses）、不读 Swift catalog，新增条目不影响打包校验。

## [0.1.7] · 2026-09-16 · 弱网播放修复（issue #1）、日志系统重整与设置页重组

### 修复

- **播到一半就停（issue #1）：内核换装 `v0.1.9+dolby.buffering.dev`，弱网只缓冲不再中断**：根因是内核把整个预读窗口作为**一次** HTTP 请求拉取，而单请求有 15 秒响应上限——32 MiB 档等于要求 ≈18 Mbps 持续带宽，低于门槛两次超时后 demux 直接把播放判死，只能手点「重试」。新内核（fork 合流版 commit 122be55：dolby.1 杜比管线 + 上游 PR #137）改为 **4 MiB 分块拉取**——单请求封顶、超时续传、预取失败降级同步读（不再判死）、保留 16 MiB 已播尾巴供回退命中（实测回退 10 秒零网络请求）、媒体源原始错误透传到 demux 错误。节流压测（3 Mbps 测试片 + 32 MiB 档）：700 KB/s 下 2 倍速播放（需求 750 KB/s 超过供给）全程只缓冲、干净播到片尾；250 KB/s（需求 3 倍于供给，旧内核 open 阶段即死）约 3 分钟拖完整片，0 播放错误。该 release 附全平台资产，macOS / iOS 首次同内核。C ABI 无变化，App 侧零适配。ErikaReadAheadBehaviorTests 断言适配分块语义（单请求 ≤4 MiB 封顶为回归守卫，另支持 `ERIKA_READAHEAD_TEST_MEDIA` 指定本地大文件验证）。
- **MoviePilot token 过期后不再甩原始 JSON、不再挂着无效的「重试」**：服务端对**过期 JWT** 回的是 403 + 自家信封 `{"success":false,"message":"token 校验不通过","data":null}`（只有缺 token / 解不出 payload 才是 401，jwt 过期签名落在 `verify_token` 的 `InvalidTokenError` → 403 分支），而客户端此前只把 401 当登录失效——403 落进 forbidden，信封里又取不到 FastAPI 的 `detail`，整包原始 JSON 直接当文案甩给 UI，且完全绕过「401 → 静默重登 → 失败才广播」的自愈链路：token 死了页面还显示已登录，「重试」永远失败。三层修复：错误体解析兼容 MP 信封（文案取 `message`，`detail` 兜底）；401/403 带 token 校验措辞一律归为 `requireLogin` 走静默重登——密码没改就无感自愈（订阅/搜索/下载全链路受益），密码改了或登录不上才清 token 广播通知把 UI 拉回未登录态；SSE 流式搜索的 401/403 同口径归一。订阅页与搜索页的错误态区分登录失效：标题「登录状态已失效」，按钮从「重试」换成「重新登录」直弹 MoviePilot 登录窗（预填地址与账号，只补密码）；「未登录」门控同样补了直弹登录窗入口。MoviePilotKit 新增 4 用例（403 信封自愈重放 / 普通 403 不误伤 / 信封文案提取 / 分类契约）。
- **缓冲不再强弹 HUD（issue #2「三十秒闪一次」的可见症状）**：HUD 的显隐判据此前只有一个 `canAutoHideControls`（`(playing||paused) && !isBuffering && 无遮挡`），且「变化即唤出」——于是每轮缓冲起止都强制唤出一次 HUD，跟着弹出来的是全屏压暗遮罩（`PlayerHUDReadabilityScrim`，32% 黑）＋转圈＋弹幕冻结，网络抖动下就是用户看到的「画面暗一下亮一下」。判据拆成 `PlayerHUDGates` 的两个值：`revealTrigger`（该不该唤出：暂停 / 错误 / 字幕导入 / 弹幕选择 / 辅助功能 / 播放起止）与 `canAutoHide`（能不能自动收起，缓冲期间为 false）；`PlayerHUDVisibilityCoordinator` 新增 `refreshAutoHide(canAutoHide:)`——缓冲只续期、不计显隐：HUD 在屏上就留住，已收起则不会被弹出来。**顺带修掉因此暴露的转圈对比度问题**：中央缓冲指示以前靠 HUD 的全屏暗幕托底，HUD 不再强弹后白转圈直接压在亮画面上几乎看不见，改成套 `PlayerHUDPanel` 暗底（与错误徽章 / 2 倍速徽章同族）并常挂载 + `.opacity` 淡入淡出（HUD 收起期间没有容器动画托底，`if` 挂载会是硬闪）。App 层新增 6 用例（含「缓冲只改收起资格」「不弹已收起的 HUD」两条回归）。
- **UI 缓冲态加迟滞，单帧饿数据不再闪动控件**：`PlayerState` 新增 `isBufferingSustained`——进缓冲要**连续持续 300ms** 才置位，恢复时补足 500ms 最短可见时长再收回（期间再进缓冲不重计、不收回）。转圈、HUD 状态行「缓冲中」、弹幕冻结/续播、HUD 收起计时全部改用它；诊断真值 `isBuffering`（`buffer.start/end` 事件、卡死看门狗）不受影响——埋点里不留迟滞。PlaybackKit 新增 4 用例（单帧饿数据完全不惊动 UI / 上沿与最短可见 / 收回前再进不闪 / reset 取消在飞计时）。
- **日志跨进程共写把记录撕碎（116 行残缺）**：`diagnostics.jsonl` 用 `FileHandle(forWritingTo:)` + `seekToEnd()` 打开、各进程各记文件偏移，"App 进程 + 测试宿主进程"共写同一文件时，后写者的 write 落在旧偏移上覆盖对方——实测三份文件共 116 行残缺（两条记录互相插入、或一条被拦腰截断，样本里能看到测试假内核名混进真实日志）。改为打开后置 `O_APPEND`（每次 write 由内核原子追加到真实末尾），补回归用例 `testAppendLandsAtRealEndWhenAnotherWriterIntervenes`，A/B 验证有牙齿：禁用 `O_APPEND` 时该用例必挂（对方写入被覆盖，3 行变 2 行）。历史残缺行仍在旧归档里，未清理。
- **维护会把「正在写的」日志文件删掉**：保留策略要跳过当前会话文件，但 `contentsOfDirectory` 返回的 URL 会把 `/var` 解析成 `/private/var`，直接比 URL 恒不相等 → 当前文件被判成淘汰候选。改成解析符号链接后比路径。由新写的「按数量淘汰最旧、当前文件永不删」用例抓出（实测确认 URL 字符串差异）。
- **测试宿主污染真实日志目录**：`xcodebuild test` 注入的 App 进程跑真实代码，一次全量 AppTests 会在 `~/Library/Logs/OcPlayer/` 留下 6 个会话文件（也是上面那 116 行残缺的另一半来源）。测试宿主现在改写临时目录（`XCTestConfigurationFilePath` 判定），跑完真实目录文件数不变。
- **弹幕时基混用致偏移非零时弹幕整集不出现（清屏死循环）**：弹幕 overlay 的 seek 跳变检测在 `tick` 里比较**原始媒体时间**，而 `resync`（装载 / seek / 改偏移后对齐）写入的却是**减过偏移的生效时间**——两个时基混用。只要偏移非零（dandanplay 匹配返回的 shift、或 HUD「时间偏移」调出 ±0.5s 以上），对齐后的下一拍算出 `delta ≈ 偏移量 + 1/60s`，越过 seek 阈值被误判成 seek → 再对齐 → **永久循环**：每拍 `view.stop()/play()` 清屏、发射逻辑永不执行，表现为「弹幕一条都不出来」。检测逻辑抽成纯值类型 `DanmakuSeekDetector`（只持原始媒体时间一个时基，类型本身杜绝再次混用），`resync` 的对齐基改回原始时间（积压兜底基维持生效时间同源不改）。修复后「调偏移修对齐」不再把弹幕全部弄没。App 层新增 7 用例：核心回归是「偏移 3s 下对齐后下一拍必须连续」，另覆盖前后向跳变仍被检出、`jumped` 后基准推进、`reset` 回无基准态。
- **Bangumi 集成开关读取吃掉默认值，全新安装的播放结束自动标记静默关闭**：后台门控用 `UserDefaults.bool(forKey:)` 读「启用 Bangumi」——这个开关默认 `true` 但**默认值从不落盘**（Toggle/`@AppStorage` 只写用户拨过的值），键不存在时 `bool(forKey:)` 返回 `false`，于是对所有从未拨过开关的人（含全新安装）实际是「停用」：播放结束不再自动标记看过，只在诊断日志里留一行「集成已停用」。新增 `UserDefaults.bool(forKey:default:)`（键不存在回 fallback，注释写明这个坑并落在 `SettingsKeys` 便于发现），门控改用它；`PlaybackPreferences.storedBool` 的私有同款实现收敛为委托该方法（行为逐字不变）。App 层新增 3 用例。
- **章节 / MediaSegments 链路静默失效（时序竞态）**：`loadChapters` 与引擎 `open` 并发执行（章节请求 28ms 即回，引擎 open 约半秒），但其时效守卫要求 `activeRequest` 已是当前请求——而 `activeRequest` 恰恰要到 open 完成才赋值，守卫因此**每次必败**，三个 await 检查点静默 return：MediaSegments 请求不发、章节与服务端跳过标记全部丢弃、日志零痕迹（媒体库装了 Intro Skipper 插件也不会生效）。守卫改为只认装配层的 `expectedRequestID`（跨请求换片时同步更新，是这路数据真正的失效判据），与引擎 open / 引擎重建解耦；作废路径补日志，不再无声。修复后 Jellyfin / Emby 的章节列表、章节名启发式与 MediaSegments 片头片尾识别首次真正可用。

### 改动

- **设置页「网络预读缓冲」文案随新内核回落**：内核按 4 MiB 分块拉取后，档位不再对应成比例的带宽门槛（约 2 Mbps 即可稳定拉取），文案改为「数值越大越能抗带宽抖动，内存占用相应增加；弱网下无需刻意调小，回退播放有 16 MiB 缓存兜底」——`PlaybackPreferences` 档位注释、设置页说明与 README 同口径。
- **内存 tick 记录补 `output_mode_switches`**：输出模式切换计数此前只参与「这次 tick 要不要记」的判定，日志里看不到值。现在进字段（每次记到的 tick 都带），配合内核 `ERIKA_HDR_DEBUG` 的 `ErikaHDR: … output mode=…` 行，现场就能分辨「显示器侧真的切了 HDR / 刷新率」还是 UI 自己闪（issue #2）。ErikaKit 新增 1 用例。

- **日志系统重整：默认档精简 + 一键诊断包 + 播放事件行 + 内核 stderr 接入**（issue #1/#2 排障暴露的缺口，完整清单见提交历史与 `Docs/LOGGING.md`）。四件事：
  1. **级别口径重定 + 默认 `info` 档**：全仓 119 处 debug 调用点逐条定级（升 info 约 63、升 warning 27、留 debug 18、合并删除 25，另删 6 个无调用方的网络日志死包装）——「一次操作的结果」「状态迁移」必须在默认档可见，守卫与中间态留 debug。管线加了进程级最低级别（默认 info）与实例覆盖，过滤放在**消息求值、脱敏、节流之前**（`@autoclosure` 消息因此不求值；被压掉的记录不污染节流计数）。
  2. **设置页「详细日志」开关 + 「导出诊断包…」**：开关打开 = debug 档并联动内核 `ERIKA_HTTP_TRACE`/`ERIKA_PLAYBACK_TRACE`/`ERIKA_HDR_DEBUG`（内核在引擎创建时读环境变量，**下一次播放生效**）；刻意不含高频开关（`ERIKA_FFMPEG_DEBUG` 实测 1500+ 行/秒、`ERIKA_SUBTITLE_DIAG` 约 100 行/秒，会把诊断文件冲掉，需要时手动加）。导出产出**单个 `.txt`**（头部：版本/构建/commit/平台/系统/当前档位/脱敏说明 → 全部 JSONL 记录 → 内核 trace 文件），走 `.fileExporter` 双端同一实现（不用 zip：iOS 起不了 `ditto`）。验证：设置开关 → 播放 → 导出，文件可直接附件。
  3. **播放生命周期事件行**：`open.start`（源类型/预读窗口/是否续播）、`open.done`（`ok` + `elapsed_ms`）、`first_frame`、`buffer.start`/`buffer.end`（带位置与这轮缓冲时长）、`stall`（宿主看门狗：在播、内核**没**报缓冲、位置连续 5s 不动 → warning，恢复后补 `recovered=true`）、`seek`（`kind` 区分 scrub/skip/chapter/auto/resume）、`error`（带内核原文）、`session.end`（`played_ms`/`buffer_count`/`buffered_ms`/`error_count`/`stall_count` 汇总）。每条记录带**会话标识**（进程级 8 位 id，一次启动一个）与**毫秒时间戳**，按 `session` 过滤即得一次启动的完整时间线（此前秒级精度判不出「续播 seek 与弹幕注入谁先」）。
  4. **内核 stderr 接进诊断管线**：GUI 启动时进程 fd 2 归 launchd，内核 stderr（`ErikaHDR`、结构化事件、Rust panic、ffmpeg 告警）此前完全丢失。现在 fd 2 → 管道，按前缀分类写进同一份 JSONL（`Erika/Output`、`Erika/Open`、`Erika/Stderr`；错误特征行提到 warning/error 让默认档可见），**原 stderr 保留一份 fd 做 tee**（终端/Console 行为不变、崩溃栈照样可见）；内核逐帧 trace 的 stderr 回声不入管线（内容在 trace 文件里），200 行/秒限速兜底。实测（自检模式 + DV/HDR 片源）：同一场景从 3469 条降到 100 条，留下的全是高价值事件（`video_seek_preroll elapsedMs/firstOutputPts`、`ffmpeg_seek`、`video_decoder_changed backend=videotoolbox`）。

- **日志文件改为按会话组织**：一次启动一个 `diagnostics-<时间戳>-<会话id>.jsonl`（写满续编 `-2`），保留最新 10 个 / 总量 ≤50MB / 不超过 30 天，当前会话文件永不删；替掉「单文件 2MB 滚动 + 3 份归档」（长会话的关键行会被切碎、上限一到还会直接删掉正在写的文件）。单条超长记录改成**截断保留**（头 1KB + 标注被截字节数），不再整条换成一条 warning（旧行为等于把内容丢了）。终止路径改有界 `flush(timeout:)`（macOS 2s / iOS 1s）——iOS 此前**完全不 flush 日志**，最后一批排队写入随进程丢。验证：连开三次产生三个会话文件；旧版 `diagnostics.jsonl.1/.2` 被同一策略自然淘汰。

- **降噪两处**：`displayEDRHeadroom` 同值不再下发（屏参通知风暴实测一次播放刷 3155 条同值记录）；内核内存 tick 采样改成「有实质变化才记」（关键分项变化 ≥8MiB 或 ≥10%，或 drawable 数／输出模式切换计数变了），open/stop 基线照常记——播放中每 5s 一条会让 1 小时片子多约 700 行噪声。

- **文档**：新增 [`Docs/LOGGING.md`](Docs/LOGGING.md)（级别规范、模块矩阵、事件字段口径、内核开关、不记什么）与 [`Docs/TROUBLESHOOTING.md`](Docs/TROUBLESHOOTING.md)（症状 → 看哪几行 → 常用命令），README 补链接与「遇到问题先导诊断包」的使用建议。

- **「跳过片头」接入 AniSkip 社区标注（第四路数据源）**：在弹幕报点推导之上再接 [AniSkip](https://api.aniskip.com/api-docs)（社区提交 + 投票背书的 OP/ED 区间库，浏览器扩展/IINA 跳 OP 脚本同源），优先级变为 **MediaSegments > AniSkip > 弹幕 > 章节启发式**。解析链：Jellyfin ProviderIds 直取 MAL ID（`MediaItem` 新增 `malID`/`anilistID` 透出，`Mal`/`MyAnimeList` 键都兼容）→ 缺失时 AniList GraphQL 换算/标题搜索（本地 24 部真实番实测映射成功率 20/24）→ `AniSkipClient` 按集查询 OP/mixed-op 区间。MAL ID 解析结果永久缓存（`aniskip-ids.json`），标题搜不中记负缓存 7 天过期重试，不重复打 AniList；AniSkip 无数据（404）/网络失败静默降级到弹幕推导，查询放在弹幕注入之后不拖慢弹幕上屏。AniSkip 区间转提示时起点直接用 OP 区间起点——有冷开场/前情回顾的集（如 OP 在 638–728s 的命运石之门）按钮只在 OP 区间内出现，比弹幕的最早报点估计更准；区间长度/绝对值双向合理性钳制防错季脏数据。已知局限记账：AniSkip 只认 MAL ID 且集数按条目内计，长篇连载/标题搜索不分季可能错季（有 episodeLength 过滤 + 钳制兜底）；覆盖与弹幕互补（我的朋友很少/来玩游戏吧/蜂蜜柠檬碳酸水等弹幕零信号的番 AniSkip 有数据，2026 新番两边都还没有）。`DanmakuIntroHint` 增加 `source` 字段（存量缓存解码兼容，缺省弹幕来源），`ChapterSession` 合并按 `SkipMarkSource.rank` 取舍、同级别刷新原位覆盖。DanmakuKit 新增 AniSkip 客户端 5 用例 + ID 解析器 3 用例 + 编排层优先级 2 用例，App 层 1 用例。

- **弹幕驱动的「跳过片头」**：播放器已有的片头/片尾跳过系统（Jellyfin MediaSegments 优先、章节名启发式兜底）接入第三路数据源——**弹幕报点推导**。弹幕文化里观众跳 OP 时会发「跳伞/空降 02:12」报出落点，落地后再发「空降成功/感谢指挥部」确认；两批独立行为在真实缓存弹幕上收敛到同一秒（54 集标定：报点主簇中位数与着陆确认逐秒吻合，同集冷开场长短差异也能如实区分）。新增 `DanmakuKit.DanmakuIntroDetector`：报点目标按 25s 间距聚类取最大簇（片头结束点 = 簇中位数），着陆/正片标记做交叉确认（无确认时要求 ≥3 个不同目标值），片尾玩笑报点（22:17）、中段跳过（11:50）被目标区间 + 聚类自然剔除，片头起点由最早报点帖估计（有冷开场的集不从 0 跳）。提示按 episodeID **永久缓存**（`intro-hints.json`，独立于弹幕正文的 1h TTL），之后弹幕过期或网关不可达跳过按钮照样可用。`DanmakuLoadOutcome.loaded/.empty` 带出提示，`DanmakuCoordinator` → `PlaybackController` 注入 `ChapterSession`（requestID 守卫防旧代迟到回调；章节与弹幕两条异步链路谁后到谁负责合并）；`SkipMark` 增加 `source` 字段标注来源，合并按可信度取舍：MediaSegments > 弹幕 > 章节启发式。顺带修掉 `performSkip` 跳过目标不钳制片长的隐患（越过 EOF 会触发内核错误风暴，与 `skip(by:)` 同一道防线）。UI 零新增：现有悬浮「跳过片头」按钮、窗口判定与会话内去重全部复用。DanmakuKit 新增检测器用例 9 个（真实形态回归含全角冒号/`2.21`/`3:9` 变体解析与「跳伞1.5倍」防误伤）+ 提示链路用例 4 个，App 层注入用例 6 个。

- **液态玻璃文字/图标动态颜色修复**：跳过片头/片尾按钮此前沿用 HUD 的固定白调色板（`PlayerHUDPalette`），但它挂在 HUD 之外、不享受全屏压暗暗幕的保护——HUD 自动隐藏后玻璃直接采样原视频，亮场面下玻璃翻浅变体、白字图标随之看不见；改用动态色 `.primary`（玻璃上的动态色随玻璃明暗变体自动翻转，WWDC25 session 284 确认），`PlayerHUDPalette` 补注释钉死「固定白仅限 HUD 暗幕之内」的使用契约。iOS 横滑 seek 预览条（白字白条裸压视频、拖动期间 HUD 不唤醒）包进实底 `PlayerHUDPanel` 背板，与音量/亮度 OSD 同族，任何画面下对比度都有保证。弹幕选择弹窗与 MoviePilot 资源页 4 处写死白的描边/行高亮改 `Color.primary` 同值——深色模式渲染零变化，浅色模式（浅玻璃下白描边隐形）修复。

- **设置页信息架构重排为六组**：原 10 个 Section 平铺一条龙（服务器/播放/播放内核/界面/弹幕/MoviePilot/关于/存储/诊断/无名登出）重排为 **通用 → 播放（含播放内核）→ 弹幕 → Jellyfin 服务器 → Bangumi → MoviePilot → 关于 → 维护**，并按「说明文字一行为辄」瘦身：「播放内核」删掉构成行、永久禁用的弹幕渲染开关与内核 notes（工程信息归开源许可证页），只留内核信息行与「下次播放生效」提示；「关于」删掉直连策略 / 弹幕来源两条静态文案；弹幕网关的 API Key / 状态行收进配置弹窗语境，区块缩为一行 + 条件提示；MoviePilot 介绍长文删除；存储 + 诊断合并为「维护」。**服务器管理抽成「管理服务器」子页**（新增 `ServersView`）：当前服务器首次进入列表（带「使用中」标），切换 / 删除 / 默认星标都在子页完成，不再需要先「连接其它服务器」才能看到自己的档案；页尾无名 Section 的 Jellyfin「退出登录」并入服务器区块并改名「退出 Jellyfin」，与 MoviePilot 的「退出 MoviePilot」消除同名歧义。

- **播放入口迁出设置页（首页工具栏「打开」菜单 + macOS 文件菜单）**：首页工具栏新增「打开」菜单（本地视频文件 / 直连链接，macOS / iOS 共用）；macOS 补上惯例的文件菜单——`CommandGroup(replacing: .newItem)` 提供「打开本地视频文件…」⌘O、「打开直连链接…」⇧⌘O。`fileImporter` 与 `URLEntrySheet` 上移到 `RootView`（`isPresented` 绑 `AppModel` 的请求标志，工具栏菜单 / 文件菜单只置标志，任何分区下都能触发，⌘O 在设置页按下也有效），`URLEntrySheet` 随迁 RootView；设置页「播放」区块只剩网络预读缓冲。

- **播放内核选择失效自愈**：装配点（`PlaybackEngineAssembly.registerAll`）注册完成后若发现存的选择指向本构建不存在的内核（MPV 实验分支残留的 `mpv-that-does-not-exist`），就地清除回退第一个可用内核并记 PlaybackLog——失效偏好在启动时自愈，不再常驻；设置页「播放内核」的橙色回退告警随之删除，本机 defaults 残留已清。

- **Bangumi / MoviePilot 集成启用开关（设置页）**：不用这两个集成的人可以整体停用——关闭后侧栏 / iPhone Tab 的对应入口消失（停用瞬间正停在该分区则选中回落首页）、详情页的 Bangumi 章节区块与 MoviePilot 资源区块 / Bangumi 条目页「MoviePilot下载」按钮隐藏、播放结束的 Bangumi 自动标记与 MoviePilot profile 校验等后台活动一并停止。默认开（现有行为不变）；关闭只藏 UI 停网络，登录凭据、服务器配置、条目关联与本地缓存全部保留，重新打开即恢复。开关 key 收进 `SettingsKeys`（`bangumi.enabled` / `moviepilot.enabled`），各触点经 `@AppStorage` 读同一登记 key。

- **macOS 菜单栏与系统界面中文化**：App 声明支持简体中文（新增 `App/Shared/zh-Hans.lproj/Localizable.strings` 声明载体 + Info.plist `CFBundleLocalizations` 登记），系统语言为中文时 AppKit/SwiftUI 提供的标准菜单（文件/编辑/显示/窗口/帮助）、菜单项（关闭/全部关闭等）与系统面板按钮（打开/取消）跟随中文渲染——此前整个菜单栏落在开发区域语言（英文）上；App 自有文案本就是中文硬编码不受影响。无障碍树里合并子标签的连接符也随语言变为顿号（如卡片「标题、年份」），VoiceOver 朗读更自然。

- **设置页内核行带版本号**：「内核」行显示为「Erika v0.1.9+dolby.1」。`PlaybackEngineDescriptor` 增加可选 `version` 字段（多内核时选择器同样带版本）；版本来源为新增的 `Packages/ErikaKit/Sources/ErikaKit/ErikaVersion.swift`——由 `Scripts/fetch-erika.sh` 在每次拉取内核时重写，与 vendored 二进制保持同源（该文件入库、diff 可见，拉了新内核不提交它会立刻暴露漂移）。

## [0.1.6] · 2026-09-11 · 前端组件化重构、HUD 液态玻璃与内核 v0.1.9

### 改动

- **修复 Bangumi 搜索「请求参数有误」**：带类型过滤的搜索（关联条目选择器、自动匹配的动画优先搜索、主页分类筛选）此前把 `filter.type` 编码成 `{"type":{"0":2}}` 对象——`BangumiJSONValue` 缺数组 case，只能用字典伪造，Bangumi 服务端校验拒绝直接 400（`body/filter/type must be array`），UI 报「请求参数有误，请检查后重试」。现在 `BangumiJSONValue` 补 `.array` case，搜索请求体改为 `{"type":[2]}` 正确数组形态；自动匹配原先靠吞 400 回退全类型搜索才没挂，修复后不再依赖兜底。新增 2 个请求体形状单测钉住编码。

- **弹幕网关瞬断自动重试**：匹配偶发「弹幕服务暂时不可用」的根因是网关（Cloudflare Workers）冷启动/子请求超时导致的瞬时 502/503/504——该文案是 `httpStatus` 兜底，此前 `GatewayClient` 一次请求即弃、四层降级只是换参数重试。现在接入阶段 3 的共享 `RetryPolicy`（3 次尝试、指数退避带抖动、429 尊重 Retry-After 封顶 60s，判据与 Bangumi 同口径）：网络超时/断网、502/503/504、429 自动重试；任一降级层命中网关级错误即短路剩余层，不再连打必败请求（也避免自触网关限流）；403 拆出独立语义「网关拒绝了请求（API Key 无效或已被限制）」，不再误报「暂时不可用」。匹配/搜索/弹幕正文接口全部幂等只读，重试天然安全；手动搜索与手动选集同享。新增重试用例 8 个（客户端 7 + 编排层短路 1），既有网关失败用例加请求计数断言。

- **macOS 26 全屏顶栏衔接层**：全屏时系统把工具栏搬进独立的 `NSToolbarFullScreenWindow`，顶部画一条与窗口底色同源的不透明硬底条带，氛围图被拦腰截断。新增 `FullscreenTitlebarFade` 衔接层（顶部 52pt 保持窗口底色、再 84pt 渐隐进氛围图），挂在整窗氛围层（`AppShell.windowAmbienceLayer`）与首页轮播两处；**衔接层必须放在氛围层的动画作用域之外**——放进去会被切页/换片时的 `Motion.ambient` 交叉淡入卷着一起动，背景里滑出一条渐变带（全屏专属症状）。工具栏本身不藏：实测 `.windowToolbarFullScreenVisibility(.onHover)` 会在全屏进详情页后留下旧页面残影并吃掉那片点击，AppKit 改 `toolbar.isVisible` 会把窗口踢出全屏——两条藏工具栏路线均已否决并留档。

- **播放器收边（阶段 4）**：弹幕偏好到引擎的映射合并为单一 `DanmakuPrefsSnapshot` 通路（原来 open 队列闭包的静态版与实例版各写一份字段对应表）；Erika 弹幕 JSON 的解析从 App 层（DanmakuOverlay）下移到 DanmakuKit（新增 `DanmakuJSONParser`，与写入侧 `DanmakuJSONConverter` 同包同 schema），App 不再认识内核数据格式；新增解析器测试 5 用例（含 converter↔parser 往返一致）。手势分类纯逻辑此前已抽 `PlayerPanGestureModel`（有测试），PlayerScreen 剩余的触摸编排评估后保留在视图（与控制器/HUD/亮度耦合，换壳无收益）。

- **网络层收敛（阶段 3）**：共享 HTTP 执行层落到 DiagnosticsKit——`HTTPClient`（请求构造/发送/计时日志/传输错误映射，状态码 ≥400 记失败级）+ `RetryPolicy`（指数退避 + 抖动 + 429 Retry-After，封顶 60s，支持 `sending` 闭包与调用方隔离域继承）。BangumiKit（`BangumiAPIClient.request`）、MoviePilotKit（`sendOnce`）、DanmakuKit（`GatewayClient.send`）三个客户端的手写「组请求/发送/URLError 分类/状态分支」全部替换为共享执行器；各域只保留自己的鉴权与状态语义。新增 `HTTPClientTests`（6 用例钉住退避/重试/取消语义）。新增 `SettingsKeys` 登记表，收编跨文件重复的 UserDefaults key（`ambientBackdrop`、`httpReadAheadMiB` 等曾各写三份）。纯重构，无行为变化。

- **状态层重构（阶段 2）**：
  - `AppModel` 域模型全部改为 init 显式注入（`store/bangumi/moviepilot/danmakuModel`，默认值不变），`bangumi.setup()` 从 init 挪进 `bootstrap()`——构造 AppModel 不再有副作用，测试拿到干净实例。
  - `BangumiCoordinator` 支持注入 `BangumiContext`（默认 `.shared`）。
  - **MoviePilot 凭证存储收敛为单实例**：`MoviePilotStore.shared`——此前协调器与 `MoviePilotAPIClient` 各持一个实例、只靠同一份 UserDefaults 碰巧同步。
  - 401 凭证失效接线收敛：RootView 里 Bangumi/MoviePilot 两段几乎相同的 `onReceive` 合并为共享的 `onAuthenticationRequired` 修饰符 + `AuthNotification` 解码。
  - **`DetailView` 数据面抽成 `DetailViewModel`**（1342→1083 行，@State 21→6）：详情/季/集/类似的加载、SWR 快照缓存、按季缓存、选中态与智能默认季/集全部进 VM，视图只剩布局与交互编排。详情页行内错误条并入共享 `ErrorNotice`，集列表空态/失败态并入 `EmptyState`。
  - 决策记录：`AppModel+Playback` 的播放编排**不**再抽独立对象——它要协调导航层/上报/弹幕/Bangumi/首页缓存五方，抽出来只是把同一份耦合换个壳；`@Observable` 本身已按属性粒度隔离重绘。播放侧的真正整改在阶段 4（PlaybackController 职责拆分）。

- **前端组件化重构：设计系统下沉为新包 `AppDesignKit`，卡片/胶囊/分页/空态向共享原语收敛**（`refactor/component-reuse`）。
  - 动效/尺寸 token、骨架屏、卡片原语、横向滚动、液态玻璃、远程图管道（`ImagePipeline`/`RemoteImage`）从 `App` 移入新包 `Packages/AppDesignKit`——只吃纯值、不依赖任何域模型，新 Feature 直接复用。
  - 新增模型无关原语：`MediaArtwork`（海报/剧照画幅 + overlay 槽）、`CardProgressTrack`（3pt 胶囊进度细轨）、`PillChip`（分类/印章徽章，三档语义色）、`RatingPill`（评分徽章统一橙）、`EmptyState`、`ErrorNotice`、`PagedListLoader` + `LoadMoreFooter`（分页状态机：代次守卫/追加去重/满页判断，含 `replace`/`remove`/`reportError`）。
  - 收起重复卡片：Bangumi 的 `CollectionTile`/`ProgressCard`/`CollectionRow`/`SearchResultRow`/`CalendarItemCard` 与 MoviePilot 的 `MoviePilotSubscribeCard`/`MoviePilotMediaGlassCard`/`MoviePilotTorrentGlassCard`，以及 `PosterCard`/`StillCard`，全部落到 `MediaArtwork`/`CardProgressTrack`/`PillChip`/`RatingPill`。
  - 收起手写分页：Bangumi 首页在播/搜索两套分页 + 收藏列表页改用 `PagedListLoader`。媒体库 `LibraryView` 因分页数据住在 `AppModel.libraryPages` 缓存而有意保留自管状态机，避免再造一个数据源。
  - 收起错误/空态/胶囊：`BangumiNotice` 并入 `ErrorNotice`；LibraryView/AppShell/Home/Bangumi 收藏列表空态并入 `EmptyState`；展示型标签用 `PillChip`，交互型菜单/状态胶囊按钮保持原生。
  - 净效果：App 层约 -1000 行；`BangumiHomeView` 999→836、`BangumiCollectionListView` 160→151。新增 `AppDesignKitTests`（12 用例）。纯 UI 重构，无视觉/行为变化，播放器 HUD 零改动。

- **HDR 片首次真出 EDR**：内核在 macOS 不探测屏幕，HDR 输出档位全靠宿主喂 headroom，而 App 从 v0.1.0 起一直传 `Auto + 0`——HDR 片始终被映射成 SDR（播放详情的「映射 SDR」标注只是让它显形）。现在引擎创建时按窗口所在屏的 `maximumPotentialEDR` 传 `edr_headroom`（SDR 屏 = 1.0 行为不变，XDR 屏 ≈8 真出 EDR），`PlaybackEngine` 增 `updateDisplayEDRHeadroom`（默认实现防静态派发坑），PlayerScreen 监听换屏/显示配置变化并首报、引擎重建时补推。非 macOS 不查不推。**限制**：运行时切换要等内核 Metal 后端实现 `set_output_headroom`（当前只在创建时生效，播放中换屏档位不跟手）。

- **关于页与产物可追溯到提交**：构建号与 Git commit 全程注入——`App.xcconfig` 增 `CURRENT_PROJECT_VERSION` 默认值，`Info.plist` 增 `GitCommit` 键（构建时注入，字面量兜底为 nil）；AppVersion 新增 `gitCommit`，关于页显示 `v版本 (Build N · 短哈希)`、启动诊断日志带 commit；构建脚本 Build 号 CI 取 run number、本地取提交总数，dirty 构建带 `-dirty` 后缀，本地产物文件名带 build + commit 后缀，打包脚本语义版本校验前置。补 `AppVersion.displayString` 单测。

- **弹幕匹配成功率提升（模糊候选打分 + 四级降级检索）**：`isMatched == false` 的模糊候选接入 `DanmakuCandidateScorer`（集数 / 季度 / 标题打分）救回有效弹幕；检索引入四级瀑布流降级——Hash 匹配 → TMDB ID 搜索 → 标题+集数精准搜索 → 提纯标题全集匹配（此前每级静默吞错，见「修复」里网关故障误报那条）。新增 `DanmakuFilenameParser`：全角半角转换、中文数字解析、剥离发布组与压制参数噪声；Jellyfin 与单播文件的元数据推断同步优化（解决 `01.mkv` 丢番剧名、单播支持向上回溯父目录）。

- **MoviePilot 与弹幕选择界面重构为液态玻璃 + 多层子菜单**：DesignSystem 增通用 `liquidGlassCard` / `liquidGlassCapsule` 材质修饰器；MoviePilot 媒体搜索结果改通透流式卡片（去掉放大悬浮动效），资源搜索页引入氛围背景、移除 300+ 行实时 glass 着色器与 textSelection、背景启用 Metal 离屏栅格化（此前严重掉帧）；弹幕选择面板重构为「作品 → 选集」两级下钻（平滑层级返回 + 透明液态玻璃背景），播放器为该弹窗配透明背景。

- **播放中 HUD 自动隐藏时一并藏鼠标光标**：用 `NSCursor.setHiddenUntilMouseMoves` 与 HUD 同步显隐，退出播放器强制 unhide 兜底；暂停 / 缓冲 / VoiceOver 时光标保持可见。
- **播放内核升级到 fork 的 `v0.1.9+dolby.1`（macOS）**：基于上游 v0.1.9 + libplacebo 风格 Dolby Vision RPU 映射（P5/P8.1 SSIM≈0.995）。相对 `v0.1.7+dolby.3` 带来上游 0.1.8/0.1.9 一系列播放修复——渲染阻塞恢复后的音画时钟重校准、倍速切换平滑过渡、iOS 前台/音频中断恢复、首条音轨解码失败自动回退后续音轨、弹幕跨规划窗口重现跳轨、`ErikaOpenOptions` 预读（本 App 已在用）。C ABI 与 `v0.1.7+dolby.2+` 一致（`ErikaPresenterConfig` 四字段），App 侧无需改代码。**iOS 暂维持 `v0.1.7+dolby.3`**：该 release 仅手工打包了 macOS arm64 资产，`package-ios.sh` / CI iOS job 继续钉最近一次全平台 tag；`fetch-erika.sh` 支持 macOS-only release（无 iOS zip 时复用本地已有切片并在 Info.plist 登记）。下载哈希 pin、脚本与 CI 钉点同步换版。

- **设置页新增「启动时默认服务器」**：多服务器用户可在设置 → 服务器里选定打开 App 时优先连接的档案，不必再被「上次使用的服务器」绑死。选「上次使用的服务器」保持旧行为；选定具体档案后启动静默恢复优先走它，token 失效仍回退到其它有有效会话的档案。默认服务器在已保存列表带星标；删除该档案会自动清掉默认设置，不留悬空 ID。默认与「当前会话」独立：临时切到另一台看片，下次打开仍回到你指定的默认服务器。

- **媒体库每个库页面右上角新增排序与观看状态筛选**：电影 / 剧集等库的网格页工具栏加「排序与筛选」按钮，点开系统下拉菜单（macOS 26 / iOS 26 原生液态玻璃，与首页 / MoviePilot 菜单同款）三组单选——排序字段（名称 / 最近添加 / 年份 / 评分 / 时长 / 随机，带图标与对勾）、顺序（升序 / 降序）、观看状态（全部 / 没看过 / 看过，服务端 isPlayed / isUnplayed 过滤）。排序完全在服务端生效（items API `sortBy`/`sortOrder`，主键外固定挂名称升序副键），分页大库全量有序；候选集按库类型收敛——剧集库去掉时长（Runtime 是单集时长）、混合内容 / 家庭视频等只留名称 / 最近添加 / 随机，随机无方向不显示顺序组。换字段时方向自动重置到自然默认（评分默认高→低等），排序与观看状态按库独立记忆，变更即作废该库分页缓存从第一页重取。顺带把 MoviePilot 筛选条与 Bangumi 详情页两份逐字节相同的私有 FlowLayout 抽到 DesignSystem 共用（新增 `FlowLayout` / `OptionChip` 共享组件）。

- **资源搜索筛选排序对齐 MoviePilot 网页端**：原先「站点选择 + 一颗筛选按钮弹整表单 + 排序菜单」换成官方同款筛选条——排序（字段 + 升降序）与七组筛选（站点 / 季 / 促销 / 编码 / 质量 / 分辨率 / 制作组）平铺一行，每组点开是候选值 chips 下拉（头部「全选 / 清除」，可多选，点击即时生效；iPhone 紧凑宽度自动升级为半屏 sheet）；激活的分组按钮 tint 玻璃高亮并记数，下方以「站点:观众 ×」样式的已选 chip 汇总、可逐个移除或一键清除。全部走原生 Liquid Glass（`glassEffect` 胶囊），候选值随搜索结果聚合并记忆化（随批次落账，不随界面求值重算）。搜索固定全站（与官方默认一致），「搜索范围」站点选择弹窗整个移除，站点收窄一律走结果筛选；原整表单筛选弹窗移除。
- **资源搜索结果懒加载（MoviePilot）**：聚合结果多时页面内存暴增、操作卡顿——筛选+排序原先在每次界面求值时全量重算（关键词逐键输入、流式批次、下载按钮状态变化都会触发），整表结果也无差别塞进列表。现在筛选+排序结果记忆化，只在搜索批次落账、筛选弹窗勾选/清除、排序切换这几个赋值点重算；列表按 60 条一窗懒加载物化，滚到底部自动续载并显示「已展示 X / Y 条」，视图 diff 与卡片状态只随窗口走。全量结果仍留在内存（筛选候选聚合与下载时原样回传服务端需要），但界面求值与渲染开销不再随结果数线性放大。
- **播放内核升级到 fork 的 `v0.1.7+dolby.3`，修复播放中切换全屏的音画失步**：全屏 Space 切换动画期间 WindowServer 扣住 `CAMetalLayer` 全部 drawable，内核渲染线程的 `nextDrawable()` 会被阻塞（实测 733ms，GPU 本身仅 0.4ms），而音频补泵同在该渲染 tick 上——音频环（原 ~290ms 存货）被抽干，underflow 约 450ms 静音；更糟的是恢复后积压回填让环指针落后时钟 ~0.7s，距离型 stale 判定（250ms）把之后所有时钟重锚永久拒绝，**失步一直持续到手动 seek/暂停**（trace 实测 35,769 次重锚全部被拒）。三处内核修复：Metal surface 启用 `allowsNextDrawableTimeout`（拿不到 drawable 跳帧而非阻塞，含跳过计数与节流诊断）；播放时钟对音频环样本改按设备活性判定（计数推进即重锚，大偏差走既有 snap），积压照常播出、画面短暂定格后重新对齐；CoreAudio 输出环 1.2s 真门控 + worker 预填同步加深，停顿期间音频从积压播出。真机压测：6 次全屏切换 underflow 从 1,140ms 降至 25ms（不可闻）、时钟校正零断流、窗口态渲染 tick 均值 1.35ms。C ABI 无变化，下载哈希 pin、脚本与 CI 钉点同步换版。
- **`build-macos.sh` 支持 `SKIP_ERIKA_FETCH=1`**（与 `package-macos.sh` / `package-ios.sh` 同一开关，含 shim 头防呆）：此前 build 脚本无条件跑 fetch，会把手动铺进 Vendor 的自编译内核按钉点版本静默覆盖回 Release 产物。

- **播放内核升级到 fork 的 `v0.1.7+dolby.2`，新增杜比视界支持**：内核在 HTTP 预读之上引入杜比视界 RPU 处理——profile 5（单层非兼容）自动回落 FFmpeg 软解并按 RPU 逐帧重映射色彩（libplacebo 同路线），profile 8（HDR10 兼容双层）保持硬解走 HDR10 底层；C ABI 无变化，预读链路不受影响。下载哈希 pin、脚本与 CI 钉点同步换版。
- **播放信息面板「动态范围」标注杜比视界**：从 Jellyfin/Emby 的流信息（`MediaStreams.videoRangeType`）识别杜比源，杜比片源不再裸报 HDR (PQ)/SDR——输出端实际映射成 SDR 时显示「杜比视界（映射 SDR）」（SDR 屏上放杜比片的最常见场景），真出 HDR 时显示「杜比视界（HDR）」；输出状态来自内核 `get_output_status` 的新封装（`PlaybackOutputEncoding` 中立枚举进 `PlaybackEngine` 协议）。本地文件/手动 URL 拿不到服务端流信息，维持原有文案。

- **详情页简介在 Mac / iPad 上同样超行折叠**（原先只有 iPhone 折叠、桌面端全文铺开）：超过 3 行截断，底部附「展开全文」/「收起」按钮，与紧凑宽度行为一致（仅字号随宽度）。按钮按实测截断与否显隐——全文不足 3 行不出按钮，窗口拉宽到不再截断时自动消失，收起状态重新截断时恢复。
- **详情页新增 Emby 风格全页氛围背景**（设置 → 界面 →「海报氛围背景」，默认开）：开启时去掉英雄区横幅，海报、标题、元数据与播放钮直接浮在整页 backdrop 氛围背景上——背景低档模糊（能认出是哪部剧）、固定不随滚动，全屏遮罩日间白雾 / 夜间黑纱，无额外压暗带。头部文字与按钮颜色跟随外观自适应（日间深字、夜间白字），白色按钮带柔和投影分界；两种布局共用同一套自适应文字——清晰横幅布局的压字渐变日间换白雾、元数据行同样随外观变色。条目没有 backdrop 图时始终走清晰横幅布局。氛围图为 800 宽小图 + 512px 解码下采样，不为糊图拉原画。
- **首页背景库内随机 backdrop 渐变轮播**（同一开关控制）：服务器端 `SortBy=Random` 从全库随机取 8 张带 backdrop 的电影 / 剧集（查询失败或为空回退首页已加载条目），同样模糊+雾化垫底，每 12 秒淡入淡出换一张（减弱动态效果时保持静态首图）。首图进缓存后才亮相，其余后台预热，切换零占位闪烁；切换服务器会话或开关时自动重取。
- **播放器 HUD 改用原生 Liquid Glass 液态玻璃（Infuse 风格）**：右下角五个功能入口（弹幕/字幕/音轨/章节/更多）从标题行旁的独立圆钮改为融合成一颗玻璃胶囊，悬浮在进度条上方右侧；点开的按钮整体液态形变为玻璃面板，其余按钮回流成短胶囊，点击面板外任意处收起。面板内容重写为「行 + 子菜单」结构——根层是「图标 + 标题 + 当前值 + 箭头」的行列表（如「不透明度 100% ›」「字幕轨道 简体中文 ›」），点入后子菜单滑入显示选项（选中行带 checkmark）、返回滑出；音轨与章节保持单层选单；弹幕根行含启用开关与匹配状态徽章。面板内不再放关闭/快速切换按钮：切换 Tab 直接点胶囊上其余按钮，与 Infuse 一致。
- **最低系统要求提升至 macOS 26 / iOS 26**：HUD 玻璃改用系统原生 `glassEffect`（原先 26+ 才走玻璃、旧系统回落 ultraThinMaterial 的双轨制移除，旧系统不再支持）。
- **播放器「播放信息」与「播放统计」合并为一个面板**：更多面板里的两个开关收敛为单个「播放信息」开关，面板从两块各自为政的散字改为分区排版——播放（状态/进度/倍速/音量/章节）、视频（分辨率与宽高比、动态范围 HDR/SDR、色彩空间、出画状态）、音频（当前音轨与采样率）、字幕（当前字幕轨，外挂标注）、内核统计（解码/渲染/硬解/软解/零拷贝/音频帧/失败计数，每秒刷新）。
- **首页右上角新增刷新按钮**：长期停在首页也不怕数据过期，点一下重新向服务器请求首页与媒体库数据（等同下拉刷新）；按钮为 macOS 26 / iOS 26 原生液态玻璃工具栏样式，加载中原地转圈，未连接服务器时置灰。
- **设置页新增「弹幕诊断日志」调试开关**（默认关闭）：开启后弹幕 overlay 记录时间轴对齐点、爆发发射与续播定位日志（写入 `~/Library/Logs/OcPlayer/diagnostics.jsonl`），用于排查「续播起播爆出一大片非当前时间点的弹幕」等时间轴错位问题；平时保持关闭以减少日志噪声。

### 修复

- **弹幕装载在主线程解几 MB JSON**：`DanmakuService` 早在 actor 上把弹弹play 弹幕转成了 Erika JSON 串，界面侧拿到后又在**主线程**解码 + 排序一遍——三万条 = 主线程 100–400ms，正好压在「源就绪、视频起播」这一拍。现在转换与排序都留在 actor 上（`DanmakuJSONConverter.entries(from:)`，与 JSON 路线共用一套滤镜判据），overlay 装载只是赋值；JSON 串保留给当前停用的内核弹幕轨路线。新增 2 个包用例钉住「两条产出路径同结果」。

- **2s 阈值内的前向 seek 把窗口内弹幕一帧喷完**：出场循环没有单拍上限，往回跳 1.9s（不到 `seekJumpSeconds` 的 seek 重同步阈值）时窗口里几十到几百条会在同一拍出场，每条都要测字宽、取 cell、建视图。现在发射决策抽成 `DanmakuSpawnPlanner`：每拍最多 24 条、超出顺延（60Hz 下约 1440 条/s，远超正常密度），积压跳变的清屏兜底原样保留。新增 6 个用例（正常节奏 / 上限顺延 / 1.9s 前向 seek 摊成 7 拍 / 跳变清屏 / 指针越界钳制）。

- **截图瞬间整个播放器卡住**：`captureScreenshot` 在主线程一气做完取帧（33MB 缓冲分配 + 持引擎锁整份拷贝）、PNG 编码（再拷一份 + CGImageDestination）与写盘，4K 片可达数百 ms——期间 HUD / 手势 / 弹幕全冻。现在只有取帧留在主线程（必须与渲染线程串行），编码与写盘挪到后台任务，回来后只更新界面提示；顺带加一条「截图编码写盘 宽x高 耗时=Nms」诊断日志。

- **MoviePilot「保存并登录」失败会毁掉原本可用的会话**：改密码打错一次（或把地址改到另一台服务器再登录失败），错误凭据已经落盘、旧 token 已被删——点「取消」也救不回来，之前能用的 MoviePilot 会话彻底没了（gate 变「未登录」，后续请求 401 → 静默重登拿着错密码 → 通知登出）。现在登录前先打「服务器地址 / 用户名 / 密码 / token」四键快照，失败把快照原样还原（含旧 token），错误凭据只作尝试不落盘；成功路径不变（换凭据 ⇒ 旧 token 照旧作废）。同批修掉密码被静默 trim：含首尾空格的密码此前被改写、登录永远失败且无提示，现在密码原样存取与发送（地址与用户名仍 trim，判空用 trim 结果）。快照与回滚落在 `MoviePilotStore.credentialSnapshot()` / `restore(_:)`，新增 3 个包用例钉住「失败不动旧值」。

- **MoviePilot 订阅里清空的字段清不掉**：编辑订阅以服务端原始记录起底，「自定义存储路径」「TMDB / Bangumi / 豆瓣 ID」「海报」「简介」这几个字段只做「非空才写」、清空不回删——用户删掉存储路径或 ID 保存后旧值原样回传服务端继续生效（而关键词 / 包含 / 排除 / 画质同表却是会删的，一张表单两套语义）。现在可清空字段统一走 `MoviePilotSubscribeFieldRules`：空 = 从字典删键；成对键（`tmdbid`/`tmdb_id`、`doubanid`/`douban_id`、`bangumiid`/`bangumi_id`、`poster`/`poster_path`、`overview`/`description`）同进同出——只删一个等于没删，读侧是 `raw["tmdbid"] ?? raw["tmdb_id"]`。简介仍写原值（保留换行）、判空用 trim 结果。新增 5 个规则用例。

- **Bangumi 条目瞬时网络抖动下被清出「在看」**：单条目接口 `p1/subjects/{id}` 本就不返回收藏状态，回读路径（详情页加载、播放结束后的进度对齐）靠附加请求补，补失败即 `nil`——而落库把 `interest == nil` 当成「服务端确认没收藏」，把本地 `interest`/`ctype`/`collectedAt` 一并清零：条目从「在看」消失、已看进度与评分归零，直到下次全量同步才回来。现在「按 nil 清空」改成显式参数 `authoritativeInterest`：只有收藏全量同步（每页都带收藏状态）这条权威路径传 `true`，单条回读与进度对齐默认保留本地收藏态、只更新元数据（本地改收藏走专用方法，从不置 nil，不受影响）。新增 2 个库用例（非权威保留 / 权威仍清空）。

- **GitHub CI 修复：fetch-erika.sh 全角逗号粘连变量名 + v0.1.9+dolby.1 资产哈希 pin 过期**：CI 自 09-10 起秒挂，根因两条——(1) 脚本 4 处 `$var，` 全角逗号直接粘在变量名后（203 行 `$expected，`、三处 `$f，`），在 CI runner 的 bash/locale 下被当成变量名一部分，`set -u` 直接报 `expected: unbound variable`（3b39961 修过同款 `$PINNED，`，本次漏网；已全部改 `${var}` 花括号隔离）；(2) v0.1.9+dolby.1 的 macOS 资产在本地下载（09-10 13:21）之后被重新上传，pin 哈希停留在旧资产（98cde716），缓存过期后 CI 首次实拉即哈希不匹配——粘连 bug 又把真实的「哈希不匹配」报错吞成 unbound。pin 已更新为线上资产哈希（7b622c21），本地全流程（实拉→校验→合成 xcframework→缓存复用）验证通过。

- **播放信息面板打开时快捷键操作后 HUD 不再自动收起**：`canAutoHideControls` 此前把 `showInfoPanel` 一并收进「不许自动隐藏」——面板开着时用快捷键调进度/音量唤出的 HUD 被钉死，直到关面板或鼠标移出窗口才消失。信息面板只读、`allowsHitTesting(false)`、且独立于 HUD 挂载（HUD 卸载后它照常每秒刷新），不依赖 HUD 常驻，从规则中移出后两者各自独立显隐。

- **跳过钮被面板压住、且展开动画被打断**：展开面板高度上提到 PlayerScreen 后，跳过钮保持单实例、锚点改为「簇底距 + 按钮高 + 间距 + 面板高度」平滑上移；上一版挂在卡片 overlay 里的副本会因挂载时的 prompt 状态写入打断 `glassEffectID` 液态展开动画（面板直接弹出），副本已移除；面板切子菜单变高变矮时跳过钮跟随移动，`reduceMotion` 生效。

- **HUD 展开面板被撑满 320pt**：`ScrollView` 是贪婪布局、`frame(maxHeight:)` 只封顶不收缩，只有一个选项的子菜单也撑满 320。改为隐藏镜像（`fixedSize` 实测自然高度）驱动分支——内容 ≤320 原生高度贴合，超出才滚动（`ViewThatFits` 方案在 `GlassEffectContainer` 内实测不生效，弃用）。

- **氛围背景不铺侧栏、顶栏露出窗口底色**：页面的氛围图此前挂在详情列 ScrollView 的背景上，而 macOS 26 的 `NavigationSplitView` 里只有**栈根**的背景能铺满全窗（首页轮播正是这样垫到侧栏玻璃底下的），pushed 页被裁在详情列内、导航栈宿主自带不透明底——在列内垫什么都连不到侧栏，侧栏整列（尤其下半截）空玻璃，详情页顶部工具栏区域还会露出一条窗口底色。现在有氛围图的页面出现时经 `windowAmbience(_:)` 向 `AppModel.windowAmbience` 声明、离屏时撤回（MoviePilot 资源搜索页声明海报、详情页声明 backdrop，与「海报氛围背景」开关一致），AppShell 把声明图垫在整块 `NavigationSplitView` 后面——透明的 pushed 页、侧栏玻璃和顶部工具栏透出的都是同一张连续的图，观感与首页完全一致；返回或切到无氛围页自动回落系统玻璃，iPhone 紧凑布局没有整窗层、页面自垫不受影响。实现坑：氛围图的 fill 溢出若作为 ZStack 兄弟参与布局会把 split view 撑出窗口，必须走 layout 隔离的 `.background` 挂载；层必须在调用点显式 `ignoresSafeArea()`——详情页这类自带顶部 ignoresSafeArea 滚动视图的页面会改变层继承到的安全区，让图片被 `.clipped()` 裁到工具栏以下。
- **iPad 氛围布局海报被顶部导航栏按钮遮挡、上沿发糊**：详情页氛围头部内容整体越过顶部安全区，顶部只留 64pt，而 iPadOS 26 导航栏的玻璃按钮（侧栏开关 + 返回）悬深到 ~76pt、滚动边缘渐进模糊尾部到 ~82pt——海报顶部正好压进两者：上沿一截被系统渐进模糊洗掉，收起侧栏后海报左缘（52pt）正对按钮列，左上角直接被玻璃圆钮盖住（侧栏展开时返回键也压着海报一角）。现在 iOS 上头部顶距抬到 104pt，海报整张落在模糊带与按钮之下；Mac 工具栏浅，维持原深度不变。
- **看完一集退出到详情页，Bangumi 章节格子不变「已看」**：播放结束的自动标记走「远端 PATCH → 写本地库 → 广播失效通知」，而详情页内嵌的 Bangumi 章节区块一直没监听这条通知——它唯一能感知的刷新（退出播放器触发的 `detailRefreshGeneration` 重载）通常赶在标记落库之前，自动标记完成后也没有任何信号再推它重读，格子就停在旧的未看状态（手动点标记因为更新完自己重读，所以有转圈和即时刷新）。现在章节区块与进度页 / Bangumi 条目详情页同款：监听失效通知、按关联条目过滤后重读本地库，自动标记落库后格子立刻刷新。
- **弹幕网关挂掉时误报「未匹配到剧集」**：自动匹配的四级降级检索（Hash → TMDB → 标题+集数 → 提纯标题）每级都把请求错误静默吞掉，网关宕机、断网、额度用完最终都落成「未匹配到剧集」，用户误以为这部剧没弹幕且日志无告警。现在任何一级检索抛错都会落到「失败可重试」态并复用稳定文案（额度用完 / 网络请求失败 / 服务暂时不可用），全部干净无结果才报未匹配；错误路径升 warning 日志。同批顺带：open 在飞期间字幕缩放 / 弹幕设置 / 选轨等入口不再撞引擎长持锁（loading 中动菜单不再卡主线程）；loading 中按下的暂停在起播后生效；弹幕解析的 ~20 个正则改静态编译，长篇全集搜索不再卡主线程；文件名解析支持行首发布组位与年份括号剥除（VCB-Studio 等枚举外组名不再污染标题、[2023] 不再混进标题）。
- **网络差时播放加载页让整个 App 卡死（繁忙光标、取消按钮点不动）**：内核打开媒体源是在调用线程上同步完成网络连接与格式探测的，而这条调用整个跑在主线程上——弱网下连接 + 探测可达数十秒（DNS 解析甚至没有超时），主线程不处理事件就是 macOS 的「繁忙」转圈光标，loading 层的取消按钮根本点不了；就算点得了，取消路径的 stop / detach 也要和正在进行的 open 抢同一把引擎锁，照样卡死。现在 open 的阻塞段移到专用串行后台队列（完成后回主线程落状态，代次守卫防串台）；引擎适配层加「让位契约」——open 在飞期间 stop / detach / resize 只登记意图立即返回、由 open 收尾补做，play / seek / 改速率音量直接丢弃，统计快照与媒体时间一样走独立小锁，loading 轮询首帧标志不再撞锁。取消、换片（自动连播）、失败重试全程主线程零阻塞，取消按钮即点即生效；另加 60 秒看门狗，open 卡死时强制转「连接超时」给重试入口，不再无限黑屏；同请求重入不会二开。
- **关闭播放器时闪现「画中画样式」的占位画面**：点 × / ESC 后引擎被同步停掉，无引擎占位图（画中画样式图标 + 剧集标题）与常驻 HUD 在停播到退出播放器的约 0.25s 窗口期裸露闪现。现在关闭时窗口先带着正在播的画面缩回原位（与打开时的展开动画对称）、HUD 同步淡出，缩完再停引擎并退出播放器，全程看不到占位图；停播前校验屏上仍是被关的那片，不会误停窗口期内新开的内容。
- **继续播放起播时爆出一大片非当前时间点的弹幕**：续播 seek 与弹幕注入竞速，注入时媒体时间还在片头 0.5s，弹幕出场指针被对齐到片头；seek 跳到续播位后跳变检测又被 resync 后的首拍空窗吞掉，0.5s~续播位之间的弹幕被一次性补发。现在 resync 后首拍照常做 seek 跳变检测，且发射端增加兜底——两次发射机会之间媒体时间前进超过 2s（漏检跳变）时清屏重对齐、跳过积压的过期弹幕，任何路径的漏检都不可能再把一大片旧弹幕喷出来。
- **首页「继续观看」与「接下来看」重复**：播了一部分但没看完的剧集会被服务器同时算进两条 Rail——Resume 按 IsResumable 收录它，NextUp 又把它当「第一部未看完的剧」（服务端只认 PlayCount，半集仍是未看）。现在有播放进度的条目只留在「继续观看」，从「接下来看」剔除；首页骨架屏有无记录与剧集详情页「播放」按钮的条目复用同步适配。

## [0.1.5] · 2026-08-30 · Emby 适配、iOS 安装包与自编译预读内核

### 服务器支持

- **新增 Emby 服务器适配**：登录流程探活时自动识别服务器类型（`ProductName` 含 Emby / 主版本 4.x），Emby 走 `/emby` API 前缀与老式路由（媒体库 `/Users/{id}/Views`、继续观看 `/Users/{id}/Items/Resume`），账号密码登录、浏览、播放、图片、字幕、播放上报全链路可用。Emby 没有 Quick Connect（Jellyfin 独有），登录页在 Emby 服务器上只显示账号密码表单；Emby 老版本密码错误返回 400 时也归入「账号密码不对」提示。服务器卡片显示所属类型（Jellyfin / Emby）。
- `ServerProfile` 新增 `kind` 字段（jellyfin/emby）；旧版本落盘的档案无此字段，解码默认 Jellyfin，静默恢复不受影响。
- **多服务器记忆与快速切换**：登录页新增「已保存的服务器」区块，token 还在的一键重连；设置页「服务器」区块列出其余已保存的服务器，支持就地切换和删除（删除连 token 一起清，有确认弹窗）。登出不再等于遗忘——档案持续保留，来回切服务器不用重新输地址。启动恢复也更聪明：当前服务器 token 失效时自动尝试其它有有效 token 的档案，而不是直接弹登录页。

### Emby 真机联调修复

- **标记已看/取消已看失败**：`/UserPlayedItems/{id}` 是 Jellyfin 新式路由，Emby 上不存在（404）。Emby 改走老式 `/Users/{uid}/PlayedItems/{id}`；详情页「标记已看」按钮在 Emby 上恢复可用。
- **播放时 MediaSegments 404 日志噪音**：`/MediaSegments/{id}` 是 Jellyfin 插件提供的端点，Emby 没有。Emby 服务器现在跳过该调用直接回退章节启发式。
- **外挂字幕下载路径**：路由第二段原先硬编码为条目 id，多版本条目（同一影片挂多个 MediaSource）会 404。现从 `/Items` 响应透传真实的 MediaSource id；单源条目行为不变。
- **章节与条目详情解码失败**：Emby 响应洗白规则误伤顶层 `Type` 字段，SDK 解码报 "Cannot initialize BaseItemKind from invalid String value Default"，章节列表每次都拉取失败。改为按 `MediaSources` key 精确处理子树；回归测试覆盖真实机场景。

### iOS

- **首次提供 iOS 安装包**：release 附带未签名 IPA（`OcPlayer-<版本>-ios-unsigned.ipa`），通过 AltStore / Sideloadly / TrollStore 等工具重签安装；与 macOS 包同一内核、同一测试门禁。iPhone 与 iPad 均已真机验证。
- **播放画面手势**：长按 2 倍速（HUD 独立「▶▶ 2.0x」徽章，不唤醒面板）、横滑 seek（独立进度条）、纵滑调节亮度/音量；手势收敛为单一状态机，双击暂停不再被吞，多指不再误触发，切后台/来电自动收尾。
- 打开播放器自动转横屏；iPad 浏览态跟随重力旋转，不再锁竖屏；iPhone 首页横向卡片收紧显示更多内容、详情页紧凑重设计、海报上下渐变适配全端。
- iOS 测试链路修复：测试 target 改为零产品依赖 + BUNDLE_LOADER，Archive 链接失败修复。

### 播放内核（Erika）

- **网络预读缓冲可调**：设置 → 播放 新增「网络预读缓冲」（默认 2 MiB / 8 / 16 / 32 MiB）。公网高延迟服务器（远程 Emby 等）建议 16 MiB 以上，可显著减少播放中的反复缓冲。基于自编译 Erika 内核新增的 `erika_presenter_open_with_options` C API（fork 分支 `feat/http-readahead-option`，已提上游），逐请求生效，本地文件自动忽略。
- 发版内核 `v0.1.7+readahead.1` 的下载哈希固化入仓（`Scripts/erika-v0.1.7+readahead.1.sha256`），构建时可复验。
- 修复拉取脚本 zip-slip 防护对绝对路径归档必然误报的问题（会让全新 CI 环境无法拉取内核）。

### 应用内更新

- 关于区显示版本号，可手动检查 GitHub Release 更新；应用启动与进入设置页时静默检查，发现新版本自动弹窗，支持「忽略此版本」。

### 新功能与优化

- **Jellyfin Clear Logo**：媒体库与详情页支持服务器提供的透明 logo 展示。
- **Bangumi**：播放结束自动标记已看时先把条目推进为「在看」；番剧候选打分算法多维度优化并与剧集季信息联动。
- 详情页海报顶部/底部渐变过渡适配全端。

### 播放器修正

- 弹幕颜色为负数时先夹紧再转换，修复内核 trap 崩溃（P0）。
- seek 不再越过片长；内核重复错误事件去重。
- 保底跳过片尾记入会话，按钮不再原地循环。
- 弹幕「时间偏移」按 overlay 数据显隐；暂停态下弹幕恢复逻辑不再被误触发。
- 音量落盘 300ms 尾去抖并在停止收口补写，消除丢失窗口；2x 临时倍速不再持久化。

### 稳定性与性能

- 播放停止后 malloc pressure relief 四拍调度（+2/+25/+60/+120s），进程占用回落更快。
- RemoteImage 复合加载键守卫修复：图片悬停闪烁（认证头字典序抖动致缓存键漂移）与全量图片不加载回归。
- 详情页横幅渐变被裁剪的回归修复（图片层定高钳制）。
- Bangumi 数据库换 DatabasePool（WAL 多连接并发）；弹幕网关响应单遍解码、mapping 内存缓存；overlay 采样 Timer 频率自适应；Erika idle 帧率档。
- 网络健壮性：429 读取 Retry-After、退避加抖动、鉴权 401 发通知引导重登、用户取消原样透传、MoviePilot 静默重登加看门狗与熔断。

### 工程与质量

- 2026-08-29 全项目 review（161 条）处置完毕：P0–P3 全部收官，覆盖并发、网络、性能、构建与 UI 细节；报告入库 `Reports/review-20260829.md`。
- 发版流水线：tag 构建必过全量测试门禁；Erika 环境准备抽为 composite action；SwiftPM 构建加缓存；`MARKETING_VERSION` 收敛 `App.xcconfig` 单源。
- release 新增 iOS 产物：`OcPlayer-<版本>-ios-unsigned.ipa` 与 `SHA256SUMS-ios.txt`。

### 随 0.1.4 附带但当时说明未展开

以下功能已包含在 0.1.4 的安装包中，当时发布说明过于简略，在此补记：

- Bangumi 全套：OAuth 登录、进度管理、个人主页、收藏列表、番剧日历、播放联动（看完整季自动推进条目状态）。
- MoviePilot 全套：设置页登录、找片下载（搜索 → 选种 → 下载）、订阅管理。
- 播放器章节列表与片头片尾/末 90 秒跳过；弹幕手动搜索选集与 HUD 弹幕菜单。

### 版本

- 版本号 0.1.5。

## [0.1.4] · 2026-08-25 · UI 规范统一与弹幕渲染路线收敛

### 弹幕

- **内核内置弹幕渲染器（Erika DFM+）被禁用**：内核的滑窗重排仍会让在屏弹幕跳轨，本版本起运行时强制走 App 层 overlay（`DanmakuRenderKit`），设置 → 播放内核 中的「用内核渲染弹幕」开关置灰并附原因说明。内核修复后恢复该开关与偏好读取（`PlaybackPreferences.danmakuUseOverlayRenderer` 保留）。

### 界面与交互

- 设计规范统一：状态色、骨架屏、文案、圆角、悬停反馈、键值行展示收敛到同一套样式。
- 高频文案收敛：`UIStrings` 集中常量替代裸字面量。

## [0.1.3] · 2026-08-20 · 弹幕完整链路与播放体验打磨

### 弹幕

- 串起 OcPlay 网关到 Erika 的完整播放链路：已有剧集映射直接复用；首次匹配先用本地文件或带认证头的远程 HTTP Range 数据计算前 16 MiB MD5，再以文件名、哈希、大小和时长一次性匹配；结果与弹幕正文分层缓存，并保留分集时间偏移。
- 播放器 HUD 新增弹幕开关、自动重匹配、手动搜索选集、时间偏移、不透明度、显示区域和顶部 / 底部 / 滚动类型过滤；换片、重试和退出会取消旧任务，并用播放源代次阻止旧弹幕注入新视频。
- 设置页支持编辑 HTTPS 网关地址、以安全输入框保存 API Key 和控制自动加载。未自定义时使用默认网关和内置公共 API Key；显式无效地址才会停用弹幕且不影响视频播放。
- DanmakuKit 增加远程 Range 哈希、匹配编排、缓存格式迁移、请求参数校验和异常弹幕过滤的离线测试。
- 弹幕诊断日志补充安全文件名、大小、时长、匹配模式、哈希是否存在、手动搜索词、Episode ID 和正文数量；不记录完整哈希、媒体 URL、认证头或 API Key。

### 稳定性

- 保护 Erika counted-array 轨道读取：限制填充数量不超过缓冲区容量，并在成功、失败路径释放已填充记录。
- 修复媒体库切换时旧异步请求回写新库状态的竞态；旧请求不能覆盖新数据或提前清除 loading 状态。
- 保证弹幕 fallback ID 避开整批真实 `cid`，并严格校验远程 `206 Content-Range` 的完整性，拒绝截断响应。
- 为 `ServerStore` 的 profile/current ID 复合读改写操作增加统一锁，并补充并发保存回归测试。
- 为字幕副本、播放截图和诊断日志增加启动/每日维护与容量上限；日志同时增加 30 天保留、超大单条保护和旧文件尺寸校验。
- 图片缓存保持 512 MiB 硬上限，设置页新增当前用量和手动清空入口。
- `PlayerScreen`、`DetailView` 拆出独立组件；Jellyfin 客户端版本改为读取 App version/build，弹幕 User-Agent 保持纯 marketing version。
- 从 `AppModel` 抽离 `PlaybackReportingCoordinator`，独立负责 Start / 10 秒心跳 / Stopped 的顺序化与去重；新增 macOS App 测试 target，覆盖后台快照、自然结束与显式退出竞态、重复停止、跨片等待和播放请求身份隔离。
- 明确 Jellyfin 不提供收藏时间；收藏轮播按收藏过滤后使用媒体入库时间倒序，不再描述为“最近收藏”。

### 播放器界面与交互

- 即时播放加载态：loading 覆盖到内核出帧，消除两段式等待；保底 400ms，加载过快不再闪现晃眼；消除出画面白闪。
- 单击播放区切换 HUD，暂停改用空格 / HUD 按钮；点击关闭 HUD 后滑动不再重新打开。
- 加载态隐藏工具栏、取消按钮玻璃化，根治连点取消重来。
- 窗口比例贴合、关闭播放器时窗口先缩再退出、还原同样带弹性动画，不脱节。
- 弹幕开关加 opacity 过渡，弹幕按钮换用 text.alignleft 图标与字幕区分。

### 首页与详情页

- 移除首页轮播图功能。
- 详情页选集改为横向滚动列表，两侧加悬浮箭头（一次滚动 4 集），主按钮按选中集播放；箭头悬停显示。
- 详情页播放旁新增「已看过」按钮，与播放按钮同高胶囊、纯图标样式；继续观看卡角标悬停显示并增加边距。
- 卡片悬停抬升动画更顺滑；首页与横向列表滚动更顺滑；媒体库分页读取与播放体验修正。

### 构建与内核

- Erika 拉取脚本默认解析 GitHub 最新正式版；CI 先解析具体 tag 再建立缓存键，本地构建和打包也会每次检查最新版本并复用同版本完整产物。
- 当前 `v0.1.7` macOS/iOS release 资产已固定 SHA-256；未来未固定的新版本会明确提示校验边界。
- 播放日志统一迁移到 `diagnostics.jsonl`，使用异步串行写入、2 MB 轮转和 3 份保留。
- 设置 → 关于新增独立的开源许可证入口，按依赖图展示 Erika、Jellyfin SDK、SwiftPM 与内核原生组件；发布脚本同步聚合这些组件的许可证文本，缺失时终止打包。

## [0.1.1] · 2026-08-18 · 完善首页海报与播放器界面

### 应用图标与版本

- 新增共享 `AppIcon` 资源集：iOS 使用浅色默认图标和深色外观图标，macOS 使用深色图标并提供 16–1024 px 的完整尺寸。
- macOS / iOS 的 Debug 与 Release 配置均显式使用 `AppIcon`，后续 Xcode 构建会自动编译并写入 App 包。
- 工程版本与 Jellyfin 客户端版本统一更新为 0.1.1；本地打包脚本和 GitHub Release 工作流的默认标签同步为 `v0.1.1`。

### 首页海报与布局

- 轮播横幅宽度改由外层视口真实宽度约束，修复侧栏开合时横向内容宽度泄漏、横幅超出详情列的问题。
- 轮播页码标识从数组下标改为媒体 ID：数据刷新后页码身份保持稳定；冷启动时明确按页首对齐，不再把第一页停在两个页面之间。
- 窗口缩放（live resize）时等布局稳定后无动画重锚当前页，避免用旧页面位置对齐新视口造成错位。
- 修复长标题横幅在窄窗口下左右各被裁掉约 52pt 的问题（边距与约束顺序调整）。
- macOS 窗口最小尺寸设为 960×620，保证英雄区标题边距和操作按钮可读。

### 播放器界面

- 重构播放器 HUD 与本地配置（音量 / 进度 / 倍速等控件布局统一）。
- 新增 P2 HUD 并接入 Liquid Glass 风格。
- 修复音量拖动：拖动过程即时生效，松手不再回弹。

### 播放核心

- 播放地址解析任务支持取消：快速连续切换播放内容时，旧请求不会在新请求之后返回并覆盖播放器；退出、换片、注销时都会取消未完成的解析。
- 系列 / 剧集类条目播放前先解析为具体可播放的剧集（优先「接下来看」，否则取首个未看完的常规剧集），不再把 Series ID 直接送进流地址；续播位置随解析结果联动。

### 验证

- `swift test --package-path Packages/JellyfinKit`：32/32 通过；`swift test --package-path Packages/ErikaKit`：13/13 通过。
- macOS Debug / Release App 构建通过；Release 产物已确认包含 `AppIcon.icns` 与完整 `Assets.car`，App 的 `CFBundleIconName` / `CFBundleIconFile` 均为 `AppIcon`，ad-hoc 签名校验通过。
- iOS target 已解析 `AppIcon` 与浅色 / 深色槽位并进入资源编译阶段；当前机器未安装 iOS Simulator runtime，完整 iOS 构建仍受本机环境限制。

## [0.1.0] · 2026-08-17

### 首页

- 新增轮播：多张英雄图自动切换；设置页新增「轮播使用收藏」开关，可在「最近添加 / 我的收藏」间切换数据来源。
- 修复收藏轮播为空时区域消失的问题：收藏请求失败或收藏全无背景图时按「最近添加」回落，不再整页报错或留空。
- 修复从首页轮播进入详情页时页面背景透明的问题；详情页现在显式使用系统页面底色。

### 修复

- 修复 `JellyfinError.wrap` 错误归类失效：先 `as NSError` 会把 `APIError`（enum）桥接掉，`as? APIError` 永远失败，401/404 全部漏进「其它错误」；改为先判 `APIError` / `JellyfinError`，最后才桥接 `NSError`。
- 图片加载改为「内存解码缓存 + 请求去重」：同一张图并发出现只发一次网络请求（列表快速滚动不重复拉）；任务取消（视图消失 / 换 URL）不再被当成加载失败，换 URL 时旧请求自动作废。
- 保存服务器列表编码失败不再静默吞掉：原来 `set(nil)` 会直接把服务器列表 key 删掉（等于清空已登录服务器），现在失败只记日志、保留旧数据。
- 修复退出播放后立刻再播放时，异步窗口还原可能把新播放窗口误拉回旧帧的问题（还原前校验窗口身份与播放会话）。
- 设置页「关于」的描述同步当前状态：直连策略改为「优先直连直解（DirectPlay），播放前经 PlaybackInfo 选择媒体源；不支持直连的源回退直连流（DirectStream）」（原文案的「码率超限时请求转码」尚未实现）；弹幕改为「暂缓接入」（M3 已暂缓）。
- 修复详情页演员名字 / 角色不显示：演员头像宽高都固定为 108×108（只给宽度时 RemoteImage 占位竖向撑开、文字被挤出可视区），详情请求显式携带 `fields=People,Genres,Overview`（部分服务器版本默认不返回扩展字段）。
- 修复“播放 → 退出播放 → 再次播放”后所有视频都打不开的问题；退出播放时不再把旧源标记为待换片，并直接重建播放引擎，避免旧 presenter 进入不可 reopen 的 closed 状态。
- 修复播放中换片 / 自动连播失败的问题（详情页点另一集、播完自动连播下一集、`onOpenURL` 换片）：换片不再对内核 `close()` 后 `open()`（`close()` 是终态，同一 presenter 不可 reopen，实测抛 `ErikaError "player is closed"`），改为 `stop()` 后丢弃旧引擎重建；播放画面承载视图跟随引擎身份重建（`.id(engine)`），否则新引擎不挂画面、状态事件收不到，换片后 UI 卡在 idle。
- 修复首次连接因网络异常失败后，点击首页重试虽然恢复内容但侧边栏媒体库仍为空的问题；重试和下拉刷新现在会同时重新加载媒体库与首页数据。

### 播放核心

- 接入 `PlaybackInfo` + `DeviceProfile`：播放前先请求服务器媒体源信息，优先选择支持直接播放的 `MediaSource`，并在直连 URL 中带上 `mediaSourceId`；老服务器或 PlaybackInfo 不可用时自动回退到原来的直连 URL。

### 调试

- 增加播放链路文件日志：`~/Library/Logs/OcPlayer/playback.log`，记录引擎创建、open/close/stop/attach/detach、播放状态变化和错误，方便复现“退出后再播放失败”时定位。
- 修复电视剧详情页中系列海报、标题、元数据和播放按钮被 320 pt 横幅裁切的问题。
- 修复分集列表中图片高度随加载状态变化，以及图片和标题在刷新/换季后错位的问题。
- 修复注销后旧会话的首页、媒体库、进度上报、下一集和外挂字幕请求回写新会话的问题。
- 详情页将必要的详情/季/集数据与类似推荐解耦；切季时清空旧集列表并显示加载失败、空列表状态，剧集没有真实集数据时不再播放剧集容器。
- 修复本地视频和手动字幕在 iOS 文件选择器回调结束后失去访问权限的问题；字幕会复制到应用支持目录，视频权限保持到播放结束。
- 修复播放源替换失败后残留当前 URI、音量 0 被当成未保存、字幕字号不持久化等播放状态问题。
- Jellyfin 媒体库浏览改为按 `startIndex` 分页读取全部条目；全剧集请求按季号和集号排序，避免跨季连播顺序错误。
- 自动连播跳过第 0 季（特典/花絮），看完特典不自动跳下一集。
- 首页加载不再因会话切换残留 loading 态；登录后不等首屏数据返回，Quick Connect 轮询流即时结束。
- 网络错误细分：连不上（DNS / 拒绝连接 / 断网）仍提示检查地址，超时 / 连接中断带具体传输错误细节。
- 图片加载失败后，视图再次出现时会重试（之前一次失败永久 404 到退出）。
- 为 iOS 生成的 Info.plist 增加局域网访问说明和 ATS 局域网配置；移除 SwiftPM 锁文件忽略规则，锁定依赖版本。

### Jellyfin 图片数据

- 分集请求显式获取 `Primary` / `Thumb` 图片并按集数排序。
- 分集不再把父剧集的海报 tag 当作自己的图片；`RemoteImage` 在 URL 变化时会清理旧图片状态。

### 验证

- `swift test --package-path Packages/JellyfinKit`
- `swift test --package-path Packages/ErikaKit`
- JellyfinKit 31/31、ErikaKit 13/13 通过（新增「播放生命周期」回归 suite：同源/不同源 `stop` 后重开、`close` 终态锁定、连播换片重建）；macOS Debug App 构建通过。
- macOS Debug App 真实环境人工验证：自动连播下一集（播完 S1E7 → 自动切 S1E8）成功——换片后新引擎重新 attach、状态正常推进到 playing（日志 `playback.log` 实证）；从详情页点另一集与 `onOpenURL` 换片走同一条 `openIfNeeded → open` 路径。
- iOS 模拟器构建因当前机器未安装 iOS Simulator runtime 无法选择 destination；工程配置已写入双端 target。
- macOS Debug App 真实详情页人工验证：系列海报完整显示，分集缩略图与集标题逐行对应。

本轮构建目录均位于 `.local-build/`，不进入版本控制。
