#!/usr/bin/env bash
set -euo pipefail
ROOT="/Users/jumusu/Documents/project/OcPlayer"
PREP="$ROOT/.local-build/release-preparation-20261106"
mkdir -p "$PREP/tools"
cat > "$PREP/tools/xcodebuild" <<'EOF'
#!/usr/bin/env bash
exec /usr/bin/xcodebuild "$@" -disableAutomaticPackageResolution -onlyUsePackageVersionsFromResolvedFile
EOF
chmod +x "$PREP/tools/xcodebuild"
export PATH="$PREP/tools:$PATH"
export SKIP_ERIKA_FETCH=1
cd "$ROOT"
for platform in macos ios; do
    export BUILD_ROOT="$PREP/$platform"
    export DIST_DIR="$ROOT/dist/release-preparation-20261106/$platform"
    set +e
    "Scripts/package-$platform.sh" > "$PREP/evidence/package-$platform.log" 2>&1
    result=$?
    set -e
    printf '%s\n' "$result" > "$PREP/evidence/package-$platform.exit"
    tail -12 "$PREP/evidence/package-$platform.log"
    [[ "$result" == 0 ]] || exit "$result"
done
