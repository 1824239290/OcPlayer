import hashlib
import json
import plistlib
import re
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path('/Users/jumusu/Documents/project/OcPlayer')
PREP = ROOT / '.local-build/release-preparation-20261106'
EVIDENCE = PREP / 'evidence'
DIST = ROOT / 'dist/release-preparation-20261106'
COMMIT = (EVIDENCE / 'source-commit.txt').read_text().strip()

def run(args, log):
    proc = subprocess.run(args, capture_output=True, text=True)
    (EVIDENCE / log).write_text(proc.stdout + proc.stderr)
    if proc.returncode:
        raise RuntimeError(f'{args[0]} failed ({proc.returncode}); see {log}')
    return proc.stdout

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

results = {}
for platform in ['macos', 'ios']:
    directory = DIST / platform
    checksum_file = directory / ('SHA256SUMS.txt' if platform == 'macos' else 'SHA256SUMS-ios.txt')
    hashes = {}
    for line in checksum_file.read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        name = name.lstrip('*')
        actual = sha(directory / name)
        assert actual == expected, f'checksum mismatch: {name}'
        hashes[name] = actual
    archive = next(p for p in directory.iterdir() if p.suffix == ('.zip' if platform == 'macos' else '.ipa') and '.dSYM.' not in p.name)
    symbols = next(directory.glob('*.dSYM.zip'))
    prefix = 'OcPlayer.app/Contents/' if platform == 'macos' else 'Payload/OcPlayer.app/'
    with zipfile.ZipFile(archive) as z, zipfile.ZipFile(symbols) as s:
        assert z.testzip() is None and s.testzip() is None
        plist = plistlib.loads(z.read(prefix + 'Info.plist'))
        assert plist['CFBundleShortVersionString'] == '0.2.3'
        assert plist['GitCommit'] == COMMIT[:7]
        binary_name = prefix + ('MacOS/' if platform == 'macos' else '') + plist['CFBundleExecutable']
        notice_prefix = prefix + ('Resources/' if platform == 'macos' else '') + 'THIRD_PARTY_LICENSES/'
        notices = [n for n in z.namelist() if n.startswith(notice_prefix) and not n.endswith('/')]
        manifest = z.read(notice_prefix + 'erika/MANIFEST.txt').decode()
        assert re.search(r'^ref:\s*v0\.3\.4\s*$', manifest, re.M), manifest
        licence_hash = hashlib.sha256(z.read(notice_prefix + 'erika/LICENSE')).hexdigest()
        assert licence_hash == '3f3d9e0024b1921b067d6f7f88deb4a60cbe7a78e76c64e3f1d7fc3b779b9d04'
        assert z.read(notice_prefix + 'swiftpm/Package.resolved') == (EVIDENCE / 'Package.resolved').read_bytes()
        assert len(notices) == 29, notices
        symbol_name = next(n for n in s.namelist() if '/Contents/Resources/DWARF/' in n and not n.endswith('/') and not n.startswith('__MACOSX/'))
        with tempfile.TemporaryDirectory(prefix='ocplayer-artifact-') as tmp:
            executable = Path(tmp) / 'OcPlayer'
            dwarf = Path(tmp) / 'OcPlayer.dwarf'
            executable.write_bytes(z.read(binary_name))
            dwarf.write_bytes(s.read(symbol_name))
            uuid = re.findall(r'UUID: ([0-9A-F-]+) \(([^)]+)\)', run(['xcrun', 'dwarfdump', '--uuid', str(executable)], f'{platform}-executable-uuid.log'))
            dsym_uuid = re.findall(r'UUID: ([0-9A-F-]+) \(([^)]+)\)', run(['xcrun', 'dwarfdump', '--uuid', str(dwarf)], f'{platform}-dsym-uuid.log'))
            assert uuid and uuid == dsym_uuid
            assert [arch for _, arch in uuid] == ['arm64']
        results[platform] = {
            'version': plist['CFBundleShortVersionString'], 'build': plist['CFBundleVersion'],
            'commit': plist['GitCommit'], 'kernel': 'v0.3.4', 'crcPassed': True,
            'licenseFiles': len(notices), 'licenseHash': licence_hash,
            'dependencyLockMatches': True, 'uuid': uuid, 'uuidMatches': True,
            'sha256': hashes,
        }

dmg = next((DIST / 'macos').glob('*.dmg'))
run(['hdiutil', 'verify', str(dmg)], 'dmg-verify.log')
mount = PREP / 'dmg-mount'
mount.mkdir(exist_ok=True)
run(['hdiutil', 'attach', '-readonly', '-nobrowse', '-mountpoint', str(mount), str(dmg)], 'dmg-attach.log')
try:
    app = mount / 'OcPlayer.app'
    assert app.is_dir()
    assert (mount / 'Applications').is_symlink()
    assert (mount / 'Applications').readlink() == Path('/Applications')
    run(['codesign', '--verify', '--deep', '--strict', '--verbose=2', str(app)], 'dmg-codesign.log')
    results['macos']['dmgVerified'] = True
    results['macos']['mountedSignatureVerified'] = True
finally:
    run(['hdiutil', 'detach', str(mount)], 'dmg-detach.log')

assert (ROOT / 'OcPlayer.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved').read_bytes() == (EVIDENCE / 'Package.resolved').read_bytes()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == COMMIT
(EVIDENCE / 'artifact-verification.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({k: {key: value for key, value in v.items() if key != 'sha256'} for k, v in results.items()}, indent=2))
