from pathlib import Path
import hashlib,zipfile,plistlib,tempfile,subprocess,json
root=Path('Docs/reviews/2026-11-06-image-isolation')
assets=Path('/tmp/ocplayer-image-isolation-artifacts')
result={}
licenseSHA='3f3d9e0024b1921b067d6f7f88deb4a60cbe7a78e76c64e3f1d7fc3b779b9d04'
for platform in ('macos','ios'):
    d=assets/platform
    check={}
    for line in next(d.glob('SHA256SUMS*.txt')).read_text().splitlines():
        expected,name=line.split(maxsplit=1)
        p=d/name.lstrip('*')
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
        assert h.hexdigest()==expected,p.name
        check[p.name]=expected
    archive=next(d.glob('*.ipa')) if platform=='ios' else next(p for p in d.glob('*.zip') if '.dSYM.' not in p.name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        prefix='Payload/OcPlayer.app/' if platform=='ios' else 'OcPlayer.app/'
        infoPath=prefix+('Info.plist' if platform=='ios' else 'Contents/Info.plist')
        info=plistlib.loads(z.read(infoPath))
        assert info['CFBundleShortVersionString']=='0.2.3'
        licenses=[n for n in z.namelist() if n.startswith(prefix) and '/THIRD_PARTY_LICENSES/' in n and not n.endswith('/')]
        assert len(licenses)==29,len(licenses)
        erika=next(n for n in licenses if n.endswith('/erika/LICENSE'))
        assert hashlib.sha256(z.read(erika)).hexdigest()==licenseSHA
        executable=prefix+('OcPlayer' if platform=='ios' else 'Contents/MacOS/OcPlayer')
        with tempfile.TemporaryDirectory(prefix='ocplayer-image-uuid-') as tmp:
            exe=Path(tmp)/'OcPlayer';exe.write_bytes(z.read(executable))
            exeUUID=subprocess.check_output(['xcrun','dwarfdump','--uuid',str(exe)],text=True)
            with zipfile.ZipFile(next(d.glob('*.dSYM.zip'))) as ds:
                assert ds.testzip() is None
                dwarf=next(n for n in ds.namelist() if n.endswith('/DWARF/OcPlayer') and not n.startswith('__MACOSX/'))
                sym=Path(tmp)/'OcPlayer.dwarf';sym.write_bytes(ds.read(dwarf))
                symUUID=subprocess.check_output(['xcrun','dwarfdump','--uuid',str(sym)],text=True)
            assert exeUUID.split()[1:3]==symUUID.split()[1:3]
    result[platform]={'version':info['CFBundleShortVersionString'],'build':info['CFBundleVersion'],'GitCommit':info['GitCommit'],'archiveCRC':True,'licenseFiles':len(licenses),'erikaLicenseSHA256':licenseSHA,'executableUUID':exeUUID,'dsymUUID':symUUID,'uuidMatches':True,'sha256':check}
(root/'artifact-verification.json').write_text(json.dumps(result,indent=2))
(root/'ipa-verification.json').write_text(json.dumps(result['ios'],indent=2))
print({k:{x:v[x] for x in ('version','build','GitCommit','licenseFiles','uuidMatches')} for k,v in result.items()})
dmg=next((assets/'macos').glob('*.dmg'))
with (root/'dmg-verify.log').open('w') as log:
    subprocess.run(['hdiutil','verify',str(dmg)],stdout=log,stderr=subprocess.STDOUT,check=True)
with tempfile.TemporaryDirectory(prefix='ocplayer-image-dmg-') as tmp:
    mount=Path(tmp)/'mount';mount.mkdir()
    with (root/'dmg-mount.log').open('w') as log:
        subprocess.run(['hdiutil','attach','-readonly','-nobrowse','-mountpoint',str(mount),str(dmg)],stdout=log,stderr=subprocess.STDOUT,check=True)
    try:
        app=mount/'OcPlayer.app';assert app.is_dir();assert (mount/'Applications').is_symlink()
        with (root/'dmg-signature.log').open('w') as log:
            subprocess.run(['codesign','--verify','--deep','--strict','--verbose=2',str(app)],stdout=log,stderr=subprocess.STDOUT,check=True)
        info=plistlib.loads((app/'Contents/Info.plist').read_bytes());assert info['CFBundleShortVersionString']=='0.2.3'
    finally:
        with (root/'dmg-unmount.log').open('w') as log:
            subprocess.run(['hdiutil','detach',str(mount)],stdout=log,stderr=subprocess.STDOUT,check=True)
(root/'dmg-verification.json').write_text(json.dumps({'verified':True,'mountedReadOnly':True,'appAndApplicationsLinkPresent':True,'signatureVerified':True,'unmounted':True},indent=2))
print('DMG integrity, mount and signature passed')
